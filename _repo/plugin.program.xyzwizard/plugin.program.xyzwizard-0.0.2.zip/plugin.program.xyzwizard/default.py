# -*- coding: utf-8 -*-
#from __future__ import unicode_literals
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import os, sys
import glob
import shutil
import urllib2,urllib
import re
import zipfile
import uservar
import fnmatch
import time
import subprocess 
try:   from sqlite3   import dbapi2 as database
except:from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta
from urlparse import urljoin
from resources.lib import extract, downloader, notify, debridit, traktit, loginit, skinSwitch, uploadLog, yt, wizard as wiz
#from libs import kodi# plugin.git.browser
ADDON_ID             = uservar.ADDON_ID
ADDON                = wiz.addonId(ADDON_ID)
if  ADDON:
    ADDONTITLE       = uservar.ADDONTITLE
    VERSION          = wiz.addonInfo(ADDON_ID,'version')
    ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
    xbmc.log(msg='##['+ADDON_ID+'] Start %s  %s  %s' % (ADDONTITLE,VERSION,ADDONPATH), level=xbmc.LOGNOTICE)
    DIALOG           = xbmcgui.Dialog()
    DP               = xbmcgui.DialogProgress()
    HOME             = xbmc.translatePath('special://home/')
    LOG              = xbmc.translatePath('special://logpath/')
    PROFILE          = xbmc.translatePath('special://profile/')
    ADDONS           = os.path.join(HOME,      'addons')
    USERDATA         = os.path.join(HOME,      'userdata')
    PLUGIN           = os.path.join(ADDONS,     ADDON_ID)
    PACKAGES         = os.path.join(ADDONS,    'packages')
    ADDOND           = os.path.join(USERDATA,  'addon_data')
    ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
    ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
    PLAYERCORE       = os.path.join(USERDATA,  'playercorefactory.xml')
    RSSFILE          = os.path.join(USERDATA,  'RssFeeds.xml')
    SOURCES          = os.path.join(USERDATA,  'sources.xml')
    FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
    PROFILES         = os.path.join(USERDATA,  'profiles.xml')
    GUISETTINGS      = os.path.join(USERDATA,  'guisettings.xml')
    THUMBS           = os.path.join(USERDATA,  'Thumbnails')
    DATABASE         = os.path.join(USERDATA,  'Database')
    ART              = os.path.join(ADDONPATH, 'resources', 'media')
    FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
    #ICON             = os.path.join(ADDONPATH, 'icon.png')
    ICON             = os.path.join(ART,       'loading.gif')
    WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
    LOGFILES         = wiz.LOGFILES
    SKIN             = xbmc.getSkinDir()
    DEFAULTPLUGINS   = uservar.DEFAULTPLUGINS
    FONTBIG          = uservar.FONTBIG
    FONT             = uservar.FONT
    FONTSMALL        = uservar.FONTSMALL
    MODURL           = uservar.MODURL
    MODURL2          = uservar.MODURL2
    INSTALLMETHODS   = ['Always Ask', 'Reload Profile', 'Force Close']
    SEPERATE         = wiz.getS('seperate')
    #ISFIRSTRUN       = wiz.getS('firstrun')
    BACKUPLOCATION   = uservar.BACKUPLOCATION
    MYBUILDS         = uservar.MYBUILDS
    EXCLUDES         = uservar.EXCLUDES
    # builds
    BUILDNAME        = wiz.getS('buildname')
    DEFAULTSKIN      = wiz.getS('defaultskin')
    DEFAULTNAME      = wiz.getS('defaultskinname')
    DEFAULTIGNORE    = wiz.getS('defaultskinignore')
    BUILDVERSION     = wiz.getS('buildversion')
    BUILDTHEME       = wiz.getS('buildtheme')
    BUILDLATEST      = wiz.getS('latestversion')
    INSTALLMETHOD    = wiz.getS('installmethod')
    SHOW15           = wiz.getS('show15')
    SHOW16           = wiz.getS('show16')
    SHOW17           = wiz.getS('show17')
    SHOW18           = wiz.getS('show18')
    SHOWADULT        = wiz.getS('adult')
    # maint
    DEVELOPER        = wiz.getS('developer')#
    SHOWMAINT        = wiz.getS('showmaint')
    AUTOCLEANUP      = wiz.getS('autoclean')
    AUTOCACHE        = wiz.getS('clearcache')
    AUTOPACKAGES     = wiz.getS('clearpackages')
    AUTOTHUMBS       = wiz.getS('clearthumbs')
    AUTOFEQ          = wiz.getS('autocleanfeq')
    AUTONEXTRUN      = wiz.getS('nextautocleanup')
    AUTOFEQ          = int(float(AUTOFEQ)) if AUTOFEQ.isdigit() else 0
    TODAY            = date.today()
    TOMORROW         = TODAY + timedelta(days=1)
    THREEDAYS        = TODAY + timedelta(days=3)
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    MCNAME           = wiz.mediaCenter()
    # notify messages welcom
    NOTIFY           = wiz.getS('notify')
    NOTEID           = wiz.getS('noteid')
    NOTEDISMISS      = wiz.getS('notedismiss')
    # logins trakt dabrid
    TRAKTID          = traktit.TRAKTID
    DEBRIDID         = debridit.DEBRIDID
    LOGINID          = loginit.LOGINID
    # logins
    INCLUDEVIDEO     = wiz.getS('includevideo')
    INCLUDEALL       = wiz.getS('includeall')
    INCLUDE1CHANNEL  = wiz.getS('include1channel')
    INCLUDEALLUC     = wiz.getS('includealluc')
    INCLUDEBENNU     = wiz.getS('includebennu')
    INCLUDEBOBUNLEASHED=wiz.getS('includebobunleashed')
    INCLUDEBUBBLES   = wiz.getS('includebubbles')
    INCLUDECOVENANT  = wiz.getS('includecovenant')
    INCLUDEELYSIUM   = wiz.getS('includeelysium')
    INCLUDEXODUS     = wiz.getS('includeexodus')
    INCLUDEGURZIL    = wiz.getS('includegurzil')
    INCLUDEICEFILMS  = wiz.getS('includeicefilms')
    INCLUDESPECTO    = wiz.getS('includespecto')
    INCLUDETINKLEPAD = wiz.getS('includetinklepad')
    INCLUDEUGOTTOC   = wiz.getS('includeugottoc')
    INCLUDEXXXODUS   = wiz.getS('includexxxodus')
    INCLUDESALTS     = wiz.getS('includesalts')
    INCLUDEALLUC     = wiz.getS('includealluc')
    INCLUDEONECHANNEL= wiz.getS('includeonechannel')
    INCLUDEUGOOTTOOC = wiz.getS('includeugottoc')
    TRAKTSAVE        = wiz.getS('traktlastsave')
    REALSAVE         = wiz.getS('debridlastsave')
    LOGINSAVE        = wiz.getS('loginlastsave')
    KEEPFAVS         = wiz.getS('keepfavourites')
    KEEPSOURCES      = wiz.getS('keepsources')
    KEEPPROFILES     = wiz.getS('keepprofiles')
    KEEPADVANCED     = wiz.getS('keepadvanced')
    KEEPREPOS        = wiz.getS('keeprepos')
    KEEPSUPER        = wiz.getS('keepsuper')
    KEEPWHITELIST    = wiz.getS('keepwhitelist')
    KEEPTRAKT        = wiz.getS('keeptrakt')
    KEEPREAL         = wiz.getS('keepdebrid')
    KEEPLOGIN        = wiz.getS('keeplogin')
    LOGINSAVE        = wiz.getS('loginlastsave')
    # check for updates
    UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
    NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
    ENABLE           = uservar.ENABLE
    HEADERMESSAGE    = uservar.HEADERMESSAGE
    AUTOUPDATE       = uservar.AUTOUPDATE
    HIDECONTACT      = uservar.HIDECONTACT
    CONTACT          = uservar.CONTACT
    CONTACTICON      = uservar.CONTACTICON if not uservar.CONTACTICON == 'http://' else ICON 
    CONTACTFANART    = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
    #THEMEFILE        = uservar.THEMEFILE # not used
    # colors
    HIDESPACERS      = uservar.HIDESPACERS
    COLOR1           = uservar.COLOR1
    COLOR2           = uservar.COLOR2
    COLOR3           = uservar.COLOR3
    COLOR4           = uservar.COLOR4
    COLOR5           = uservar.COLOR5
    COLOR6           = uservar.COLOR6
    COLOR7           = uservar.COLOR7
    COLOR8           = uservar.COLOR8
    # wizard themes
    THEME1           = uservar.THEME1
    THEME2           = uservar.THEME2
    THEME3           = uservar.THEME3
    THEME4           = uservar.THEME4
    THEME5           = uservar.THEME5
    THEME6           = uservar.THEME6
    THEME7           = uservar.THEME7
    THEME8           = uservar.THEME8
    THEME9           = uservar.THEME9
    THEME10          = uservar.THEME10
    # icons
    ICONBUILDS       = uservar.ICONBUILDS     if not uservar.ICONBUILDS     == 'http://' else ICON
    ICONMAINT        = uservar.ICONMAINT      if not uservar.ICONMAINT      == 'http://' else ICON
    ICONAPKS         = uservar.ICONAPKS       if not uservar.ICONAPKS       == 'http://' else ICON
    ICONADDONS       = uservar.ICONADDONS     if not uservar.ICONADDONS     == 'http://' else ICON
    ICONYOUTUBE      = uservar.ICONYOUTUBE    if not uservar.ICONYOUTUBE    == 'http://' else ICON
    ICONSAVE         = uservar.ICONSAVE       if not uservar.ICONSAVE       == 'http://' else ICON
    ICONTRAKT        = uservar.ICONTRAKT      if not uservar.ICONTRAKT      == 'http://' else ICON
    ICONREAL         = uservar.ICONREAL       if not uservar.ICONREAL       == 'http://' else ICON
    ICONLOGIN        = uservar.ICONLOGIN      if not uservar.ICONLOGIN      == 'http://' else ICON
    ICONCONTACT      = uservar.ICONCONTACT    if not uservar.ICONCONTACT    == 'http://' else ICON
    ICONSETTINGS     = uservar.ICONSETTINGS   if not uservar.ICONSETTINGS   == 'http://' else ICON
    ICONRESTORE      = uservar.ICONRESTORE    if not uservar.ICONRESTORE    == 'http://' else ICON
    ICONRESTOREALL   = uservar.ICONRESTOREALL if not uservar.ICONRESTOREALL == 'http://' else ICON
    ICONBACKUP       = uservar.ICONBACKUP     if not uservar.ICONBACKUP     == 'http://' else ICON
    ICONDELETE       = uservar.ICONDELETE     if not uservar.ICONDELETE     == 'http://' else ICON
    ICONEMAIL        = uservar.ICONEMAIL      if not uservar.ICONEMAIL      == 'http://' else ICON
    ICONFORCECLOSE   = uservar.ICONFORCECLOSE if not uservar.ICONFORCECLOSE == 'http://' else ICON
    ICONFRESHSTART   = uservar.ICONFRESHSTART if not uservar.ICONFRESHSTART == 'http://' else ICON
    ICONLOG          = uservar.ICONLOG        if not uservar.ICONLOG        == 'http://' else ICON
    ICONXML          = uservar.ICONXML        if not uservar.ICONXML        == 'http://' else ICON
    ICONSPMC         = uservar.ICONSPMC       if not uservar.ICONSPMC       == 'http://' else ICON
    ICONCLEAN        = uservar.ICONCLEAN      if not uservar.ICONCLEAN      == 'http://' else ICON
    ICONCLEANALL     = uservar.ICONCLEANALL   if not uservar.ICONCLEANALL   == 'http://' else ICON
    ICONFIX          = uservar.ICONFIX        if not uservar.ICONFIX        == 'http://' else ICON
    ICONSKIN         = uservar.ICONSKIN       if not uservar.ICONSKIN       == 'http://' else ICON
    ICONTWEAKS       = uservar.ICONTWEAKS     if not uservar.ICONTWEAKS     == 'http://' else ICON
    ICONSPACER       = uservar.ICONSPACER     if not uservar.ICONSPACER     == 'http://' else ICON
    ICONINFO         = uservar.ICONINFO       if not uservar.ICONINFO       == 'http://' else ICON
    ICONGITHUB       = uservar.ICONGITHUB     if not uservar.ICONGITHUB     == 'http://' else ICON
    ICONURL          = uservar.ICONURL        if not uservar.ICONURL        == 'http://' else ICON
    ICONVIMEO        = uservar.ICONVIMEO      if not uservar.ICONVIMEO      == 'http://' else ICON
    ICONCHROME       = uservar.ICONCHROME     if not uservar.ICONCHROME     == 'http://' else ICON
    ICONM3U          = uservar.ICONM3U        if not uservar.ICONM3U        == 'http://' else ICON
    ICONLINUX        = uservar.ICONLINUX      if not uservar.ICONLINUX      == 'http://' else ICON
    ICONOSX          = uservar.ICONOSX        if not uservar.ICONOSX        == 'http://' else ICON
    ICONWIN          = uservar.ICONWIN        if not uservar.ICONWIN        == 'http://' else ICON
    #ICONSEARCH       = uservar.ICONSEARCH     if not uservar.ICONSEARCH     == 'http://' else ICON
    #ICONFTMC         = uservar.ICONFTMC       if not uservar.ICONFTMC       == 'http://' else ICON
    #ICONFILE         = uservar.ICONFILE       if not uservar.ICONFILE       == 'http://' else ICON
    #ICONZIP          = uservar.ICONZIP        if not uservar.ICONZIP        == 'http://' else ICON
    #ICONTVGFS        = uservar.ICONTVGFS      if not uservar.ICONTVGFS      == 'http://' else ICON
    #ICONINI          = uservar.ICONINI        if not uservar.ICONINI        == 'http://' else ICON
    ICONREPO          = uservar.ICONREPO       if not uservar.ICONREPO       == 'http://' else ICON
    ######################
    # sys info for descriptions
    import platform
    pythonver        = platform.python_version()
    # platform version ie windows or android
    osinfo           = platform.system()+' '+platform.release()
    xbmc_version     = uservar.xbmc_version
    kodi_version     = uservar.kodi_version
    dns1             = xbmc.getInfoLabel('Network.DNS1Address')
    gateway          = xbmc.getInfoLabel('Network.GatewayAddress')
    IPAddress        = xbmc.getInfoLabel('Network.IPAddress')
    CpuUsage         = xbmc.getInfoLabel('System.CpuUsage')
    totalmem         = xbmc.getInfoLabel('System.Memory(total)')
    freemem          = xbmc.getInfoLabel('System.FreeMemory')
    screenres        = xbmc.getInfoLabel('system.screenresolution')
    descriptioninfo  = '[COLOR grey]Ver:[/COLOR] '+xbmc_version+ '\n[COLOR grey]OS:[/COLOR] '+osinfo+ '\n[COLOR grey]Cpu:[/COLOR] '+CpuUsage+ ' [COLOR grey]Mem:[/COLOR] '+freemem+ ' \ '+totalmem+ '\n[COLOR grey]IP:[/COLOR] '+IPAddress+ '   '+screenres+'\n[COLOR grey]py [B]'+pythonver+'[/B]  ( 2.7.9+ TLS\https)[/COLOR]\n'
    bullet           = wiz.getS('bullet')
    on               = '[B][COLOR green]ON [/COLOR][/B]  %s  ' % bullet
    off              = '[B][COLOR red]OFF[/COLOR][/B]  %s  ' % bullet
    name=None
    url=None
    menu=None
    ##### language strings for settings
    '''
    MENU1  = 30000
    MENU2  = 30001
    MENU3  = 30003
    MENU4  = 30004
    MENU5  = 30005
    MENU6  = 30006
    MENU7  = 30007
    MENU8  = 30008
    MENU9  = 30009
    MENU10 = 30010
    MENU11 = 30011
    MENU12 = 30012
    '''
    ######################
    # txt
    EXTRAPATH        = uservar.EXTRAPATH     # addon resources\data
    DATAPATH         = uservar.DATAPATH # userdata resources\data
    #EXTRAPATH       = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'data'))
    #DATAPATH        = os.path.join(ADDONDATA, 'data')
    DUMMY            = xbmc.translatePath(os.path.join(DATAPATH, '__temp__.txt'))
    DUMMYADDON       = xbmc.translatePath(os.path.join(DATAPATH, 'addons_xml_settings.txt'))
    DUMMYAPK         = xbmc.translatePath(os.path.join(DATAPATH, 'apk_xml_settings.txt'))
    ## chrome
    stopPlayback     = 'no'
    CHROMEKIOSK      = wiz.getS('CHROMEKIOSK')
    kiosk            = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    userAgent        = ''
    useOwnProfile    = ADDON.getSetting("useOwnProfile") == "true"
    useCustomPath    = ADDON.getSetting("useCustomPath") == "true"
    customPath       = xbmc.translatePath(ADDON.getSetting("customPath"))
    profileFolder    = os.path.join(ADDONDATA, 'profile')
    siteFolder       = os.path.join(ADDONDATA, 'sites')
    if not os.path.isdir(ADDONDATA):      os.mkdir(ADDONDATA)
    if not os.path.isdir(profileFolder):  os.mkdir(profileFolder)
    if not os.path.isdir(siteFolder):     os.mkdir(siteFolder)
    if not os.path.isdir(DATAPATH):       os.mkdir(DATAPATH)
    ######################
    #ENABLEADDON
    ADDONFILE        = uservar.ADDONFILE
    #ADDONNAME1  + ADDONFILE  Online txt url    ##########################
    #ADDONNAME2  + ADDONFILE2 Online txt url 2 - 10
    ######################
    #ENABLEADDONT
    #ADDONTNAME1  + ADDONTFILE1 Offline txt url 1 - 10
    ######################
    spmcurl1         = uservar.spmcurl1
    kodiurl1         = uservar.kodiurl1
    kodiurl2         = uservar.kodiurl2
    APKFILE          = uservar.APKFILE
    #APKFILEOFFLINE  = wiz.getS('APKFILE.file')
    #APKFILEF        = xbmc.translatePath(os.path.join(EXTRAPATH, APKFILEOFFLINE))
    APKTFILE         = xbmc.translatePath(os.path.join(wiz.getS('APKTFILE')))
    #APKDIRECTFNAME1 + APKDIRECTFILE1  Online Direct apk urls  1 - 19
    #APKFNAME1  +  APKFILE1    Online Menu txt url  1 - 9
    ######################
    ADVANCEDFILE     = uservar.ADVANCEDFILE
    ######################
    BUILDFILE        = uservar.BUILDFILE
    ######################
    YOUTUBEFILE      = uservar.YOUTUBEFILE
    YOUTUBETFILE     = xbmc.translatePath(os.path.join(wiz.getS('YOUTUBETFILE')))
    #YOUTUBETFILE    = wiz.getS('YOUTUBETFILE')
    #YOUTUBETFILE    = uservar.YOUTUBETFILE
    ######################
    NOTIFICATION     = uservar.NOTIFICATION    # used in statup.py and test
    #NOTIFICATIONT   = uservar.NOTIFICATIONT  # used in statup.py
    #NOTIFICATIONT   = xbmc.translatePath(os.path.join(wiz.getS('NOTIFICATIONT')))
    ######################
    HELPFILE         = xbmc.translatePath(os.path.join(EXTRAPATH, 'help', wiz.getS('HELPFILE')))
    ######################
    # for Builds
    versionbuiltin   = uservar.versionbuiltin
    kodibuiltin      = uservar.kodibuiltin
    adultbuiltin     = uservar.adultbuiltin
    namebuiltin      = uservar.namebuiltin
    iconbuiltin      = ICON
    fanartbuiltin    = FANART
    ENABLEONLINE     = wiz.getS('ENABLEONLINE')
    ENABLEOFFLINE    = wiz.getS('ENABLEOFFLINE')
    ENABLEXML        = wiz.getS('ENABLEXML')
    # toggle builds
    #if kodi_version== 15: wiz.setS('show15', 'true')
    #if kodi_version== 16: wiz.setS('show16', 'true')
    #if kodi_version== 17: wiz.setS('show17', 'true')
    #if kodi_version== 18: wiz.setS('show18', 'true')
    ######################
    ADDONNEWNAME     = wiz.getS('ADDONNEWNAME')
    ADDONNEWID       = wiz.getS('ADDONNEWID')
    ######################
    KEYMAPSFILE      = uservar.KEYMAPSFILE
    KEYMAPSTFILE     = uservar.KEYMAPSTFILE
    #KEYMAPSFILE   = 'http://indigo.tvaddons.co/keymaps/customkeys.txt'
    #KEYMAPSTFILE  = 'http://indigo.tvaddons.co/keymaps/customkeys.txt'
    KEYBOARD_FILE = xbmc.translatePath(os.path.join('special://home/userdata/keymaps/', 'keyboard.xml'))
    #####################
    # repo built in
    REPOID                 = uservar.REPOID
    repo_url               = uservar.repo_url
    # Addon zip Installer
    zips_url               = uservar.zips_url
    url_addons_repo        = uservar.url_addons_repo
    url_addons_audio       = uservar.url_addons_audio
    url_addons_program     = uservar.url_addons_program
    url_addons_video       = uservar.url_addons_video
    url_addons_iptv        = uservar.url_addons_iptv
    url_addons_sub         = uservar.url_addons_sub
    url_addons_extra       = uservar.url_addons_extra
    url_theme              = uservar.url_theme
    url_theme_18           = uservar.url_theme_18
    url_theme_17           = uservar.url_theme_17
    url_theme_16           = uservar.url_theme_16
    url_theme_15           = uservar.url_theme_15
    # END SETTINGS

def index():    ####MAIN MENU
    # delete temp txt
    #delete_file(DUMMY)
    xbmc.log(msg='##['+ADDON_ID+'] **MAIN MENU**', level=xbmc.LOGNOTICE)
    ####
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    menuautoclean = createMenu('autoclean', '', 'Clean All Kodi Files Now')
    addDir('Clean Kodi Files [B][COLOR blue](Cache\Packages\Thumbs)[/COLOR]:[/B]  [COLOR lightgreen][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize), 'indexcleaning', description='Clean common Kodi files like Cache\Packages\Thumbs that slow your system down over time.',  icon=ICONCLEAN, menu=menuautoclean, themeit=THEME1)
    ####
    addDir('ADDONS',                                         'addonsmenu',          description='Install Kodi 3rd party addons, pre configured addon zips (builds) or Android apks.\nStart here if you have a fresh setup.', icon=ICONBUILDS,themeit=THEME1)
    addDir ('ANDROID  (apk)',                                'apk',                 description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPKS, themeit=THEME1)
    #if xbmc.getCondVisibility('system.platform.android'):   addDir ('ANDROID  (apk)' ,'apk',description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPKS, themeit=THEME1)
    addDir('BUILDS  (Zip of Addons)',                        'builds',              description='3rd Party pre fabricated builds or zips of preset Kodi configurations',  icon=ICONBUILDS, themeit=THEME1)
    addDir('MAINTENANCE and FIXES',                          'maint',               description='Various Kodi Maintenance Tools and Fixes', icon=ICONMAINT,themeit=THEME1)
    addDir('BACKUP \ RESTORE',                               'indexbackup',         description='Backup or Restore a zip file backup of your Kodi system setup and addons', icon=ICONBACKUP,themeit=THEME1)
    addDir('XMLs  (playerfactorycore \\ advancedsettings)',  'indexinstallxml',     description='Install an XML file like advancedsettings or playercorefactory to increse Kodi performance or features.',  icon=ICONXML,themeit=THEME1)
    addDir('LOG  (Errors) \ HELP',                           'indexlog',            description='View or upload your Kodi log file to diagnose errors',  icon=ICONLOG,themeit=THEME1)
    if HIDECONTACT == 'No': addFile('Help With Server and Donate via https://www.paypal.me/name',   'contact',  description='If you are gullible pay me',  icon=ICONCONTACT, themeit=THEME1)
    addDir('Youtube \ M3U \ VOD',                            'indexmedia',          description='Youtube tutorials for what the hell to do',  icon=ICONYOUTUBE,themeit=THEME1)
    addFile('Settings  [COLOR grey]' +ADDONTITLE+'  ('+ADDON_ID+')[/COLOR]','settings', description='Open the settings for '+ADDON_ID, icon=ICONSETTINGS, themeit=THEME3)
    #addFile('test Settings  [COLOR grey]' +ADDONTITLE+'  ('+ADDON_ID+')[/COLOR]',  'settings12',   description='Open the settings for '+ADDON_ID, icon=ICONSETTINGS, themeit=THEME3)
    if not ADDONNEWID == '':  addFile('Run Clone  [COLOR grey]' +ADDONNEWNAME+'  ('+ADDONNEWID+')[/COLOR]', 'runaddon',  name=ADDONNEWID,  description='Open the settings for '+ADDON_ID, icon=ICONSETTINGS, themeit=THEME3)
    ####
    if AUTOUPDATE == 'Yes':
        if wiz.workingURL(WIZARDFILE) == True:
            ver = wiz.checkWizard('version')
            if ver > VERSION: addFile('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (ADDONTITLE, VERSION, ver), 'wizardupdate', themeit=THEME2)
            #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
        #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
    #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
    if len(BUILDNAME) > 0:
        version = wiz.checkBuild(BUILDNAME, 'version')
        build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
        if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
        addDir(build,'viewbuild',BUILDNAME, themeit=THEME4)
        themefile = wiz.themeCount(BUILDNAME)
        if not themefile == False:
            addFile('None' if BUILDTHEME == "" else BUILDTHEME, 'theme', BUILDNAME, themeit=THEME5)
    #else: addDir('None', 'builds', themeit=THEME4)
    setView('files', 'viewType')
    
    
def doWritesources():
    if os.path.isfile(SOURCES):
        choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]sources.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLOR2, COLOR1), yeslabel="[B][COLOR green]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
        if not choice == 0:
            xbmcvfs.copy(SOURCES, SOURCES+'.last')
            delete_file(SOURCES)
    customsources = False
    iscustomsources = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to use custom media paths?[/COLOR]" % COLOR2, '(Probably No)', yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No[/COLOR][/B]")
    if iscustomsources == 0: customsources = True
            
    with open(SOURCES, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<sources>\n')
        f.write('    <programs>\n')
        f.write('        <default pathversion="1"></default>\n')
        if xbmc.getCondVisibility('system.platform.android'):
            f.write('        <source>\n')
            f.write('            <name>!/storage/emulated/0/</name>\n')
            f.write('            <path pathversion="1">/storage/emulated/0/</path>\n')
            f.write('            <allowsharing>true</allowsharing>\n')
            f.write('        </source>\n')
        if xbmc.getCondVisibility('system.platform.windows'):
            f.write('        <source>\n')
            f.write('            <name>zC:\</name>\n')
            f.write('            <path pathversion="1">C:\</path>\n')
            f.write('            <allowsharing>true</allowsharing>\n')
            f.write('        </source>\n')
        f.write('    </programs>\n')
        f.write('    \n')
        f.write('    <pictures>\n')
        f.write('        <default pathversion="1"></default>\n')
        f.write('        <source>\n')
        f.write('            <name>Time Of Day</name>\n')
        f.write('            <path pathversion="1">rss://pla1.net/time.rss/</path>\n')
        #f.write('            <thumbnail pathversion="1">DefaultNetwork.png</thumbnail>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </pictures>\n')
        f.write('    \n')
        f.write('    <video>\n')
        f.write('        <default pathversion="1"></default>\n')
        #f.write('    \n')
        f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_video.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>PnP Media Servers (Auto-Discover)</name>\n')
        f.write('            <path pathversion="1">upnp://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('        <source>\n')
        f.write('            <name>PVR</name>\n')
        f.write('            <path pathversion="1">pvr://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </video>\n')
        f.write('    \n')
        f.write('    <music>\n')
        f.write('        <default pathversion="1"></default>\n')
        #f.write('    \n')
        f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_music.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>PnP Media Servers (Auto-Discover)</name>\n')
        f.write('            <path pathversion="1">upnp://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </music>\n')
        f.write('    \n')
        f.write('    <files>\n')
        f.write('        <default pathversion="1"></default>\n')
        f.write('    \n')
        #f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_files.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>!Home</name>\n')
        f.write('            <path pathversion="1">special://home/</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </files>\n')
        f.write('</sources>\n')
        f.write('\n')
    f.close()


    
    
# wip install an online zip addon
def install_from_url():
    url = _get_keyboard('', 'Enter the URL of the addon/repository ZIP file you wish to install', hidden=False)
    if url:
        name = os.path.basename(url)
        #ADDONINSTALL(name, zip_url, '', '', '', True, '', '')
        #addonInstaller(name, zip_url)
        #PATH_ADDON(name, url, ADDONS)
        
        DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
        #urlsplit = url.split('/')
        #lib=os.path.join(PACKAGES, urlsplit[-1])
        lib=os.path.join(PACKAGES, name)
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
        DP.update(0, title, 'Extracting Zip', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
        percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
        #
        DP.update(0, title, name, '[COLOR %s]Installing Dependencies[/COLOR]' % COLOR2)
        installed(name)
        installDep(name, DP)
        DP.close()

    
    
# wip
def index_rompacks(name=None, url=None, view=None):
    ROMPACKFILE1      = wiz.getS('ROMPACKFILE1')
    ROMPACKTFILE1     = wiz.getS('ROMPACKTFILE1')
    addFile('Dummy - Install a rompack somehow',  'vodguixml',           description='Open VOD'  ,icon=ICONSETTINGS, themeit=THEME3)

    setView('files', 'viewType') 
# wip
def index_help():
    if not os.path.exists(HELPFILE): return
    f = xbmcvfs.File(HELPFILE,'rb')
    data = f.read()
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Help', data)
    



#wip
#def editaddontxt(number, prefix):
#def editaddontxt(name, number):
def editaddontxt(name, url):
    prefix = name
    number = url
    #name  = eval('THIRDNAME%s' % number)
    #url   = eval('THIRDURL%s' % number)
    name   = wiz.getS('ADDON%sNAME%s' % (prefix,number))
    url    = wiz.getS('ADDON%sURL%s' % (prefix,number))
    name2  = wiz.getKeyboard(name, 'Enter the Name (Menu)')
    url2   = wiz.getKeyboard(url, 'Enter the URL of the Addon txt Menu')
    wiz.setS('ADDON%sNAME%s' % (prefix,number), name2)
    wiz.setS('ADDON%sURL%s' % (prefix,number), url2)
    


###########################
###### ADDON  Install   ###
###########################
def index_addons(url=None, view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Addon Menu**', level=xbmc.LOGNOTICE)
    #if not xbmc.getCondVisibility('System.HasAddon(plugin.blahblah)'):
    ############################################################################
    ## online txts
    ############################################################################
    ENABLEADDON =  wiz.getS('ENABLEADDON')
    testENABLEADDON  = 'true' if ENABLEADDON == 'true' else 'false'
    if ENABLEONLINE == 'true': addFile('%s  Addon Installer  [COLOR %s](Online txts)[/COLOR]  ########################' % (testENABLEADDON.replace('true',on).replace('false',off), COLOR6),'togglesetting', name='ENABLEADDON', description='Turn on Addon Installer  (Online)',  fanart=FANART, icon=ICONADDONS, themeit=THEME9)
    if ENABLEONLINE == 'true':
        if ENABLEADDON == 'true':
            if not ADDONFILE == 'http://':
                if wiz.workingURL(ADDONFILE) == True:  addDir('%s[COLOR %s](Online txt)[/COLOR]  %s  (MAIN)' % (bullet, COLOR6, wiz.getS('ADDONNAME')),  'addontxt',  name=wiz.getS('ADDONNAME'), url=ADDONFILE, description='Install Kodi addons\n%s' % ADDONFILE, icon=ICONADDONS, themeit=THEME1)
            for items in range(1,100):
                name = wiz.getS('ADDONNAME%s' % items)
                url  = wiz.getS('ADDONFILE%s' % items)
                if not url  == 'http://':
                    if not name  == '':
                        menuaddontxt = createMenu('menuedittxt', 'addontxt', items)
                        #if wiz.workingURL(url) == True:   addDir('* [COLOR %s](Online txt)[/COLOR]  %s' % (COLOR6, name), 'addontxt',  name=name, url=url,  description='Install Kodi addons\n%s' % url, icon=ICONADDONS, themeit=THEME1)
                        addDir('%s[COLOR %s](Online txt)[/COLOR]  %s' % (bullet, COLOR6, name), 'addontxt',  name=name, url=url,  description='Install Kodi addons\n%s' % url, icon=ICONADDONS, menu=menuaddontxt, themeit=THEME1)

    ############################################################################
    ## offline txts
    ############################################################################
    ENABLEADDONT =  wiz.getS('ENABLEADDONT')
    testENABLEADDONT  = 'true' if ENABLEADDONT == 'true' else 'false'
    if ENABLEOFFLINE == 'true': addFile('%s  Addon Installer  [COLOR %s](Offline txts)[/COLOR]  ########################' % (testENABLEADDONT.replace('true',on).replace('false',off), COLOR7),'togglesetting', name='ENABLEADDONT', description='Turn on Addon Installer  (Offline)',  fanart=FANART, icon=ICONADDONS, themeit=THEME9)
    if ENABLEOFFLINE == 'true':
        if ENABLEADDONT == 'true':
            for items in range(1,100):
                url = wiz.getS('ADDONTFILE%s' % items)
                name = wiz.getS('ADDONTNAME%s' % items)
                if not url  == 'http://':
                    if os.path.exists(url):
                        menuaddont = createMenu('menuedittxt', 'addont', 'Edit Entry')
                        addDir('%s[COLOR %s](Offline txt)[/COLOR]  %s' % (bullet, COLOR6, name), 'addontxt',  name=name, url=url,  description='Install Kodi addons\n%s' % url, icon=ICONADDONS, menu=menuaddont, themeit=THEME1)
    ############################################################################

    ############################################################################
    ## addons from settings xml
    ############################################################################
    #progress = xbmcgui.DialogProgressBG()
    #progress.create("Wizard Parse")
    #progress.update(ADDON_ID, ' test ')
    #progress.close()
    delete_file(DUMMYADDON)
    ENABLEADDONX =  wiz.getS('ENABLEADDONX')
    testENABLEADDONX  = 'true' if ENABLEADDONX == 'true' else 'false'
    if ENABLEXML  == 'true': addFile('%s  Addon Installer  [COLOR %s](Settings xml)[/COLOR]  #######################' % (testENABLEADDONX.replace('true',on).replace('false',off), COLOR5) ,'togglesetting', name='ENABLEADDONX', description='Turn on Addon Installer  (Settings xml)',  fanart=FANART, icon=ICONADDONS, themeit=THEME9)
    if ENABLEXML == 'true':
        if ENABLEADDONX == 'true':
            addonxset = False; addin = []
            for items in range(1,100):
                url=None
                try: url = eval('ADDONXFILE%s' % items)
                except: pass
                if not url  == 'http://': addonxset = True; addin.append(items)
            if addonxset == True:
                for item in addin:
                    enable         = wiz.getS('ENABLEADDONX%s' % item)
                    name           = wiz.getS('ADDONXNAME%s' % item)
                    url            = wiz.getS('ADDONXFILE%s' % item)
                    icon           = wiz.getS('ADDONXICONURL%s' % item)
                    if icon       == 'http://': icon  = ICON
                    plugin         = wiz.getS('ADDONXPLUGIN%s' % item)
                    repository     = wiz.getS('ADDONXREPO%s' % item)
                    repositoryxml  = wiz.getS('ADDONXREPOXML%s' % item)
                    repositoryurl  = wiz.getS('ADDONXREPOURL%s' % item)
                    fanart         = 'http://'
                    adult          = 'No'
                    description    = 'DUMMY'
                    if enable == 'true' and not url  == 'http://':
                            if plugin.lower() == 'section':
                                menuaddonx = createMenu('menuedittxt', 'addonx', 'Edit Entry')
                                xbmc.log(msg='##['+ADDON_ID+'] **Addons  (Settings xml) MENU  Item: %s -  %s - %s - %s - %s' % (item,name,plugin,repository,url), level=xbmc.LOGNOTICE)
                                addDir("[B]%s[/B]" % name, 'addontxt', name=name, url=url, description='URL Menu\n%s' % url, icon=icon, fanart=FANART, menu=menuaddonx, themeit=THEME1)
                            # as addon
                            SETCOL1='white'
                            if os.path.exists(os.path.join(ADDONS,plugin)):  SETCOL1='lightgreen'
                            SETCOL2='grey'
                            repotest = os.path.join(ADDONS, repository)
                            if os.path.exists(repotest): SETCOL2='lightgreen'
                            if repository == 'repository.xbmchub': SETCOL2='lightgreen'
                            NAME='[COLOR %s]%s[/COLOR]  [COLOR skyblue][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, name, plugin, SETCOL2, repository)
                            xbmc.log(msg='##['+ADDON_ID+'] **Addons  (Settings xml) CREATE MENU  Item: %s -  %s - %s - %s - %s' % (item,name,plugin,repository,url), level=xbmc.LOGNOTICE)
                            with open(DUMMYADDON, 'a') as f:
                                f.write('name="'+name+'"\n')
                                f.write('plugin="'+plugin+'"\n')
                                f.write('url="'+url+'"\n')
                                f.write('repository="'+repository+'"\n')
                                f.write('repositoryxml="'+repositoryxml+'"\n')
                                f.write('repositoryurl="'+repositoryurl+'"\n')
                                f.write('icon="'+icon+'"\n')
                                f.write('fanart="'+fanart+'"\n')
                                f.write('adult="'+adult+'"\n')
                                f.write('description="'+description+'"\n\n\n')
                                f.close()
            if os.path.exists(DUMMYADDON):  addDir('%s[COLOR %s](Settings.xml txt)[/COLOR]' % (bullet, COLOR7),  'addontxt', name='*Addon Installer [COLOR %s](Settings.xml txt)[/COLOR]' % COLOR7,  url=DUMMYADDON,  description='Install Kodi addons from an offline txt file.',icon=ICONADDONS, themeit=THEME1)

    ############################################################################
    ## 
    ############################################################################
    addDir ('Github Search',      'githubmain',       description='Search the common addon www host Github for addons.\nThanks to TVA.', icon=ICONGITHUB, themeit=THEME1)
    addDir('Addon Tools and Fixes',                           'maint',               description='Various Kodi Maintenance Tools and Fixes', icon=ICONMAINT,themeit=THEME1)
    #addFile('Check for missing Dependencies', 'checkdeps', 'url', description='Install Kodi addons dependencies that run in the background and are needed to work.',icon=ICONADDONS, themeit=THEME3)
    #addFile('Scan For Broken Repositories',          'checkrepos',       description='Scan For Broken Repositories',   icon=ICONADDONS, themeit=THEME3)
    #addFile('View Log File',                          'viewlog',         description='View the contents of the Logfile to check for Kodi addon errors',  icon=ICONLOG, themeit=THEME3)
    #if kodi_version == '18': addFile('Enable All Addons (Kodi 18)',         'kodi17fix',  description='When you install addons from a zip file or build it doesnt install the normal way - it just extracts it.  In Kodi 17 addons must be Enabled to work to cover their ass for 3rd party addons and unknown sources.  This will scann the addons and enable them.',  icon=ICONSETTINGS, themeit=THEME3)
    #if kodi_version == '17': addFile('Enable All Addons (Kodi 17)',         'kodi17fix',  description='When you install addons from a zip file or build it doesnt install the normal way - it just extracts it.  In Kodi 17 addons must be Enabled to work to cover their ass for 3rd party addons and unknown sources.  This will scann the addons and enable them.',  icon=ICONSETTINGS, themeit=THEME3)
    #addFile('[COLOR red](EXIT)[/COLOR]  Force Close Kodi', 'forceclose', description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly', icon=ICONFORCECLOSE,themeit=THEME3)
    #addFile('Fresh Start',        'freshstart',       description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART, themeit=THEME7)
    addFile('Install an addon .zip dirct from url',   'addonfromurl', 'Install from URL', description='Install an addon zip directly from its url',  icon=ICONADDONS,themeit=THEME3)
    addFile('Repo [COLOR grey]'+REPOID+'[/COLOR]  (Main repo)', 'Repolink', REPOID, description='Browse the '+REPOID+' Default Repo for Addons and Skins',  icon=ICONREPO,themeit=THEME3)
    setView('files', 'viewType')
def addonInstaller(plugin, url):
    progress = xbmcgui.DialogProgressBG()
    progress.create(plugin,'Checking Addon...')
    try: _notify('Checking Addon...', plugin, xbmcaddon.Addon(id=plugin).getAddonInfo('icon'), duration=1000)
    except: _notify('Checking Addon...', plugin, ICON, duration=1000)
    if not url in ['http://', 'https://', '']:
        # no url fallback to main online txt
        if url == None:
            TEMPADDONFILE = uservar.ADDONFILE
            ADDONWORKING  = wiz.workingURL(TEMPADDONFILE)
            if ADDONWORKING == True:
                xbmc.log(msg='##['+ADDON_ID+'] Addon txt Install Menu -  Fallbak main online url', level=xbmc.LOGNOTICE)
                link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
        # url online txt
        else:
            TEMPADDONFILE = url
            ADDONWORKING  = wiz.workingURL(TEMPADDONFILE)
            # add online source
            if ADDONWORKING == True:
                xbmc.log(msg='##['+ADDON_ID+'] Addon txt Install Menu -  online url', level=xbmc.LOGNOTICE)
                link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            # add offline source
            else:
                if os.path.exists(TEMPADDONFILE):
                    xbmc.log(msg='##['+ADDON_ID+'] Addon txt Install Menu -  offline txt url', level=xbmc.LOGNOTICE)
                    ADDONWORKING = True
                    link = xbmcvfs.File(TEMPADDONFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
        #
        # try addon install or launch menu if exists
        if ADDONWORKING == True:
            match = re.compile('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % plugin).findall(link)
            xbmc.log(msg='##['+ADDON_ID+'] Match - %s' % match, level=xbmc.LOGNOTICE)
            if len(match) > 0:
                for name, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    #
                    # if addon exists menu
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        progress.close()
                        xbmc.log(msg='##['+ADDON_ID+'] Step 0 - ADDON ALREADY EXISTS woot', level=xbmc.LOGNOTICE)
                        do = ['Launch Addon', 'Fix Dependancies', 'Remove Addon:  %s' % plugin, 'Browse Repo:  %s' % repository, 'Remove Repo:  %s' % repository, 'ReInstall Repo:  %s' % repository, 'Refresh Addons and Repos']
                        selected = DIALOG.select("[COLOR %s]%s[/COLOR] is installed" % (COLOR1,plugin), do)
                        # launch addon
                        if selected == 0:
                            #_notify('Run Addon', plugin, xbmcaddon.Addon(id=plugin).getAddonInfo('icon'))
                            wiz.ebi('RunAddon(%s)' % plugin)
                            xbmc.sleep(500)
                            return True
                        # fix deps
                        elif selected == 1:
                            #xbmc.log(msg='##['+ADDON_ID+'] Fix dependencies' % plugin, level=xbmc.LOGNOTICE)
                            #_notify('Dependencies', plugin, xbmcaddon.Addon(id=plugin).getAddonInfo('icon'))
                            DP.create(ADDONTITLE,'[COLOR %s][B]Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, plugin), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
                            DP.update(0, '[COLOR %s][B]Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, plugin), plugin, '[COLOR %s]Installing Dependencies[/COLOR]' % COLOR2)
                            installed(plugin)
                            installDep(plugin, DP)
                            DP.close()
                            xbmc.sleep(500)
                            return True
                        # remove addon
                        elif selected == 2:
                            #xbmc.log(msg='##['+ADDON_ID+'] Delete addon %s' % plugin, level=xbmc.LOGNOTICE)
                            wiz.cleanHouse(os.path.join(ADDONS, plugin))
                            try: wiz.removeFolder(os.path.join(ADDONS, plugin))
                            except: pass
                            if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to remove the addon_data for:" % COLOR2, "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, plugin), yeslabel="[B][COLOR green]Yes Remove[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
                                try: removeAddonData(plugin)
                                except: pass
                                wiz.refresh()
                                _notify('Delete Done', plugin, ICON)
                                return True
                            else: return True
                        #else: return False
                        # Browse repo
                        elif selected == 3:
                            repo = os.path.join(ADDONS, repository)
                            if not os.path.exists(repo): return
                            #xbmc.log(msg='##['+ADDON_ID+'] **ADDON INSTALLER** run repo', level=xbmc.LOGNOTICE)
                            #_notify('Run Repo', repository, xbmcaddon.Addon(id=repository).getAddonInfo('icon'))
                            xbmc.executebuiltin('ActivateWindow(10040,addons://'+repository+'/,return)')
                            xbmc.sleep(500)
                            return True
                        # Remove repo
                        elif selected == 4:
                            #xbmc.log(msg='##['+ADDON_ID+'] Remove repo  %s' % repository, level=xbmc.LOGNOTICE)
                            repo = os.path.join(ADDONS, repository)
                            if not os.path.exists(repo): return
                            wiz.cleanHouse(os.path.join(ADDONS, repository))
                            try: wiz.removeFolder(os.path.join(ADDONS, repository))
                            except: pass
                            wiz.refresh()
                            _notify('Delete Done', repository, ICON)
                            return True
                        # Reinstall repo
                        elif selected == 5:
                            #xbmc.log(msg='##['+ADDON_ID+'] Reinstall repo  %s' % repository, level=xbmc.LOGNOTICE)
                            # check for repo and install if possible
                            #xbmc.log(msg='##['+ADDON_ID+'] **ADDON INSTALLER** check for repo and install if possible', level=xbmc.LOGNOTICE)
                            repo = os.path.join(ADDONS, repository)
                            if not repository.lower() == 'none' and not os.path.exists(repo):
                                wiz.log("Repository not installed, installing it")
                                if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Repository %s not installed, install ? [COLOR %s]%s[/COLOR]" % (COLOR2, repository, COLOR6, plugin), "Repo:   [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
                                    ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
                                    if len(ver) > 0:
                                        #xbmc.log(msg='##['+ADDON_ID+'] **ADDON INSTALLER** install repo', level=xbmc.LOGNOTICE)
                                        repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
                                        wiz.log(repozip)
                                        if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                        install = installAddon(repository, repozip)
                                        if install:
                                            #wiz.ebi('UpdateAddonRepos()')
                                            #wiz.ebi('UpdateLocalAddons()')
                                            #_notify('Done Repo', repository, xbmcaddon.Addon(id=repository).getAddonInfo('icon'))
                                            xbmc.executebuiltin('UpdateAddonRepos()')
                                            wiz.refresh()
                                            return True
                                        else:
                                            repozip2 = "%s%s.zip" % (repositoryurl, repository)
                                            wiz.log(repozip2)
                                            if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                            install2 = installAddon(repository, repozip2)
                                            if install2:
                                                wiz.log("Done - Install from Kodi: %s" % install2)
                                                wiz.refresh()
                                                return True
                        # Refresh addon
                        elif selected == 6:
                            _notify('Refresh Addons', plugin, ICON)
                            wiz.ebi('UpdateAddonRepos()')
                            wiz.ebi('UpdateLocalAddons()')
                            wiz.refresh()
                            return True
                        #
                        # Return from found addon menu
                        else: return False
                    #
                    # try repo
                    #DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
                    #title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
                    #DP.update(0, title, name, '[COLOR %s]Installing Dependencies[/COLOR]' % COLOR2)
                    #DP.close()
                    xbmc.log(msg='##['+ADDON_ID+'] Step 0 - ADDON Not found - Start install procedure.', level=xbmc.LOGNOTICE)
                    repo = os.path.join(ADDONS, repository)
                    #if repository == 'repository.xbmchub':
                    #    try: repo = xbmcaddon.Addon(id=repository).getAddonInfo('path')
                    #    except: pass
                    wiz.log("Step 1 - Repository - Check for %s" % repo)
                    if not repository.lower() == 'none' and not os.path.exists(repo):
                        if not repository == 'repository.xbmchub':
                        #if DIALOG.yesno(ADDONTITLE, "Would you like to install the repository for:  [COLOR %s]%s[/COLOR]" % (COLOR7, plugin), "[COLOR %s]%s[/COLOR]" % (COLOR1, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
                            progress.update(1, 'Try Repository','%s' % repo )
                            wiz.log("Repository %s not installed, try installing it" % repo)
                            ver=''
                            try:    ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
                            except: pass
                            if len(ver) > 0:
                                # try installing with version in zip
                                repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
                                wiz.log("Step 1 - Repository - install repozip with version - %s" % repozip)
                                progress.update(20, 'Install Repository','%s' % repozip)
                                if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                installrepo = installAddon(repository, repozip)
                                if installrepo:
                                    wiz.log("[Addon Installer] Repository %s installed" % repository)
                                    wiz.ebi('UpdateAddonRepos()')
                                    progress.update(40, 'Repository Installed','%s' % repozip)
                                    #wiz.ebi('UpdateLocalAddons()')
                                # try installing without version in zip
                                else:
                                    repozip2 = '%s%s.zip' % (repositoryurl, repository)
                                    wiz.log("Step 1 - Repository - install repozip without version - %s" % repozip2)
                                    progress.update(30, 'Trying Install Repo without ver','%s' % repozip2)
                                    if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                    installrepo = installAddon(repository, repozip2)
                                    if installrepo:
                                        progress.update(40, 'Repository Installed','%s' % repozip2)
                                        wiz.log("[Addon Installer] Repository %s installed" % repository)
                                        wiz.ebi('UpdateAddonRepos()')
                                        #wiz.ebi('UpdateLocalAddons()')
                                #
                                repo = os.path.join(ADDONS, repository)
                                try: repo = xbmcaddon.Addon(id=repository).getAddonInfo('path')
                                except: pass
                                if os.path.exists(repo):
                                    xbmc.sleep(500)
                                    wiz.log("Installing Addon from Kodi")
                                    progress.update(50, 'Installing Addon with Kodi','%s' % plugin)
                                    install = installFromKodi(plugin)
                                    if install:
                                        progress.update(100, 'Addon Installed','%s' % plugin)
                                        wiz.log("Done - Install from Kodi: %s" % install)
                                        wiz.refresh()
                                        progress.close()
                                        return True
                                #else: wiz.log("[Addon Installer] Repository %s not installed" % repository)
                            #else: wiz.log("[Addon Installer] Repository not installed: Unable to grab url for (%s)  %s" % (repository, repositoryurl))
                        #else: wiz.log("[Addon Installer] Repository for %s not installed: %s" % (plugin, repository))
                        else: wiz.log("SKIP Step 1 - Repository - Check for %s" % repo)
                    #
                    # repo not installed or none - try install addon
                    elif repository.lower() == 'none':
                        wiz.log("Step 2 - Repository is none, try installing addon direct (will probably fail)")
                        progress.update(50, 'No Repo - Try addon direct','%s' % plugin)
                        #wiz.log("No repository, installing addon")
                        pluginid = plugin
                        zipurl = url
                        install = installAddon(plugin, url)
                        if install:
                            wiz.log("Done - Install from Kodi: %s" % plugin)
                            progress.update(100, 'Installed','%s' % plugin)
                            wiz.refresh()
                            progress.close()
                            return True
                        else:  wiz.log("SKIP Step 2 - Repository is none, try installing addon direct")
                    else:
                        wiz.log("Step 3 - Repository installed - install  %s" % plugin)
                        progress.update(50, 'Install From Repo','%s' % plugin)
                        install = installFromKodi(plugin, False)
                        if install:
                            wiz.log("Done - Install from Kodi: %s" % install)
                            progress.update(100, 'Installed','%s' % plugin)
                            wiz.refresh()
                            progress.close()
                            return True
                        else:  wiz.log("SKIP Step 3 - Repository installed - install  %s" % plugin)
                    #
                    if os.path.exists(os.path.join(ADDONS, plugin)): return True
                    #
                    # try install addon last resort
                    wiz.log("Step 4 - Last Resort - for %s" % plugin)
                    progress.update(75, 'Last Resort','Install %s' % plugin)
                    ver2=''
                    try:    ver2 = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': plugin})
                    except: pass
                    #ver2 = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': plugin})
                    if len(ver2) > 0:
                        url2 = "%s%s-%s.zip" % (url, plugin, ver2[0])
                        wiz.log("Step 4 - Last Resort with version - try url   %s" % url2)
                        progress.update(80, 'Try install with version','Try url   %s' % url2)
                        wiz.log(str(url2))
                        if KODIV >= 17: wiz.addonDatabase(plugin, 1)
                        install = installAddon(plugin, url2)
                        if install:
                            progress.update(100, 'Installed','%s' % plugin)
                            wiz.log("Done - Install from Kodi: %s" % install)
                            wiz.refresh()
                            progress.close()
                            return True
                        else:
                            url3 = "%s%s.zip" % (url, plugin)
                            progress.update(80, 'Try install without version','%s' % url3)
                            wiz.log("Step 5 - Last Resort without version - try url   %s" % url3)
                            wiz.log(str(url3))
                            if KODIV >= 17: wiz.addonDatabase(plugin, 1)
                            install = installAddon(plugin, url3)
                            if install:
                                progress.update(100, 'Installed','%s' % plugin)
                                #wiz.log("Done - Install from Kodi: %s" % install)
                                wiz.refresh()
                                progress.close()
                                return True
                    # No matches
                    else: wiz.log('No matches for %s' % plugin)
            #
            else: wiz.log("[Addon Installer] Invalid Format")
        else:
            progress.update(1, 'Install zip','%s' % plugin)
            progress.close()
            wiz.log("[Addon Installer] Text File not valid : %s" % ADDONWORKING)
            '''
            ####################################################################
            # install from zip try from url install
            confirm = xbmcgui.Dialog().yesno("Please Confirm", "Do you wish to install %s" % plugin,url,"", "Cancel", "Install")
            if confirm:
                install = installAddon(plugin, url)
                name = plugin
                dp = xbmcgui.DialogProgress()
                dp.create("Download Progress:", "", '', 'Please Wait')
                lib = os.path.join(PACKAGES, name + '.zip')
                try:
                    os.remove(lib)
                except:
                    pass
                addonfolder = xbmc.translatePath(os.path.join('special://', 'home', 'addons'))
                download(url, lib, addonfolder, name)
                try:
                    addonname = re.match('(.+)(-\d+\.)', addonname).group(1)
                except:
                    pass
                # extract.all(lib, addonfolder, '')
                set_enabled(name)
                xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
                xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
                try:
                    dataurl = repourl.split("repository", 1)[0]

                    # Start Addon Depend Search ==================================================================
                    # Handles the addons/dependencies that have the version in the addon name
                    try:
                        addonname = re.match('(.+)(-\d+\.)', addonname).group(1)
                    except:
                        pass
                    depends = xbmc.translatePath(os.path.join('special://home', 'addons', addonname, 'addon.xml'))
                    source = open(depends, mode='r')
                    link = source.read()
                    source.close()
                    dmatch = re.compile('import addon="(.+?)"').findall(link)
                    for requires in dmatch:
                        if not 'xbmc.python' in requires:
                            if not 'xbmc.gui' in requires:
                                dependspath = xbmc.translatePath(os.path.join('special://home/addons', requires))
                                if not os.path.exists(dependspath):
                                    NEW_Depend(dataurl, requires)
                                    Deep_Depends(dataurl, requires)
                                # name, url = NEW_Depend(dataurl,requires)
                                # DEPENDINSTALL(name,url)
                except:
                    traceback.print_exc(file=sys.stdout)
                # # End Addon Depend Search ======================================================================

                kodi.log("STARTING REPO INSTALL")
                kodi.log("Installer: Repo is : " + repourl)
                if repourl:
                    if 'None' not in repourl:
                        path = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
                        # lib = os.path.join(path, name + '.zip')
                        files = repourl.split('/')
                        dependname = files[-1:]
                        dependname = str(dependname)
                        reponame = dependname.split('-')
                        nextname = reponame[:-1]
                        nextname = str(nextname).replace('[', '').replace(']', '').replace('"', '').replace('[', '')\
                            .replace("'", '').replace(".zip", '')
                        lib = os.path.join(path, nextname + '.zip')
                        kodi.log("REPO TO ENABLE IS  " + nextname)
                        try:
                            os.remove(lib)
                        except:
                            pass
                        addonfolder = xbmc.translatePath(os.path.join('special://', 'home/addons'))
                        # download(repourl, lib, addonfolder, name)
                        download(repourl, lib, addonfolder, nextname)
                        set_enabled(nextname)

                set_enabled(addonname)
                xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
                xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
                if not dialog.yesno(siteTitle, '                     Click Continue to install more addons or',
                                    '                    Restart button to finalize addon installation',
                                    "                          Brought To You By %s " % siteTitle,
                                    nolabel='Restart', yeslabel='Continue'):
                    xbmc.executebuiltin('ShutDown')
            else:
                return
            '''
    else:
        wiz.log("[Addon Installer] Not Enabled.")
        progress.close()
def addontxt(name=None, url=None):
    xbmc.log(msg='##['+ADDON_ID+'] Addon txt Install Menu Start', level=xbmc.LOGNOTICE)
    # online txt
    #if not url == 'http://':
    if not url in ['http://', 'https://', '']:
        # no url fallback to main online txt
        if url == None:
            TEMPADDONFILE = uservar.ADDONFILE
            ADDONWORKING  = wiz.workingURL(TEMPADDONFILE)
            if ADDONWORKING == True:
                addFile('Online txt -  %s' % name, 'refresh', description=TEMPADDONFILE,  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
                link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
        # url online txt
        else:
            TEMPADDONFILE = url
            ADDONWORKING  = wiz.workingURL(TEMPADDONFILE)
            # add online source
            if ADDONWORKING == True:
                addFile('Online txt -  %s' % name, 'refresh', description=TEMPADDONFILE,  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
                link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            # add offline source
            else:
                if os.path.exists(TEMPADDONFILE):
                    addFile('Offline txt -  %s' % name, 'refresh', description=TEMPADDONFILE,  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
                    link = xbmcvfs.File(TEMPADDONFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                    ADDONWORKING = True
        # try addon install
        if ADDONWORKING == True:
            xbmc.log(msg='##['+ADDON_ID+'] Working addon url  %s' % TEMPADDONFILE, level=xbmc.LOGNOTICE)
            match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            addFile('%s' % TEMPADDONFILE, 'refreshaddon', description=TEMPADDONFILE,  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
            if len(match) > 0:
                x = 0
                for name, plugin, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    if plugin.lower() == 'section':
                        x += 1
                        addDir("[B]%s[/B]" % name, 'addontxt', name=name, url=url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
                    else:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        # if addon is already installed
                        add1  = os.path.join(ADDONS, plugin)
                        if os.path.exists(add1): name = "[COLOR lightgreen]%s[/COLOR]" % name
                        # if repo installed
                        repotest = os.path.join(ADDONS, repository)
                        if repository == 'repository.xbmchub':
                            try: repotest = xbmcaddon.Addon(id=repository).getAddonInfo('path')
                            except: pass
                        repository2   = repository
                        if os.path.exists(repotest): repository2 = "[COLOR lightgreen]%s[/COLOR]" % repository
                        x += 1
                        addFile("[COLOR %s]%s[/COLOR]  [%s]  [COLOR %s][%s][/COLOR]" % (COLOR2, name, plugin, COLOR8, repository2), 'addoninstall', name=plugin, url=TEMPADDONFILE, description="[COLOR blue]Name:[/COLOR] %s\n[COLOR blue]Plugin:[/COLOR] %s\n[COLOR blue]Repo:[/COLOR] %s\n%s" % (name, plugin, repository2, description), icon=icon, fanart=fanart, themeit=THEME2)
                    if x < 1:
                        addFile("No addons added to this menu!", '',description=TEMPADDONFILE, fanart=FANART, icon=ICONSPACER, themeit=THEME6)
            else: 
                addFile('Text File not formated correctly!', '', description=TEMPADDONFILE, fanart=FANART, icon=ICONSPACER, themeit=THEME6)
                wiz.log("[Addon Menu] ERROR: Invalid Format.")
        else: 
            wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
            addFile('Not valid: %s  %s' % (name, TEMPADDONFILE), 'refreshaddon', description=TEMPADDONFILE, themeit=THEME6)
    else:  wiz.log("[Addon Menu] No Addon list added - Disabled with http://")
    setView('files', 'viewType')
def installFromKodi(plugin, over=True):
    xbmc.log(msg='##['+ADDON_ID+'] **ADDON INSTALLER** install From Kodi', level=xbmc.LOGNOTICE)
    if over == True:
        xbmc.sleep(2000)
    #wiz.ebi('InstallAddon(%s)' % plugin)
    wiz.ebi('RunPlugin(plugin://%s)' % plugin)
    #'''
    if not wiz.whileWindow('yesnodialog'):
        return False
    #'''
    xbmc.sleep(100)
    if wiz.whileWindow('okdialog'):
        return False
    #'''
    wiz.whileWindow('progressdialog')
    #xbmc.executebuiltin('Container.Refresh()')
    if os.path.exists(os.path.join(ADDONS, plugin)):
        icontest  = os.path.join(ADDONS, name, 'icon.png')
        if os.path.exists(icontest):  _notify('Installed', name, icontest)
        else:                         _notify('Installed', name, ICON)
        wiz.refresh()
        #xbmc.executebuiltin('Container.Refresh()')
        return True
    else: return False
def installAddon(name, url):
    #wiz.log("Install addon START")
    #DIALOG.ok(ADDONTITLE, '[COLOR %s]Install addon START[/COLOR]' % COLOR2)
    if not wiz.workingURL(url) == True:
        wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLOR1, '[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Url![/COLOR]' % (COLOR1, name, COLOR2))
        wiz.log('Invalid Url for addon installer:  %s' % url)
        return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    urlsplit = url.split('/')
    lib=os.path.join(PACKAGES, urlsplit[-1])
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
    DP.update(0, title, 'Extracting Zip', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
    #
    DP.update(0, title, name, '[COLOR %s]Installing Dependencies[/COLOR]' % COLOR2)
    installed(name)
    installDep(name, DP)
    DP.close()
    icontest  = os.path.join(ADDONS, name, 'icon.png')
    if os.path.exists(icontest):  _notify('Installed', name, icontest)
    else:                         _notify('Installed', name, ICON)
    wiz.refresh()
    try: wiz.ebi('UpdateAddonRepos()')
    except: pass
    try: wiz.ebi('UpdateLocalAddons()')
    except: pass
def installed(addon):
    url = os.path.join(ADDONS,addon,'addon.xml')
    if os.path.exists(url):
        try:
            list  = open(url,mode='r'); g = list.read(); list.close()
            name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': addon})
            icon  = os.path.join(ADDONS, addon, 'icon.png')
            wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, name[0]), '[COLOR %s]Addon Enabled[/COLOR]' % COLOR2, '3000', icon)
        except: pass
def installDep(name, DP=None):
    dep=os.path.join(ADDONS,name,'addon.xml')
    if os.path.exists(dep):
        source = open(dep,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        for depends in match:
            if not 'xbmc.python' in depends:
                if not DP == None:
                    DP.update(0, '', '[COLOR %s]%s[/COLOR]' % (COLOR1, depends))
                wiz.createTemp(depends)
                #
                continue
                dependspath=os.path.join(ADDONS, depends)
                if not os.path.exists(dependspath):
                    zipname = '%s-%s.zip' % (depends, match2[match.index(depends)])
                    depzip = urljoin("%s%s/" % (MODURL2, depends), zipname)
                    if not wiz.workingURL(depzip) == True:
                        depzip = urljoin(MODURL, '%s.zip' % depends)
                        if not wiz.workingURL(depzip) == True:
                            wiz.createTemp(depends)
                            if KODIV >= 17: wiz.addonDatabase(depends, 1)
                            continue
                    lib=os.path.join(PACKAGES, '%s.zip' % depends)
                    try: os.remove(lib)
                    except: pass
                    DP.update(0, '[COLOR %s][B]Downloading Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends),'', 'Please Wait')
                    downloader.download(depzip, lib, DP)
                    xbmc.sleep(100)
                    title = '[COLOR %s][B]Installing Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends)
                    DP.update(0, title,'', 'Please Wait')
                    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
                    DP.close()
                    if KODIV >= 17: wiz.addonDatabase(depends, 1)
                    installed(depends)
                    installDep(depends)
                    xbmc.sleep(100)
def checkdeps(check=False):
    if DIALOG.yesno(ADDONTITLE, "Would you also like to make sure all addons are enabled?", yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):  check=True
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    DP.create(ADDONTITLE,'[COLOR %s][B]Check Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, ADDONS), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        DP.update(0, '[COLOR %s][B]Check Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, foldername), foldername, '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
        if check == True:
            installed(foldername)
        installDep(foldername, DP)
    DP.close()
# wip
def Deep_Depends(dataurl, addonname):
    depends = xbmc.translatePath(os.path.join('special://home', 'addons', addonname, 'addon.xml'))
    source = open(depends, mode='r')
    link = source.read()
    source.close()
    dmatch = re.compile('import addon="(.+?)"').findall(link)
    for requires in dmatch:
        if not 'xbmc.python' in requires:
            dependspath = xbmc.translatePath(os.path.join('special://home/addons', requires))
            if not os.path.exists(dependspath):
                NEW_Depend(dataurl, requires)


###########################
###### APK  menu        ###
###########################
def index_apk(url=None, view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Apk Menu**', level=xbmc.LOGNOTICE)
    ############################################################################
    ## online txts
    ############################################################################
    ENABLEAPK =  wiz.getS('ENABLEAPK')
    testENABLEAPK  = 'true' if ENABLEAPK == 'true' else 'false'
    if ENABLEONLINE == 'true': addFile('%s  Apk Installer  [COLOR %s](Online txts)[/COLOR]  ########################' % (testENABLEAPK.replace('true',on).replace('false',off), COLOR6),'togglesetting', name='ENABLEAPK', description='Turn on Apk Installer  (Online)',  fanart=FANART, icon=ICONAPKS, themeit=THEME9)
    if ENABLEONLINE == 'true':
        if ENABLEAPK == 'true':
            if not APKFILE == 'http://':
                if wiz.workingURL(APKFILE) == True:    addDir('%s[COLOR %s](Online txt)[/COLOR]  %s  (MAIN)' % (bullet, COLOR6, wiz.getS('APKNAME')),  'apktxt',  name=wiz.getS('APKNAME'), url=APKFILE, description='Install apks\n%s' % APKFILE, icon=ICONAPKS, themeit=THEME1)
            for items in range(1,100):
                url  = wiz.getS('APKFILE%s' % items)
                name = wiz.getS('APKNAME%s' % items)
                if not url  == 'http://':
                    if not name  == '':
                        if wiz.workingURL(url) == True: addDir('%s[COLOR %s](Online txt)[/COLOR]  %s' % (bullet, COLOR6, name), 'apktxt',  name=name, url=url,  description='Install apks\n%s' % url, icon=ICONAPKS, themeit=THEME1)

    ############################################################################
    ## offline txts
    ############################################################################
    ENABLEAPKT =  wiz.getS('ENABLEAPKT')
    testENABLEAPKT    = 'true' if ENABLEAPKT == 'true' else 'false'
    if ENABLEOFFLINE == 'true': addFile('%s  Apk Installer  [COLOR %s](Offline txts)[/COLOR]  ########################' % (testENABLEAPKT.replace('true',on).replace('false',off), COLOR7),'togglesetting', name='ENABLEAPKT', description='Turn on Apk Installer  (Offline)',  fanart=FANART, icon=ICONAPKS, themeit=THEME9)
    if ENABLEOFFLINE == 'true':
        if ENABLEAPKT == 'true':
            for items in range(1,100):
                url = wiz.getS('APKTFILE%s' % items)
                name = wiz.getS('APKTNAME%s' % items)
                if not url  == 'http://':
                    if os.path.exists(url):
                        addDir('%s[COLOR %s](Offline txt)[/COLOR]  %s' % (bullet, COLOR6, name), 'apktxt',  name=name, url=url,  description='Install apks\n%s' % url, icon=ICONAPKS, themeit=THEME1)
    ############################################################################

    ############################################################################
    ## addons from settings xml
    ############################################################################
    delete_file(DUMMYAPK)
    ENABLEAPKX =  wiz.getS('ENABLEAPKX')
    testENABLEAPKX  = 'true' if ENABLEAPKX == 'true' else 'false'
    if ENABLEXML == 'true':  addFile('%s  Apk Installer  [COLOR %s](Settings xml)[/COLOR]  #######################' % (testENABLEAPKX.replace('true',on).replace('false',off), COLOR5) ,'togglesetting', name='ENABLEAPKX', description='Turn on Apk Installer  (Settings xml)',  fanart=FANART, icon=ICONAPKS, themeit=THEME9)
    if ENABLEXML == 'true':
        if ENABLEAPKX == 'true':
            apkxset = False; addin = []
            for items in range(1,100):
                #'''
                url=None
                try: url = eval('APKXFILE%s' % items)
                except: pass
                #'''
                #url          = wiz.getS('APKXFILE%s' % items)
                if not url  == 'http://': apkxset = True; addin.append(items)
            if apkxset == True:
                for item in addin:
                    enable         = wiz.getS('ENABLEAPKX%s' % item)
                    name           = wiz.getS('APKXNAME%s' % item)
                    url            = wiz.getS('APKXFILE%s' % item)
                    section        = 'yes' if wiz.getS('APKXSECT%s' % item) == 'true' else 'no'
                    icon           = wiz.getS('APKXICONURL%s' % item)
                    if icon       == 'http://': icon  = ICON
                    fanart         = 'http://'
                    adult          = 'No'
                    description    = 'DUMMY'
                    xbmc.log(msg='##['+ADDON_ID+'] **Apk Item: %s -  %s - %s - %s - %s' % (item,name,section,enable,url), level=xbmc.LOGNOTICE)
                    if enable == 'true' and not url == 'http://':
                            xbmc.log(msg='##['+ADDON_ID+'] **Apks  (Settings xml) MENU  Item: %s -  %s - %s - %s' % (item,name,section,url), level=xbmc.LOGNOTICE)
                            if section.lower() == 'yes':
                                addDir("[B]%s[/B]" % name, 'apktxt', name=name, url=url, description='URL Menu\n%s' % url, icon=icon, fanart=FANART, themeit=THEME1)
                            xbmc.log(msg='##['+ADDON_ID+'] **Apks  (Settings xml) CREATE MENU  Item: %s -  %s - %s - %s' % (item,name,section,url), level=xbmc.LOGNOTICE)
                            with open(DUMMYAPK, 'a') as f:
                                f.write('name="'+name+'"\n')
                                f.write('section="'+section+'"\n')
                                f.write('url="'+url+'"\n')
                                f.write('icon="'+icon+'"\n')
                                f.write('fanart="'+fanart+'"\n')
                                f.write('adult="'+adult+'"\n')
                                f.write('description="'+description+'"\n\n\n')
                                f.close()
            if os.path.exists(DUMMYAPK):  addDir('%s[COLOR %s](Settings.xml txt)[/COLOR]' % (bullet, COLOR7),  'apktxt', name='*Apk Installer [COLOR %s](Settings.xml txt)[/COLOR]' % COLOR7,  url=DUMMYAPK,  description='Install Kodi addons from an offline txt file.',icon=ICONAPKS, themeit=THEME1)

    #addDir('Official SPMC Apk\'s', 'apkscrape', 'spmc', icon=ICONSPMC, themeit=THEME1)
    addDir('Official Kodi Apk\'s', 'apkscrape', 'kodi', icon=ICONAPKS, themeit=THEME1)
    addDir("%s" % 'Common Android Shortcuts', 'apkmaintmenu', url='none', description='Common Android Shortcuts to various settings and paths', icon=ICONAPKS, fanart=FANART, themeit=THEME1)
    setView('files', 'viewType')
def apktxt(name=None, url=None, view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **APK MENU**', level=xbmc.LOGNOTICE)
    # online txt
    if not url in ['http://', 'https://', '']:
        # no url fallback to main online txt
        if url == None:
            TEMPAPKFILE = uservar.APKFILE
            APKWORKING  = wiz.workingURL(TEMPAPKFILE)
            if APKWORKING == True:
                addFile('Online txt -  %s' % name, 'refresh', description=TEMPAPKFILE,  fanart=FANART, icon=ICONAPKS, themeit=THEME6)
                link = wiz.openURL(TEMPAPKFILE).replace('\n','').replace('\r','').replace('\t','')
        # url online txt
        else:
            TEMPAPKFILE = url
            APKWORKING  = wiz.workingURL(TEMPAPKFILE)
            # add online source
            if APKWORKING == True:
                addFile('Online txt -  %s' % name, 'refresh', description=TEMPAPKFILE,  fanart=FANART, icon=ICONAPKS, themeit=THEME6)
                link = wiz.openURL(TEMPAPKFILE).replace('\n','').replace('\r','').replace('\t','')
            # add offline source
            else:
                if os.path.exists(TEMPAPKFILE):
                    addFile('Offline txt -  %s' % name, 'refresh', description=TEMPAPKFILE,  fanart=FANART, icon=ICONAPKS, themeit=THEME6)
                    link = xbmcvfs.File(TEMPAPKFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                    APKWORKING = True

        if APKWORKING == True:
            addFile('%s' % TEMPAPKFILE, '', description=TEMPAPKFILE,  fanart=FANART, icon=ICONSPACER, themeit=THEME6)
            #link = wiz.openURL(TEMPAPKFILE).replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for name, section, url, icon, fanart, adult, description in match:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    if section.lower() == 'yes':
                        x += 1
                        addDir("[B]%s[/B]" % name, 'apktxt', name, url, description=description, icon=icon, fanart=FANART, themeit=THEME3)
                    else:
                        x += 1
                        addFile(name, 'apkinstall', name, url, description=description, icon=icon, fanart=FANART, themeit=THEME2)
                    if x < 1:
                        addFile("No apks added to this menu yet!", '', themeit=THEME2)
            else: wiz.log("[APK Menu] ERROR: Invalid Format.", xbmc.LOGERROR)
        else:     wiz.log("[APK Menu] ERROR: URL for apk list not working.", xbmc.LOGERROR)
    else:  wiz.log("[Addon Menu] No Addon list added - Disabled with http://")
    setView('files', 'viewType')
def apkInstaller(apk, url):
    wiz.log(apk)
    wiz.log(url)
    if not xbmc.getCondVisibility('system.platform.android'):
        wiz.LogNotify("[COLOR %s]Not Android?[/COLOR]" % COLOR1, 'You do realize this is not an Android?')
    yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install:" % COLOR2, "\n[COLOR %s]%s[/COLOR]" % (COLOR1, apk), yeslabel="[B][COLOR green]Download[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
    if not yes:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ERROR: Install Cancelled[/COLOR]' % COLOR2); return
    display = apk
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    if not wiz.workingURL(url) == True:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]' % COLOR2); return
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, display),'', 'Please Wait')
    lib=os.path.join(PACKAGES, "%s.apk" % apk.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', ''))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    xbmc.sleep(100)
    DP.close()
    notify.apkInstaller(apk)
    wiz.ebi('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
def apkScraper(name=""):
    if name == 'kodi':
        #kodiurl1 = 'http://mirrors.kodi.tv/releases/android/arm/'
        #kodiurl2 = 'http://mirrors.kodi.tv/releases/android/arm/old/'
        url1 = wiz.openURL(kodiurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        url2 = wiz.openURL(kodiurl2).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url1)
        match2 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url2)
        addFile("Official Kodi Apk\'s", themeit=THEME1)
        rc = False
        for url, name, size, date in match1:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1 and rc == True: continue
            try:
                tempname = name.split('-')
                if not url.find('_') == -1:
                    rc = True
                    name2, v2 = tempname[2].split('_')
                else: 
                    name2 = tempname[2]
                    v2 = ''
                title = "[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], v2.upper(), name2, COLOR2, size.replace(' ', ''), COLOR1, date)
                download = urljoin(kodiurl1, url)
                addFile(title, 'apkinstall', "%s v%s%s %s" % (tempname[0].title(), tempname[1], v2.upper(), name2), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
        for url, name, size, date in match2:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1: continue
            try:
                tempname = name.split('-')
                title = "[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], tempname[2], COLOR2, size.replace(' ', ''), COLOR1, date)
                download = urljoin(kodiurl2, url)
                addFile(title, 'apkinstall', "%s v%s %s" % (tempname[0].title(), tempname[1], tempname[2]), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
        if x == 0: addFile("Error Kodi Scraper Is Currently Down.")
    elif name == 'spmc':
        #spmcurl1 = 'https://github.com/koying/SPMC/releases'
        url1 = wiz.openURL(spmcurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall(url1)
        addFile("Official SPMC Apk\'s", icon=ICONSPMC, themeit=THEME1)
        for name, urls in match1:
            tempurl = ''
            match2 = re.compile('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall(urls)
            for apkurl, apksize, apkname in match2:
                if apkname.find('armeabi') == -1: continue
                if apkname.find('launcher') > -1: continue
                tempurl = urljoin('https://github.com', apkurl)
                break
            if tempurl == '': continue
            try:
                name = "SPMC %s" % name
                title = "[COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, name, COLOR2, apksize.replace(' ', ''))
                download = tempurl
                addFile(title, 'apkinstall', name, download)
                x += 1
            except Exception, e:
                wiz.log("Error on: %s / %s" % (name, str(e)))
        if x == 0: addFile("Error SPMC Scraper Is Currently Down.")
def apkindex_maint(url=None):
    # Common Android Paths
    addFile('Android Application Manager', 'androidappmanager', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    addFile('Android Kodi Settings', 'androidkodisettings', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    addFile('Android Apps', 'androidapps', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    #addFile('Android Programs', 'androidprograms', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    #addFile('Android Settings', 'androidsettings', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    #addFile('Program Addons', 'androidprogramaddons', fanart=FANART, icon=ICONAPKS, themeit=THEME3)
    setView('files', 'viewType')

###########################
###### Menu Builds  .txt  #
###########################
def index_builds(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Build MENU**', level=xbmc.LOGNOTICE)
    #on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    # current build and theme flag
    if len(BUILDNAME) > 0:
        version = wiz.checkBuild(BUILDNAME, 'version')
        build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
        if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
        addDir(build,'viewbuild', BUILDNAME, themeit=THEME4)
        themefile = wiz.themeCount(BUILDNAME)
        if not themefile == False:  addFile('None' if BUILDTHEME == "" else BUILDTHEME, 'theme',  BUILDNAME, themeit=THEME5)
    else: addDir('None',  'builds',  description='No build installed wich is generally considered a good thing unless it is constantly updated.', icon=ICONBUILDS, themeit=THEME4)
    #
    
    ############################################################################
    ## online txt  - viewbuild  main single build file
    ############################################################################
    # BUILDNAME wip
    ENABLEBUILD  = wiz.getS('ENABLEBUILD')
    testENABLEBUILD  = 'true' if ENABLEBUILD    == 'true' else 'false'
    if ENABLEONLINE == 'true':  addFile('%s  Online Builds' % testENABLEBUILD.replace('true',on).replace('false',off), 'togglesetting', name='ENABLEBUILD', description='Turn on extra Online build paths\n%s' % BUILDFILE,  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    if ENABLEONLINE == 'true':
        if ENABLEBUILD == 'true':
            # check build online
            WORKINGURL = wiz.workingURL(BUILDFILE)
            if not WORKINGURL == True:
                addFile('Url for Online txt file not valid  %s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
            else:
                total, count15, count16, count17, count18, adultcount, hidden = wiz.buildCount()
                third = False; addin = []
                link  = wiz.openURL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"').replace('adult=""', 'adult="no"')
                match = re.compile('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                if total == 1 and third == False:
                    for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if not DEVELOPER == 'true' and wiz.strTest(name): continue
                        viewBuild(match[0][0])
                        return
                addFile('****  Online txt Builds', '', description='Online txt Builds', fanart=FANART, icon=ICON, themeit=THEME6)
                # online
                if len(match) >= 1:
                    if SEPERATE == 'true':
                        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if not DEVELOPER == 'true' and wiz.strTest(name): continue
                            menu = createMenu('install', '', name)
                            addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description='%s\n%s' % (description,url), fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
                    else:
                        if count18 > 0:
                            state = '+' if SHOW18 == 'false' else '-'
                            addFile('18 [B]%s Leia Builds(%s)[/B]' % (state, count18), 'togglesetting',  name='show18', themeit=THEME3)
                            if SHOW18 == 'true':
                                for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    if not DEVELOPER == 'true' and wiz.strTest(name): continue
                                    kodiv = int(float(kodi))
                                    if kodiv == 18:
                                        menu = createMenu('install', '', name)
                                        addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description='%s\n%s' % (description,url),  fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
                        if count17 > 0:
                            state = '+' if SHOW17 == 'false' else '-'
                            addFile('17 [B]%s Krypton Builds(%s)[/B]' % (state, count17), 'togglesetting',  name='show17', themeit=THEME3)
                            if SHOW17 == 'true':
                                for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    if not DEVELOPER == 'true' and wiz.strTest(name): continue
                                    kodiv = int(float(kodi))
                                    if kodiv == 17:
                                        menu = createMenu('install', '', name)
                                        addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description='%s\n%s' % (description,url),  fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
                        if count16 > 0:
                            state = '+' if SHOW16 == 'false' else '-'
                            addFile('16 [B]%s Jarvis Builds(%s)[/B]' % (state, count16), 'togglesetting', name='show16', themeit=THEME3)
                            if SHOW16 == 'true':
                                for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    if not DEVELOPER == 'true' and wiz.strTest(name): continue
                                    kodiv = int(float(kodi))
                                    if kodiv == 16:
                                        menu = createMenu('install', '', name)
                                        addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description='%s\n%s' % (description,url),  fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
                        if count15 > 0:
                            state = '+' if SHOW15 == 'false' else '-'
                            addFile('15 [B]%s Isengard and Below Builds(%s)[/B]' % (state, count15), 'togglesetting',  name='show15', themeit=THEME3)
                            if SHOW15 == 'true':
                                for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    if not DEVELOPER == 'true' and wiz.strTest(name): continue
                                    kodiv = int(float(kodi))
                                    if kodiv <= 15:
                                        menu = createMenu('install', '', name)
                                        addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description='%s\n%s' % (description,url), fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
                elif hidden > 0: 
                    if adultcount > 0:
                        addFile('There is currently only Adult builds', '', icon=ICONBUILDS, themeit=THEME3)
                        addFile('Enable Show Adults in Addon Settings > Misc', '', icon=ICONBUILDS, themeit=THEME3)
                    else:
                        addFile('Currently No Builds Offered from %s' % ADDONTITLE, '', icon=ICONBUILDS, themeit=THEME3)
                else: addFile('Text file for builds not formated correctly.', '', icon=ICONBUILDS, themeit=THEME3)
     
        
    
    ############################################################################
    # online third party txt menus   - viewthirdparty
    ############################################################################
    ENABLETHIRD  = wiz.getS('ENABLETHIRD')
    testENABLETHIRD  = 'true' if ENABLETHIRD  == 'true' else 'false'
    if ENABLEONLINE == 'true':  addFile('%s  Third Party Online Menu Wizards' % testENABLETHIRD.replace('true',on).replace('false',off),'togglesetting', name='ENABLETHIRD', description='Turn on extra 3rd party build paths',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    if ENABLEONLINE == 'true':
        third = False; addin = []
        if ENABLETHIRD == 'true':
            # step 1 - third menu wizardname and wizardurl  from settings
            THIRDNAME1       = wiz.getS('THIRDNAME1');THIRDURL1        = wiz.getS('THIRDURL1')
            THIRDNAME2       = wiz.getS('THIRDNAME2');THIRDURL2        = wiz.getS('THIRDURL2')
            THIRDNAME3       = wiz.getS('THIRDNAME3');THIRDURL3        = wiz.getS('THIRDURL3')
            THIRDNAME4       = wiz.getS('THIRDNAME4');THIRDURL4        = wiz.getS('THIRDURL4')
            THIRDNAME5       = wiz.getS('THIRDNAME5');THIRDURL5        = wiz.getS('THIRDURL5')
            THIRDNAME6       = wiz.getS('THIRDNAME6');THIRDURL6        = wiz.getS('THIRDURL6')
            THIRDNAME7       = wiz.getS('THIRDNAME7');THIRDURL7        = wiz.getS('THIRDURL7')
            THIRDNAME8       = wiz.getS('THIRDNAME8');THIRDURL8        = wiz.getS('THIRDURL8')
            THIRDNAME9       = wiz.getS('THIRDNAME9');THIRDURL9        = wiz.getS('THIRDURL9')
            THIRDNAME10      = wiz.getS('THIRDNAME10');THIRDURL10       = wiz.getS('THIRDURL10')
            THIRDNAME11      = wiz.getS('THIRDNAME11');THIRDURL11       = wiz.getS('THIRDURL11')
            THIRDNAME12      = wiz.getS('THIRDNAME12');THIRDURL12       = wiz.getS('THIRDURL12')
            THIRDNAME13      = wiz.getS('THIRDNAME13');THIRDURL13       = wiz.getS('THIRDURL13')
            THIRDNAME14      = wiz.getS('THIRDNAME14');THIRDURL14       = wiz.getS('THIRDURL14')
            THIRDNAME15      = wiz.getS('THIRDNAME15');THIRDURL15       = wiz.getS('THIRDURL15')
            THIRDNAME16      = wiz.getS('THIRDNAME16');THIRDURL16       = wiz.getS('THIRDURL16')
            THIRDNAME17      = wiz.getS('THIRDNAME17');THIRDURL17       = wiz.getS('THIRDURL17')
            THIRDNAME18      = wiz.getS('THIRDNAME18');THIRDURL18       = wiz.getS('THIRDURL18')
            THIRDNAME19      = wiz.getS('THIRDNAME19');THIRDURL19       = wiz.getS('THIRDURL19')
            THIRDNAME20      = wiz.getS('THIRDNAME20');THIRDURL20       = wiz.getS('THIRDURL20')
            # step 2  - corresponding entry for above
            if not THIRDURL1 == 'http://': third = True; addin.append('1')
            if not THIRDURL2 == 'http://': third = True; addin.append('2')
            if not THIRDURL3 == 'http://': third = True; addin.append('3')
            if not THIRDURL4 == 'http://': third = True; addin.append('4')
            if not THIRDURL5 == 'http://': third = True; addin.append('5')
            if not THIRDURL6 == 'http://': third = True; addin.append('6')
            if not THIRDURL7 == 'http://': third = True; addin.append('7')
            if not THIRDURL8 == 'http://': third = True; addin.append('8')
            if not THIRDURL9 == 'http://': third = True; addin.append('9')
            if not THIRDURL10 == 'http://': third = True; addin.append('10')
            if not THIRDURL11 == 'http://': third = True; addin.append('11')
            if not THIRDURL12 == 'http://': third = True; addin.append('12')
            if not THIRDURL13 == 'http://': third = True; addin.append('13')
            if not THIRDURL14 == 'http://': third = True; addin.append('14')
            if not THIRDURL15 == 'http://': third = True; addin.append('15')
            if not THIRDURL16 == 'http://': third = True; addin.append('16')
            if not THIRDURL17 == 'http://': third = True; addin.append('17')
            if not THIRDURL18 == 'http://': third = True; addin.append('18')
            if not THIRDURL19 == 'http://': third = True; addin.append('19')
            if not THIRDURL20 == 'http://': third = True; addin.append('20')
            xbmc.log(msg='##['+ADDON_ID+'] **Build 3rd party**', level=xbmc.LOGNOTICE)
            if third == True:
                for item in addin:
                    name = eval('THIRDNAME%s' % item)
                    url  = eval('THIRDURL%s' % item)
                    addDir ("[B]%s[/B]" % name, 'viewthirdparty', name, url, description='3rd party '+url, icon=ICONBUILDS, themeit=THEME1)
            # edit wizards
            if third == True:
                for item in addin:
                    #name = eval('THIRD%sNAME' % item)
                    name = eval('THIRDNAME%s' % item)
                    #url  = eval('THIRDURL%s' % item)
                    addFile('Edit Third Party Wizard: [COLOR %s]%s[/COLOR]' % (COLOR2, name), 'editthird', name=name, url=item, icon=ICONBUILDS, themeit=THEME3)
        

    ############################################################################
    ## offline txts wip
    ############################################################################
    #if ENABLEOFFLINE == 'true':

                    

    ############################################################################
    ## built in Builds from Settings (no txt)    - installoffline     wip make text
    ############################################################################
    ENABLEBUILDX = wiz.getS('ENABLEBUILDX')
    testENABLEBUILDX = 'true' if ENABLEBUILDX  == 'true' else 'false'
    if ENABLEXML == 'true':  addFile('%s  Builds from Settings (no txt)' % testENABLEBUILDX.replace('true',on).replace('false',off),'togglesetting', name='ENABLEBUILDX', description='Builds from Settings (no txt)  Online',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    if ENABLEXML == 'true':
        build = False; addin = []
        if ENABLEBUILDX == 'true':
            # step 1 -  buildname and buildurl from Settings (no txt)
            BUILDNAME1       = wiz.getS('BUILDNAME1');  BUILDURL1        = wiz.getS('BUILDURL1')
            BUILDNAME2       = wiz.getS('BUILDNAME2');  BUILDURL2        = wiz.getS('BUILDURL2')
            BUILDNAME3       = wiz.getS('BUILDNAME3');  BUILDURL3        = wiz.getS('BUILDURL3')
            BUILDNAME4       = wiz.getS('BUILDNAME4');  BUILDURL4        = wiz.getS('BUILDURL4')
            BUILDNAME5       = wiz.getS('BUILDNAME5');  BUILDURL5        = wiz.getS('BUILDURL5')
            BUILDNAME6       = wiz.getS('BUILDNAME6');  BUILDURL6        = wiz.getS('BUILDURL6')
            BUILDNAME7       = wiz.getS('BUILDNAME7');  BUILDURL7        = wiz.getS('BUILDURL7')
            BUILDNAME8       = wiz.getS('BUILDNAME8');  BUILDURL8        = wiz.getS('BUILDURL8')
            BUILDNAME9       = wiz.getS('BUILDNAME9');  BUILDURL9        = wiz.getS('BUILDURL9')
            BUILDNAME10      = wiz.getS('BUILDNAME10');BUILDURL10        = wiz.getS('BUILDURL10')
            BUILDNAME11      = wiz.getS('BUILDNAME11');BUILDURL11        = wiz.getS('BUILDURL11')
            BUILDNAME12      = wiz.getS('BUILDNAME12');BUILDURL12        = wiz.getS('BUILDURL12')
            BUILDNAME13      = wiz.getS('BUILDNAME13');BUILDURL13        = wiz.getS('BUILDURL13')
            BUILDNAME14      = wiz.getS('BUILDNAME14');BUILDURL14        = wiz.getS('BUILDURL14')
            BUILDNAME15      = wiz.getS('BUILDNAME15');BUILDURL15        = wiz.getS('BUILDURL15')
            BUILDNAME16      = wiz.getS('BUILDNAME16');BUILDURL16        = wiz.getS('BUILDURL16')
            BUILDNAME17      = wiz.getS('BUILDNAME17');BUILDURL17        = wiz.getS('BUILDURL17')
            BUILDNAME18      = wiz.getS('BUILDNAME18');BUILDURL18        = wiz.getS('BUILDURL18')
            BUILDNAME19      = wiz.getS('BUILDNAME19');BUILDURL19        = wiz.getS('BUILDURL19')
            BUILDNAME20      = wiz.getS('BUILDNAME20');BUILDURL20        = wiz.getS('BUILDURL20')
            # step 2  - correspomding entry based on above
            if not BUILDURL1 ==  'http://': build = True; addin.append('1')
            if not BUILDURL2 ==  'http://': build = True; addin.append('2')
            if not BUILDURL3 ==  'http://': build = True; addin.append('3')
            if not BUILDURL4 ==  'http://': build = True; addin.append('4')
            if not BUILDURL5 ==  'http://': build = True; addin.append('5')
            if not BUILDURL6 ==  'http://': build = True; addin.append('6')
            if not BUILDURL7 ==  'http://': build = True; addin.append('7')
            if not BUILDURL8 ==  'http://': build = True; addin.append('8')
            if not BUILDURL9 ==  'http://': build = True; addin.append('9')
            if not BUILDURL10 == 'http://': build = True; addin.append('10')
            if not BUILDURL11 == 'http://': build = True; addin.append('11')
            if not BUILDURL12 == 'http://': build = True; addin.append('12')
            if not BUILDURL13 == 'http://': build = True; addin.append('13')
            if not BUILDURL14 == 'http://': build = True; addin.append('14')
            if not BUILDURL15 == 'http://': build = True; addin.append('15')
            if not BUILDURL16 == 'http://': build = True; addin.append('16')
            if not BUILDURL17 == 'http://': build = True; addin.append('17')
            if not BUILDURL18 == 'http://': build = True; addin.append('18')
            if not BUILDURL19 == 'http://': build = True; addin.append('19')
            if not BUILDURL20 == 'http://': build = True; addin.append('20')
            xbmc.log(msg='##['+ADDON_ID+'] **Builds from Settings (no txt)**', level=xbmc.LOGNOTICE)
            if build == True:
                for item in addin:
                    name = eval('BUILDNAME%s' % item)
                    url  = eval('BUILDURL%s' % item)
                    if not url == 'http://':  addFile(name, 'installoffline',  name=name,  url=url, description='BuiltIn Zip Build  '+url, fanart=FANART, icon=ICON, themeit=THEME2)



    #
    # Builtin Zips                          - installofflineFULL -  installoffline - installofflinetheme
    BUILTINZIPS      = wiz.getS('enablebuiltinzips')
    builtinzipsdirect = 'true' if BUILTINZIPS  == 'true' else 'false'
    if ENABLEXML == 'true':  addFile('%s  Zips from Settings (no txt)  Online or Offline' % builtinzipsdirect.replace('true',on).replace('false',off),'togglesetting', name='enablebuiltinzips', description='Builds from Settings (no txt)  Online\n%s' % ADDONFILE,  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    if ENABLEXML == 'true':
        if BUILTINZIPS == 'true':
            # step 2 - run zips
            addFile('ALL Zips  %s' % versionbuiltin,                           'installofflineFULL', name=url_addons_repo,    url=zips_url+url_addons_repo,    description='Install all BuiltIn Zips as a build', fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_video == 'http://':   addFile(url_addons_video,  'installoffline',     name=url_addons_video,   url=zips_url+url_addons_video,   description='BuiltIn Zip Build  '+url_addons_video, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_repo == 'http://':    addFile(url_addons_repo,   'installoffline',     name=url_addons_repo,    url=zips_url+url_addons_repo,    description='BuiltIn Zip Build  '+url_addons_repo, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_audio == 'http://':   addFile(url_addons_audio,  'installoffline',     name=url_addons_audio,   url=zips_url+url_addons_audio,   description='BuiltIn Zip Build  '+url_addons_audio, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_program == 'http://': addFile(url_addons_program,'installoffline',     name=url_addons_program, url=zips_url+url_addons_program, description='BuiltIn Zip Build  '+url_addons_program, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_iptv == 'http://':    addFile(url_addons_iptv,   'installoffline',     name=url_addons_iptv,    url=zips_url+url_addons_iptv,    description='BuiltIn Zip Build  '+url_addons_iptv, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_addons_sub == 'http://':     addFile(url_addons_sub,    'installoffline',     name=url_addons_sub,     url=zips_url+url_addons_sub,     description='BuiltIn Zip Build  '+url_addons_sub, fanart=FANART, icon=ICON, themeit=THEME2)
            if not url_theme == 'http://':          addFile(url_theme,         'installofflinetheme',name=url_theme,          url=zips_url+url_theme,          description='Default BuiltIn Zip Theme:  '+url_theme, fanart=FANART, icon=ICON, themeit=THEME2)


    #
    # Themes from Settings (no txt)  Online -  self contained settings below
    #addFile('****  Themes from Settings (no txt)  Online', '', fanart=FANART, icon=ICON, themeit=THEME6)
    BUILTINZIPSTHEME = wiz.getS('enablebuiltinzipstheme')
    builtinzipsdirecttheme = 'true' if BUILTINZIPSTHEME  == 'true' else 'false'
    if ENABLEXML == 'true':  addFile('%s  Zip Themes from Settings (no txt)  Online or Offline' % builtinzipsdirecttheme.replace('true',on).replace('false',off),'togglesetting', name='enablebuiltinzipstheme', description='Builds from Settings (no txt)  Online\n%s' % ADDONFILE,  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    if ENABLEXML == 'true':  
        if BUILTINZIPSTHEME == 'true':
            addtheme = False; addin = []
            # step 1  -  THEMENAME and THEMEURL from settings
            THEMENAME1   = wiz.getS('THEMENAME1');THEMEURL1  = wiz.getS('THEMEURL1')
            THEMENAME2   = wiz.getS('THEMENAME2');THEMEURL2  = wiz.getS('THEMEURL2')
            THEMENAME3   = wiz.getS('THEMENAME3');THEMEURL3  = wiz.getS('THEMEURL3')
            THEMENAME4   = wiz.getS('THEMENAME4');THEMEURL4  = wiz.getS('THEMEURL4')
            THEMENAME5   = wiz.getS('THEMENAME5');THEMEURL5  = wiz.getS('THEMEURL5')
            THEMENAME6   = wiz.getS('THEMENAME6');THEMEURL6  = wiz.getS('THEMEURL6')
            THEMENAME7   = wiz.getS('THEMENAME7');THEMEURL7  = wiz.getS('THEMEURL7')
            THEMENAME8   = wiz.getS('THEMENAME8');THEMEURL8  = wiz.getS('THEMEURL8')
            THEMENAME9   = wiz.getS('THEMENAME9');THEMEURL9  = wiz.getS('THEMEURL9')
            # step 2  -  corresponding entry based on above
            if not THEMEURL1 == 'http://': addtheme = True; addin.append('1')
            if not THEMEURL2 == 'http://': addtheme = True; addin.append('2')
            if not THEMEURL3 == 'http://': addtheme = True; addin.append('3')
            if not THEMEURL4 == 'http://': addtheme = True; addin.append('4')
            if not THEMEURL5 == 'http://': addtheme = True; addin.append('5')
            if not THEMEURL6 == 'http://': addtheme = True; addin.append('6')
            if not THEMEURL7 == 'http://': addtheme = True; addin.append('7')
            if not THEMEURL8 == 'http://': addtheme = True; addin.append('8')
            if not THEMEURL9 == 'http://': addtheme = True; addin.append('9')
            xbmc.log(msg='##['+ADDON_ID+'] **Direct theme zip**', level=xbmc.LOGNOTICE)
            if addtheme == True:
                for item in addin:
                    name = eval('THEMENAME%s' % item)
                    url  = eval('THEMEURL%s' % item)
                    if not url == 'http://':  addFile(name, 'installofflinetheme', name=name, url=url, description='BuiltIn Zip Theme  '+url, fanart=FANART, icon=ICON, themeit=THEME2)


    #
    addDir ('RomPacks',           'rompacks',         description='Install Emulator roms.  Totally experimental.', icon=ICONADDONS, themeit=THEME1)
    addDir('Restore Your Backup  (Zip of Addons)',    'indexrestore',    description='Builtin pre fabricated builds or zips of preset Kodi configurations', icon=ICONBUILDS, themeit=THEME1)
    #addDir ('Save Data Menu',      'savedata',        icon=ICONSAVE,     themeit=THEME1)
    addFile('Fresh Start',         'freshstart',      description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART,themeit=THEME7)
    setView('files', 'viewType')
def buildWizard(name, type, theme=None, over=False):
    if over == False:
        testbuild = wiz.checkBuild(name, 'url')
        if testbuild == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Unabled to find build[/COLOR]" % COLOR2)
            return
        testworking = wiz.workingURL(testbuild)
        if testworking == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Build Zip Error: %s[/COLOR]" % (COLOR2, testworking))
            return
    if type == 'gui':
        if name == BUILDNAME:
            if over == True: yes = 1
            else: yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to apply the guifix for:' % COLOR2, '[COLOR %s]%s[/COLOR]?[/COLOR]' % (COLOR1, name), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        else: 
            yes = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, "[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed." % (COLOR2, COLOR1, name), "Would you like to apply the guiFix anyways?.[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        if yes:
            buildzip = wiz.checkBuild(name,'gui')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]' % COLOR2); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading GuiFix:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
            DP.update(0, title,'', 'Please Wait')
            extract.all(lib,USERDATA,DP, title=title)
            DP.close()
            wiz.defaultSkin()
            wiz.lookandFeelData('save')
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Gui fix has been installed.  Would you like to Reload the profile or Force Close Kodi?[/COLOR]" % COLOR2, yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix()
            else: DIALOG.ok(ADDONTITLE, "[COLOR %s]To save changes you now need to force close Kodi, Press OK to force close Kodi[/COLOR]" % COLOR2); wiz.killxbmc('true')
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Cancelled![/COLOR]' % COLOR2)
    elif type == 'fresh':
        freshStart(name)
    elif type == 'normal':
        if url == 'normal':
            if KEEPTRAKT == 'true':
                traktit.autoUpdate('all')
                wiz.setS('traktlastsave', str(THREEDAYS))
            if KEEPREAL == 'true':
                debridit.autoUpdate('all')
                wiz.setS('debridlastsave', str(THREEDAYS))
            if KEEPLOGIN == 'true':
                loginit.autoUpdate('all')
                wiz.setS('loginlastsave', str(THREEDAYS))
        temp_kodiv = int(KODIV); buildv = int(float(wiz.checkBuild(name, 'kodi')))
        if not temp_kodiv == buildv: 
            if temp_kodiv == 16 and buildv <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            yes_pressed = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, '[COLOR %s]There is a chance that the skin will not appear correctly' % COLOR2, 'When installing a %s build on a Kodi %s install' % (wiz.checkBuild(name, 'kodi'), KODIV), 'Would you still like to install: [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        else:
            if not over == False: yes_pressed = 1
            else: yes_pressed = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to Download and Install:' % COLOR2, '[COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        if yes_pressed:
            wiz.clearS('build')
            # xml
            XML_All()
            buildzip = wiz.checkBuild(name, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Build Install: Invalid Zip Url![/COLOR]' % COLOR2); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version')),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            if int(float(percent)) > 0:
                wiz.fixmetas()
                wiz.lookandFeelData('save')
                wiz.defaultSkin()
                #wiz.addonUpdates('set')
                wiz.setS('buildname', name)
                wiz.setS('buildversion', wiz.checkBuild( name,'version'))
                wiz.setS('buildtheme', '')
                wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                wiz.setS('lastbuildcheck', str(NEXTCHECK))
                wiz.setS('installed', 'true')
                wiz.setS('extract', str(percent))
                wiz.setS('errors', str(errors))
                wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
                try: os.remove(lib)
                except: pass
                if int(float(errors)) > 0:
                    yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild( name,'version')), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]', yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
                    if yes:
                        if isinstance(errors, unicode):
                            error = error.encode('utf-8')
                        wiz.TextBox(ADDONTITLE, error)
                DP.close()
                themefile = wiz.themeCount(name)
                if not themefile == False:
                    buildWizard(name, 'theme')
                # RTMP
                if KODIV >= 17: EnableRTMP()
                # DONE
                wiz.clearPackages()#; wiz.refresh()
                _notify('Done','Done Installing',ICON)
                if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
                if INSTALLMETHOD == 1: todo = 1
                elif INSTALLMETHOD == 2: todo = 0
                else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
                if todo == 1: wiz.reloadFix()
                else: wiz.killxbmc(True)
            else:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox("%s: Error Installing Build" % ADDONTITLE, error)
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Build Install: Cancelled![/COLOR]' % COLOR2)
    elif type == 'theme':
        if theme == None:
            themefile = wiz.checkBuild(name, 'theme')
            themelist = []
            if not themefile == 'http://' and wiz.workingURL(themefile) == True:
                themelist = wiz.themeCount(name, False)
                if len(themelist) > 0:
                    if DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes" % (COLOR2, COLOR1, name, COLOR1, len(themelist)), "Would you like to install one now?[/COLOR]", yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]"):
                        wiz.log("Theme List: %s " % str(themelist))
                        ret = DIALOG.select(ADDONTITLE, themelist)
                        wiz.log("Theme install selected: %s" % ret)
                        if not ret == -1: theme = themelist[ret]; installtheme = True
                        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
            else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: None Found![/COLOR]' % COLOR2)
        else: installtheme = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to install the theme:' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, theme), 'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
        if installtheme:
            themezip = wiz.checkTheme(name, theme, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(themezip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]' % COLOR2); return False
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(themezip, lib, DP)
            xbmc.sleep(500)
            DP.update(0,"", "Installing %s " % name)
            test = False
            if url not in ["fresh", "normal"]:
                test = testTheme(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                test2 = testGui(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                if test == True:
                    wiz.lookandFeelData('save')
                    skin     = 'skin.confluence' if KODIV < 17 else 'skin.estuary'
                    gotoskin = xbmc.getSkinDir()
                    #if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Installing the theme [COLOR %s]%s[/COLOR] requires the skin to be swaped back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, theme, COLOR1, skin[5:]), "Would you like to switch the skin?[/COLOR]", yeslabel="[B][COLOR green]Switch Skin[/COLOR][/B]", nolabel="[B][COLOR red]Don't Switch[/COLOR][/B]"):
                    skinSwitch.swapSkins(skin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)
                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                    xbmc.sleep(500)
            title = '[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme)
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            wiz.setS('buildtheme', theme)
            wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
            DP.close()
            if url not in ["fresh", "normal"]: 
                wiz.forceUpdate()
                if KODIV >= 17: wiz.kodi17Fix()
                if test2 == True:
                    wiz.lookandFeelData('save')
                    wiz.defaultSkin()
                    gotoskin = wiz.getS('defaultskin')
                    skinSwitch.swapSkins(gotoskin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)

                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    wiz.lookandFeelData('restore')
                elif test == True:
                    skinSwitch.swapSkins(gotoskin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)

                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                    wiz.lookandFeelData('restore')
                else:
                    wiz.ebi("ReloadSkin()")
                    xbmc.sleep(1000)
                    wiz.ebi("Container.Refresh") 
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2)
def viewBuild(name):
    WORKINGURL = wiz.workingURL(BUILDFILE)
    if not WORKINGURL == True:
        addFile('Url for txt file not valid', '', themeit=THEME3)
        addFile('%s' % WORKINGURL, '', themeit=THEME3)
        return
    if wiz.checkBuild(name, 'version') == False: 
        addFile('Error reading the txt file.', '', themeit=THEME3)
        addFile('%s was not found in the builds list.' % name, '', themeit=THEME3)
        return
    link = wiz.openURL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"')
    match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % name).findall(link)
    for version, url, gui, kodi, themefile, icon, fanart, preview, adult, description in match:
        icon        = icon   if wiz.workingURL(icon)   else ICON
        fanart      = fanart if wiz.workingURL(fanart) else FANART
        build       = '%s (v%s)' % (name, version)
        if BUILDNAME == name and version > BUILDVERSION:
            build = '%s [COLOR red][CURRENT v%s][/COLOR]' % (build, BUILDVERSION)
        addFile(build, '', description=description, fanart=fanart, icon=icon, themeit=THEME4)
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
        addDir ('Save Data Menu',       'savedata', icon=ICONSAVE,     themeit=THEME1)
        addFile('Build Information',    'buildinfo', name, description=description, fanart=fanart, icon=icon, themeit=THEME3)
        if not preview == "http://": addFile('View Video Preview', 'buildpreview', name, description=description, fanart=fanart, icon=icon, themeit=THEME3)
        temp1 = int(float(KODIV)); temp2 = int(float(kodi))
        if not temp1 == temp2: 
            if temp1 == 16 and temp2 <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            addFile('[I]Build designed for kodi version %s(installed: %s)[/I]' % (str(kodi), str(KODIV)), '', fanart=fanart, icon=icon, themeit=THEME3)
        addFile(wiz.sep('INSTALL'), '', fanart=fanart, icon=icon, themeit=THEME6)
        addFile('Fresh Install'   , 'install', name, 'fresh'  , description=description, fanart=fanart, icon=icon, themeit=THEME3)
        addFile('Standard Install', 'install', name, 'normal' , description=description, fanart=fanart, icon=icon, themeit=THEME3)
        if not gui == 'http://': addFile('Apply guiFix'    , 'install', name, 'gui'     , description=description, fanart=fanart, icon=icon, themeit=THEME3)
        if not themefile == 'http://':
            if wiz.workingURL(themefile) == True:
                addFile(wiz.sep('THEMES'), '', fanart=fanart, icon=icon, themeit=THEME6)
                link  = wiz.openURL(themefile).replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                for themename, themeurl, themeicon, themefanart, themeadult, description in match:
                    if not SHOWADULT == 'true' and themeadult.lower() == 'yes': continue
                    themeicon   = themeicon   if themeicon   == 'http://' else icon
                    themefanart = themefanart if themefanart == 'http://' else fanart
                    addFile(themename if not themename == BUILDTHEME else "[B]%s (Installed)[/B]" % themename, 'theme', name, themename, description=description, fanart=themefanart, icon=themeicon, themeit=THEME3)
    setView('files', 'viewType')
def thirdPartyInstall(name, url):
    xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall', level=xbmc.LOGNOTICE)
    if not wiz.workingURL(url):  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Invalid URL for 3rd party Build[/COLOR]' % COLOR2); return
    type = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]" % (COLOR2, COLOR1, COLOR1), "[COLOR %s]%s[/COLOR]" % (COLOR1, name), yeslabel="[B][COLOR green]Fresh Install[/COLOR][/B]", nolabel="[B][COLOR red]Normal Install[/COLOR][/B]")
    if type == 1:  freshStart('third', True)
    wiz.clearS('build')
    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
    lib=os.path.join(PACKAGES, '%s.zip' % zipname)
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    xbmc.sleep(500)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
    DP.update(0, title,'', 'Please Wait')
    percent, errors, error = extract.all(lib,HOME,DP, title=title)
    if int(float(percent)) > 0:
        wiz.fixmetas()
        wiz.lookandFeelData('save')
        wiz.defaultSkin()
        #wiz.addonUpdates('set')
        wiz.setS('installed', 'true')
        wiz.setS('extract', str(percent))
        wiz.setS('errors', str(errors))
        wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
        try: os.remove(lib)
        except: pass
        if int(float(errors)) > 0:
            yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
            if yes:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox(ADDONTITLE, error)
    DP.close()
    if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
    if INSTALLMETHOD == 1: todo = 1
    elif INSTALLMETHOD == 2: todo = 0
    else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR white]Would you like to:[/COLOR]\n[COLOR gold]Force Close[/COLOR]       (Close Kodi and enable settings)\n[COLOR gold]Reload Profile[/COLOR]   (Only Refresh skin to enable settings)", yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
    if todo == 1: wiz.reloadFix()
    else: wiz.killxbmc(True)
def viewThirdList(name, url):
    xbmc.log(msg='##['+ADDON_ID+'] viewThirdList', level=xbmc.LOGNOTICE)
    work = wiz.workingURL(url)
    if not work == True:
        addFile('[COLOR gold]Url for txt file not valid[/COLOR]', '', icon=ICONBUILDS, themeit=THEME3)
        #addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
    else:
        type, buildslist = wiz.thirdParty(url)
        addFile("Current URL Menu:  [B]%s[/B]" % name, '', themeit=THEME3)
        if type:
            for name, version, url, kodi, icon, fanart, adult, description in buildslist:
                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                addFile("[%s] %s v%s" % (kodi, name, version), 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEME2)
        else:
            for name, url, icon, fanart, description in buildslist:
                addFile(name, 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEME2)
#def editThirdParty(number):
def editThirdParty(name, number):
    #name  = eval('THIRDNAME%s' % number)
    #url   = eval('THIRDURL%s' % number)
    name   = wiz.getS('THIRDNAME%s' % number)
    url    = wiz.getS('THIRDURL%s' % number)
    name2  = wiz.getKeyboard(name, 'Enter the Name of the Wizard')
    url2   = wiz.getKeyboard(url, 'Enter the URL of the Wizard Text')
    wiz.setS('THIRDNAME%s' % number, name2)
    wiz.setS('THIRDURL%s' % number, url2)
def installoffline(name, url, type, full=False):
    xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall non online txt', level=xbmc.LOGNOTICE)
    choice = DIALOG.yesno('Do you want to install this zip?', "[COLOR %s]%s[/COLOR]" % (COLOR1, name))
    if choice == 0:
        xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall Exit Back to menu', level=xbmc.LOGNOTICE)
        return
    # main installer
    if type == 'install':
        xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall INSTALL', level=xbmc.LOGNOTICE)
        if not wiz.workingURL(url): LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Invalid URL for 3rd party Build[/COLOR]' % COLOR2); return
        type = DIALOG.yesno(ADDONTITLE, "Would you like to preform a [COLOR red]Fresh[/COLOR] or [COLOR green]Normal[/COLOR]  Install?", "[COLOR %s]%s[/COLOR]" % (COLOR1, name), yeslabel="[B][COLOR green]Fresh Install[/COLOR][/B]", nolabel="[B][COLOR red]Normal Install[/COLOR][/B]")
        if type == 1:
            xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall Run Freshstart', level=xbmc.LOGNOTICE)
            freshStart('third', True, offline=True)
            type = 0
        if type == 0:
            xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall Run Install', level=xbmc.LOGNOTICE)
            wiz.clearS('build')
            # saves
            if KEEPTRAKT == 'true':
                traktit.autoUpdate('all')
                wiz.setS('traktlastsave', str(THREEDAYS))
            if KEEPREAL == 'true':
                debridit.autoUpdate('all')
                wiz.setS('debridlastsave', str(THREEDAYS))
            if KEEPLOGIN == 'true':
                loginit.autoUpdate('all')
                wiz.setS('loginlastsave', str(THREEDAYS))
            # XML
            XML_All()
            
            # try offline zip
            ########################################################################1
            ISOFFLINE = xbmc.translatePath(os.path.join(MYBUILDS, name))
            if os.path.exists(ISOFFLINE):
                xbmc.log(msg='##['+ADDON_ID+'] **Zip exists offline '+ISOFFLINE, level=xbmc.LOGNOTICE)
                if DIALOG.yesno('Offline Zip Found!', '[COLOR %s]Do you wish to restore from your Zip Folder?[/COLOR]\nFile:       [COLOR gold]%s[/COLOR]\nFolder:  [COLOR gold]%s[/COLOR]' % (COLOR2,name,MYBUILDS)):
                    xbmc.log(msg='##['+ADDON_ID+'] **Zip is offline**', level=xbmc.LOGNOTICE)
                    lib=ISOFFLINE
                    DP=xbmcgui.DialogProgress()
                    DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
                    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
                    DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
                    percent, errors, error = extract.all(lib, HOME, DP, title=title)
                    #xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
                    #wiz.refresh()
                else: # dl
                    xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
                    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
                    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
                    # download zip
                    DP=xbmcgui.DialogProgress()
                    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR]  [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
                    lib=os.path.join(PACKAGES, '%s.zip' % zipname)
                    try: os.remove(lib)
                    except: pass
                    downloader.download(url, lib, DP)
                    xbmc.sleep(500)
                    ########################################################################2
                    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, zipname)
                    DP.update(0, title,'', 'Please Wait')
                    percent, errors, error = extract.all(lib,HOME,DP, title=title)
                    if int(float(percent)) > 0:
                        wiz.fixmetas()
                        wiz.lookandFeelData('save')
                        wiz.defaultSkin()
                        # test
                        wiz.setS('buildname', name)
                        wiz.setS('buildversion', wiz.checkBuild( name,'version'))
                        wiz.setS('buildtheme', '')
                        wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                        wiz.setS('lastbuildcheck', str(NEXTCHECK))
                        
                        #wiz.addonUpdates('set')
                        wiz.setS('installed', 'true')
                        wiz.setS('extract', str(percent))
                        wiz.setS('errors', str(errors))
                        wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
                        #try: os.remove(lib)
                        #except: pass
                        if int(float(errors)) > 0:
                            yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
                            if yes:
                                if isinstance(errors, unicode):
                                    error = error.encode('utf-8')
                                wiz.TextBox(ADDONTITLE, error)
                    DP.close()
            else: # dl
                ########################################################################1
                xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
                zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
                if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
                # download zip
                DP=xbmcgui.DialogProgress()
                DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR]  [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
                lib=os.path.join(PACKAGES, '%s.zip' % zipname)
                try: os.remove(lib)
                except: pass
                downloader.download(url, lib, DP)
                xbmc.sleep(500)
                ########################################################################2
                title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
                DP.update(0, title,'', 'Please Wait')
                percent, errors, error = extract.all(lib,HOME,DP, title=title)
                if int(float(percent)) > 0:
                    wiz.fixmetas()
                    wiz.lookandFeelData('save')
                    wiz.defaultSkin()
                    # test
                    wiz.setS('buildname', name)
                    wiz.setS('buildversion', wiz.checkBuild( name,'version'))
                    wiz.setS('buildtheme', '')
                    wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                    wiz.setS('lastbuildcheck', str(NEXTCHECK))
                    
                    #wiz.addonUpdates('set')
                    wiz.setS('installed', 'true')
                    wiz.setS('extract', str(percent))
                    wiz.setS('errors', str(errors))
                    wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
                    #try: os.remove(lib)
                    #except: pass
                    if int(float(errors)) > 0:
                        yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
                        if yes:
                            if isinstance(errors, unicode):
                                error = error.encode('utf-8')
                            wiz.TextBox(ADDONTITLE, error)
                DP.close()
                
            ########################################################################3
            # if full download other zips
            if full == True:
                xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall INSTALL Full', level=xbmc.LOGNOTICE)
                try:  PATH_ADDON(url_addons_audio, zips_url+url_addons_audio, HOME)
                except: pass
                try:  PATH_ADDON(url_addons_video, zips_url+url_addons_video, HOME)
                except: pass
                if DIALOG.yesno('Free IPTV?', 'Do you want LiveTV (IPTV)?','Free IPTV', 'Unpredictable'):
                    try:  PATH_ADDON(url_addons_iptv, zips_url+url_addons_iptv, HOME)
                    except: pass
                    if DIALOG.yesno('Paid IPTV Subscriptions?', 'Do you pay for LiveTV (IPTV)?','Vader and IPTVSubs', 'Stable'):
                        try:  PATH_ADDON(url_addons_sub, zips_url+url_addons_sub, HOME)
                        except: pass
                if DIALOG.yesno('Restore Programs?', 'Restore Program Addons?','These are programs like trakt that help manage your local library, but are unneeded if you primarily stream things', 'Answer yes if you dont care.'):
                    try: PATH_ADDON(url_addons_program, zips_url+url_addons_program, HOME)
                    except: pass
            # theme
            '''
            xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstall INSTALL Try Theme', level=xbmc.LOGNOTICE)
            themefile = wiz.themeCount(name)
            if not themefile == False:
                buildWizard(name, 'theme')
                xbmc.log(msg='##['+name+'] name   thirdPartyInstall INSTALL Try online Theme', level=xbmc.LOGNOTICE)
            else:
                #installoffline(name, THEMEFILE, 'theme', full=False)
                installoffline(name, url, 'theme', full=False)
                
                xbmc.log(msg='##['+name+'] name thirdPartyInstall INSTALL Try offline Theme', level=xbmc.LOGNOTICE)
                xbmc.log(msg='##['+url+'] file thirdPartyInstall INSTALL Try offline Theme',  level=xbmc.LOGNOTICE)
            '''
            installofflineTheme(url_theme, zips_url+url_theme)
            
            #try: PATH_ADDON(url_guisettings_18, zips_url+url_guisettings_18, USERDATA)
            #except: pass
            # gui
            #try: PATH_ADDON(url_theme_18, zips_url+url_theme_18, HOME)
            #except: pass
            #if xbmc.getCondVisibility('system.platform.android'): PATH_ADDON('Addons_Android.zip', zips_url+url_addons_program_android, xbmc.translatePath(os.path.join('special://home','addons')))
            #if xbmc.getCondVisibility('system.platform.windows'): PATH_ADDON('Addons_Windows.zip', zips_url+url_addons_program_windows, xbmc.translatePath(os.path.join('special://home','addons')))
            if KODIV >= 17: EnableRTMP()
            wiz.clearPackages()#; wiz.refresh()
            _notify('Done','Done Installing',ICON)
            # DONE
            if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR white]Would you like to:[/COLOR]\n[COLOR gold]Force Close[/COLOR]       (Close Kodi and enable settings)\n[COLOR gold]Reload Profile[/COLOR]   (Only Refresh skin to enable settings)", yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix()
            else: wiz.killxbmc(True)
def installofflineTheme(name, themezip):
    xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstallOffline  theme', level=xbmc.LOGNOTICE)
    #DIALOG.yesno(ADDONTITLE, "thirdPartyInstallOffline  theme", yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
    installtheme = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to install the theme:' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, name), yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
    if installtheme:
        xbmc.log(msg='##['+ADDON_ID+'] thirdPartyInstallOffline  is theme -  gooooo', level=xbmc.LOGNOTICE)
        #themezip = wiz.checkTheme(name, theme, 'url')
        #zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
        if not wiz.workingURL(themezip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]' % COLOR2); return False
        zipname = name
        if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
        DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
        lib=os.path.join(PACKAGES, '%s.zip' % zipname)
        try: os.remove(lib)
        except: pass
        downloader.download(themezip, lib, DP)
        xbmc.sleep(500)
        DP.update(0,"", "Installing %s " % name)
        test = False
        if url not in ["fresh", "normal"]:
            test = testTheme(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
            test2 = testGui(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
            if test == True:
                wiz.lookandFeelData('save')
                skin     = 'skin.confluence' if KODIV < 17 else 'skin.estuary'
                gotoskin = xbmc.getSkinDir()
                #if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Installing the theme [COLOR %s]%s[/COLOR] requires the skin to be swaped back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, theme, COLOR1, skin[5:]), "Would you like to switch the skin?[/COLOR]", yeslabel="[B][COLOR green]Switch Skin[/COLOR][/B]", nolabel="[B][COLOR red]Don't Switch[/COLOR][/B]"):
                skinSwitch.swapSkins(skin)
                x = 0
                xbmc.sleep(1000)
                while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                    x += 1
                    xbmc.sleep(200)
                if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                    wiz.ebi('SendClick(11)')
                else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                xbmc.sleep(500)
        title = '[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
        DP.update(0, title,'', 'Please Wait')
        percent, errors, error = extract.all(lib,HOME,DP, title=title)
        wiz.setS('buildtheme', name)
        wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
        DP.close()
        if url not in ["fresh", "normal"]: 
            wiz.forceUpdate()
            if KODIV >= 17: wiz.kodi17Fix()
            if test2 == True:
                wiz.lookandFeelData('save')
                wiz.defaultSkin()
                gotoskin = wiz.getS('defaultskin')
                skinSwitch.swapSkins(gotoskin)
                x = 0
                xbmc.sleep(1000)
                while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                    x += 1
                    xbmc.sleep(200)
                if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                    wiz.ebi('SendClick(11)')
                wiz.lookandFeelData('restore')
            elif test == True:
                skinSwitch.swapSkins(gotoskin)
                x = 0
                xbmc.sleep(1000)
                while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                    x += 1
                    xbmc.sleep(200)
                if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                    wiz.ebi('SendClick(11)')
                else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                wiz.lookandFeelData('restore')
            else:
                wiz.ebi("ReloadSkin()")
                xbmc.sleep(1000)
                wiz.ebi("Container.Refresh") 
    else:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2)
def PATH_ADDON(name, url, dest):
    ISOFFLINE = xbmc.translatePath(os.path.join(MYBUILDS, name))
    if os.path.exists(ISOFFLINE):
        xbmc.log(msg='##['+ADDON_ID+'] **Zip exists offline '+ISOFFLINE, level=xbmc.LOGNOTICE)
        if DIALOG.yesno('Offline Zip Found!', '[COLOR %s]Do you wish to restore from your Zip Folder?[/COLOR]\nFile:       [COLOR gold]%s[/COLOR]\nFolder:  [COLOR gold]%s[/COLOR]' % (COLOR2,name,MYBUILDS)):
            xbmc.log(msg='##['+ADDON_ID+'] **Zip is offline**', level=xbmc.LOGNOTICE)
            DP=xbmcgui.DialogProgress()
            DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
            DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
            percent, errors, error = extract.all(ISOFFLINE, dest, DP, title=title)
            xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
            wiz.refresh()
        else: # dl
            xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
            DP=xbmcgui.DialogProgress()
            DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
            lib=os.path.join(PACKAGES,name)
            try: os.remove(lib)
            except: pass
            if str(url).endswith('[error]'):
                print url; dialog=xbmcgui.Dialog()
                DIALOG.ok("Error!",url)
                return
            if '[error]' in url:
                print url; dialog=xbmcgui.Dialog()
                DIALOG.ok("Error!",url)
                return
            downloader.download(url, lib, DP)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
            DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
            percent, errors, error = extract.all(lib, dest, DP, title=title)
            try: os.remove(lib)
            except: pass
            #xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
            #wiz.refresh()
    else: # dl
        xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
        DP=xbmcgui.DialogProgress()
        DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
        lib=os.path.join(PACKAGES,name)
        try: os.remove(lib)
        except: pass
        if str(url).endswith('[error]'):
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
        if '[error]' in url:
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
        downloader.download(url, lib, DP)
        title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
        DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
        percent, errors, error = extract.all(lib, dest, DP, title=title)
        try: os.remove(lib)
        except: pass
def XML_All():
    doWriterss()
    if not os.path.isfile(SOURCES):     doWritesources()
    if not os.path.isfile(PLAYERCORE):  doWriteplayerfactorycore()
    if not os.path.isfile(ADVANCED):    showAutoAdvanced()


###########################
###### Media menu  ########
###########################
def index_media(url=None):
    addDir ('Youtube',  'youtube',    description='Play a Youtube link',icon=ICONWIN, themeit=THEME1)
    addDir ('M3U',      'indexm3u',   description='Play an m3u File',icon=ICONWIN, themeit=THEME1)
    if xbmc.getCondVisibility('Library.HasContent(TVShows) | Library.HasContent(Movies) | Library.HasContent(Music)'): addFile('VOD  (Library)', 'vodguixml', description='Open VOD'  ,icon=ICONSETTINGS, themeit=THEME1)
    else :  addFile('VOD  [COLOR red](Library)[/COLOR]', 'vodguixml', description='Open VOD'  ,icon=ICONSETTINGS, themeit=THEME1)
    addDir('Chrome url Launcher',  'chrome',  description='Chrome url Launcher', icon=ICONCHROME,themeit=THEME1)
    if xbmc.getCondVisibility('system.platform.windows'): addDir ('WINDOWS' ,'windows',    description='Perform a Windows task',icon=ICONWIN, themeit=THEME1)
    setView('files', 'viewType')

###########################
###### youtube .txt and m3u
###########################
def index_youtube(url=None):
    YOUTUBEENABLE  = wiz.getS('YOUTUBEENABLE')
    youtubeenable  = 'true' if YOUTUBEENABLE  == 'true' else 'false'
    addFile('%s  Youtube direct links from settings.xml' % youtubeenable.replace('true',on).replace('false',off),'togglesetting', name='YOUTUBEENABLE', description='Turn on Youtube direct links',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEME9)
    if youtubeenable == 'true':
        #addFile('[COLOR limegreen]Youtube[/COLOR]  [COLOR %s](Offline)[/COLOR]  [COLOR white](settings.xml)[/COLOR]  ###############################################################################' % COLOR7, 'refreshaddon', description='Youtube Offline',  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
        if not wiz.getS('YOUTUBEENABLE1')  == 'false' and not wiz.getS('YOUTUBEURL1')  == 'http://': addFile(wiz.getS('YOUTUBENAME1'),  'viewVideo', url=wiz.getS('YOUTUBEURL1'),  description=wiz.getS('YOUTUBENAME1'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE2')  == 'false' and not wiz.getS('YOUTUBEURL2')  == 'http://': addFile(wiz.getS('YOUTUBENAME2'),  'viewVideo', url=wiz.getS('YOUTUBEURL2'),  description=wiz.getS('YOUTUBENAME2'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE3')  == 'false' and not wiz.getS('YOUTUBEURL3')  == 'http://': addFile(wiz.getS('YOUTUBENAME3'),  'viewVideo', url=wiz.getS('YOUTUBEURL3'),  description=wiz.getS('YOUTUBENAME3'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE4')  == 'false' and not wiz.getS('YOUTUBEURL4')  == 'http://': addFile(wiz.getS('YOUTUBENAME4'),  'viewVideo', url=wiz.getS('YOUTUBEURL4'),  description=wiz.getS('YOUTUBENAME4'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE5')  == 'false' and not wiz.getS('YOUTUBEURL5')  == 'http://': addFile(wiz.getS('YOUTUBENAME5'),  'viewVideo', url=wiz.getS('YOUTUBEURL5'),  description=wiz.getS('YOUTUBENAME5'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE6')  == 'false' and not wiz.getS('YOUTUBEURL6')  == 'http://': addFile(wiz.getS('YOUTUBENAME6'),  'viewVideo', url=wiz.getS('YOUTUBEURL6'),  description=wiz.getS('YOUTUBENAME6'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE7')  == 'false' and not wiz.getS('YOUTUBEURL7')  == 'http://': addFile(wiz.getS('YOUTUBENAME7'),  'viewVideo', url=wiz.getS('YOUTUBEURL7'),  description=wiz.getS('YOUTUBENAME7'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE8')  == 'false' and not wiz.getS('YOUTUBEURL8')  == 'http://': addFile(wiz.getS('YOUTUBENAME8'),  'viewVideo', url=wiz.getS('YOUTUBEURL8'),  description=wiz.getS('YOUTUBENAME8'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE9')  == 'false' and not wiz.getS('YOUTUBEURL9')  == 'http://': addFile(wiz.getS('YOUTUBENAME9'),  'viewVideo', url=wiz.getS('YOUTUBEURL9'),  description=wiz.getS('YOUTUBENAME9'),  icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        if not wiz.getS('YOUTUBEENABLE10') == 'false' and not wiz.getS('YOUTUBEURL10') == 'http://': addFile(wiz.getS('YOUTUBENAME10'), 'viewVideo', url=wiz.getS('YOUTUBEURL10'), description=wiz.getS('YOUTUBENAME10'), icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
    #
    # youtube online txt
    YOUTUBEENABLEFILE  = wiz.getS('YOUTUBEENABLEFILE')
    youtubeenablefile  = 'true' if YOUTUBEENABLEFILE  == 'true' else 'false'
    addFile('%s  Youtube  Online  txt' % youtubeenablefile.replace('true',on).replace('false',off),'togglesetting', name='YOUTUBEENABLEFILE', description='Youtube Online  txt',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEME9)
    if youtubeenablefile == 'true':
        if not YOUTUBEFILE == 'http://':
            if url == None:
                YOUTUBEWORKING  = wiz.workingURL(YOUTUBEFILE)
                TEMPYOUTUBEFILE = uservar.YOUTUBEFILE
            else:
                YOUTUBEWORKING  = wiz.workingURL(url)
                TEMPYOUTUBEFILE = url
            if YOUTUBEWORKING == True:
                link = wiz.openURL(TEMPYOUTUBEFILE).replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
                #addFile('[COLOR limegreen]Youtube[/COLOR]  [COLOR %s](Online)[/COLOR]   [COLOR white]txt[/COLOR]  ####################################################################################' % COLOR6, 'refreshaddon', description='Youtube Online',  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
                if len(match) > 0:
                    for name, section, url, icon, fanart, description in match:
                        if section.lower() == "yes":
                            addDir ("[B]%s[/B]" % name, 'youtube', url, description=description, icon=ICONYOUTUBE, fanart=FANART, themeit=THEME1)
                        else:
                            addFile(name, 'viewVideo', url=url, description=description, icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
                else: wiz.log("[YouTube Menu] ERROR: Invalid Format.")
            else: 
                wiz.log("[YouTube Menu] ERROR: URL for YouTube list not working.")
                
    # youtube offline txt
    YOUTUBEENABLETFILE  = wiz.getS('YOUTUBEENABLETFILE')
    youtubeenabletfile  = 'true' if YOUTUBEENABLETFILE  == 'true' else 'false'
    addFile('%s  Youtube  Offline txt' % youtubeenabletfile.replace('true',on).replace('false',off),'togglesetting', name='YOUTUBEENABLETFILE', description='Youtube Offline txt',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEME9)
    if youtubeenabletfile == 'true':
        if not YOUTUBETFILE == 'http://':
            if os.path.exists(YOUTUBETFILE):
                link = xbmcvfs.File(YOUTUBETFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
                if len(match) > 0:
                    #addFile('[COLOR limegreen]Youtube[/COLOR] [COLOR %s](Offline)[/COLOR]  [COLOR white]txt[/COLOR]  #######################################################################################' % COLOR7, 'refreshaddon', description='Youtube Offline',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEME6)
                    for name, section, url, icon, fanart, description in match:
                        if section.lower() == "yes":
                            addDir ("[B]%s[/B]" % name, 'youtube', url, description=description, icon=ICONYOUTUBE, fanart=FANART, themeit=THEME1)
                        else:
                            addFile(name, 'viewVideo', url=url, description=description, icon=ICONYOUTUBE, fanart=FANART, themeit=THEME3)
        else: wiz.log("[YouTube Menu] No YouTube list added.")
    setView('files', 'viewType')

###########################
###### m3u menu    ########
###########################
def index_m3u(url=None):
    #addFile('Help',  'indexhelp',  url=HELPFILE,   description='Help file from settings',  icon=ICONINFO,themeit=THEME1)
    #addDir('M3U',  'indexm3u',  url=M3UFILE,   description='Play m3u file from settings',  icon=ICONM3U,themeit=THEME1)
    M3UENABLE  = wiz.getS('M3UENABLE')
    m3uenable  = 'true' if M3UENABLE  == 'true' else 'false'
    addFile('%s  m3u direct links from settings.xml' % m3uenable.replace('true',on).replace('false',off),'togglesetting', name='M3UENABLE', description='Turn on m3u direct links',  fanart=FANART, icon=ICONM3U, themeit=THEME9)
    if m3uenable == 'true':
        #addFile('[COLOR limegreen]m3u[/COLOR]  [COLOR %s](Offline)[/COLOR]  [COLOR white](settings.xml)[/COLOR]  ###############################################################################' % COLOR7, 'refreshaddon', description='m3u Offline',  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
        if not wiz.getS('M3UENABLE1')  == 'false' and not wiz.getS('M3UURL1')  == 'http://': addFile(wiz.getS('M3UNAME1'),  'playm3u', url=wiz.getS('M3UURL1'),  description=wiz.getS('M3UNAME1'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE2')  == 'false' and not wiz.getS('M3UURL2')  == 'http://': addFile(wiz.getS('M3UNAME2'),  'playm3u', url=wiz.getS('M3UURL2'),  description=wiz.getS('M3UNAME2'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE3')  == 'false' and not wiz.getS('M3UURL3')  == 'http://': addFile(wiz.getS('M3UNAME3'),  'playm3u', url=wiz.getS('M3UURL3'),  description=wiz.getS('M3UNAME3'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE4')  == 'false' and not wiz.getS('M3UURL4')  == 'http://': addFile(wiz.getS('M3UNAME4'),  'playm3u', url=wiz.getS('M3UURL4'),  description=wiz.getS('M3UNAME4'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE5')  == 'false' and not wiz.getS('M3UURL5')  == 'http://': addFile(wiz.getS('M3UNAME5'),  'playm3u', url=wiz.getS('M3UURL5'),  description=wiz.getS('M3UNAME5'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE6')  == 'false' and not wiz.getS('M3UURL6')  == 'http://': addFile(wiz.getS('M3UNAME6'),  'playm3u', url=wiz.getS('M3UURL6'),  description=wiz.getS('M3UNAME6'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE7')  == 'false' and not wiz.getS('M3UURL7')  == 'http://': addFile(wiz.getS('M3UNAME7'),  'playm3u', url=wiz.getS('M3UURL7'),  description=wiz.getS('M3UNAME7'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE8')  == 'false' and not wiz.getS('M3UURL8')  == 'http://': addFile(wiz.getS('M3UNAME8'),  'playm3u', url=wiz.getS('M3UURL8'),  description=wiz.getS('M3UNAME8'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE9')  == 'false' and not wiz.getS('M3UURL9')  == 'http://': addFile(wiz.getS('M3UNAME9'),  'playm3u', url=wiz.getS('M3UURL9'),  description=wiz.getS('M3UNAME9'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UENABLE10') == 'false' and not wiz.getS('M3UURL10') == 'http://': addFile(wiz.getS('M3UNAME10'), 'playm3u', url=wiz.getS('M3UURL10'), description=wiz.getS('M3UNAME10'), icon=ICONM3U, fanart=FANART, themeit=THEME3)
    #
    M3UTENABLE  = wiz.getS('M3UTENABLE')
    m3utenable  = 'true' if M3UTENABLE  == 'true' else 'false'
    addFile('%s  m3u offline files from settings.xml' % m3utenable.replace('true',on).replace('false',off),'togglesetting', name='M3UTENABLE', description='Turn on m3u offline links',  fanart=FANART, icon=ICONM3U, themeit=THEME9)
    if m3utenable == 'true':
        #addFile('[COLOR limegreen]m3u[/COLOR]  [COLOR %s](Offline)[/COLOR]  [COLOR white](settings.xml)[/COLOR]  ###############################################################################' % COLOR7, 'refreshaddon', description='m3u Offline',  fanart=FANART, icon=ICONADDONS, themeit=THEME6)
        if not wiz.getS('M3UTENABLE1')  == 'false' and not wiz.getS('M3UTURL1')  == 'http://': addFile(wiz.getS('M3UTNAME1'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL1'))),  description=wiz.getS('M3UTNAME1'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE2')  == 'false' and not wiz.getS('M3UTURL2')  == 'http://': addFile(wiz.getS('M3UTNAME2'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL2'))),  description=wiz.getS('M3UTNAME2'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE3')  == 'false' and not wiz.getS('M3UTURL3')  == 'http://': addFile(wiz.getS('M3UTNAME3'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL3'))),  description=wiz.getS('M3UTNAME3'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE4')  == 'false' and not wiz.getS('M3UTURL4')  == 'http://': addFile(wiz.getS('M3UTNAME4'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL4'))),  description=wiz.getS('M3UTNAME4'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE5')  == 'false' and not wiz.getS('M3UTURL5')  == 'http://': addFile(wiz.getS('M3UTNAME5'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL5'))),  description=wiz.getS('M3UTNAME5'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE6')  == 'false' and not wiz.getS('M3UTURL6')  == 'http://': addFile(wiz.getS('M3UTNAME6'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL6'))),  description=wiz.getS('M3UTNAME6'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE7')  == 'false' and not wiz.getS('M3UTURL7')  == 'http://': addFile(wiz.getS('M3UTNAME7'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL7'))),  description=wiz.getS('M3UTNAME7'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE8')  == 'false' and not wiz.getS('M3UTURL8')  == 'http://': addFile(wiz.getS('M3UTNAME8'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL8'))),  description=wiz.getS('M3UTNAME8'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE9')  == 'false' and not wiz.getS('M3UTURL9')  == 'http://': addFile(wiz.getS('M3UTNAME9'),  'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL9'))),  description=wiz.getS('M3UTNAME9'),  icon=ICONM3U, fanart=FANART, themeit=THEME3)
        if not wiz.getS('M3UTENABLE10') == 'false' and not wiz.getS('M3UTURL10') == 'http://': addFile(wiz.getS('M3UTNAME10'), 'playm3u', url=xbmc.translatePath(os.path.join(wiz.getS('M3UTURL10'))), description=wiz.getS('M3UTNAME10'), icon=ICONM3U, fanart=FANART, themeit=THEME3)
    #
    setView('files', 'viewType')
def playm3u(url):
    xbmc.executebuiltin('ActivateWindow(10025,'+url+',return)')

# wip
###########################
###### Menu Windows # just because
###########################
def index_windows(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Windows Things MENU**', level=xbmc.LOGNOTICE)
    addFile('firefox',   'runexe', name='C:\Program Files\Mozilla Firefox\firefox.exe', url='',  description='Run Windows exe file',  icon=ICONBUILDS, themeit=THEME3)
    addFile('notepad',   'runexe', name='C:\Windows\System32\notepad.exe', url='',  description='Run Windows exe file',  icon=ICONBUILDS, themeit=THEME3)
    setView('files',  'viewType')

# wip
################################################################################
#   Record with ffmpeg
################################################################################
def run_exe(name, url):
    from subprocess import call
    from subprocess import Popen
    xbmc.log(msg='##['+ADDON_ID+'] Start 3rd Party exe', level=xbmc.LOGNOTICE)
    if os.path.exists(url):
        cmd = [url, name]
        #cmd = [ffmpeg, "-y", "-i", url, "-c:v", "copy", "-c:a", "copy", "-t", str(seconds), "-f", "mpegts", "-map", "0:v", "-map", "0:a", filename]
        #cmd = [ffmpeg, "-y", "-i", url, "-c:v", "copy", "-c:a", "copy", "-t", str(seconds), filename]
        #p = Popen(cmd,shell=True) # has NO cmd window info prompt
        p = Popen(cmd,shell=False) # has cmd window info prompt
        xbmcgui.Dialog().notification(name, url, ICON, 2000, False)
        #time.sleep(5)
        #try: xbmc.executebuiltin('PlayMedia(%s)' % filename)
        #except: pass



###########################
###### chrome Menu Items ##
###########################
def index_chrome():
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    addFile('(%s)  Kiosk Mode?' % kiosk.replace('true',on).replace('false',off), 'togglesetting', name='CHROMEKIOSK', description='Turn on Kiosk Mode',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    files = os.listdir(siteFolder)
    for file in files:
        if file.endswith(".link"):
            fh = open(os.path.join(siteFolder, file), 'r')
            title = ""
            url = ""
            thumb = ""
            #kiosk = "no"
            stopPlayback = "no"
            for line in fh.readlines():
                entry = line[:line.find("=")]
                content = line[line.find("=")+1:]
                if entry   == "title":
                    title = content.strip()
                elif entry == "url":
                    url = content.strip()
                elif entry == "thumb":
                    thumb = content.strip()
                elif entry == "kiosk":
                    kiosk = content.strip()
                elif entry == "stopPlayback":
                    stopPlayback = content.strip()
            fh.close()
            addChromeSiteDir(title, url, 'showSite', thumb, stopPlayback, kiosk)
    addFile('[ Vimeo Couchmode ]',  'showSite', name='Vimeo',    url="http://www.vimeo.com/couchmode",     description='Vimeo',       icon=ICONVIMEO,  themeit=THEME3)
    addFile('[ Youtube Leanback ]', 'showSite', name='Youtube',  url="http://www.youtube.com/leanback",    description='Youtube',     icon=ICONYOUTUBE, themeit=THEME3)
    if not wiz.getS('CHROMEURL1')  == 'http://': addFile(wiz.getS('CHROMEURL1'),  'showSite', name=wiz.getS('CHROMEURL1'),  url=wiz.getS('CHROMEURL1'),  description=wiz.getS('CHROMEURL1'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL2')  == 'http://': addFile(wiz.getS('CHROMEURL2'),  'showSite', name=wiz.getS('CHROMEURL2'),  url=wiz.getS('CHROMEURL2'),  description=wiz.getS('CHROMEURL2'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL3')  == 'http://': addFile(wiz.getS('CHROMEURL3'),  'showSite', name=wiz.getS('CHROMEURL3'),  url=wiz.getS('CHROMEURL3'),  description=wiz.getS('CHROMEURL3'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL4')  == 'http://': addFile(wiz.getS('CHROMEURL4'),  'showSite', name=wiz.getS('CHROMEURL4'),  url=wiz.getS('CHROMEURL4'),  description=wiz.getS('CHROMEURL4'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL5')  == 'http://': addFile(wiz.getS('CHROMEURL5'),  'showSite', name=wiz.getS('CHROMEURL5'),  url=wiz.getS('CHROMEURL5'),  description=wiz.getS('CHROMEURL5'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL6')  == 'http://': addFile(wiz.getS('CHROMEURL6'),  'showSite', name=wiz.getS('CHROMEURL6'),  url=wiz.getS('CHROMEURL6'),  description=wiz.getS('CHROMEURL6'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL7')  == 'http://': addFile(wiz.getS('CHROMEURL7'),  'showSite', name=wiz.getS('CHROMEURL7'),  url=wiz.getS('CHROMEURL7'),  description=wiz.getS('CHROMEURL7'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL8')  == 'http://': addFile(wiz.getS('CHROMEURL8'),  'showSite', name=wiz.getS('CHROMEURL8'),  url=wiz.getS('CHROMEURL8'),  description=wiz.getS('CHROMEURL8'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL9')  == 'http://': addFile(wiz.getS('CHROMEURL9'),  'showSite', name=wiz.getS('CHROMEURL9'),  url=wiz.getS('CHROMEURL9'),  description=wiz.getS('CHROMEURL9'),  icon=ICONCHROME, themeit=THEME3)
    if not wiz.getS('CHROMEURL10') == 'http://': addFile(wiz.getS('CHROMEURL10'), 'showSite', name=wiz.getS('CHROMEURL10'), url=wiz.getS('CHROMEURL10'), description=wiz.getS('CHROMEURL10'), icon=ICONCHROME, themeit=THEME3)
    # add another entry above and in settings.xml
    addFile('*[B]- Add Website[/B]', 'addSite',  name='Add Website',  url='',        description='Add Website to Menu.  Saves in user_data settings.', icon=ICONURL, themeit=THEME3)
    setView('files', 'viewType')
def addSite(site="", title=""):
    if site:
        filename = getFileName(title)
        content = "title="+title+"\nurl="+site+"\nthumb=DefaultFolder.png\nstopPlayback=no\nkiosk=yes"
        fh = open(os.path.join(siteFolder, filename+".link"), 'w')
        fh.write(content)
        fh.close()
        wiz.refresh()
    else:
        keyboard = xbmc.Keyboard('', 'Title')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            title = keyboard.getText()
            keyboard = xbmc.Keyboard('http://', 'URL')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                url = keyboard.getText()
                keyboard = xbmc.Keyboard('no', 'Stop XBMC playback?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
                    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
                    stopPlayback = keyboard.getText()
                    keyboard = xbmc.Keyboard(kiosk, 'Use kiosk mode?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        kiosk = keyboard.getText()
                        content = "title="+title+"\nurl="+url+"\nthumb=DefaultFolder.png\nstopPlayback="+stopPlayback+"\nkiosk="+kiosk
                        fh = open(os.path.join(siteFolder, getFileName(title)+".link"), 'w')
                        fh.write(content)
                        fh.close()
                        wiz.refresh()
                        return
    return
def getFileName(title):
    return (''.join(c for c in unicode(title, 'utf-8') if c not in '/\\:?"*|<>')).strip()
def getFullPath(path, url, useKiosk, userAgent):
    profile = ""
    if useOwnProfile:
        profile = '--user-data-dir="'+profileFolder+'" '
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    if useKiosk=="yes":
        kiosk = '--kiosk '
    if userAgent:
        userAgent = '--user-agent="'+userAgent+'" '
    return '"'+path+'" '+profile+userAgent+'--start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run '+kiosk+'"'+url+'"'
def showSite(url, stopPlayback, kiosk, userAgent):
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    if stopPlayback == "yes":
        xbmc.Player().stop()
    if xbmc.getCondVisibility('system.platform.windows'):
        path = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        path64 = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        elif os.path.exists(path64):
            fullUrl = getFullPath(path64, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    elif xbmc.getCondVisibility('system.platform.osx'):
        path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    elif xbmc.getCondVisibility('system.platform.linux'):
        path = "/usr/bin/google-chrome"
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    else : return
def removeSite(title):
    os.remove(os.path.join(siteFolder, getFileName(title)+".link"))
    wiz.refresh()
def editSite(title):
    filenameOld = getFileName(title)
    file = os.path.join(siteFolder, filenameOld+".link")
    fh = open(file, 'r')
    title = ""
    url = ""
    #kiosk = "yes"
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    thumb = "DefaultFolder.png"
    stopPlayback = "no"
    for line in fh.readlines():
        entry = line[:line.find("=")]
        content = line[line.find("=")+1:]
        if entry == "title":
            title = content.strip()
        elif entry == "url":
            url = content.strip()
        elif entry == "kiosk":
            kiosk = content.strip()
        elif entry == "thumb":
            thumb = content.strip()
        elif entry == "stopPlayback":
            stopPlayback = content.strip()
    fh.close()
    oldTitle = title
    keyboard = xbmc.Keyboard(title, 'Title')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        title = keyboard.getText()
        keyboard = xbmc.Keyboard(url, 'URL')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = keyboard.getText()
            keyboard = xbmc.Keyboard(stopPlayback, 'Stop XBMC playback?')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                stopPlayback = keyboard.getText()
                keyboard = xbmc.Keyboard(kiosk, 'Use kiosk mode?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    kiosk = keyboard.getText()
                    content = "title="+title+"\nurl="+url+"\nthumb="+thumb+"\nstopPlayback="+stopPlayback+"\nkiosk="+kiosk
                    fh = open(os.path.join(siteFolder, getFileName(title)+".link"), 'w')
                    fh.write(content)
                    fh.close()
                    if title != oldTitle:
                        os.remove(os.path.join(siteFolder, filenameOld+".link"))
    wiz.refresh()
def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict
def addChromeSiteDir(name, url, mode, iconimage, stopPlayback, kiosk):
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&stopPlayback="+urllib.quote_plus(stopPlayback)+"&kiosk="+urllib.quote_plus(kiosk)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.addContextMenuItems([('Edit Website Settings', 'RunPlugin(plugin://'+ADDON_ID+'/?mode=editSite&url='+urllib.quote_plus(name)+')',), ('Remove Website', 'RunPlugin(plugin://'+ADDON_ID+'/?mode=removeSite&url='+urllib.quote_plus(name)+')',)])
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    #wiz.refresh()
    return ok

###########################
###### Menu XML           #
###########################
def index_installxml(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **XML MENU**', level=xbmc.LOGNOTICE)
    if     os.path.isfile(ADVANCED):  addFile('[COLOR red][DELETE][/COLOR]   Advancedsettings.xml   [COLOR green][ENABLED][/COLOR]',  'delautoadvanced',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEME3)
    if not os.path.isfile(ADVANCED):  addFile('[COLOR green][INSTALL][/COLOR]  Advancedsettings.xml',                                 'autoadvanced',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEME3)
    if os.path.isfile(PLAYERCORE):    addFile('[COLOR red][DELETE][/COLOR]   playercorefactory.xml   [COLOR green][ENABLED][/COLOR]', 'delplayercorefactory', description='Install a playercorefactory.xml file to allow playing media from a 3rd party player like chromecast', icon=ICONXML,   themeit=THEME3)
    if not os.path.isfile(PLAYERCORE):addFile('[COLOR green][INSTALL][/COLOR]  playercorefactory.xml',                                'doWriteplayerfactorycore', description='Install a playercorefactory.xml file to allow playing media from a 3rd party player like chromecast', icon=ICONXML,   themeit=THEME3)
    if os.path.isfile(SOURCES):       addFile('[COLOR red][DELETE][/COLOR]   sources.xml   [COLOR green][ENABLED][/COLOR]',           'delsources', description='Install a sources.xml file to add repo sources',  icon=ICONXML,   themeit=THEME3)
    if not os.path.isfile(SOURCES):   addFile('[COLOR green][INSTALL][/COLOR]  sources.xml',                                          'doWritesources', description='Install a sources.xml file to add repo sources',  icon=ICONXML,   themeit=THEME3)
    if os.path.isfile(RSSFILE):       addFile('[COLOR red][DELETE][/COLOR]   RssFeeds.xml   [COLOR green][ENABLED][/COLOR]',          'delRssFeeds',      description='Install a better RSS feed xml to be more informed',  icon=ICONXML,   themeit=THEME3)
    if not os.path.isfile(RSSFILE):   addFile('[COLOR green][INSTALL][/COLOR]  RssFeeds.xml',                                         'doWriterss',      description='Install a better RSS feed xml to be more informed',  icon=ICONXML,   themeit=THEME3)
    addFile('View one of the above', 'viewlog',        description='View the contents of the Logfile or xmls',  icon=ICONLOG, themeit=THEME3)
    if not ADVANCEDFILE == 'http://': addDir('Advancedsettings.xml  Online',  'advancedsetting',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEME1)
    if not KEYMAPSFILE  == 'http://': addDir('Keymaps.xml  (Online)',  'keymaps', url=KEYMAPSFILE,  description='Create a custom keymap file.',  icon=ICONXML,   themeit=THEME1)
    if not KEYMAPSTFILE == 'http://': addDir('Keymaps.xml  (Offline)', 'keymaps', url=KEYMAPSTFILE, description='Create a custom keymap file.',  icon=ICONXML,   themeit=THEME1)
    setView('files', 'viewType')
def doWriterss():
    # RssFeeds.xml urls
    RSS1 = wiz.getS('RSS1')
    RSS2 = wiz.getS('RSS2')
    RSS3 = wiz.getS('RSS3')
    RSS4 = wiz.getS('RSS4')
    RSS5 = wiz.getS('RSS5')
    RSS6 = wiz.getS('RSS6')
    RSS7 = wiz.getS('RSS7')
    RSS8 = wiz.getS('RSS8')
    with open(RSSFILE, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<!--RSS feeds. To have multiple feeds, just add a feed to the set. You can also have multiple sets -->\n')
        f.write('<!--To use different sets in your skin, each must be called from skin with a unique id -->\n')
        f.write('<rssfeeds>\n')
        f.write('    <set id="1">\n')
        if not RSS1 == 'http://': f.write('        <feed updateinterval="30">'+RSS1+'</feed>\n')
        if not RSS2 == 'http://': f.write('        <feed updateinterval="30">'+RSS2+'</feed>\n')
        if not RSS3 == 'http://': f.write('        <feed updateinterval="30">'+RSS3+'</feed>\n')
        if not RSS4 == 'http://': f.write('        <feed updateinterval="30">'+RSS4+'</feed>\n')
        if not RSS5 == 'http://': f.write('        <feed updateinterval="30">'+RSS5+'</feed>\n')
        if not RSS6 == 'http://': f.write('        <feed updateinterval="30">'+RSS6+'</feed>\n')
        if not RSS7 == 'http://': f.write('        <feed updateinterval="30">'+RSS7+'</feed>\n')
        if not RSS8 == 'http://': f.write('        <feed updateinterval="30">'+RSS8+'</feed>\n')
        f.write('        <feed updateinterval="30">http://feeds.kodi.tv/xbmc</feed>\n')
        f.write('    </set>\n')
        f.write('</rssfeeds>\n')
    f.close()

def doWriteplayerfactorycore():
    xbmc.log(msg='##['+ADDON_ID+'] dynamic playercorefactory.xml', level=xbmc.LOGNOTICE)
    if os.path.isfile(PLAYERCORE):
        choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]playerfactorycore.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLOR2, COLOR1), yeslabel="[B][COLOR green]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
        if choice == 0: return
        if os.path.isfile(PLAYERCORE):
            xbmcvfs.copy(PLAYERCORE, PLAYERCORE+'.last')
            delete_file(PLAYERCORE)
    with open(PLAYERCORE, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<!-- http://kodi.wiki/view/HOW-TO:Use_external_players_on_Android  -->\n')
        f.write('<!-- http://kodi.wiki/view/External_players  -->\n')
        f.write('<playercorefactory>\n')
        f.write('    <players>\n')
        ##################
        if xbmc.getCondVisibility('system.platform.android'):
            PLAYERCFFILE1     = wiz.getS('PLAYERCFFILE1')
            PLAYERCFNAME1     = wiz.getS('PLAYERCFNAME1')
            f.write('         <player name="'+PLAYERCFNAME1+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE1+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE2     = wiz.getS('PLAYERCFFILE2')
            PLAYERCFNAME2     = wiz.getS('PLAYERCFNAME2')
            f.write('         <player name="'+PLAYERCFNAME2+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+playercorefactory2+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE3     = wiz.getS('PLAYERCFFILE3')
            PLAYERCFNAME3     = wiz.getS('PLAYERCFNAME3')
            f.write('         <player name="'+PLAYERCFNAME3+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE3+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE4     = wiz.getS('PLAYERCFFILE4')
            PLAYERCFNAME4     = wiz.getS('PLAYERCFNAME4')
            f.write('         <player name="'+PLAYERCFNAME4+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE4+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE5     = wiz.getS('PLAYERCFFILE5')
            PLAYERCFNAME5     = wiz.getS('PLAYERCFNAME5')
            f.write('         <player name="'+PLAYERCFNAME5+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE5+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE6     = wiz.getS('PLAYERCFFILE6')
            PLAYERCFNAME6     = wiz.getS('PLAYERCFNAME6')
            f.write('         <player name="'+PLAYERCFNAME6+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE6+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE7     = wiz.getS('PLAYERCFFILE7')
            PLAYERCFNAME7     = wiz.getS('PLAYERCFNAME7')
            f.write('         <player name="'+PLAYERCFNAME7+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE7+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE8     = wiz.getS('PLAYERCFFILE8')
            PLAYERCFNAME8     = wiz.getS('PLAYERCFNAME8')
            f.write('         <player name="'+PLAYERCFNAME8+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE8+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
        ##################
        if xbmc.getCondVisibility('system.platform.windows'): 
            # vlc x64 
            if os.path.isfile(xbmc.translatePath('C:/Program Files/VideoLAN/VLC/vlc.exe')):
                f.write('         <player name="VLC" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\VideoLAN\VLC\vlc.exe</filename>\n')
                f.write('            <args>--play-and-exit --video-on-top --fullscreen "{1}"</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # vlc x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files (x86)/VideoLAN/VLC/vlc.exe')):
                f.write('         <player name="VLC" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files (x86)\VideoLAN\VLC\vlc.exe</filename>\n')
                f.write('            <args>--play-and-exit --video-on-top --fullscreen "{1}"</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC x64
            if os.path.isfile(xbmc.translatePath('C:/Program Files/MPC-HC64/mpc-hc64.exe')):
                f.write('         <player name="Media Player Classic x64" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\MPC-HC64\mpc-hc64.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files/MPC-HC/mpc-hc.exe')):
                f.write('         <player name="Media Player Classic" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\MPC-HC\mpc-hc.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC-KLite x64
            if os.path.isfile(xbmc.translatePath('C:/Program Files (x86)/K-Lite Codec Pack/MPC-HC64/mpc-hc64.exe')):
                f.write('         <player name="MPC-KLite x64" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64\mpc-hc64.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC-KLite x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files/K-Lite Codec Pack/MPC-HC/mpc-hc.exe')): 
                f.write('         <player name="MPC-KLite" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\K-Lite Codec Pack\MPC-HC\mpc-hc.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # ffmpeg
            #'''
            if os.path.isfile(xbmc.translatePath('C:/utils/ffmpeg.exe')): 
                f.write('         <player name="Record ffmpeg" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\\utils\\ffmpeg.exe</filename> \n')
                f.write('            <args>-i "{1}" -y -c copy -t 4:00:00 c:\pvr_ffmpeg.ts</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('            <playonestackitem>true</playonestackitem>\n')
                f.write('         </player>\n')
                f.write('         <player name="Play with ffmpeg" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\\utils\\ffmpeg.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('            <playonestackitem>true</playonestackitem>\n')
                f.write('         </player>\n')
            #'''
        #
        f.write('    </players>\n')
        f.write('    \n')
        '''
        f.write('    <rules action="overwrite">\n')
        f.write('<!--<rule protocols="nfs|smb" player="dvdplayer"></rule>-->\n')
        f.write('<!-- change the default player below -->\n')
        f.write('<!-- uncomment to make play the default player-->\n')
        f.write('<!--<rule video="true" player="play"></rule>-->\n')
        f.write('<!-- uncomment to make record the default player-->\n')
        f.write('<!-- <rule video="true" player="record"></rule>-->\n')
        f.write('<!--uncomment to make external player the default player -->\n')
        f.write('<!--<rule video="true" player="external player"></rule>-->\n')
        f.write('<!--uncomment to make stream the default player-->\n')
        f.write('<!--<rule video="true" player="stream"></rule>-->\n')
        f.write('    </rules>\n')
        '''
        f.write('</playercorefactory>\n')
        f.write('\n')
    f.close()
def delete_file_prompt(filename):
    if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like delete the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, filename), yeslabel="[B][COLOR green]Yes Delete[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
        tries = 10
        while os.path.exists(filename) and tries > 0:
            try:
                os.remove(filename)
                break
            except:
                tries -= 1
        _notify('Done','Done Deleting  '+filename,ICON)
        
###########################
#### advancedsettings GUI #
###########################
def advancedWindow(url=None):
    if not ADVANCEDFILE == 'http://':
        if url == None:
            ADVANCEDWORKING = wiz.workingURL(ADVANCEDFILE)
            TEMPADVANCEDFILE = uservar.ADVANCEDFILE
        else:
            ADVANCEDWORKING  = wiz.workingURL(url)
            TEMPADVANCEDFILE = url
        addFile('Quick Configure AdvancedSettings.xml',    'autoadvanced',    icon=ICONMAINT, themeit=THEME3)
        if os.path.exists(ADVANCED): 
            addFile('View Currect AdvancedSettings.xml',   'currentsettings', icon=ICONMAINT, themeit=THEME3)
            addFile('Remove Currect AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEME3)
        if ADVANCEDWORKING == True:
            #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONMAINT, themeit=THEME6)
            if HIDESPACERS == 'No': addFile(wiz.sep('ADVANCEDSETTINGS TXT'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
            link = wiz.openURL(TEMPADVANCEDFILE).replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                for name, section, url, icon, fanart, description in match:
                    if section.lower() == "yes":
                        addDir ("[B]%s[/B]" % name, 'advancedsetting', url, description=description, icon=ICON, fanart=FANART, themeit=THEME3)
                    else:
                        addFile(name, 'writeadvanced', name, url, description=description, icon=ICON, fanart=FANART, themeit=THEME2)
            else:
                wiz.log("[Advanced Settings] ERROR: Invalid Format.")
        else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING)
    else: wiz.log("[Advanced Settings] not Enabled")
def writeAdvanced(name, url):
    # add sql
    ADVANCEDWORKING = wiz.workingURL(url)
    if ADVANCEDWORKING == True:
        if os.path.exists(ADVANCED): choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Overwrite[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        else: choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install:\n\n[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Install[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        if choice == 1:
            file = wiz.openURL(url)
            f = open(ADVANCED, 'w'); 
            f.write(file)
            f.close()
            DIALOG.ok(ADDONTITLE, '[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]' % COLOR2)
            wiz.killxbmc(True)
        else: wiz.log("[Advanced Settings] install canceled"); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]Write Cancelled![/COLOR]" % COLOR2); return
    else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]URL Not Working[/COLOR]" % COLOR2)
def viewAdvanced():
    f = open(ADVANCED)
    a = f.read().replace('\t', '    ')
    wiz.TextBox(ADDONTITLE, a)
    f.close()
def removeAdvanced():
    if os.path.exists(ADVANCED):
        wiz.removeFile(ADVANCED)
    else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")
def showAutoAdvanced():
    notify.autoConfig()
    #notify.autoConfig()
    
###########################
###### Menu Maintenance   #
###########################
def index_maint(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Maintenence MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    if wiz.Grab_Log(True) == False: kodilog = 0
    else: kodilog = errorChecking(wiz.Grab_Log(True), True, True)
    if wiz.Grab_Log(True, True) == False: kodioldlog = 0
    else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True, True)
    errorsinlog = int(kodilog) + int(kodioldlog)
    errorsfound = str(errorsinlog) + ' Error(s) Found' if errorsinlog > 0 else 'None Found'
    wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    addFile('[COLOR red](EXIT)[/COLOR]  Force Close Kodi', 'forceclose', description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly', icon=ICONFORCECLOSE,themeit=THEME3)
    addFile('Fresh Start',        'freshstart',       description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART, themeit=THEME7)

    addFile('Scan for Missing Dependencies', 'checkdeps', 'url', description='Install Kodi addons dependencies that run in the background and are needed to work.',icon=ICONMAINT, themeit=THEME3)
    addFile('Scan For Broken Repositories',          'checkrepos',       description='Scan For Broken Repositories',   icon=ICONMAINT, themeit=THEME3)
    addFile('Scan Sources.xml for broken links',         'checksources',     description='Scan Sources for broken links',  icon=ICONMAINT, themeit=THEME3)
    if kodi_version >= '17': addFile('Enable All Addons  (Fix disabled plugins)',         'kodi17fix',  description='When you install addons from a zip file or build it doesnt install the normal way - it just extracts it.  In Kodi 17 addons must be Enabled to work to cover their ass for 3rd party addons and unknown sources.  This will scann the addons and enable them.',  icon=ICONSETTINGS, themeit=THEME3)
    if kodi_version >= '17': addFile('Enable RTMP for Streaming', 'EnableRTMP', description='Starting in Kodi 17 you must enable these 2 somewhat secret addons built into Kodi in order to stream properly.  This enables them.',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Remove Addons',                  'removeaddons',    description='Remove all installed Addons',  icon=ICONDELETE,   themeit=THEME3)
    addDir ('Remove Addon Data',              'removeaddondata', description='Remove installed Addons user data settings',  icon=ICONDELETE,   themeit=THEME3)
    addDir ('Enable/Disable Addons',          'enableaddons',    description='Enable or disable installed Addons that are already installed',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Enable/Disable Adult Addons',    'toggleadult',     description='Enable or disable Adult Addons that are already installed',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Force Update Addons',            'forceupdate',     description='Force Kodi to search for possible Addon Updates',  icon=ICONSETTINGS, themeit=THEME3)

    if view == "tweaks" or SHOWMAINT == 'true': 
        addFile('Fix Addons Not Updating',           'fixaddonupdate',   description='Fix Addons Not Updating',     icon=ICONMAINT, themeit=THEME3)
        addFile('Remove Non-Ascii filenames',        'asciicheck',       description='Remove Non-Ascii filenames',  icon=ICONMAINT, themeit=THEME3)
        addFile('Convert Paths to special',          'convertpath',      description='Convert Paths to special',    icon=ICONMAINT, themeit=THEME3)
    #
    if view == "misc" or SHOWMAINT == 'true': 
        addFile('Hide Passwords On Keyboard Entry',  'hidepassword',     description='Hide Passwords On Keyboard Entry',  icon=ICONSETTINGS, themeit=THEME3)
        addFile('Unhide Passwords On Keyboard Entry','unhidepassword',   description='Unhide Passwords On Keyboard Entry',  icon=ICONSETTINGS, themeit=THEME3)
        addFile('Reload Skin',                       'forceskin',        description='Reload Skin',     icon=ICONSKIN, themeit=THEME3)
        addFile('Reload Profile',                    'forceprofile',     description='Reload Profile',    icon=ICONSKIN, themeit=THEME3)
    addFile('Clone This Addon and ID',        'cloneaddon',      description='Create your own addon', icon=ICONFRESHSTART, themeit=THEME7)

    addFile('Show All Maintenance: %s' % maint.replace('true',on).replace('false',off) ,'togglesetting', name='showmaint', description='Show All Maintenance',  icon=ICONSETTINGS, themeit=THEME9)
    if DEVELOPER == 'true': addDir('Developer Menu','developer',  description='Developer Menu',   icon=ICONSETTINGS, themeit=THEME1)
    addDir ('System Information',                    'systeminfo',       description='Sys Info',   icon=ICONINFO, themeit=THEME3)
    setView('files', 'viewType')
'''
###########################
###### Menu addonfixes    #
###########################
def index_addonfixes(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **addonfixes MENU**', level=xbmc.LOGNOTICE)
    addFile('Scan for Missing Dependencies', 'checkdeps', 'url', description='Install Kodi addons dependencies that run in the background and are needed to work.',icon=ICONMAINT, themeit=THEME3)
    addFile('Scan For Broken Repositories',          'checkrepos',       description='Scan For Broken Repositories',   icon=ICONMAINT, themeit=THEME3)
    addFile('Scan Sources.xml for broken links',         'checksources',     description='Scan Sources for broken links',  icon=ICONMAINT, themeit=THEME3)
    if kodi_version >= '17': addFile('Enable All Addons  (Fix disabled plugins)',         'kodi17fix',  description='When you install addons from a zip file or build it doesnt install the normal way - it just extracts it.  In Kodi 17 addons must be Enabled to work to cover their ass for 3rd party addons and unknown sources.  This will scann the addons and enable them.',  icon=ICONSETTINGS, themeit=THEME3)
    if kodi_version >= '17': addFile('Enable RTMP for Streaming', 'EnableRTMP', description='Starting in Kodi 17 you must enable these 2 somewhat secret addons built into Kodi in order to stream properly.  This enables them.',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Remove Addons',                  'removeaddons',    description='Remove all installed Addons',  icon=ICONDELETE,   themeit=THEME3)
    addDir ('Remove Addon Data',              'removeaddondata', description='Remove installed Addons user data settings',  icon=ICONDELETE,   themeit=THEME3)
    addDir ('Enable/Disable Addons',          'enableaddons',    description='Enable or disable installed Addons that are already installed',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Enable/Disable Adult Addons',    'toggleadult',     description='Enable or disable Adult Addons that are already installed',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('Force Update Addons',            'forceupdate',     description='Force Kodi to search for possible Addon Updates',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('[COLOR red](EXIT)[/COLOR]  Force Close Kodi', 'forceclose', description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly', icon=ICONFORCECLOSE,themeit=THEME3)
    addFile('Fresh Start',        'freshstart',       description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART, themeit=THEME7)
    addFile('Clone This Addon and ID',        'cloneaddon',      description='Create your own addon', icon=ICONFRESHSTART, themeit=THEME7)
    setView('files', 'viewType')
'''
###########################
###### Menu backup   #
###########################
def index_backup(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Backup MENU**', level=xbmc.LOGNOTICE)

    try:
        mybuilds = xbmc.translatePath(MYBUILDS)
        if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
    except:pass
    
    addFile('Back Up Zip Location: [COLOR %s]%s[/COLOR]' % (COLOR3, MYBUILDS),'settings', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEME3)
    addFile('Clean Back Up Folder  [COLOR red](Delete all Zips)[/COLOR]',                 'clearbackup', description='Erase all the zips in the save folder.', icon=ICONDELETE,   themeit=THEME3)
    addFile('Settings Whitelist (What to backup or erase)',                               'firstrunsettingsgui', description='Select wich files to backup or wipe when the time comes.'  ,icon=ICONSETTINGS, themeit=THEME3)
    addDir('Create Backup Zip of your Addons and Settings',                                   'indexbackuponly', description='Select wich files to backup of your Addons and Settings and create your own custom build or backup zip'  ,icon=ICONSETTINGS, themeit=THEME1)

    '''
    if view == "backup" or SHOWMAINT == 'true':
        if HIDESPACERS == 'No': addFile(wiz.sep('MAKE BACKUP FILES (BUILD)'),'',fanart=FANART,icon=ICONSPACER,   themeit=THEME6)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Build',               'backupbuild',     icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] GuiFix',              'backupgui',       icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Theme',               'backuptheme',     icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Addon_data',          'backupaddon',     icon=ICONBACKUP,   themeit=THEME3)
        addDir('Save Debrid And Trakt Data',                               'savedata',        icon=ICONTRAKT,    themeit=THEME1)
    if HIDESPACERS == 'No': addFile(wiz.sep('RESTORE BACKUP ZIP (BUILD)'),'',fanart=FANART,icon=ICONSPACER,  themeit=THEME6)
    '''
    #addDir('[B]Restore[/B]',                                          'maint', 'backup', icon=ICONRESTORE,  themeit=THEME1)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Build',         'restorezip',      icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local GuiFix',        'restoregui',      icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Addon_data',    'restoreaddon',    icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Build',      'restoreextzip',   icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External GuiFix',     'restoreextgui',   icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Addon_data', 'restoreextaddon', icon=ICONRESTORE,  themeit=THEME3)
    setView('files', 'viewType')
def index_backup_only(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Backup MENU**', level=xbmc.LOGNOTICE)
    addFile('Back Up Zip Location: [COLOR %s]%s[/COLOR]' % (COLOR3, MYBUILDS),'settings', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEME3)
    addFile('Clean Back Up Folder  [COLOR red](Delete all Zips)[/COLOR]', 'clearbackup', description='Erase all the zips in the save folder.', icon=ICONDELETE,   themeit=THEME3)
    addFile('Settings Whitelist Gui',                                  'firstrunsettingsgui', description='Select wich files to backup or wipe when the time comes.'  ,icon=ICONSETTINGS, themeit=THEME3)
    if HIDESPACERS == 'No': addFile(wiz.sep('MAKE BACKUP FILES (BUILD)'),'',fanart=FANART,icon=ICONSPACER,   themeit=THEME6)
    addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Build',               'backupbuild',     icon=ICONBACKUP,   themeit=THEME3)
    addFile('[COLOR blue][B]Back Up:[/B][/COLOR] GuiFix',              'backupgui',       icon=ICONBACKUP,   themeit=THEME3)
    addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Theme',               'backuptheme',     icon=ICONBACKUP,   themeit=THEME3)
    addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Addon_data',          'backupaddon',     icon=ICONBACKUP,   themeit=THEME3)
    addDir('Save Debrid And Trakt Data',                               'savedata',        icon=ICONTRAKT,    themeit=THEME1)
    setView('files', 'viewType')
def index_restore(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Backup MENU**', level=xbmc.LOGNOTICE)
    addFile('Back Up Zip Location: [COLOR %s]%s[/COLOR]' % (COLOR3, MYBUILDS),'settings', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEME3)
    addFile('Clean Back Up Folder  [COLOR red](Delete all Zips)[/COLOR]', 'clearbackup', description='Erase all the zips in the save folder.', icon=ICONDELETE,   themeit=THEME3)
    if HIDESPACERS == 'No': addFile(wiz.sep('RESTORE BACKUP ZIP (BUILD)'),'',fanart=FANART,icon=ICONSPACER,  themeit=THEME6)
    #addDir('[B]Restore[/B]',                                          'maint', 'backup', icon=ICONRESTORE,  themeit=THEME1)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Build',         'restorezip',      icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local GuiFix',        'restoregui',      icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Addon_data',    'restoreaddon',    icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Build',      'restoreextzip',   icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External GuiFix',     'restoreextgui',   icon=ICONRESTORE,  themeit=THEME3)
    addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Addon_data', 'restoreextaddon', icon=ICONRESTORE,  themeit=THEME3)
    setView('files', 'viewType')


###########################
###### Menu Clean         #
###########################
def index_cleaning(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Clean MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    autoclean   = 'true' if AUTOCLEANUP    == 'true' else 'false'
    cache       = 'true' if AUTOCACHE      == 'true' else 'false'
    packages    = 'true' if AUTOPACKAGES   == 'true' else 'false'
    thumbs      = 'true' if AUTOTHUMBS     == 'true' else 'false'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    includevid  = 'true' if INCLUDEVIDEO   == 'true' else 'false'
    includeall  = 'true' if INCLUDEALL     == 'true' else 'false'
    if includeall == 'true':
        include1ch = 'true'
        includeall = 'true' 
        includeben = 'true' 
        includebob = 'true'
        includebub = 'true' 
        includecov = 'true' 
        includeely = 'true' 
        includeexo = 'true' 
        includegur = 'true' 
        includeice = 'true' 
        includespe = 'true' 
        includetin = 'true' 
        includeugo = 'true'
        includexxx = 'true' 
        includesal = 'true' 
        includeall = 'true' 
        includeone = 'true' 
        includeugo = 'true' 
    else:
        include1ch = 'true' if INCLUDE1CHANNEL     == 'true' else 'false'
        includeall = 'true' if INCLUDEALLUC        == 'true' else 'false'
        includeben = 'true' if INCLUDEBENNU        == 'true' else 'false'
        includebob = 'true' if INCLUDEBOBUNLEASHED == 'true' else 'false'
        includebub = 'true' if INCLUDEBUBBLES      == 'true' else 'false'
        includecov = 'true' if INCLUDECOVENANT     == 'true' else 'false'
        includeely = 'true' if INCLUDEELYSIUM      == 'true' else 'false'
        includeexo = 'true' if INCLUDEXODUS        == 'true' else 'false'
        includegur = 'true' if INCLUDEGURZIL       == 'true' else 'false'
        includeice = 'true' if INCLUDEICEFILMS     == 'true' else 'false'
        includespe = 'true' if INCLUDESPECTO       == 'true' else 'false'
        includetin = 'true' if INCLUDETINKLEPAD    == 'true' else 'false'
        includeugo = 'true' if INCLUDEUGOTTOC      == 'true' else 'false'
        includexxx = 'true' if INCLUDEXXXODUS      == 'true' else 'false'
        includesal = 'true' if INCLUDESALTS        == 'true' else 'false'
        includeall = 'true' if INCLUDEALLUC        == 'true' else 'false'
        includeone = 'true' if INCLUDEONECHANNEL   == 'true' else 'false'
    #
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    #
    if view == "clean" or SHOWMAINT == 'true': 
        addFile('[COLOR yellow]*[/COLOR]Clean Kodi Files Now  [B][COLOR blue](Cache\Packages\Thumbs)[/COLOR]:[/B]  [COLOR lightgreen][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize) ,'fullclean'  ,description='Clean NOW the Kodi files like Cache\Packages\Thumbs that slow your system down over time.',icon=ICONCLEANALL, themeit=THEME3)
        #addFile('Total Clean Up (Cache\Packages\Thumbs): [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize),  'fullclean',  description='Clean NOW the Kodi files like Cache\Packages\Thumbs that slow your system down over time.',     icon=ICONCLEANALL, themeit=THEME3)
        addFile('Clear Cache: [COLOR green][B]%s[/B][/COLOR]' %      wiz.convertSize(sizecache),   'clearcache',      description='Clean the Kodi cache of temporary files created by addons to run.  After awhile the files pile up and slow down performance.  Cleaning them refreshes the files too often fixing small errors',  icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Packages: [COLOR green][B]%s[/B][/COLOR]' %   wiz.convertSize(sizepack),    'clearpackages',   description='Clean the addon zip files left over from an addon install.  By default they arent deleted so you can downgrade an addon, but they eventually take up alot of space.',  icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Thumbnails: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizethumb),   'clearthumb',      description='Clean the thumbnail pictures that accumulate over time when loading movie information tags.',  icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Old Thumbnails',                                                            'oldThumbs',       description='Clean old thumbnails for missing files',  icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Crash Logs',                                                                'clearcrash',      description='Clear the Kodi crash logs',  icon=ICONCLEAN, themeit=THEME3)
        addFile('Purge Databases',                                                                 'purgedb',         description='Purge the database files.  Once a year for 1 night you can purge the database legally without being charged for murder.  rimshot',  icon=ICONCLEAN, themeit=THEME3)
        #addFile('[COLOR red](EXIT)[/COLOR]  Force Close Kodi',                                    'forceclose',      description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly', icon=ICONFORCECLOSE,themeit=THEME3)
        #addFile('Fresh Start',                                                                    'freshstart',      description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART,themeit=THEME7)
    
    addFile('Auto Clean Up On Startup: %s' % autoclean.replace('true',on).replace('false',off) ,   'togglesetting', name='autoclean',      description='Toggle if you want the Kodi temp files like thumbnails and cache cleaned occasionally.',  icon=ICONSETTINGS, themeit=THEME9)
    if autoclean == 'true':
        addFile('Auto Clean Fequency: [B][COLOR green]%s[/COLOR][/B]' % feq[AUTOFEQ],               'changefeq',                      description='How often to run the auto clean on startup',  icon=ICONSETTINGS, themeit=THEME9)
        addFile('Clear Cache on Startup: %s' % cache.replace('true',on).replace('false',off),       'togglesetting', name='clearcache',    description='Clear Cache on Startup', icon=ICONSETTINGS, themeit=THEME9)
        addFile('Clear Packages on Startup: %s' % packages.replace('true',on).replace('false',off), 'togglesetting', name='clearpackages', description='Clear Packages on Startup', icon=ICONSETTINGS, themeit=THEME9)
        addFile('Clear Old Thumbs on Startup: %s' % thumbs.replace('true',on).replace('false',off), 'togglesetting', name='clearthumbs',   description='Clear Old Thumbs on Startup', icon=ICONSETTINGS, themeit=THEME9)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep('TOGGLE VIDEO CACHE SETTINGS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Include Video Cache in Clear Cache: %s' % includevid.replace('true',on).replace('false',off), 'togglecache', 'includevideo', description='Include Video Addons Caches when you clear the cache', icon=ICONSETTINGS, themeit=THEME9)
    if includevid == 'true':
        addFile('Enable All Video Addons', 'togglecache', 'true',  description='Enable All Video Addons',   icon=ICONSETTINGS, themeit=THEME9)
        addFile('Disable All Video Addons', 'togglecache', 'false',description='Disable All Video Addons',  icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include All Video Addons: %s'% includeall.replace('true',on).replace('false',off),'togglecache','includeall',           icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include 1Channel: %s'       % include1ch.replace('true',on).replace('false',off), 'togglecache', 'include1channel',     icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Alluc: %s'          % includeall.replace('true',on).replace('false',off), 'togglecache', 'includealluc',        icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Bennu: %s'          % includeben.replace('true',on).replace('false',off), 'togglecache', 'includebennu',        icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include BOB Unleashed: %s'  % includebob.replace('true',on).replace('false',off), 'togglecache', 'includebobunleashed', icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Bubbles: %s'        % includebub.replace('true',on).replace('false',off), 'togglecache', 'includebubbles',      icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Covenant: %s'       % includecov.replace('true',on).replace('false',off), 'togglecache', 'includecovenant',     icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Elysium: %s'        % includeely.replace('true',on).replace('false',off), 'togglecache', 'includeelysium',      icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Exodus: %s'         % includeexo.replace('true',on).replace('false',off), 'togglecache', 'includeexodus',       icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Gurzil: %s'         % includegur.replace('true',on).replace('false',off), 'togglecache', 'includegurzil',       icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Icefilms: %s'       % includeice.replace('true',on).replace('false',off), 'togglecache', 'includeicefilms',     icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Specto: %s'         % includespe.replace('true',on).replace('false',off), 'togglecache', 'includespecto',       icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include Tinklepad: %s'      % includetin.replace('true',on).replace('false',off), 'togglecache', 'includetinklepad',    icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include UGOTTOC: %s'        % includeugo.replace('true',on).replace('false',off), 'togglecache', 'includeugottoc',      icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include XXXODUS: %s'        % includexxx.replace('true',on).replace('false',off), 'togglecache', 'includexxxodus',      icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include SALTS: %s'          % includesal.replace('true',on).replace('false',off), 'togglecache', 'includesalts',        icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include ALLUC: %s'          % includeall.replace('true',on).replace('false',off), 'togglecache', 'includealluc',        icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include ONECHANNEL: %s'     % includeone.replace('true',on).replace('false',off), 'togglecache', 'includeonechannel',   icon=ICONSETTINGS, themeit=THEME9)
        addFile('Include UGOTTOC: %s'        % includeugo.replace('true',on).replace('false',off), 'togglecache', 'includeugottoc',      icon=ICONSETTINGS, themeit=THEME9)
    setView('files', 'viewType')
####THANKS GUYS @ NaN #######
def clearCache():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Clear Cache[/COLOR][/B]'):
        wiz.clearCache()
def totalClean():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
        wiz.clearCache()
        wiz.clearPackages('total')
        clearThumb('total')
def clearThumb(type=None):
    latest = wiz.latestDB('Textures')
    if not type == None: choice = 1
    else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
    if choice == 1:
        try: wiz.removeFile(os.join(DATABASE, latest))
        except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
        wiz.removeFolder(THUMBS)
        #if not type == 'total': wiz.killxbmc()
    else: wiz.log('Clear thumbnames cancelled')
    wiz.redoThumbs()
def purgeDb():
    DB = []; display = []
    for dirpath, dirnames, files in os.walk(HOME):
        for f in fnmatch.filter(files, '*.db'):
            if f != 'Thumbs.db':
                found = os.path.join(dirpath, f)
                DB.append(found)
                dir = found.replace('\\', '/').split('/')
                display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
    if KODIV >= 16: 
        choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
        if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        else: 
            for purge in choice: wiz.purgeDb(DB[purge])
    else:
        choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
        if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        else: wiz.purgeDb(DB[purge])
def freshStart(install=None, over=False, offline=False):
    if KEEPTRAKT == 'true':
        traktit.autoUpdate('all')
        wiz.setS('traktlastsave', str(THREEDAYS))
    if KEEPREAL == 'true':
        debridit.autoUpdate('all')
        wiz.setS('debridlastsave', str(THREEDAYS))
    if KEEPLOGIN == 'true':
        loginit.autoUpdate('all')
        wiz.setS('loginlastsave', str(THREEDAYS))
    if over == True: yes_pressed = 1
    elif install == 'restore': yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your Kodi configuration to default settings before installing the local backup?[/COLOR]" % COLOR1, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    elif install: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR red]Fresh Start:[/COLOR]", "Do you wish to restore your Kodi configuration to default settings before installing [COLOR %s]%s[/COLOR]?" % (COLOR1, install), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    else: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR red]Fresh Start:[/COLOR]", "[COLOR %s]Do you wish to restore your Kodi configuration to default settings?[/COLOR]" % COLOR1, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    if yes_pressed:
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            skin = 'skin.confluence' if KODIV < 17 else 'skin.estuary'
            #yes=DIALOG.yesno(ADDONTITLE, "[COLOR %s]The skin needs to be set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, skin[5:]), "Before doing a fresh install to clear all Texture files,", "Would you like us to do that for you?[/COLOR]", yeslabel="[B][COLOR green]Switch Skins[/COLOR][/B]", nolabel="[B][COLOR red]I'll Do It[/COLOR][/B]";
            #if yes:
            skinSwitch.swapSkins(skin)
            x = 0
            xbmc.sleep(1000)
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                x += 1
                xbmc.sleep(200)
                wiz.ebi('SendAction(Select)')
            if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                wiz.ebi('SendClick(11)')
            else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return False
            xbmc.sleep(1000)
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Failed![/COLOR]' % COLOR2)
            return
        wiz.addonUpdates('set')
        xbmcPath=os.path.abspath(HOME)
        DP.create(ADDONTITLE,"[COLOR %s]Calculating files and folders" % COLOR2,'', 'Please Wait![/COLOR]')
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
        DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
        EXCLUDES.append('My_Builds')
        EXCLUDES.append('archive_cache')
        if KEEPREPOS == 'true':
            repos = glob.glob(os.path.join(ADDONS, 'repo*/'))
            for item in repos:
                repofolder = os.path.split(item[:-1])[1]
                if not repofolder == EXCLUDES:
                    EXCLUDES.append(repofolder)
        if KEEPSUPER == 'true':
            EXCLUDES.append('plugin.program.super.favourites')
        if KEEPWHITELIST == 'true':
            pvr = ''
            whitelist = wiz.whiteList('read')
            if len(whitelist) > 0:
                for item in whitelist:
                    try: name, id, fold = item
                    except: pass
                    if fold.startswith('pvr'): pvr = id 
                    depends = dependsList(fold)
                    for plug in depends:
                        if not plug in EXCLUDES:
                            EXCLUDES.append(plug)
                        depends2 = dependsList(plug)
                        for plug2 in depends2:
                            if not plug2 in EXCLUDES:
                                EXCLUDES.append(plug2)
                    if not fold in EXCLUDES:
                        EXCLUDES.append(fold)
                if not pvr == '': wiz.setS('pvrclient', fold)
        if wiz.getS('pvrclient') == '':
            for item in EXCLUDES:
                if item.startswith('pvr'):
                    wiz.setS('pvrclient', item)
        DP.update(0, "[COLOR %s]Clearing out files and folders:" % COLOR2)
        latestAddonDB = wiz.latestDB('Addons')
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                del_file += 1
                fold = root.replace('/','\\').split('\\')
                x = len(fold)-1
                if name ==   'sources.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep Sources: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'playercorefactory.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep playercorefactory: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'favourites.xml' and fold[-1] == 'userdata' and KEEPFAVS == 'true': wiz.log("Keep Favourites: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'profiles.xml' and fold[-1] == 'userdata' and KEEPPROFILES == 'true': wiz.log("Keep Profiles: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'advancedsettings.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep Advanced Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name in LOGFILES: wiz.log("Keep Log File: %s" % name, xbmc.LOGNOTICE)
                elif name.endswith('.db'):
                    try:
                        if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), xbmc.LOGNOTICE)
                        else: os.remove(os.path.join(root,name))
                    except Exception, e: 
                        if not name.startswith('Textures13'):
                            wiz.log('Failed to delete, Purging DB', xbmc.LOGNOTICE)
                            wiz.log("-> %s" % (str(e)), xbmc.LOGNOTICE)
                            wiz.purgeDb(os.path.join(root,name))
                else:
                    DP.update(int(wiz.percentage(del_file, total_files)), '', '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '')
                    try:
                        # test
                        #name1 = unicodedata.normalize('NFKD', name).encode('ASCII', 'ignore')
                        os.remove(os.path.join(root,name))
                    except Exception, e: 
                        wiz.log("Error removing %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                        wiz.log("-> / %s" % (str(e)), xbmc.LOGNOTICE)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
                return False
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in dirs:
                DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name), '')
                if name not in ["Database","userdata","temp","addons","addon_data"]:
                    shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
                return False
        DP.close()
        wiz.clearS('build')
        if over == True:
            return True
        elif install == 'restore': 
            return True
            
        elif install: 
            if offline == False:
                xbmc.log(msg='##['+ADDON_ID+'] Freshstart Done  Running   Online Install', level=xbmc.LOGNOTICE)
                buildWizard(install, 'normal', over=True)
            else:
                xbmc.log(msg='##['+ADDON_ID+'] Freshstart Done  Running   ThirdParty Install', level=xbmc.LOGNOTICE)
                #buildWizard(install, 'normal', over=True)
                #installoffline(name, install, 'install', full=False)
                return
        else:
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR white]Would you like to:[/COLOR]\n[COLOR gold]Force Close[/COLOR]       (Close Kodi and enable settings)\n[COLOR gold]Reload Profile[/COLOR]   (Only Refresh skin to enable settings)", yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix('fresh')
            else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
    else: 
        if not install == 'restore':
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Cancelled![/COLOR]' % COLOR2)
            wiz.refresh()

##########################
### DEVELOPER MENU #######
##########################
def testnotify():
    NOTIFICATION     = uservar.NOTIFICATION
    url = wiz.workingURL(NOTIFICATION)
    if url == True:
        try:
            id, msg = wiz.splitNotify(NOTIFICATION)
            if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Notification: Not Formated Correctly[/COLOR]" % COLOR2); return
            notify.notification(msg, True)
        except Exception, e:
            wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Invalid URL for Notification[/COLOR]" % COLOR2)
def testupdate():
    if BUILDNAME == "":
        notify.updateWindow()
    else:
        notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))
def testfirst():
    notify.firstRun()
def testfirstRun():
    notify.firstRunSettings()

###########################
###### Menu Log           #
###########################
def index_log(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Log MENU**', level=xbmc.LOGNOTICE)
    if wiz.Grab_Log(True) == False: kodilog = 0
    else: kodilog = errorChecking(wiz.Grab_Log(True), True, True)
    if wiz.Grab_Log(True, True) == False: kodioldlog = 0
    else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True, True)
    errorsinlog = int(kodilog) + int(kodioldlog)
    errorsfound = str(errorsinlog) + ' Error(s) Found' if errorsinlog > 0 else 'None Found'
    wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
    addFile('View Log File',                          'viewlog',         description='View the contents of the Logfile to check for Kodi addon errors',  icon=ICONLOG, themeit=THEME3)
    addFile('View Errors in Log: %s' % (errorsfound), 'viewerrorlog',    description='View the errors in the Logfile',  icon=ICONLOG, themeit=THEME3)
    addFile('View Wizard Log File',                   'viewwizlog',      description='View the contents of this addons Logfile to check for errors',  icon=ICONLOG, themeit=THEME3)
    addFile('Clear Wizard Log File%s' % wizlogsize,   'clearwizlog',     description='Clear the wizard log files',  icon=ICONDELETE, themeit=THEME3)
    addFile('Email Log to yourself',                  'emaillog',        description='Email the Log to yourself if you provide an email adress.',  icon=ICONEMAIL, themeit=THEME3)
    addFile('Upload Kodi.log to random Pastebin',     'uploadlog',       description='Upload the Log to Pastebin if you provide an email adress.',  icon=ICONEMAIL, themeit=THEME3)
    addFile('Toggle Debug',                           'debug',           description='Toggle debug mode',  icon=ICONSETTINGS, themeit=THEME9)
    addFile('Help',  'indexhelp',  url=HELPFILE,   description='Help file from settings',  icon=ICONINFO,themeit=THEME3)
    #addDir('M3U',  'indexm3u',  url=M3UFILE,   description='Play m3u file from settings',  icon=ICONM3U,themeit=THEME1)
    #addDir('Youtube Tutorials',                       'youtube',         description='Youtube tutorials for what the hell to do',  icon=ICONYOUTUBE,themeit=THEME1)
    #addFile('Help',  'indexhelp',  url=HELPFILE,   description='Help file from settings',  icon=ICONINFO,themeit=THEME3)
    #if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'): addDir('Youtube Videos',     'youtube',            description='Youtube tutorials for what the hell to do',  icon=ICONYOUTUBE,themeit=THEME1)
    setView('files', 'viewType')
###########################
# Log Uploader
def send_email(LOG):
    xbmc.log(msg='##['+ADDON_ID+'] Email '+LOG, level=xbmc.LOGNOTICE)
    THESMTP ,THEPORT = Servers()
    fromaddr=wiz.getS('email')
    toaddr=fromaddr
    if toaddr =='[COLOR red]Cancel[/COLOR]':
        Show_Dialog('No Email Sent','','Email Cancelled')
    else:
        import datetime
        TODAY=datetime.datetime.today().strftime('[%d-%m-%Y %H:%M]')
        from email.MIMEMultipart import MIMEMultipart
        from email.MIMEText import MIMEText
        fromaddr = '"Hi Message From Yourself" <%s>'% (fromaddr)
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = toaddr
        msg['Subject'] = "Your Kodi Log "+str(TODAY)
        THEHTML = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'data', 'theemail.html'))
        body = open(THEHTML).read()
        content = MIMEText(body, 'html')
        msg.attach(content)
        try:filename = LOG.rsplit('\\', 1)[1]
        except:filename = LOG.rsplit('/', 1)[1]
        f = file(LOG)
        attachment = MIMEText(f.read())
        attachment.add_header('Content-Disposition', 'attachment', filename=filename.replace('log','txt'))
        msg.attach(attachment)
        import smtplib
        server = smtplib.SMTP(str(THESMTP), int(THEPORT))
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(wiz.getS('email').encode('UTF-8'),wiz.getS('emailpassword').encode('UTF-8'))
        text = msg.as_string()
        server.sendmail(fromaddr, toaddr, text)
        Show_Dialog('Email Sent To','[COLOR green]'+toaddr+'[/COLOR]','Also Check Junk Folder')
def Servers():
    SERVER = wiz.getS('server')
    APPENDED=[]
    server_list   =[('Gmail','smtp.gmail.com','587'),
                    ('Outlook/Hotmail','smtp-mail.outlook.com','587'),
                    ('Office365','smtp.office365.com','587'),
                    ('Yahoo Mail','smtp.mail.yahoo.com','465'),
                    ('Yahoo Mail Plus','smtp.mail.yahoo.co.uk','465'),
                    ('AOL','smtp.att.yahoo.com','465'),
                    ('Verizon','smtp.zoho.com','465'),
                    ('Mail','smtp.mail.com','587'),
                    ('GMX','smtp.gmx.com','465')]
    for server , smtp ,port in server_list:
        if SERVER ==server:
            APPENDED.append([smtp ,port])
    return  APPENDED[0][0],APPENDED[0][1]
def email_log():
    # check email setting
    emailSERVER = wiz.getS('email')
    if not emailSERVER :
        DIALOG.ok('Enter Email and Password in settings', 'Invalid email for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDON_ID).openSettings()
        sys.exit(0)
    emailpass = wiz.getS('emailpassword')
    if not emailpass :
        DIALOG.ok('Enter password in settings', 'Invalid email PASSWORD for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDON_ID).openSettings()
        sys.exit(0)
    #
    nameSelect=[]
    logSelect=[]
    import glob
    folder = xbmc.translatePath('special://logpath')
    xbmc.log(msg=folder, level=xbmc.LOGNOTICE)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
    LOG = logSelect[xbmcgui.Dialog().select('Please Select Log', nameSelect)]
    send_email(LOG)






##########plugin.git.browser 1.0  Thanks to TVA      new
'''
@kodi.register('github_main')
#def main():
def github_main():
    show_about()
    kodi.add_menu_item({'mode': 'search_menu', 'type': "username", 'title': "Search by GitHub Username"}, {'title': "Search by GitHub Username"}, icon='username.png')
    kodi.add_menu_item({'mode': 'search_menu', 'type': "repository", 'title': "Search by GitHub Repository Title"}, {'title': "Search by GitHub Repository Title"}, icon='repository.png')
    kodi.add_menu_item({'mode': 'search_menu', 'type': "addonid",'title': "Search by Addon ID"}, {'title': "Search by Addon ID"}, icon='addonid.png')
    kodi.add_menu_item({'mode': 'update_addons'}, {'title': "Check for Updates"}, icon='update.png', visible=kodi.get_setting('enable_updates') == 'true')
    kodi.add_menu_item({'mode': 'about'}, {'title': "About GitHub Installer"}, icon='about.png')
    kodi.add_menu_item({'mode': 'addon_settings'}, {'title': "Tools and Settings"}, icon='settings.png')
    kodi.eod()
'''
'''
'github_search_username' = "username"
'github_search_repo' = "repository"
'github_search_addon_id' = "addonid"
,'github_update' = 'update_addons'
'github_instructions' = 'about'
'''
'''
#@kodi.register('search_menu')
def search_menu():
    from libs.database import DB
    kodi.add_menu_item({'mode': 'void'}, {'title': "[COLOR darkorange]%s[/COLOR]" % kodi.arg('title')}, icon='null')
    kodi.add_menu_item({'mode': 'search', 'type': kodi.arg('type')}, {'title': "*** New Search ***"}, icon='null')
    results = DB.query_assoc("SELECT search_id, query FROM search_history WHERE search_type=? ORDER BY ts DESC LIMIT 10", [kodi.arg('type')], silent=True)
    if results is not None:
        for result in results:
            menu = kodi.ContextMenu()
            menu.add('Delete from search history', {"mode": "history_delete", "id": result['search_id']})
            kodi.add_menu_item({'mode': 'search', 'type': kodi.arg('type'), 'query': result['query']}, {'title': result['query']}, menu=menu, icon='null')
    kodi.eod()
    
#@kodi.register('search')
def search():
    from libs.database import DB
    from libs import github_api
    from libs.github_api import re_repository
    q = kodi.arg('query') if kodi.arg('query') else kodi.dialog_input('Search GitHub')
    if q in [None, False, '']: return False
    DB.execute('INSERT INTO search_history(search_type, query) VALUES(?,?)', [kodi.arg('type'), q])
    DB.commit()
    if kodi.arg('type') == 'username':
        rtype = 'api'
        response = github_api.find_zips(q)
        if response is None: return
        for r in github_api.sort_results(response['items']):
            url = github_api.content_url % (r['repository']['full_name'], r['path'])
            menu = kodi.ContextMenu()
            if re_repository.search(r['name']):
                menu.add('Browse Repository Contents', {"mode": "browse_repository", "url": url, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])})
            kodi.add_menu_item({'mode': 'github_install', "url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}, {'title': r['name']}, menu=menu, icon='null')
        kodi.eod()
    elif  kodi.arg('type') == 'repository':
        rtype = 'api'
        results = github_api.search(q, 'title')
        if results is None: return
        for i in results['items']:
            user = i['owner']['login']
            response = github_api.find_zips(user)
            if response is None: continue
            for r in github_api.sort_results(response['items']):
                url = github_api.content_url % (r['repository']['full_name'], r['path'])
                menu = kodi.ContextMenu()
                if re_repository.search(r['name']):
                    menu.add('Browse Repository Contents', {"mode": "browse_repository", "url": url, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])})
                kodi.add_menu_item({'mode': 'github_install', "url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}, {'title': r['name']}, menu=menu, icon='null')
        kodi.eod()
    elif  kodi.arg('type') == 'addonid':
        rtype = 'web'
        results = github_api.web_search(q)
        if results is None: return
        for r in results['items']:
            kodi.add_menu_item({'mode': 'github_install', "user": r['owner']['login'], "repo": r['name'], "rtype": rtype}, {'title': "%s/%s" % (r['owner']['login'], r['name'])}, icon='null')
        kodi.eod()
    
#@kodi.register('github_install')
def github_install():
    if kodi.arg('rtype') == 'web':
        from libs import github_installer
        from libs.github_api import master_url
        full_name = "%s/%s" % (kodi.arg('user'), kodi.arg('repo'))
        c = kodi.dialog_confirm("Confirm Install", full_name, yes="Install", no="Cancel")
        if not c: return
        url = master_url % (kodi.arg('user'), kodi.arg('repo'))
        github_installer.GitHub_Installer(kodi.arg('repo'), url, full_name, kodi.vfs.join("special://home", "addons"), True)
        r = kodi.dialog_confirm(kodi.get_name(), 'Click Continue to install more addons or', 'Restart button to finalize addon installation', yes='Restart', no='Continue')
        if r:
            import sys
            import xbmc
            if sys.platform in ['linux', 'linux2', 'win32']:
                xbmc.executebuiltin('RestartApp')
            else:
                xbmc.executebuiltin('ShutDown')
    else:
        import re
        from libs import github_installer
        from libs import github_api
        c = kodi.dialog_confirm("Confirm Install", kodi.arg('file'), yes="Install", no="Cancel")
        if not c: return
        addon_id = re.sub("-[\d\.]+zip$", "", kodi.arg('file'))
        github_installer.GitHub_Installer(addon_id, kodi.arg('url'), kodi.arg('full_name'), kodi.vfs.join("special://home", "addons"))
        r = kodi.dialog_confirm(kodi.get_name(), 'Click Continue to install more addons or', 'Restart button to finalize addon installation', yes='Restart', no='Continue')
        if r:
            import sys
            import xbmc
            if sys.platform in ['linux', 'linux2', 'win32']:
                xbmc.executebuiltin('RestartApp')
            else:
                xbmc.executebuiltin('ShutDown')

#@kodi.register('browse_repository')
def browse_repository():
    from libs import github_api
    xml = github_api.browse_repository(kodi.arg('url'))
    
    heading = "%s/%s" % (kodi.arg('full_name'), kodi.arg('file'))
    options = []
    if xml:
        for addon in xml.findAll('addon'):
            options.append("%s (%s)" % (addon['name'], addon['version']))
            
        kodi.dialog_select(heading, sorted(options))

#@kodi.register('history_delete')
def history_delete():
    if not kodi.arg('id'): return
    from libs.database import DB
    DB.execute("DELETE FROM search_history WHERE search_id=?", [kodi.arg('id')])
    DB.commit()    
    kodi.refresh()

#@kodi.register('update_addons')
def update_addons():
    from libs import github_installer
    quiet = True if kodi.arg('quiet') == 'quiet' else False
    if not quiet:
        c = kodi.dialog_confirm("Confirm Update", "Check for updates", yes="Update", no="Cancel")
        if not c: return
    github_installer.update_addons(quiet)
###plugin.git.browser end
'''




###########################
###### Main githubbrowse  #
###########################
def github_main(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Github Browser XML MENU**', level=xbmc.LOGNOTICE)
    #github_instructions()
    addDir('Search by GitHub Username', 'github_search_username',    description='Search Github (the common www source of many addons) for a specific Kodi developers User name',  icon=ICONGITHUB, themeit=THEME3)
    addDir('Search by GitHub Repository Title','github_search_repo', description='Search Github (the common www source of many addons) for a specific Kodi developers Repo name', icon=ICONGITHUB, themeit=THEME3)
    addDir('Search GitHub by Addon ID','github_search_addon_id',     description='Search Github (the common www source of many addons) for a specific Kodi Addon', icon=ICONGITHUB, themeit=THEME3)
    addFile('GitHub Update Addons','github_update',                  description='GitHub Update Addons ',  icon=ICONSETTINGS, themeit=THEME3)
    addFile('GitHub instructions','github_instructions',             description='Instructions for how to use GitHub Browser',  icon=ICONINFO, themeit=THEME3)
    setView('files', 'viewType')
def _get_keyboard(default="", heading="", hidden=False):  # Start Ketboard Function
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return unicode(keyboard.getText(), "utf-8")
    return default
def SEARCHADDON(url):  # Start Search Function
    vq = _get_keyboard(heading="Search add-ons")
    if (not vq):
        return False, 0
    title = urllib.quote_plus(vq)
    Get_search_results(title)
def Get_search_results(title):
    link = api.search_addons(title)
    my_list = sorted(link, key=lambda k: k['name'].upper())
    for e in link:
        name = e['name']
        repourl = e['repodlpath']
        path = e['addon_zip_path']
        description = e['description']
        icon = path.rsplit('/', 1)[0] + '/icon.png'
        fanart = path.rsplit('/', 1)[0] + '/fanart.jpg'
        if e['extension_point'] != 'xbmc.addon.repository':
            try:
                addDir(name, path, 'addoninstall', icon, fanart, description, 'addon', repourl, '', '', CMi, contextreplace=False)
            except: pass
    #viewsetter.set_view("sets")
def github_search(url):
    from resources.lib.github_installer import kodi as _kodi
    q = _get_keyboard("", "Search GitHub")
    if not q: return
    import json
    from resources.lib.github_installer import github_api
    if url == 'username':
        rtype = 'api'
        response = github_api.find_zips(q)
        if response is None: return
        for r in github_api.sort_results(response['items']):
            if not r['path'].endswith(".zip"): continue
            url = github_api.content_url % (r['repository']['full_name'], r['path'])
            _kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'repo':
        rtype = 'api'
        results = github_api.search(q, 'title')
        if results is None: return
        for i in results['items']:
            user = i['owner']['login']
            response = github_api.find_zips(user)
            if response is None: continue
            for r in github_api.sort_results(response['items']):
                if not r['path'].endswith(".zip"): continue
                url = github_api.content_url % (r['repository']['full_name'], r['path'])
                _kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'addon_id':
        rtype = 'web'
        results = github_api.web_search(q)
    else:
        rtype = 'api'
        results = github_api.search(q)
    if results is None: return
    for r in results['items']:
        if rtype == 'api':
            _kodi.addDir(r['name'], json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
        else:
            _kodi.addItem("%s/%s" % (r['owner']['login'], r['name']), json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
    #viewsetter.set_view("list")
def github_results(url):
    import json
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    from resources.lib.github_installer import github_api
    args = json.loads(url)
    #viewsetter.set_view("list")
    if args['rtype'] == 'web':
        from resources.lib.github_installer import kodi as _kodi
        full_name = "%s/%s" % (args['user'], args['repo'])
        c = _kodi.dialog_confirm("Confirm Install", full_name, yes="Install", no="Cancel")
        if not c: return
        url = "https://github.com/%s/%s/archive/master.zip" % (args['user'], args['repo'])
        Ins = github_installer.GitHub_Installer(args['repo'], url, full_name, _kodi.vfs.join("special://home", "addons"), True)
        return
    results = github_api.find_zips(args['user'], args['repo'])
    if results is None: return
    for r in results['items']:
        if r['repository']['name'] != args['repo']: continue
        url = github_api.content_url % (r['repository']['full_name'], r['path'])
        _kodi.addItem(r['name'], json.dumps({'file': r['name'], "url": url, "full_name": r['repository']['full_name']}), 'github_install', '', description="")
    #viewsetter.set_view("list")
def github_install(url):
    import re
    import json
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    from resources.lib.github_installer import github_api
    args = json.loads(url)
    if 'file' in args:
        #viewsetter.set_view("list")
        c = _kodi.dialog_confirm("Confirm Install", args['file'])
        if not c: return
        addon_id = re.sub("-[\d\.]+zip$", "", args['file'])
        github_installer.GitHub_Installer(addon_id, args['url'], args['full_name'], _kodi.vfs.join("special://home", "addons"))
        if not DIALOG.yesno(ADDONTITLE, '                     Click Continue to install more addons or',
                            '                    Restart button to finalize addon installation',
                            "                          Brought To You By %s " % ADDONTITLE,
                            nolabel='Restart', yeslabel='Continue'):
            xbmc.executebuiltin('ShutDown')
        #viewsetter.set_view("list")
    else:
        pass
def github_instructions():
    from resources.lib.github_installer import kodi as _kodi
    try:
        KODI_LANGUAGE = xbmc.getLanguage()
    except:
        KODI_LANGUAGE = 'English'
    #path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    if not _kodi.vfs.exists(path):
        path = _kodi.vfs.join(_kodi.get_path(), 'resources/lib/github_installer/github_help.txt')
    text = _kodi.vfs.read_file(path)
    _kodi.dialog_textbox('GitHub Browser Instructions', text)
def github_update():
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    c = _kodi.dialog_confirm("Confirm Update", "Search for updates?")
    if c : github_installer.update_addons()




###########################
###### KEYMAP INSTALLER####
###########################
def keymaps(url):
    try:
        # better online KEYMAPSFILE
        link = wiz.openURL(KEYMAPSFILE).replace('\n','').replace('\r','')
    except:
        addDir("No Keymaps Available", '', description='Keymap Configuration',  icon=ICONXML,themeit=THEME3)
        return
    # add offline KEYMAPSTFILE
        
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?ash="(.+?)"').findall(link)
    if os.path.isfile(KEYBOARD_FILE):
        addFile("Remove Current Keymap Configuration", 'uninstall_keymap', description='Remove Current Keymap Configuration',  icon=ICONXML,themeit=THEME3)
    for name, url, iconimage, fanart, version, description in match:
        name = "[COLOR white][B]" + name + "[/B][/COLOR]"
        addFile(name, 'install_keymap', name=name, url=url,  description='Remove Current Keymap Configuration',  icon=ICONXML,themeit=THEME3)
    setView('files', 'viewType')
def install_keymap(name, url):
    if os.path.isfile(KEYBOARD_FILE):
        try:
            os.remove(KEYBOARD_FILE)
        except:
            pass
    # Check is the packages folder exists, if not create it.
    path = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
    if not os.path.exists(path):
        os.makedirs(path)
    path_key = xbmc.translatePath(os.path.join('special://home/userdata', 'keymaps'))
    if not os.path.exists(path_key):
        os.makedirs(path_key)
    buildname = name
    dp = xbmcgui.DialogProgress()
    dp.create("Keymap Installer", "", "", "[B]Keymap: [/B]" + buildname)
    buildname = "customkeymap"
    lib = os.path.join(path, buildname + '.zip')
    try:
        os.remove(lib)
    except:
        pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://', 'home'))
    time.sleep(2)
    dp.update(0, "", "Installing Please wait..", "")
    try:
        extract.all(lib,ADDONS,dp, title="Installing Please wait..")
    except IOError, (errno, strerror):
        kodi.message("Failed to open required files", "Error code is:", strerror)
        return False
    time.sleep(1)
    try:
        os.remove(lib)
    except:
        pass
    xbmc.executebuiltin("Container.Refresh")
    xbmcgui.Dialog().ok("[B][COLOR white]Custom Keymap Installed![/COLOR][/B]", '%s' % name)
def uninstall_keymap():
    try: os.remove(KEYBOARD_FILE)
    except: pass
    #_notify('Checking Addon...', 'Success, we have removed the keyboards.xml file.', ICON, duration=1000)
    xbmcgui.Dialog().ok(AddonTitle, "[B][COLOR white]Success, we have removed the keyboards.xml file.[/COLOR][/B]", '%s' % name)



###########################
###### Misc Functions######
###########################
def clone_addon():
    if DIALOG.yesno(ADDONTITLE, "Would you like to make your custom version of this addon?", yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
        check=True
    if check==True:
        name2 = wiz.getKeyboard(ADDONTITLE, 'Enter the Name of the Wizard')
        url2  = wiz.getKeyboard(ADDON_ID+'2', 'Enter the plugin ID of the Wizard')
        wiz.setS('ADDONNEWNAME', name2)
        wiz.setS('ADDONNEWID',   url2)
        shutil.copytree(PLUGIN, os.path.join(ADDONS, url2), symlinks=False, ignore=None)
        Clean_Name = os.path.join(ADDONS, url2, 'addon.xml')
        if os.path.exists(DUMMY): os.remove(DUMMY)
        try:    os.rename(Clean_Name, DUMMY)
        except: pass
        s=open(DUMMY).read()
        s=s.replace(ADDON_ID,url2)
        s=s.replace('XYZ Wizard',name2)
        s=s.replace('icon.gif','icon.png')
        f=open(Clean_Name,'a')
        f.write(s)
        f.close()
        if os.path.exists(DUMMY): os.remove(DUMMY)
        set_enabled(url2, data=None)
        wiz.ebi('UpdateAddonRepos()')
        wiz.ebi('UpdateLocalAddons()')
        wiz.refresh()
        _notify('Done', url2, ICON, duration=1000)
        if DIALOG.yesno(ADDONTITLE, "Want to run your new addon?", yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
            check=True
        if check==True:
            wiz.ebi('RunAddon(%s)' % url2)
        else: return True
def systemInfo():
    infoLabel = ['System.FriendlyName', 
                 'System.BuildVersion', 
                 'System.CpuUsage',
                 'System.ScreenMode',
                 'Network.IPAddress',
                 'Network.MacAddress',
                 'System.Uptime',
                 'System.TotalUptime',
                 'System.FreeSpace',
                 'System.UsedSpace',
                 'System.TotalSpace',
                 'System.Memory(free)',
                 'System.Memory(used)',
                 'System.Memory(total)']
    data      = []; x = 0
    for info in infoLabel:
        temp = wiz.getInfo(info)
        y = 0
        while temp == "Busy" and y < 10:
            temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(200)
        data.append(temp)
        x += 1
    storage_free  = data[8] if 'Una' in data[8] else wiz.convertSize(int(float(data[8][:-8]))*1024*1024)
    storage_used  = data[9] if 'Una' in data[9] else wiz.convertSize(int(float(data[9][:-8]))*1024*1024)
    storage_total = data[10] if 'Una' in data[10] else wiz.convertSize(int(float(data[10][:-8]))*1024*1024)
    ram_free      = wiz.convertSize(int(float(data[11][:-2]))*1024*1024)
    ram_used      = wiz.convertSize(int(float(data[12][:-2]))*1024*1024)
    ram_total     = wiz.convertSize(int(float(data[13][:-2]))*1024*1024)
    picture = []; music = []; video = []; programs = []; repos = []; scripts = []; skins = []
    
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            prov   = re.compile("<provides>(.+?)</provides>").findall(a)
            if len(prov) == 0:
                if foldername.startswith('skin'): skins.append(foldername)
                if foldername.startswith('repo'): repos.append(foldername)
                else: scripts.append(foldername)
            elif not (prov[0]).find('executable') == -1: programs.append(foldername)
            elif not (prov[0]).find('video') == -1: video.append(foldername)
            elif not (prov[0]).find('audio') == -1: music.append(foldername)
            elif not (prov[0]).find('image') == -1: picture.append(foldername)
    # getip
    f = urllib.urlopen("http://www.canyouseeme.org/")
    html_doc = f.read()
    f.close()
    m = re.search('IP"\svalue="([^"]*)', html_doc)
    #addFile('[B]Media Center Info:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]' %        (COLOR1, COLOR2, data[0]), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]' %     (COLOR1, COLOR2, data[1]), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]' %    (COLOR1, COLOR2, wiz.platform().title()), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLOR1, COLOR2, data[2]), '', icon=ICONMAINT, themeit=THEME3)
    #addFile('[B]Ram Usage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Memory:[/COLOR] [COLOR %s]%s[/COLOR]   Free:%s\%s' % (COLOR1, COLOR2, ram_total, ram_used, ram_free), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[B]Local Storage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Storage:[/COLOR] [COLOR %s]%s[/COLOR]  Free: %s\%s' % (COLOR1, COLOR2, storage_total, storage_free,storage_used), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR grey]py [B]%s[/B]  ( 2.7.9+ TLS\https)[/COLOR]' % pythonver, '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[3]), '', icon=ICONMAINT, themeit=THEME3)
    #addFile('[B]Uptime:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[6]), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[7]), '', icon=ICONMAINT, themeit=THEME2)
    
    #addFile('[B]Network:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]IP:[/COLOR] [COLOR %s]%s[/COLOR]     (%s)' % (COLOR1, COLOR2, data[4], m.group(1)), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1, COLOR2, exter_ip), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, provider), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, location), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'% (COLOR1, COLOR2, data[5]), '', icon=ICONMAINT, themeit=THEME2)
    
    totalcount = len(picture) + len(music) + len(video) + len(programs) + len(scripts) + len(skins) + len(repos) 
    addFile('[B]Addons([COLOR %s]%s[/COLOR]):[/B]' % (COLOR1, totalcount), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLOR1, COLOR2, str(len(video))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(programs))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLOR1, COLOR2, str(len(music))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(picture))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLOR1, COLOR2, str(len(repos))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]' %          (COLOR1, COLOR2, str(len(skins))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'% (COLOR1, COLOR2, str(len(scripts))), '', icon=ICONMAINT, themeit=THEME2)
def saveMenu():
    on = '[COLOR green]ON[/COLOR]'; off = '[COLOR red]OFF[/COLOR]'
    trakt      = 'true' if KEEPTRAKT     == 'true' else 'false'
    real       = 'true' if KEEPREAL      == 'true' else 'false'
    login      = 'true' if KEEPLOGIN     == 'true' else 'false'
    sources    = 'true' if KEEPSOURCES   == 'true' else 'false'
    advanced   = 'true' if KEEPADVANCED  == 'true' else 'false'
    profiles   = 'true' if KEEPPROFILES  == 'true' else 'false'
    favourites = 'true' if KEEPFAVS      == 'true' else 'false'
    repos      = 'true' if KEEPREPOS     == 'true' else 'false'
    super      = 'true' if KEEPSUPER     == 'true' else 'false'
    whitelist  = 'true' if KEEPWHITELIST == 'true' else 'false'

    addDir ('Keep Trakt Data',               'trakt',                icon=ICONTRAKT, themeit=THEME1)
    addDir ('Keep Real Debrid',              'realdebrid',           icon=ICONREAL,  themeit=THEME1)
    addDir ('Keep Login Info',               'login',                icon=ICONLOGIN, themeit=THEME1)
    addFile('Import Save Data',              'managedata', 'import', icon=ICONSAVE,  themeit=THEME2)
    addFile('Export Save Data',              'managedata', 'export', icon=ICONSAVE,  themeit=THEME2)
    addFile(wiz.sep('Click to toggle settings'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save Trakt: %s' % trakt.replace('true',on).replace('false',off)                       ,'togglesetting', name='keeptrakt',      icon=ICONTRAKT, themeit=THEME9)
    addFile('Save Real Debrid: %s' % real.replace('true',on).replace('false',off)                  ,'togglesetting', name='keepdebrid',     icon=ICONREAL,  themeit=THEME9)
    addFile('Save Login Info: %s' % login.replace('true',on).replace('false',off)                  ,'togglesetting', name='keeplogin',      icon=ICONLOGIN, themeit=THEME9)
    addFile('Keep \'Sources.xml\': %s' % sources.replace('true',on).replace('false',off)           ,'togglesetting', name='keepsources',    icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Profiles.xml\': %s' % profiles.replace('true',on).replace('false',off)         ,'togglesetting', name='keepprofiles',   icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Advancedsettings.xml\': %s' % advanced.replace('true',on).replace('false',off) ,'togglesetting', name='keepadvanced',   icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Favourites.xml\': %s' % favourites.replace('true',on).replace('false',off)     ,'togglesetting', name='keepfavourites', icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep Super Favourites: %s' % super.replace('true',on).replace('false',off)            ,'togglesetting', name='keepsuper',      icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep Installed Repo\'s: %s' % repos.replace('true',on).replace('false',off)           ,'togglesetting', name='keeprepos',      icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep My \'WhiteList\': %s' % whitelist.replace('true',on).replace('false',off)        ,'togglesetting', name='keepwhitelist',  icon=ICONSETTINGS,  themeit=THEME9)
    if whitelist == 'true':
        addFile('Edit My Whitelist',        'whitelist', 'edit',   icon=ICONSETTINGS,  themeit=THEME3)
        addFile('View My Whitelist',        'whitelist', 'view',   icon=ICONSETTINGS,  themeit=THEME3)
        addFile('Clear My Whitelist',       'whitelist', 'clear',  icon=ICONSETTINGS,  themeit=THEME3)
        addFile('Import My Whitelist',      'whitelist', 'import', icon=ICONBACKUP,  themeit=THEME3)
        addFile('Export My Whitelist',      'whitelist', 'export', icon=ICONRESTORE,  themeit=THEME3)
    setView('files', 'viewType')
def traktMenu():
    trakt = '[COLOR green]ON[/COLOR]' if KEEPTRAKT == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(TRAKTSAVE) if not TRAKTSAVE == '' else 'Trakt hasnt been saved yet.'
    addFile('[I]Register FREE Account at http://trakt.tv[/I]', '', icon=ICONTRAKT, themeit=THEME3)
    addFile('Save Trakt Data: %s' % trakt, 'togglesetting', name='keeptrakt', icon=ICONTRAKT, themeit=THEME3)
    if KEEPTRAKT == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONTRAKT, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('TRAKT'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Trakt Data',          'savetrakt',    'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Recover All Saved Trakt Data', 'restoretrakt', 'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Import Trakt Data',            'importtrakt',  'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Clear All Saved Trakt Data',   'cleartrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Clear All Addon Data',         'addontrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONTRAKT, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('TRAKT ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for trakt in traktit.ORDER:
        name   = TRAKTID[trakt]['name']
        path   = TRAKTID[trakt]['path']
        saved  = TRAKTID[trakt]['saved']
        file   = TRAKTID[trakt]['file']
        user   = wiz.getS(saved)
        auser  = traktit.traktUser(trakt)
        icon   = TRAKTID[trakt]['icon']   if os.path.exists(path) else ICONTRAKT
        fanart = TRAKTID[trakt]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('savedebridtraktdetails', 'Trakt', trakt)
        menu2 = createMenu('savedebridtrakt', 'Trakt', trakt)
        menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)' %   (ADDON_ID, trakt)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt', trakt, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authtrakt', trakt, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt', trakt, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt', trakt, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=ICON, fanart=FANART, menu=menu2)
    
    setView('files', 'viewType')
def realMenu():
    real = '[COLOR green]ON[/COLOR]' if KEEPREAL == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(REALSAVE) if not REALSAVE == '' else 'Real Debrid hasnt been saved yet.'
    addFile('[I]http://real-debrid.com is a PAID service.[/I]', '', icon=ICONREAL, themeit=THEME3)
    addFile('Save Real Debrid Data: %s' % real, 'togglesetting', name='keepdebrid', icon=ICONREAL, themeit=THEME3)
    if KEEPREAL == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONREAL, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('REAL DEBRID'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Real Debrid Data',          'savedebrid',    'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Recover All Saved Real Debrid Data', 'restoredebrid', 'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Import Real Debrid Data',            'importdebrid',  'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Clear All Saved Real Debrid Data',   'cleardebrid',   'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Clear All Addon Data',               'addondebrid',   'all', icon=ICONREAL,  themeit=THEME3)    
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONREAL, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('REAL DEBRID ACCOUNT ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for debrid in debridit.ORDER:
        name   = DEBRIDID[debrid]['name']
        path   = DEBRIDID[debrid]['path']
        saved  = DEBRIDID[debrid]['saved']
        file   = DEBRIDID[debrid]['file']
        user   = wiz.getS(saved)
        auser  = debridit.debridUser(debrid)
        icon   = DEBRIDID[debrid]['icon']   if os.path.exists(path) else ICONREAL
        fanart = DEBRIDID[debrid]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('savedebridtraktdetails', 'Debrid', debrid)
        menu2 = createMenu('savedebridtrakt', 'Debrid', debrid)
        menu.append((THEME2 % '%s Settings' % name, 'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)' %   (ADDON_ID, debrid)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid', debrid, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authdebrid', debrid, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid', debrid, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid', debrid, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=ICON, fanart=FANART, menu=menu2)
    
    setView('files', 'viewType')
def loginMenu():
    login = '[COLOR green]ON[/COLOR]' if KEEPLOGIN == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(LOGINSAVE) if not LOGINSAVE == '' else 'Login data hasnt been saved yet.'
    addFile('[I]Several of these addons are PAID services.[/I]', '', icon=ICONLOGIN, themeit=THEME3)
    addFile('Save Login Data: %s' % login, 'togglesetting', name='keeplogin', icon=ICONLOGIN, themeit=THEME3)
    if KEEPLOGIN == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONLOGIN, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('LOGIN'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Login Data',          'savelogin',    'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Recover All Saved Login Data', 'restorelogin', 'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Import Login Data',            'importlogin',  'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Clear All Saved Login Data',   'clearlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Clear All Addon Data',         'addonlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONLOGIN, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('LOGIN'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for login in loginit.ORDER:
        name   = LOGINID[login]['name']
        path   = LOGINID[login]['path']
        saved  = LOGINID[login]['saved']
        file   = LOGINID[login]['file']
        user   = wiz.getS(saved)
        auser  = loginit.loginUser(login)
        icon   = LOGINID[login]['icon']   if os.path.exists(path) else ICONLOGIN
        fanart = LOGINID[login]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('savedebridtraktdetails', 'Login', login)
        menu2 = createMenu('savedebridtrakt', 'Login', login)
        menu.append((THEME2 % '%s Settings' % name, 'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)' %   (ADDON_ID, login)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '',                 icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin', login, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authlogin',   login, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin', login, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',      login, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user,                '',    icon=ICON, fanart=FANART, menu=menu2)


    setView('files', 'viewType')
def fixUpdate():
    if KODIV < 17: 
        dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
        try:
            os.remove(dbfile)
        except Exception, e:
            wiz.log("Unable to remove %s, Purging DB" % dbfile)
            wiz.purgeDb(dbfile)
    else:
        xbmc.log("Requested Addons.db be removed but doesnt work in Kod17")
def removeAddonMenu():
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        elif foldername in DEFAULTPLUGINS: continue
        elif foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            match  = wiz.parseDOM(a, 'addon', ret='id')

            addid  = foldername if len(match) == 0 else match[0]
            try: 
                add = xbmcaddon.Addon(id=addid)
                addonnames.append(add.getAddonInfo('name'))
                addonids.append(addid)
            except:
                pass
    if len(addonnames) == 0:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No Addons To Remove[/COLOR]" % COLOR2)
        return
    if KODIV > 16:
        selected = DIALOG.multiselect("%s: Select the addons you wish to remove." % ADDONTITLE, addonnames)
    else:
        selected = []; choice = 0
        tempaddonnames = ["-- Click here to Continue --"] + addonnames
        while not choice == -1:
            choice = DIALOG.select("%s: Select the addons you wish to remove." % ADDONTITLE, tempaddonnames)
            if choice == -1: break
            elif choice == 0: break
            else: 
                choice2 = (choice-1)
                if choice2 in selected:
                    selected.remove(choice2)
                    tempaddonnames[choice] = addonnames[choice2]
                else:
                    selected.append(choice2)
                    tempaddonnames[choice] = "[B][COLOR %s]%s[/COLOR][/B]" % (COLOR1, addonnames[choice2])
    if selected == None: return
    if len(selected) > 0:
        wiz.addonUpdates('set')
        for addon in selected:
            removeAddon(addonids[addon], addonnames[addon], True)

        xbmc.sleep(500)
        
        if INSTALLMETHOD == 1: todo = 1
        elif INSTALLMETHOD == 2: todo = 0
        else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR white]Would you like to:[/COLOR]\n[COLOR gold]Force Close[/COLOR]       (Close Kodi and enable settings)\n[COLOR gold]Reload Profile[/COLOR]   (Only Refresh skin to enable settings)", yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
        if todo == 1: wiz.reloadFix('remove addon')
        else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
def removeAddonDataMenu():
    if os.path.exists(ADDOND):
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data', 'removedata', 'all', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons', 'removedata', 'uninstalled', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data', 'removedata', 'empty', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data' % ADDONTITLE, 'resetaddon', themeit=THEME2)
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
        if HIDESPACERS == 'No': addFile(wiz.sep('ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        fold = glob.glob(os.path.join(ADDOND, '*/'))
        for folder in sorted(fold, key = lambda x: x):
            foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
            icon = os.path.join(folder.replace(ADDOND, ADDONS), 'icon.png')
            fanart = os.path.join(folder.replace(ADDOND, ADDONS), 'fanart.png')
            folderdisplay = foldername
            replace = {'audio.':'[COLOR orange][AUDIO] [/COLOR]', 'metadata.':'[COLOR cyan][METADATA] [/COLOR]', 'module.':'[COLOR orange][MODULE] [/COLOR]', 'plugin.':'[COLOR blue][PLUGIN] [/COLOR]', 'program.':'[COLOR orange][PROGRAM] [/COLOR]', 'repository.':'[COLOR gold][REPO] [/COLOR]', 'script.':'[COLOR green][SCRIPT] [/COLOR]', 'service.':'[COLOR green][SERVICE] [/COLOR]', 'skin.':'[COLOR dodgerblue][SKIN] [/COLOR]', 'video.':'[COLOR orange][VIDEO] [/COLOR]', 'weather.':'[COLOR yellow][WEATHER] [/COLOR]'}
            for rep in replace:
                folderdisplay = folderdisplay.replace(rep, replace[rep])
            if foldername in EXCLUDES: folderdisplay = '[COLOR green][B][PROTECTED][/B][/COLOR] %s' % folderdisplay
            else: folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] %s' % folderdisplay
            addFile(' %s' % folderdisplay, 'removedata', foldername, icon=ICON, fanart=FANART, themeit=THEME2)
    else:
        addFile('No Addon data folder found.', '', themeit=THEME3)
    setView('files', 'viewType')
def enableAddons():
    addFile("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]", '', icon=ICONMAINT)
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    x = 0
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        if foldername in DEFAULTPLUGINS: continue
        addonxml = os.path.join(folder, 'addon.xml')
        if os.path.exists(addonxml):
            x += 1
            fold   = folder.replace(ADDONS, '')[1:-1]
            f      = open(addonxml)
            a      = f.read().replace('\n','').replace('\r','').replace('\t','')
            match  = wiz.parseDOM(a, 'addon', ret='id')
            match2 = wiz.parseDOM(a, 'addon', ret='name')
            try:
                pluginid = match[0]
                name = match2[0]
            except:
                continue
            try:
                add    = xbmcaddon.Addon(id=pluginid)
                state  = "[COLOR green][Enabled][/COLOR]"
                goto   = "false"
            except:
                state  = "[COLOR red][Disabled][/COLOR]"
                goto   = "true"
                pass
            icon   = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ICON
            fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else FANART
            addFile("%s %s" % (state, name), 'toggleaddon', fold, goto, icon=ICON, fanart=FANART)
            f.close()
    if x == 0:
        addFile("No Addons Found to Enable or Disable.", '', icon=ICONMAINT)
    setView('files', 'viewType')
def changeFeq():
    feq        = ['Every Startup', 'Every Day', 'Every Three Days', 'Every Weekly']
    change     = DIALOG.select("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]" % COLOR2, feq)
    if not change == -1: 
        wiz.setS('autocleanfeq', str(change))
        wiz.LogNotify('[COLOR %s]Auto Clean Up[/COLOR]' % COLOR1, '[COLOR %s]Fequency Now %s[/COLOR]' % (COLOR2, feq[change]))
def developer():
    addFile('Convert Text Files to 0.1.7',         'converttext',           themeit=THEME3)
    addFile('Test Notifications',                  'testnotify',            themeit=THEME3)
    addFile('Test Update',                         'testupdate',            themeit=THEME3)
    addFile('Test First Run',                      'testfirst',             themeit=THEME3)
    addFile('Test First Run Settings',             'testfirstrun',          themeit=THEME3)
    addFile('Test APk',                            'testapk',               themeit=THEME3)
    setView('files', 'viewType')
def toggleCache(state):
    cachelist = ['includevideo', 'includeall', 'include1channel', 'includealluc', 'includebennu', 'includebobunleashed', 'includebubbles', 'includecovenant', 'includeelysium', 'includeexodus', 'includegurzil', 'includeicefilms', 'includespecto', 'includetinklepad', 'includeugottoc', 'includexxxodus', 'includesalts', 'includealluc', 'includeonechannel', 'includeugottoc']
    titlelist = ['Include Video Addons', 'Include All Addons', 'Include 1Channel', 'Include Alluc', 'Include Bennu', 'Include BOB Unleashed', 'Include Bubbles', 'Include Covenant', 'Include Elysium', 'Include Exodus', 'Include Gurzil', 'Include Icefilms', 'Include Specto', 'Include Tinklepad', 'Include UGOTTOC', 'Include XXXODUS', 'Include SALTS', 'Include ALLUC', 'Include ONECHANNEL', 'Include UGOTTOC']
    if state in ['true', 'false']:
        for item in cachelist:
            wiz.setS(item, state)
    else:
        if not state in ['includevideo', 'includeall'] and wiz.getS('includeall') == 'true':
            try:
                item = titlelist[cachelist.index(state)]
                DIALOG.ok(ADDONTITLE, "[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, COLOR1, item))
            except:
                wiz.LogNotify("[COLOR %s]Toggle Cache[/COLOR]" % COLOR1, "[COLOR %s]Invalid id: %s[/COLOR]" % (COLOR2, state))
        else:
            new = 'true' if wiz.getS(state) == 'false' else 'false'
            wiz.setS(state, new)
def playVideo(url):
    if 'watch?v=' in url:
        a, b = url.split('?')
        find = b.split('&')
        for item in find:
            if item.startswith('v='):
                url = item[2:]
                break
            else: continue
    elif 'embed' in url or 'youtu.be' in url:
        a = url.split('/')
        if len(a[-1]) > 5:
            url = a[-1]
        elif len(a[-2]) > 5:
            url = a[-2]
    wiz.log("YouTube URL: %s" % url)
    yt.PlayVideo(url)
def viewLogFile():
    mainlog = wiz.Grab_Log(True)
    oldlog  = wiz.Grab_Log(True, True)
    which = 0; logtype = mainlog
    if not oldlog == False and not mainlog == False:
        which = DIALOG.select(ADDONTITLE, ["View %s" % mainlog.replace(LOG, ""), "View %s" % oldlog.replace(LOG, "")])
        if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
    elif mainlog == False and oldlog == False:
        wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
        return
    elif not mainlog == False: which = 0
    elif not oldlog == False: which = 1
    logtype = mainlog if which == 0 else oldlog
    msg     = wiz.Grab_Log(False) if which == 0 else wiz.Grab_Log(False, True)
    wiz.TextBox("%s - %s" % (ADDONTITLE, logtype), msg)
def LogViewer(default=None):
    class LogViewer(xbmcgui.WindowXMLDialog):
        def __init__(self,*args,**kwargs):
            self.default = kwargs['default']
        def onInit(self):
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.upload     = 201
            self.kodi       = 202
            self.kodiold    = 203
            self.wizard     = 204
            self.okbutton   = 205
            #
            self.advanced   = 206
            self.playercore = 207
            self.sources    = 208
            self.rssfeeds   = 209
            f = open(self.default, 'r')
            self.logmsg = f.read()
            f.close()
            self.titlemsg = "%s: %s" % (ADDONTITLE, self.default.replace(LOG, '').replace(ADDONDATA, ''))
            self.showdialog()
        def showdialog(self):
            self.getControl(self.title).setLabel(self.titlemsg)
            self.getControl(self.msg).setText(wiz.highlightText(self.logmsg))
            self.setFocusId(self.scrollbar)
        def onClick(self, controlId):
            if   controlId == self.okbutton: self.close()
            elif controlId == self.upload: self.close(); uploadLog.Main()
            elif controlId == self.kodi:
                newmsg = wiz.Grab_Log(False)
                filename = wiz.Grab_Log(True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.kodiold:  
                newmsg = wiz.Grab_Log(False, True)
                filename = wiz.Grab_Log(True, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.wizard:
                newmsg = wiz.Grab_Log(False, False, True)
                filename = wiz.Grab_Log(True, False, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "[COLOR orange]%s: wizard.log[/COLOR]  (This addons Log)\n\n   %s" % (ADDONTITLE, filename.replace(ADDONDATA, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.advanced:
                newmsg = wiz.Grab_xml(True, False, False, False)
                filename = wiz.Grab_xml(True, False, False, False)
                if os.path.exists(ADVANCED):
                    #self.titlemsg = "%s: %s" % (ADDONTITLE,  filename.replace(ADVANCED, ''))
                    self.titlemsg = "[COLOR orange]%s: advanced.xml[/COLOR]  (extra gui tweaks to override guisettings.xml)\n\n   %s" % (ADDONTITLE,  filename.replace(ADVANCED, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View advancedsettings Error" % ADDONTITLE
                    self.getControl(self.msg).setText("advancedsettings File Does Not Exists!")
            elif controlId == self.playercore:
                newmsg = wiz.Grab_xml(False, True, False, False)
                filename = wiz.Grab_xml(False, True, False, False)
                if os.path.exists(PLAYERCORE):
                    self.titlemsg = "[COLOR orange]%s: advanced.xml[/COLOR]  (3rd Party Players)\n\n   %s" % (ADDONTITLE,  filename.replace(PLAYERCORE, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View playerfactorycore.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("playerfactorycore.xml File Does Not Exists!")
            elif controlId == self.sources:
                newmsg = wiz.Grab_xml(False, False, True, False)
                filename = wiz.Grab_xml(False, False, True, False)
                if os.path.exists(SOURCES):
                    self.titlemsg = "[COLOR orange]%s: sources.xml[/COLOR]  (Media and repo paths)\n\n   %s" % (ADDONTITLE,  filename.replace(SOURCES, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View sources.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("sources.xml File Does Not Exists!")
            elif controlId == self.rssfeeds:
                newmsg = wiz.Grab_xml(False, False, False, True)
                filename = wiz.Grab_xml(False, False, False, True)
                if os.path.exists(RSSFILE):
                    self.titlemsg = "[COLOR orange]%s: RssFeeds.xml[/COLOR]  (Kodi Rss Feeds)\n\n   %s" % (ADDONTITLE,  filename.replace(RSSFILE, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View rssfeeds.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("rssfeeds.xml File Does Not Exists!")
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    if default == None: default = wiz.Grab_Log(True)
    lv = LogViewer( "LogViewer.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', default=default)
    lv.doModal()
    del lv
def Show_Dialog(line1,line2,line3):
    dialog = xbmcgui.Dialog()
    dialog.ok('Kodi Log Emailer', line1,line2,line3)
def removeAddon(addon, name, over=False):
    if not over == False:
        yes = 1
    else: 
        yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Are you sure you want to delete the addon:'% COLOR2, 'Name: [COLOR %s]%s[/COLOR]' % (COLOR1, name), 'ID: [COLOR %s]%s[/COLOR][/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Addon[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
    if yes == 1:
        folder = os.path.join(ADDONS, addon)
        wiz.log("Removing Addon %s" % addon)
        wiz.cleanHouse(folder)
        xbmc.sleep(200)
        try: shutil.rmtree(folder)
        except Exception ,e: wiz.log("Error removing %s" % addon, xbmc.LOGNOTICE)
        removeAddonData(addon, name, over)
    if over == False:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]%s Removed[/COLOR]" % (COLOR2, name))
def removeAddonData(addon, name=None, over=False):
    if addon == 'all':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            wiz.cleanHouse(ADDOND)
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    elif addon == 'uninstalled':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = 0
            for folder in glob.glob(os.path.join(ADDOND, '*')):
                foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
                if foldername in EXCLUDES: pass
                elif os.path.exists(os.path.join(ADDONS, foldername)): pass
                else: wiz.cleanHouse(folder); total += 1; wiz.log(folder); shutil.rmtree(folder)
            wiz.LogNotify('[COLOR %s]Clean up Uninstalled[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    elif addon == 'empty':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = wiz.emptyfolder(ADDOND)
            wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
        else: wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    else:
        addon_data = os.path.join(USERDATA, 'addon_data', addon)
        if addon in EXCLUDES:
            wiz.LogNotify("[COLOR %s]Protected Plugin[/COLOR]" % COLOR1, "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % COLOR2)
        elif os.path.exists(addon_data):  
            if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
                wiz.cleanHouse(addon_data)
                try:
                    shutil.rmtree(addon_data)
                except:
                    wiz.log("Error deleting: %s" % addon_data)
            else: 
                wiz.log('Addon data for %s was not removed' % addon)
    wiz.refresh()
def restoreit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Local Restore Cancelled[/COLOR]" % COLOR2); return
    if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
        wiz.skinToDefault()
    wiz.restoreLocal(type)
def restoreextit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]External Restore Cancelled[/COLOR]" % COLOR2); return
    wiz.restoreExternal(type)
def buildInfo(name):
    #if wiz.workingURL(BUILDFILE) == True:
        if wiz.checkBuild(name, 'url'):
            name, version, url, gui, kodi, theme, icon, fanart, preview, adult, description = wiz.checkBuild(name, 'all')
            adult = 'Yes' if adult.lower() == 'yes' else 'No'
            msg  = "[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, name)
            msg += "[COLOR %s]Build Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, version)
            if not theme == "http://":
                themecount = wiz.themeCount(name, False)
                msg += "[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, ', '.join(themecount))
            msg += "[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, kodi)
            msg += "[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, adult)
            msg += "[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, description)
            wiz.TextBox(ADDONTITLE, msg)
        else: wiz.log("Invalid Build Name!")
def buildVideo(name):
    if wiz.workingURL(BUILDFILE) == True:
        videofile = wiz.checkBuild(name, 'preview')
        if videofile and not videofile == 'http://': playVideo(videofile)
        else: wiz.log("[%s]Unable to find url for video preview" % name)
    else: wiz.log("Build text file not working: %s" % WORKINGURL)
def dependsList(plugin):
    addonxml = os.path.join(ADDONS, plugin, 'addon.xml')
    if os.path.exists(addonxml):
        source = open(addonxml,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        items  = []
        for depends in match:
            if not 'xbmc.python' in depends:
                items.append(depends)
        return items
    return []
def manageSaveData(do):
    if do == 'import':
        TEMP = os.path.join(ADDONDATA, 'temp')
        if not os.path.exists(TEMP): os.makedirs(TEMP)
        #source = DIALOG.browse(1, '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % COLOR2, 'files', '.zip', False, False, HOME)
        source = DIALOG.browse(0, '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % COLOR2, 'files', '.zip', False, False, HOME)
        if not source.endswith('.zip'):
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Import Data Error![/COLOR]" % (COLOR2))
            return
        tempfile = os.path.join(MYBUILDS, 'SaveData.zip')
        goto = xbmcvfs.copy(source, tempfile)
        wiz.log("%s" % str(goto))
        extract.all(xbmc.translatePath(tempfile), TEMP)
        trakt  = os.path.join(TEMP, 'trakt')
        login  = os.path.join(TEMP, 'login')
        debrid = os.path.join(TEMP, 'debrid')
        x = 0
        if os.path.exists(trakt):
            x += 1
            files = os.listdir(trakt)
            if not os.path.exists(traktit.TRAKTFOLD): os.makedirs(traktit.TRAKTFOLD)
            for item in files:
                old  = os.path.join(traktit.TRAKTFOLD, item)
                temp = os.path.join(trakt, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            traktit.importlist('all')
            traktit.traktIt('restore', 'all')
        if os.path.exists(login):
            x += 1
            files = os.listdir(login)
            if not os.path.exists(loginit.LOGINFOLD): os.makedirs(loginit.LOGINFOLD)
            for item in files:
                old  = os.path.join(loginit.LOGINFOLD, item)
                temp = os.path.join(login, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            loginit.importlist('all')
            loginit.loginIt('restore', 'all')
        if os.path.exists(debrid):
            x += 1
            files = os.listdir(debrid)
            if not os.path.exists(debridit.REALFOLD): os.makedirs(debridit.REALFOLD)
            for item in files:
                old  = os.path.join(debridit.REALFOLD, item)
                temp = os.path.join(debrid, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            debridit.importlist('all')
            debridit.debridIt('restore', 'all')
        wiz.cleanHouse(TEMP)
        wiz.removeFolder(TEMP)
        os.remove(tempfile)
        if x == 0: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Failed[/COLOR]" % COLOR2)
        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Complete[/COLOR]" % COLOR2)
    elif do == 'export':
        mybuilds = xbmc.translatePath(MYBUILDS)
        dir = [traktit.TRAKTFOLD, debridit.REALFOLD, loginit.LOGINFOLD]
        traktit.traktIt('update', 'all')
        loginit.loginIt('update', 'all')
        debridit.debridIt('update', 'all')
        #source = DIALOG.browse(3, '[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]' % COLOR2, 'files', '', False, True, HOME)
        source = DIALOG.browse(0, '[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]' % COLOR2, 'files', '', False, True, HOME)
        source = xbmc.translatePath(source)
        tempzip = os.path.join(mybuilds, 'SaveData.zip')
        zipf = zipfile.ZipFile(tempzip, mode='w')
        for fold in dir:
            if os.path.exists(fold):
                files = os.listdir(fold)
                for file in files:
                    zipf.write(os.path.join(fold, file), os.path.join(fold, file).replace(ADDONDATA, ''), zipfile.ZIP_DEFLATED)
        zipf.close()
        if source == mybuilds:
            DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))
        else:
            try:
                xbmcvfs.copy(tempzip, os.path.join(source, 'SaveData.zip'))
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, os.path.join(source, 'SaveData.zip')))
            except:
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))
def platform():
    if xbmc.getCondVisibility('system.platform.android'): return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'): return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'): return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'): return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'): return 'ios'
def _notify(header,msg,icon_path,duration=2000, sound=False):
    #xbmc.executebuiltin('XBMC.Notification(%s,%s, %s, %s)' % (header, msg, duration, icon_path))
    xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)
def _get_keyboard(default="", heading="", hidden=False):  # Start Ketboard Function
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return unicode(keyboard.getText(), "utf-8")
    return default
def unzip(_in, _out, dp):
    __in = zipfile.ZipFile(_in,  'r')
    nofiles = float(len(__in.infolist()))
    count   = 0 
    try:
        for item in __in.infolist():
            count += 1
            update = (count / nofiles) * 100
            if DP.iscanceled():
                sys.exit()
            try:
                DP.update(int(update),'','','[COLOR dodgerblue][B]' + str(item.filename) + '[/B][/COLOR]')
                __in.extract(item, _out)
            except Exception, e:
                print str(e)
    except Exception, e:
        print str(e)
        return False    
    return True 
def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1
def remove_dir(path):
    dirList, flsList = xbmcvfs.listdir(path)
    for fl in flsList:
        xbmcvfs.delete(os.path.join(path, fl))
    for dr in dirList:
        xbmcvfs.delete(xbmc.translatePath(os.path.join(path, '%s')) % dr)
    xbmcvfs.rmdir(path)
def Destroy_Path(path):
    DP.create('Delete','Wiping...','', 'Please Wait')
    try:
        shutil.rmtree(path, ignore_errors=True)
    except: pass
def AppendText(SourceFile, DestFile):
    #xbmc.log(msg='##['+ADDON_ID+'] Append text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'a')
            f.write(s)
            f.close()
            s.close()
        except: pass
def WriteText(SourceFile, DestFile):
    #xbmc.log(msg='##['+ADDON_ID+'] Write text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'w')
            f.write(s)
            f.close()
            s.close()
        except: pass
def corefile_replace(newfile,corefiledir,corefile):
    #if dialog.yesno('Kick the tires?', 'Would you like to view '+newfile+' first?'):
    #    import main_TextViewer
    #    main_TextViewer.text_view(xbmc.translatePath(os.path.join(EXTRAPATH,corefiledir,newfile)))
    #if dialog.yesno('Replace?', 'Would you like to install '+newfile+'?'):
        xbmc.log(msg='##['+ADDON_ID+'] Attempt to replace '+corefile, level=xbmc.LOGNOTICE)
        asDest = xbmc.translatePath(os.path.join('special://home','userdata',corefile))
        asFile = xbmc.translatePath(os.path.join(EXTRAPATH,corefiledir,newfile))
        if os.path.exists(asDest):
            xbmcvfs.copy(asDest, asDest+'.last')
            delete_file(asDest)
        if os.path.exists(asFile):
           try:
                s=open(asFile).read()
                f=open(asDest,'w')
                f.write(s)
                f.close()
                s.close()
                _notify('XML','Replaced '+corefile,ICONHAPPY)
                xbmc.executebuiltin("XBMC.Container.Refresh")
           except: pass
def set_enabled(newaddon, data=None):
    from sqlite3 import dbapi2 as db_lib
    db_path = os.path.join(DATABASE, 'Addons27.db')
    conn = db_lib.connect(db_path)
    conn.text_factory = str
    #if kodi.get_kversion() > 16.5:
    if kodi_version >= 17:
        _notify('Enable','Enabling '+newaddon,ICON)
        setit = 1
        if data is None: data = ''
        sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
        conn.execute(sql, (newaddon, setit,))
        conn.commit()
    else:  pass
def setall_enable():
    from sqlite3 import dbapi2 as db_lib
    db_path = os.path.join(DATABASE, 'Addons27.db')
    conn = db_lib.connect(db_path)
    conn.text_factory = str
    #if kodi.get_kversion() > 16.5:
    if kodi_version >= 17:
        _notify('Enable','Enabling All Addons',ICON)
        contents = os.listdir(ADDONS)
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in contents))
        conn.commit()
    else: pass
def json_enable(name):# Not Needed
    if version == 17:
        ADDON      =  xbmc.translatePath(os.path.join('special://home/addons',name))
        ADDONICON  =  xbmc.translatePath(os.path.join('special://home/addons',name, 'icon.png'))
        if not os.path.exists(ADDONICON):
            ADDONICON  = ICON
        if os.path.exists(ADDON):
            _notify('Kodi 17','Refresh '+name,ADDONICON)
            addon_refresh()
            try:
                JSON = ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"%s", "enabled":true}, "id": 1}' % name)
                RunJSON = xbmc.executeJSONRPC(JSON)
            except: pass
def addon_refresh():
    xbmc.executebuiltin('ActivateWindow(busydialog)')
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')
    #time.sleep(1)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Container.Refresh')
def Update_Addons():
    # this will refresh the list of items warning when using this after video playing or dialog box it will send it in to a contentious loop
    #xbmc.executebuiltin('Container.Refresh')
    # this is a great script to user when using a function like login to the update the list result
    #xbmc.executebuiltin('Container.Update')
    # updates you local addon lists
    xbmc.executebuiltin("UpdateLocalAddons")
    #will update addons repo search for all updates 
    xbmc.executebuiltin("UpdateAddonRepos")
def delete_extra_addons(msgtitle,msgtxt,deletethisfullpath): 
    if os.path.exists(deletethisfullpath):
        if not DIALOG.yesno(msgtitle, msgtxt):
            try:
                shutil.rmtree(deletethisfullpath)
            except: pass
def EnableRTMP():
    set_enabled("inputstream.adaptive")
    time.sleep(0.5)
    set_enabled("inputstream.rtmp")
    time.sleep(0.5)
def Repolink(REPO_ID):
    #xbmc.executebuiltin('ActivateWindow(10040,addons://'+ADDON_ID+'/,return)')
    xbmc.executebuiltin('ActivateWindow(10040,addons://'+REPO_ID+'/,return)')
def testTheme(path):
    xbmc.log(msg='##['+ADDON_ID+'] testTheme', level=xbmc.LOGNOTICE)
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        if '/settings.xml' in item.filename:
            return True
    return False
def testGui(path):
    xbmc.log(msg='##['+ADDON_ID+'] testGui', level=xbmc.LOGNOTICE)
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        if '/guisettings.xml' in item.filename:
            return True
    return False
def EnableDebug():
    xbmc.executebuiltin('ToggleDebug')
    xbmc.executebuiltin('Skin.ToggleDebug')
def strings(id, replacements = None):
    string = ADDON.getLocalizedString(id)
    if replacements is not None:
        return string % replacements
    else:
        return string
def errorChecking(log=None, count=None, all=None):
    if log == None:
        mainlog = wiz.Grab_Log(True)
        oldlog  = wiz.Grab_Log(True, True)
        if not oldlog == False and not mainlog == False:
            which = DIALOG.select(ADDONTITLE, ["View %s: %s error(s)" % (mainlog.replace(LOG, ""), errorChecking(mainlog, True, True)), "View %s: %s error(s)" % (oldlog.replace(LOG, ""), errorChecking(oldlog, True, True))])
            if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
        elif mainlog == False and oldlog == False:
            wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
            return
        elif not mainlog == False: which = 0
        elif not oldlog == False: which = 1
        log = mainlog if which == 0 else oldlog
    if log == False:
        if count == None:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Log File not Found[/COLOR]" % COLOR2)
            return False
        else: 
            return 0
    else:
        if os.path.exists(log):
            f = open(log,mode='r'); a = f.read().replace('\n', '').replace('\r', ''); f.close()
            match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(a)
            if not count == None:
                if all == None: 
                    x = 0
                    for item in match:
                        if ADDON_ID in item: x += 1
                    return x
                else: return len(match)
            if len(match) > 0:
                x = 0; msg = ""
                for item in match:
                    if all == None and not ADDON_ID in item: continue
                    else: 
                        x += 1
                        msg += "[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n" % (x, item.replace('                                          ', '\n').replace('\\\\','\\').replace(HOME, ''))
                if x > 0:
                    wiz.TextBox(ADDONTITLE, msg)
                else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
            else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
        else: wiz.LogNotify(ADDONTITLE, "Log File not Found")
ACTION_PREVIOUS_MENU            =  10    ## ESC action
ACTION_NAV_BACK                 =  92    ## Backspace action
ACTION_MOVE_LEFT                =   1    ## Left arrow key
ACTION_MOVE_RIGHT               =   2    ## Right arrow key
ACTION_MOVE_UP                  =   3    ## Up arrow key
ACTION_MOVE_DOWN                =   4    ## Down arrow key
ACTION_MOUSE_WHEEL_UP           = 104    ## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN         = 105    ## Mouse wheel down
ACTION_MOVE_MOUSE               = 107    ## Down arrow key
ACTION_SELECT_ITEM              =   7    ## Number Pad Enter
ACTION_BACKSPACE                = 110    ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108
'''
def settingscategory(name):
    ADDON.openSettings(name)
'''
'''
def install_a_zip(name,url,dest,desc):
    if DIALOG.yesno('Zip Install', '[COLOR skyblue][B]Do you wish to install:[/B][/COLOR]\n[COLOR gold]%s[/COLOR]\n%s' % (name, desc)):
        PATH_ADDON(name, url, dest)
        _notify('Done','Done Installing '+name,ICON)
        wiz.clearPackages(); wiz.refresh()
        if kodi_version == '18': setall_enable()
        if kodi_version == '17': setall_enable()
        Update_Addons()
    sys.exit(0)
'''
'''
# other DLer
def download_notify(url, destination, dp=None, headers=None, cookies=None, allow_redirects=True, verify=True, timeout=30, auth=None):
    from resources.lib import requests
    if os.path.exists(destination):
        yes = DIALOG.yesno('Already Exists', "Would you like to Redownload?")
        if not yes:
            return
    try: os.remove(destination)
    except: pass
    dp = xbmcgui.DialogProgressBG()
    dp.create('Downloading')
    try:
        with open(destination, 'wb') as f:
            start = time.time()
            r = requests.get(url, headers=headers, cookies=cookies,
                             allow_redirects=allow_redirects, verify=verify,
                             timeout=timeout, auth=auth, stream=True)
            content_length = int(r.headers.get('content-length'))
            if content_length is None:
                f.write(r.content)
            else:
                dl = 0
                for chunk in r.iter_content(chunk_size=content_length/100):
                    dl += len(chunk)
                    if chunk:
                        f.write(chunk)
                    progress = (dl * 100 / content_length)
                    byte_speed = dl / (time.time() - start)
                    kbps_speed = byte_speed / 1024
                    mbps_speed = kbps_speed / 1024
                    downloaded = float(dl) / (1024 * 1024)
                    file_size = float(content_length) / (1024 * 1024)
                    if byte_speed > 0:
                        eta = (content_length - dl) / byte_speed
                    else:
                        eta = 0
                    line1 = '[COLOR darkgoldenrod]%.1f Mb[/COLOR] Of [COLOR darkgoldenrod]%.1f Mb[/COLOR]' %(downloaded, file_size)
                    line2 = 'Speed: [COLOR darkgoldenrod]%.01f Mbps[/COLOR]' %mbps_speed
                    line2 += ' ETA: [COLOR darkgoldenrod]%02d:%02d[/COLOR]' %divmod(eta, 60)
                    dp.update(progress, line1, line2)
        dp.close()
    except:
        dp.close()
'''
###########################
## Making the Directory####
###########################
    
# Context items. - add menu= in menu and mode name below
def createMenu(type=None, add=None, name=None):
    if name == None: name = ADDONTITLE
    menu_items=[]
    #name2 = urllib.quote_plus(name)
    # Global
    menu_items.append((THEME2 % 'Settings  %s' % ADDONTITLE,                    'RunPlugin(plugin://%s/?mode=settings)' % ADDON_ID))
    
    # default if type none
    if  type == 'default':
        menu_items.append((THEME3 % 'View Log',                                     'RunPlugin(plugin://%s/?mode=viewlog)' % ADDON_ID))
        menu_items.append((THEME3 % 'Update Addons and Repos',                      'RunPlugin(plugin://%s/?mode=refreshaddon)' % ADDON_ID))
        #menu_items.append((THEME3 % 'Update Addons and Repos',                     'RunPlugin(plugin://%s/?mode=forceupdate)' % ADDON_ID))
        menu_items.append((THEME3 % 'Toggle Debug',                             'RunPlugin(plugin://%s/?mode=debug)' % ADDON_ID))
        menu_items.append((THEME3 % 'Toggle Developer Menus',                   'RunPlugin(plugin://%s/?mode=developer)' % ADDON_ID))
        menu_items.append((THEME3 % 'Refresh Wizard',                           'RunPlugin(plugin://%s/?mode=refresh)' % ADDON_ID))
        menu_items.append((THEME3 % 'View Wizard Log',                          'RunPlugin(plugin://%s/?mode=viewwizlog)' % ADDON_ID))
        menu_items.append((THEME3 % 'Fresh Start',                              'RunPlugin(plugin://%s/?mode=freshstart)' % ADDON_ID))
        menu_items.append((THEME3 % 'Force Close',                              'RunPlugin(plugin://%s/?mode=forceclose)' % ADDON_ID))
    
    # trakt and debrid details
    elif type == 'savedebridtraktdetails':
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEME2 % name.title(), ' '))
        menu_items.append((THEME3 % 'Save %s Data' % add3,                      'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Restore %s Data' % add3,                   'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Clear %s Data' % add3,                     'RunPlugin(plugin://%s/?mode=clear%s&name=%s)' %   (ADDON_ID, add2, name2)))

    # trakt and debrid 
    elif type == 'savedebridtrakt':
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEME2 % name.title(), ' '))
        menu_items.append((THEME3 % 'Register %s' % add3,                       'RunPlugin(plugin://%s/?mode=auth%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Save %s Data' % add3,                      'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Restore %s Data' % add3,                   'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Import %s Data' % add3,                    'RunPlugin(plugin://%s/?mode=import%s&name=%s)' %  (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Clear Addon %s Data' % add3,               'RunPlugin(plugin://%s/?mode=addon%s&name=%s)' %   (ADDON_ID, add2, name2)))

    # builds
    elif  type == 'install':
        name2 = urllib.quote_plus(name)
        menu_items.append((THEME2 % name,                                       'RunAddon(%s, ?mode=viewbuild&name=%s)'  % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Fresh Install',                            'RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'  % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Normal Install',                           'RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)' % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Apply guiFix',                             'RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'    % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Build Information',                        'RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'  % (ADDON_ID, name2)))

    # autoclean
    elif   type == 'autoclean':
        menu_items.append((THEME2 % 'Auto Clean Now',                           'RunPlugin(plugin://%s/?mode=fullclean)'  % ADDON_ID))

    ####menuedittxt', 'addontxt
    # edit txt strings in settings
    elif   type == 'menuedittxt':
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        #add3  = add.replace('Debrid', 'Real Debrid')
        #name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        #name = name.replace('url', 'URL Resolver')
        if add == 'addontxt':
            menu_items.append((THEME2 % 'Edit Entry1',                          'RunPlugin(plugin://%s/?mode=fullclean)'  % ADDON_ID))
            menu_items.append((THEME3 % 'test %s %s %s' % (type,add2,name),    'RunPlugin(plugin://%s/?mode=edittxt%s&name=%s&url=%s)' % (ADDON_ID, add2, name, type)))
            
            #def editaddontxt(name, url):
            #prefix = name
            #number = url
            
        elif add == 'addont':
            menu_items.append((THEME2 % 'Edit Entry2',                           'RunPlugin(plugin://%s/?mode=fullclean)'  % ADDON_ID))

        elif add == 'addonx':
            menu_items.append((THEME2 % 'Edit Entry3',                           'RunPlugin(plugin://%s/?mode=fullclean)'  % ADDON_ID))
        
        
        
        
    return menu_items

def addDir(display,  mode=None, name=None, url=None, menu=None, description=ADDONTITLE+ ' Addon Installer and Maintenence', overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url  == None: u += "&url="+urllib.quote_plus(url)
    if menu     == None: menu = createMenu('default', '', '')
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": descriptioninfo+description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
    
def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE+ ' Addon Installer and Maintenence', overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url  == None: u += "&url="+urllib.quote_plus(url)
    if menu     == None: menu = createMenu('default', '', '')
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

    
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
        return param
#if not len(sys.argv) > 1: notify.vodguixml('vod.xml') ############# Run Vod if no params
params=get_params()
url=None
name=None
mode=None
#stopPlayback=None
#kiosk=None
#userAgent=None
try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass
#try:     stopPlayback=urllib.unquote_plus(params["stopPlayback"])
#except:  pass
#try:     kiosk=urllib.unquote_plus(params["kiosk"])
#except:  pass
#try:     userAgent=urllib.unquote_plus(params["userAgent"])
#except:  pass
wiz.log(ADDON_ID+'  **[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]' % (VERSION, mode if not mode == '' else None, name, url))

#def setView(content, viewType):
    #if content:  xbmcplugin.setContent(int(sys.argv[1]), content)
    #if wiz.getS('auto-view')=='true':
        #xbmc.executebuiltin("Container.SetViewMode(%s)" % wiz.getS(viewType) )
        #views = wiz.getS(viewType)
        #wiz.ebi("Container.SetViewMode(%s)" %  views)
        
def setView(content, viewType):
    if wiz.getS('auto-view')=='true':
        views = wiz.getS(viewType)
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
        wiz.ebi("Container.SetViewMode(%s)" %  views)
        
        '''
        # skin estuary
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
        '''
        '''
        # skin confluence
        if views == '55' and KODIV >= 17 and SKIN == 'skin.confluence': views = '50'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.confluence': views = '50'
        # skin mods
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary.16': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary.17': views = '55'
        if views == '50' and KODIV == 18 and SKIN == 'skin.estuary.18': views = '55'
        #estuary autoviews
        #<views>50,51,52,53,54,55,500,501,502</views>
        <include>View_50_List</include>
        <include>View_51_Poster</include>
        <include>View_52_IconWall</include>
        <include>View_53_Shift</include>
        <include>View_54_InfoWall</include>
        <include>View_55_WideList</include>
        <include>View_500_Wall</include>
        <include>View_501_Banner</include>
        <include>View_502_FanArt</include>
        '''
        
if   mode==None: index()
########################
# Main Builds
elif mode=='wizardupdate'   : wiz.wizardUpdate()
# 1 read buildmenu txt online or offline
elif mode=='builds'         : index_builds()
# 2 view the build and choose fresh or standard install or builtin
elif mode=='viewbuild'      : viewBuild(name)
elif mode=='buildinfo'      : buildInfo(name)
elif mode=='buildpreview'   : buildVideo(name)
# 3 install the build
elif mode=='viewthirdparty' : viewThirdList(name, url)
elif mode=='editthird'      : editThirdParty(name, url); wiz.refresh()
elif mode=='installthird'   : thirdPartyInstall(name, url)
elif mode=='install'        : buildWizard(name, url)
elif mode=='theme'          : buildWizard(name, mode, url)
elif mode=='installofflineFULL' : installoffline(name, url, 'install', full=True)
elif mode=='installoffline'     : installoffline(name, url, 'install', full=False)
elif mode=='installofflinetheme': installofflineTheme(name, url)
######################
elif mode=='addontxt'        : addontxt(name, url)
elif mode=='addonfromurl'    : install_from_url()
#elif mode=='addontxt': addontxt(name, url)
#elif mode=='addonMenutoggle' : addonMenutoggle(name)
elif mode=='addoninstall'    : addonInstaller(name, url)
elif mode=='checkdeps'       : checkdeps()
elif mode=='rompacks'        : index_rompacks()
elif mode=='runaddon'        : wiz.ebi('RunAddon(%s)' % name)

elif mode=='editaddontxt'    : editaddontxt(name, url); wiz.refresh()

# Addon Installer BuiltIn
elif mode=='addonmenudirect' : addonMenudirect()
######################
elif mode=='apkmaintmenu'   : apkindex_maint(name)
elif mode=='apk'            : index_apk(name)
elif mode=='apkscrape'      : apkScraper(name)
#elif mode=='apkMenuonline'  : apkMenuonline(name, url)
#elif mode=='apkMenuoffline' : apkMenuoffline(name, url)
elif mode=='apktxt'          : apktxt(name, url)
elif mode=='apkinstall'     : apkInstaller(name, url)
elif mode=='apkbuiltinMenu' : apkbuiltinMenu(url)
elif mode=='apkbuiltinInstall': apkbuiltinInstall(url)
######################
elif mode=='advancedsetting': advancedWindow(name)
elif mode=='autoadvanced'   : showAutoAdvanced(); wiz.refresh()
elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()
######################
elif mode=='backupbuild'    : wiz.backUpOptions('build')
elif mode=='backupgui'      : wiz.backUpOptions('guifix')
elif mode=='backuptheme'    : wiz.backUpOptions('theme')
elif mode=='backupaddon'    : wiz.backUpOptions('addondata')
######################
elif mode=='maint'          : index_maint(name)
elif mode=='kodi17fix'      : wiz.kodi17Fix()
elif mode=='oldThumbs'      : wiz.oldThumbs()
elif mode=='clearbackup'    : wiz.cleanupBackup()
elif mode=='convertpath'    : wiz.convertSpecial(HOME)
elif mode=='currentsettings': viewAdvanced()
elif mode=='fullclean'      : totalClean(); wiz.refresh()
elif mode=='clearcache'     : clearCache(); wiz.refresh()
elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
elif mode=='checksources'   : wiz.checkSources(); wiz.refresh()
elif mode=='checkrepos'     : wiz.checkRepos(); wiz.refresh()
elif mode=='freshstart'     : freshStart()
elif mode=='forceupdate'    : wiz.forceUpdate()
elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
elif mode=='forceclose'     : wiz.killxbmc()
elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
elif mode=='hidepassword'   : wiz.hidePassword()
elif mode=='unhidepassword' : wiz.unhidePassword()
elif mode=='enableaddons'   : enableAddons()
elif mode=='toggleaddon'    : wiz.toggleAddon(name, url); wiz.refresh()
elif mode=='togglecache'    : toggleCache(name); wiz.refresh()
elif mode=='toggleadult'    : wiz.toggleAdult(); wiz.refresh()
elif mode=='changefeq'      : changeFeq(); wiz.refresh()
elif mode=='uploadlog'      : uploadLog.Main()
elif mode=='viewlog'        : LogViewer()
elif mode=='viewwizlog'     : LogViewer(WIZLOG)
elif mode=='viewerrorlog'   : errorChecking(all=True)
elif mode=='clearwizlog'    : f = open(WIZLOG, 'w'); f.close(); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Wizard Log Cleared![/COLOR]" % COLOR2)
elif mode=='refresh'        : wiz.refresh()
elif mode=='refreshaddon'   : wiz.forceUpdate()
elif mode=='purgedb'        : purgeDb()
elif mode=='asciicheck'     : wiz.asciiCheck()
elif mode=='fixaddonupdate' : fixUpdate()
elif mode=='removeaddons'   : removeAddonMenu()
elif mode=='removeaddon'    : removeAddon(name)
elif mode=='removeaddondata': removeAddonDataMenu()
elif mode=='removedata'     : removeAddonData(name)
elif mode=='resetaddon'     : total = wiz.cleanHouse(ADDONDATA, ignore=True); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Addon_Data reset[/COLOR]" % COLOR2)
elif mode=='systeminfo'     : systemInfo()
elif mode=='restorezip'     : restoreit('build')
elif mode=='restoregui'     : restoreit('gui')
elif mode=='restoreaddon'   : restoreit('addondata')
elif mode=='restoreextzip'  : restoreextit('build')
elif mode=='restoreextgui'  : restoreextit('gui')
elif mode=='restoreextaddon': restoreextit('addondata')
elif mode=='writeadvanced'  : writeAdvanced(name, url)
######################
elif mode=='savedata'       : saveMenu()
elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()
elif mode=='managedata'     : manageSaveData(name)
elif mode=='whitelist'      : wiz.whiteList(name)
######################
elif mode=='trakt'          : traktMenu()
elif mode=='savetrakt'      : traktit.traktIt('update',      name)
elif mode=='restoretrakt'   : traktit.traktIt('restore',     name)
elif mode=='addontrakt'     : traktit.traktIt('clearaddon',  name)
elif mode=='cleartrakt'     : traktit.clearSaved(name)
elif mode=='authtrakt'      : traktit.activateTrakt(name); wiz.refresh()
elif mode=='updatetrakt'    : traktit.autoUpdate('all')
elif mode=='importtrakt'    : traktit.importlist(name); wiz.refresh()
elif mode=='realdebrid'     : realMenu()
elif mode=='savedebrid'     : debridit.debridIt('update',      name)
elif mode=='restoredebrid'  : debridit.debridIt('restore',     name)
elif mode=='addondebrid'    : debridit.debridIt('clearaddon',  name)
elif mode=='cleardebrid'    : debridit.clearSaved(name)
elif mode=='authdebrid'     : debridit.activateDebrid(name); wiz.refresh()
elif mode=='updatedebrid'   : debridit.autoUpdate('all')
elif mode=='importdebrid'   : debridit.importlist(name); wiz.refresh()
elif mode=='login'          : loginMenu()
elif mode=='savelogin'      : loginit.loginIt('update',      name)
elif mode=='restorelogin'   : loginit.loginIt('restore',     name)
elif mode=='addonlogin'     : loginit.loginIt('clearaddon',  name)
elif mode=='clearlogin'     : loginit.clearSaved(name)
elif mode=='authlogin'      : loginit.activateLogin(name); wiz.refresh()
elif mode=='updatelogin'    : loginit.autoUpdate('all')
elif mode=='importlogin'    : loginit.importlist(name); wiz.refresh()
######################
elif mode=='contact'        : notify.contact(CONTACT)
elif mode=='settings'       : wiz.openS(name); wiz.refresh()
#elif mode=='settings12'     : wiz.openS('showmaint'); wiz.refresh()
#elif mode=='settingscat'   : wiz.openS('30000'); wiz.refresh()
#elif mode=='settingscat'   : settingscategory(name)
elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()
elif mode=='developer'      : developer()
elif mode=='debug'          : EnableDebug()
elif mode=='converttext'    : wiz.convertText()
elif mode=='testnotify'     : testnotify()
elif mode=='testupdate'     : testupdate()
elif mode=='testfirst'      : testfirst()
elif mode=='testfirstrun'   : testfirstRun()
elif mode=='testapk'        : notify.apkInstaller('SPMC')
######################
# menus
elif mode=='addonsmenu'            : index_addons()
elif mode=='indexzipinstaller'     : index_zipinstaller()
elif mode=='indexcleaning'         : index_cleaning()
elif mode=='indexbackup'           : index_backup()
elif mode=='indexlog'              : index_log()
elif mode=='indexinstallxml'       : index_installxml()
#elif mode=='indexaddonfixes'      : index_addonfixes()
elif mode=='indexbackuponly'       : index_backup_only()
elif mode=='indexrestore'          : index_restore()
elif mode=='firstrunsettingsgui'   : notify.firstRunSettings(); wiz.refresh()
elif mode=='indexhelp'             : index_help()
######################
# extras
elif mode=='EnableRTMP'            : EnableRTMP()
elif mode=='emaillog'              : email_log()
elif mode=='Repolink'              : Repolink(REPOID);sys.exit(0)
elif mode=='doWriterss'            : doWriterss(); wiz.refresh(); _notify('Done','Done Writing RSS.xml',ICON)
elif mode=='doWritesources'        : doWritesources(); wiz.refresh(); _notify('Done','Done Writing sources.xml',ICON)
elif mode=='doWriteplayerfactorycore': doWriteplayerfactorycore(); wiz.refresh(); _notify('Done','Done Writing playerfactorycore.xml',ICON)
elif mode=='freshstartsettingstoo' : notify.firstRunSettings(); wiz.refresh();freshStart()
elif mode=='cloneaddon'            : clone_addon()
elif mode=='runexe'                : run_exe(name, url)
######################
elif mode=='keymaps'               : keymaps(url)
elif mode=='install_keymap'        : install_keymap(name, url)
elif mode=='uninstall_keymap'      : uninstall_keymap()
######################
# del xml
elif mode=='delautoadvanced'       : delete_file_prompt(ADVANCED); wiz.refresh()
elif mode=='delplayercorefactory'  : delete_file_prompt(PLAYERCORE); wiz.refresh()
elif mode=='delsources'            : delete_file_prompt(SOURCES); wiz.refresh()
elif mode=='delRssFeeds'           : delete_file_prompt(RSSFILE); wiz.refresh()
######################
# Github Browser
elif mode=='githubmain'            : github_main()
elif mode=='github_update'         : github_update()
elif mode=='github_instructions'   : github_instructions()
elif mode=='github_install'        : github_install(url)
elif mode=='github_search_username': github_search('username')
elif mode=='github_search_repo'    : github_search('repo')
elif mode=='github_search_addon_id': github_search('addon_id')
######################
# apk Menu
elif mode=='androidappmanager'     : xbmc.executebuiltin('StartAndroidActivity(,android.settings.APPLICATION_SETTINGS)')
elif mode=='androidkodisettings'   : xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS","","package:org.xbmc.kodi")')
elif mode=='androidapps'           : xbmc.executebuiltin('ActivateWindow(10001,androidapp://sources/apps/, return)')#Android Apps
#elif mode=='androidprograms'      : xbmc.executebuiltin('ActivateWindow(Programs)')
#elif mode=='androidsettings'      : xbmc.executebuiltin('ActivateWindow(10001,androidsetting://sources/settings/, return)')#Android Settings
#elif mode=='androidprogramaddons' : xbmc.executebuiltin('ActivateWindow(10001,addons://sources/executable/, return)')#Program Addons

######################
# media
elif mode=='indexmedia'            : index_media()
elif mode=='indexm3u'              : index_m3u()
elif mode=='playm3u'               : playm3u(url)
elif mode=='windows'               : index_windows()
elif mode=='vodguixml'             : notify.vodguixml('vod.xml')
######################
# youtube
elif mode=='youtube'               : index_youtube(name)
elif mode=='viewVideo'             : playVideo(url)
######################
# chrome
#elif mode=='chrome'               : from resources.lib import chrome;chrome.index()
elif mode=='chrome'                : index_chrome()
elif mode=='addSite'               : addSite()
elif mode=='showSite'              : showSite(url, stopPlayback, kiosk, userAgent)
elif mode=='removeSite'            : removeSite(url)
elif mode=='editSite'              : editSite(url)

elif mode=='fallbackfiles'         : fallback_files()
#elif mode=='fallbackfiles'        : fallback_files(src, dest)

if len(sys.argv) > 1: xbmcplugin.endOfDirectory(int(sys.argv[1]))
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#      ^\_(-_-)_/^,Andy                                                        #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version. Just don't be an asshole about it.  I also reserve       #
#  the right to use your DNA and persons in such experiments as and not        #
#  limited to :  Human Centipede, beer runs and and MK Ultra.                  #
#  Failure to abide is lame but punk as fuck.                                  #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################
	