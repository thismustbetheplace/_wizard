# -*- coding: utf-8 -*-
# http://aftermathwizard.net/GettingStarted/
# http://aftermathwizard.net/FAQS/
import os, xbmc, xbmcaddon, xbmcvfs
#xbmc.log(msg='|  \/  | / \  |_ _|| \| ||_   _| __| \| | / \  | \| | / __| __|', level=xbmc.LOGNOTICE)
#xbmc.log(msg='| |\/| |/ _ \  | | | .` |  | | | _|| .` |/ _ \ | .` || (__| _| ', level=xbmc.LOGNOTICE)
#xbmc.log(msg='|_|  |_/_/ \_\|___||_|\_|  |_| |___|_|\_/_/ \_\|_|\_| \___|___|', level=xbmc.LOGNOTICE)
xbmc.log(msg='Run uservar.py', level=xbmc.LOGNOTICE)

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDON          = xbmcaddon.Addon(ADDON_ID)
ADDON_DATA     = xbmc.translatePath(os.path.join('special://profile', 'addon_data'))
ADDONPATH      = xbmc.translatePath(os.path.join('special://home/addons', ADDON_ID))
BASEPATH       = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
EXTRAPATH      = xbmc.translatePath(os.path.join(ADDONPATH, 'resources', 'data'))
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds')
#BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/My_Builds/'
#MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds')
REPOID         = ADDON.getSetting('REPOID')
ADDONTITLE     = ADDON.getSetting('ADDONTITLE')
MODURL         = 'http://mirrors.kodi.tv/addons/krypton/'
MODURL2        = 'http://mirrors.kodi.tv/addons/jarvis/'
FONTBIG        = 'Font14'
FONT           = 'Font13'
FONTSMALL      = 'Font10'
# repo url
repo_url       = ADDON.getSetting('repo.url')
# spmc releases
spmcurl1       = 'https://github.com/koying/SPMC/releases/'

##### Sys info tags
# find kodi ver
xbmc_version=xbmc.getInfoLabel('System.BuildVersion')
version=float(xbmc_version[:4])
if version >= 18.0 and version <= 18.9: kodi_version = '18'
if version >= 17.0 and version <= 17.9: kodi_version = '17'
if version >= 16.0 and version <= 16.9: kodi_version = '16'
if version >= 15.0 and version <= 15.9: kodi_version = '15'
if version >= 14.0 and version <= 14.9: kodi_version = '14'
# python version
import platform
pythonver = platform.python_version()
# platform version ie windows or android
osinfo = platform.system()+' '+platform.release()

# Text File with build info in it.
BUILDFILE      = ADDON.getSetting('BUILDFILE')

# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = ADDON.getSetting('ADVANCEDFILE')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'media')
# If you want to use locally stored icons the place them in the Resources/media/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://place.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'maintenance.png')
ICONAPK        = os.path.join(ART, 'android.png')
ICONADDONS     = os.path.join(ART, 'addons.png')
ICONYOUTUBE    = os.path.join(ART, 'youtube.png')
ICONSAVE       = os.path.join(ART, 'download.png')
ICONTRAKT      = os.path.join(ART, 'trakt.png')
ICONREAL       = os.path.join(ART, 'dabrid.png')
ICONLOGIN      = os.path.join(ART, 'contact.png')
ICONCONTACT    = os.path.join(ART, 'contact.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
ICONRESTORE    = os.path.join(ART, 'restore.png')
ICONRESTOREALL = os.path.join(ART, 'restore_all.png')
ICONBACKUP     = os.path.join(ART, 'backup.png')
ICONDELETE     = os.path.join(ART, 'delete.png')
ICONEMAIL      = os.path.join(ART, 'email.png')
ICONFORCECLOSE = os.path.join(ART, 'forceclose.png')
ICONFRESHSTART = os.path.join(ART, 'freshstart.png')
ICONLOG        = os.path.join(ART, 'log.png')
ICONSEARCH     = os.path.join(ART, 'search.png')
ICONXML        = os.path.join(ART, 'xml.png')
ICONFTMC       = os.path.join(ART, 'ftmc.png')
ICONSPMC       = os.path.join(ART, 'spmc.png')
ICONCLEAN      = os.path.join(ART, 'clean.png')
ICONCLEANALL   = os.path.join(ART, 'cleanall.png')
ICONFILE       = os.path.join(ART, 'file.png')
ICONFIX        = os.path.join(ART, 'paramedic.png')
ICONSKIN       = os.path.join(ART, 'skin.png')
ICONTWEAKS     = os.path.join(ART, 'tweaks.png')
ICONZIP        = os.path.join(ART, 'zip.png')
ICONSPACER     = os.path.join(ART, 'spacer.png')
ICONINFO       = os.path.join(ART, 'info.png')
ICONTVGFS      = os.path.join(ART, 'tvgfs.png')
ICONINI        = os.path.join(ART, 'ini.png')
ICONGITHUB     = os.path.join(ART, 'github.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '*'
# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'green'
COLOR4         = 'red'
COLOR5         = 'orange'
COLOR6         = 'dodgerblue'
COLOR7         = 'steelblue'
COLOR8         = 'grey'
# menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'
#THEME1        = '[COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR7+']%s[/COLOR]'
# white items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'
# Menu Spacer / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR6+']%s[/COLOR]'
# Warning Flag / %s is the menu item and is required
THEME7        = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR4+']WARNING[/COLOR])[/B][/COLOR]  [COLOR '+COLOR8+']%s[/COLOR][/I]'
# zips / %s is the menu item and is required
THEME8         = '[COLOR '+COLOR1+'][B]([COLOR '+COLOR7+']Install Zip[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'
# Toggle menu items   / %s is the menu item and is required
THEME9         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR8+']Toggle[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'
# install prorams and build / %s is the menu item and is required
THEME10        = '[COLOR '+COLOR8+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/I][/COLOR]  Install Programs   [COLOR '+COLOR8+'](Current Build:[/COLOR] [COLOR '+COLOR5+']%s[/COLOR][COLOR '+COLOR8+'] )[/COLOR]'
#########################################################
### Message for Contact Page ############################
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
#HIDECONTACT    = 'Yes'
HIDECONTACT     = ADDON.getSetting('HIDECONTACT')
CONTACT         = ADDON.getSetting('CONTACT')
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON     = ICONCONTACT
#CONTACTFANART  = 'http://'
CONTACTFANART   = 'http://'
#########################################################
# How often you would like it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
#UPDATECHECK   = ADDON.getSetting('UPDATECHECK')
#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
#AUTOUPDATE     = 'Yes'
AUTOUPDATE      = ADDON.getSetting('AUTOUPDATE')
# Url to wizard version
#WIZARDFILE     = ''
#WIZARDFILE      = ADDON.getSetting('WIZARDFILE')
WIZARDFILE      = ADDON.getSetting('BUILDFILE')
#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
#AUTOINSTALL    = 'Yes'
AUTOINSTALL     = ADDON.getSetting('AUTOINSTALL')
# Addon ID for the repository
ICONREPO        = xbmc.translatePath(os.path.join('special://home/addons', REPOID, 'icon.png'))
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML    = repo_url+REPOID+'/addon.xml'
# Url to folder zip is located in
#REPOZIPURL     = 'https://raw.githubusercontent.com/username/_repo/master/_zips/plugin.program.addonname/'
REPOZIPURL      = repo_url+REPOID+'/'
#########################################################
### NOTIFICATION and BLACKLIST WINDOW###################
#   First Run Window and Blacklist
#########################################################
# Enable Notification screen Yes or No
#ENABLE         = 'No'
ENABLE          = ADDON.getSetting('ENABLE')
# Url to notification file
NOTIFICATION    = ADDON.getSetting('NOTIFICATION')
NOTIFYOFFLINE   = xbmc.translatePath(os.path.join(EXTRAPATH, '_notify.txt'))
BLACKLISTOFFLINE= xbmc.translatePath(os.path.join(EXTRAPATH, '_blacklist.txt'))
# Use either 'Text' or 'Image'
#HEADERTYPE     = 'Text'
HEADERTYPE      = ADDON.getSetting('HEADERTYPE')
HEADERMESSAGE   = 'Firstrun Wizard Message'
# url to image if using Image 424x180
HEADERIMAGE     = 'http://'
# Background for Notification Window
BACKGROUND     = 'http://'
#########################################################
# ie: zips_url + url_addons_repo
zips_url                 = ADDON.getSetting('zips.url')
url_addons_repo          = ADDON.getSetting('url_addons_repo')
url_addons_audio         = ADDON.getSetting('url_addons_audio')
url_addons_program       = ADDON.getSetting('url_addons_program')
url_addons_video         = ADDON.getSetting('url_addons_video')
url_addons_iptv          = ADDON.getSetting('url_addons_iptv')
url_addons_sub           = ADDON.getSetting('url_addons_sub')
url_guisettings_18       = ADDON.getSetting('url_guisettings_18')
url_theme_18             = ADDON.getSetting('url_theme_18')
url_guisettings_17       = ADDON.getSetting('url_guisettings_17')
url_theme_17             = ADDON.getSetting('url_theme_17')
url_guisettings_16       = ADDON.getSetting('url_guisettings_16')
url_theme_16             = ADDON.getSetting('url_theme_16')
url_guisettings_15       = ADDON.getSetting('url_guisettings_15')
url_theme_15             = ADDON.getSetting('url_theme_15')
url_guisettings_14       = ADDON.getSetting('url_guisettings_14')
url_theme_14             = ADDON.getSetting('url_theme_14')
# your OS defaults
if kodi_version == '18': url_guisettings  = url_guisettings_18
if kodi_version == '18': url_theme        = url_theme_18
if kodi_version == '17': url_guisettings  = url_guisettings_17
if kodi_version == '17': url_theme        = url_theme_17
if kodi_version == '16': url_guisettings  = url_guisettings_16
if kodi_version == '16': url_theme        = url_theme_16
if kodi_version == '15': url_guisettings  = url_guisettings_15
if kodi_version == '15': url_theme        = url_theme_15
if kodi_version == '14': url_guisettings  = url_guisettings_14
if kodi_version == '14': url_theme        = url_theme_14
#########################################################
# Built In Builds using zips_url Defaults
versionbuiltin         = '0.0.0'
kodibuiltin            = '0.0'
adultbuiltin           ='No'
namebuiltin            = ADDONTITLE+' Default '
#########################################################
# RssFeeds.xml urls
rss1 = ADDON.getSetting('rss1')
rss2 = ADDON.getSetting('rss2')
rss3 = ADDON.getSetting('rss3')
rss4 = ADDON.getSetting('rss4')
rss5 = ADDON.getSetting('rss5')
rss6 = ADDON.getSetting('rss6')
rss7 = ADDON.getSetting('rss7')
rss8 = ADDON.getSetting('rss8')
#########################################################
# autounattend sql credentials
sql_host = ADDON.getSetting('sql.host')
sql_user = ADDON.getSetting('sql.user')
sql_pass = ADDON.getSetting('sql.pass')
#########################################################
# Default addons 
DEFAULTPLUGINS = ['metadata.album.universal',
                  'metadata.artists.universal',
                  'metadata.common.fanart.tv',
                  'metadata.common.imdb.com',
                  'metadata.common.musicbrainz.org',
                  'metadata.themoviedb.org',
                  'metadata.tvdb.com',
                  'service.xbmc.versioncheck']
#########################################################
# Whitelist addons to save when wiping 
EXCLUDES1 = ADDON.getSetting('EXCLUDES1')
EXCLUDES2 = ADDON.getSetting('EXCLUDES2')
EXCLUDES3 = ADDON.getSetting('EXCLUDES3')
EXCLUDES4 = ADDON.getSetting('EXCLUDES4')
EXCLUDES5 = ADDON.getSetting('EXCLUDES5')
EXCLUDES6 = ADDON.getSetting('EXCLUDES6')
EXCLUDES7 = ADDON.getSetting('EXCLUDES7')
EXCLUDES8 = ADDON.getSetting('EXCLUDES8')
EXCLUDES  = [ADDON_ID,
             REPOID,
             EXCLUDES1,
             EXCLUDES2,
             EXCLUDES3,
             EXCLUDES4,
             EXCLUDES5,
             EXCLUDES6,
             EXCLUDES7,
             EXCLUDES8]
#########################################################
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = '[COLOR red]YOU[/COLOR][COLOR white]TUBE[/COLOR] Videos'
YOUTUBEFILE    = ADDON.getSetting('YOUTUBEFILE')
YOUTUBENAME1   = ADDON.getSetting('YOUTUBENAME1')
YOUTUBEURL1    = ADDON.getSetting('YOUTUBEURL1')
YOUTUBENAME2   = ADDON.getSetting('YOUTUBENAME2')
YOUTUBEURL2    = ADDON.getSetting('YOUTUBEURL2')
YOUTUBENAME3   = ADDON.getSetting('YOUTUBENAME3')
YOUTUBEURL3    = ADDON.getSetting('YOUTUBEURL3')
YOUTUBENAME4   = ADDON.getSetting('YOUTUBENAME4')
YOUTUBEURL4    = ADDON.getSetting('YOUTUBEURL4')
YOUTUBENAME5   = ADDON.getSetting('YOUTUBENAME5')
YOUTUBEURL5    = ADDON.getSetting('YOUTUBEURL5')
YOUTUBENAME6   = ADDON.getSetting('YOUTUBENAME6')
YOUTUBEURL6    = ADDON.getSetting('YOUTUBEURL6')
YOUTUBENAME7   = ADDON.getSetting('YOUTUBENAME7')
YOUTUBEURL7    = ADDON.getSetting('YOUTUBEURL7')
YOUTUBENAME8   = ADDON.getSetting('YOUTUBENAME8')
YOUTUBEURL8    = ADDON.getSetting('YOUTUBEURL8')
YOUTUBENAME9   = ADDON.getSetting('YOUTUBENAME9')
YOUTUBEURL9    = ADDON.getSetting('YOUTUBEURL9')
#########################################################
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = ADDON.getSetting('ADDONFILE')
ADDONFNAME1    = ADDON.getSetting('ADDONFNAME1')
ADDONFILE1     = ADDON.getSetting('ADDONFILE1')
ADDONFNAME2    = ADDON.getSetting('ADDONFNAME2')
ADDONFILE2     = ADDON.getSetting('ADDONFILE2')
ADDONFNAME3    = ADDON.getSetting('ADDONFNAME3')
ADDONFILE3     = ADDON.getSetting('ADDONFILE3')
ADDONFNAME4    = ADDON.getSetting('ADDONFNAME4')
ADDONFILE4     = ADDON.getSetting('ADDONFILE4')
ADDONFNAME5    = ADDON.getSetting('ADDONFNAME5')
ADDONFILE5     = ADDON.getSetting('ADDONFILE5')
ADDONFNAME6    = ADDON.getSetting('ADDONFNAME6')
ADDONFILE6     = ADDON.getSetting('ADDONFILE6')
ADDONFNAME7    = ADDON.getSetting('ADDONFNAME7')
ADDONFILE7     = ADDON.getSetting('ADDONFILE7')
ADDONFNAME8    = ADDON.getSetting('ADDONFNAME8')
ADDONFILE8     = ADDON.getSetting('ADDONFILE8')
ADDONFNAME9    = ADDON.getSetting('ADDONFNAME9')
ADDONFILE9     = ADDON.getSetting('ADDONFILE9')
#########################################################
# direct addon
ADDONDIRECTFNAME1      = ADDON.getSetting('ADDONDIRECTFNAME1')
ADDONDIRECTFILE1       = ADDON.getSetting('ADDONDIRECTFILE1')
ADDONDIRECTPLUGIN1     = ADDON.getSetting('ADDONDIRECTPLUGIN1')
ADDONDIRECTREPO1       = ADDON.getSetting('ADDONDIRECTREPO1')
ADDONDIRECTREPOXML1    = ADDON.getSetting('ADDONDIRECTREPOXML1')
ADDONDIRECTREPOURL1    = ADDON.getSetting('ADDONDIRECTREPOURL1')
ADDONDIRECTFNAME2      = ADDON.getSetting('ADDONDIRECTFNAME2')
ADDONDIRECTFILE2       = ADDON.getSetting('ADDONDIRECTFILE2')
ADDONDIRECTPLUGIN2     = ADDON.getSetting('ADDONDIRECTPLUGIN2')
ADDONDIRECTREPO2       = ADDON.getSetting('ADDONDIRECTREPO2')
ADDONDIRECTREPOXML2    = ADDON.getSetting('ADDONDIRECTREPOXML2')
ADDONDIRECTREPOURL2    = ADDON.getSetting('ADDONDIRECTREPOURL2')
ADDONDIRECTFNAME3      = ADDON.getSetting('ADDONDIRECTFNAME3')
ADDONDIRECTFILE3       = ADDON.getSetting('ADDONDIRECTFILE3')
ADDONDIRECTPLUGIN3     = ADDON.getSetting('ADDONDIRECTPLUGIN3')
ADDONDIRECTREPO3       = ADDON.getSetting('ADDONDIRECTREPO3')
ADDONDIRECTREPOXML3    = ADDON.getSetting('ADDONDIRECTREPOXML3')
ADDONDIRECTREPOURL3    = ADDON.getSetting('ADDONDIRECTREPOURL3')
ADDONDIRECTFNAME4      = ADDON.getSetting('ADDONDIRECTFNAME4')
ADDONDIRECTFILE4       = ADDON.getSetting('ADDONDIRECTFILE4')
ADDONDIRECTPLUGIN4     = ADDON.getSetting('ADDONDIRECTPLUGIN4')
ADDONDIRECTREPO4       = ADDON.getSetting('ADDONDIRECTREPO4')
ADDONDIRECTREPOXML4    = ADDON.getSetting('ADDONDIRECTREPOXML4')
ADDONDIRECTREPOURL4    = ADDON.getSetting('ADDONDIRECTREPOURL4')
ADDONDIRECTFNAME5      = ADDON.getSetting('ADDONDIRECTFNAME5')
ADDONDIRECTFILE5       = ADDON.getSetting('ADDONDIRECTFILE5')
ADDONDIRECTPLUGIN5     = ADDON.getSetting('ADDONDIRECTPLUGIN5')
ADDONDIRECTREPO5       = ADDON.getSetting('ADDONDIRECTREPO5')
ADDONDIRECTREPOXML5    = ADDON.getSetting('ADDONDIRECTREPOXML5')
ADDONDIRECTREPOURL5    = ADDON.getSetting('ADDONDIRECTREPOURL5')
ADDONDIRECTFNAME6      = ADDON.getSetting('ADDONDIRECTFNAME6')
ADDONDIRECTFILE6       = ADDON.getSetting('ADDONDIRECTFILE6')
ADDONDIRECTPLUGIN6     = ADDON.getSetting('ADDONDIRECTPLUGIN6')
ADDONDIRECTREPO6       = ADDON.getSetting('ADDONDIRECTREPO6')
ADDONDIRECTREPOXML6    = ADDON.getSetting('ADDONDIRECTREPOXML6')
ADDONDIRECTREPOURL6    = ADDON.getSetting('ADDONDIRECTREPOURL6')
ADDONDIRECTFNAME7      = ADDON.getSetting('ADDONDIRECTFNAME7')
ADDONDIRECTFILE7       = ADDON.getSetting('ADDONDIRECTFILE7')
ADDONDIRECTPLUGIN7     = ADDON.getSetting('ADDONDIRECTPLUGIN7')
ADDONDIRECTREPO7       = ADDON.getSetting('ADDONDIRECTREPO7')
ADDONDIRECTREPOXML7    = ADDON.getSetting('ADDONDIRECTREPOXML7')
ADDONDIRECTREPOURL7    = ADDON.getSetting('ADDONDIRECTREPOURL7')
ADDONDIRECTFNAME8      = ADDON.getSetting('ADDONDIRECTFNAME8')
ADDONDIRECTFILE8       = ADDON.getSetting('ADDONDIRECTFILE8')
ADDONDIRECTPLUGIN8     = ADDON.getSetting('ADDONDIRECTPLUGIN8')
ADDONDIRECTREPO8       = ADDON.getSetting('ADDONDIRECTREPO8')
ADDONDIRECTREPOXML8    = ADDON.getSetting('ADDONDIRECTREPOXML8')
ADDONDIRECTREPOURL8    = ADDON.getSetting('ADDONDIRECTREPOURL8')
ADDONDIRECTFNAME9      = ADDON.getSetting('ADDONDIRECTFNAME9')
ADDONDIRECTFILE9       = ADDON.getSetting('ADDONDIRECTFILE9')
ADDONDIRECTPLUGIN9     = ADDON.getSetting('ADDONDIRECTPLUGIN9')
ADDONDIRECTREPO9       = ADDON.getSetting('ADDONDIRECTREPO9')
ADDONDIRECTREPOXML9    = ADDON.getSetting('ADDONDIRECTREPOXML9')
ADDONDIRECTREPOURL9    = ADDON.getSetting('ADDONDIRECTREPOURL9')
ADDONDIRECTFNAME10      = ADDON.getSetting('ADDONDIRECTFNAME10')
ADDONDIRECTFILE10       = ADDON.getSetting('ADDONDIRECTFILE10')
ADDONDIRECTPLUGIN10     = ADDON.getSetting('ADDONDIRECTPLUGIN10')
ADDONDIRECTREPO10       = ADDON.getSetting('ADDONDIRECTREPO10')
ADDONDIRECTREPOXML10    = ADDON.getSetting('ADDONDIRECTREPOXML10')
ADDONDIRECTREPOURL10    = ADDON.getSetting('ADDONDIRECTREPOURL10')
ADDONDIRECTFNAME11      = ADDON.getSetting('ADDONDIRECTFNAME11')
ADDONDIRECTFILE11       = ADDON.getSetting('ADDONDIRECTFILE11')
ADDONDIRECTPLUGIN11     = ADDON.getSetting('ADDONDIRECTPLUGIN11')
ADDONDIRECTREPO11       = ADDON.getSetting('ADDONDIRECTREPO11')
ADDONDIRECTREPOXML11    = ADDON.getSetting('ADDONDIRECTREPOXML11')
ADDONDIRECTREPOURL11    = ADDON.getSetting('ADDONDIRECTREPOURL11')
ADDONDIRECTFNAME12      = ADDON.getSetting('ADDONDIRECTFNAME12')
ADDONDIRECTFILE12       = ADDON.getSetting('ADDONDIRECTFILE12')
ADDONDIRECTPLUGIN12     = ADDON.getSetting('ADDONDIRECTPLUGIN12')
ADDONDIRECTREPO12       = ADDON.getSetting('ADDONDIRECTREPO12')
ADDONDIRECTREPOXML12    = ADDON.getSetting('ADDONDIRECTREPOXML12')
ADDONDIRECTREPOURL12    = ADDON.getSetting('ADDONDIRECTREPOURL12')
ADDONDIRECTFNAME13      = ADDON.getSetting('ADDONDIRECTFNAME13')
ADDONDIRECTFILE13       = ADDON.getSetting('ADDONDIRECTFILE13')
ADDONDIRECTPLUGIN13     = ADDON.getSetting('ADDONDIRECTPLUGIN13')
ADDONDIRECTREPO13       = ADDON.getSetting('ADDONDIRECTREPO13')
ADDONDIRECTREPOXML13    = ADDON.getSetting('ADDONDIRECTREPOXML13')
ADDONDIRECTREPOURL13    = ADDON.getSetting('ADDONDIRECTREPOURL13')
ADDONDIRECTFNAME14      = ADDON.getSetting('ADDONDIRECTFNAME14')
ADDONDIRECTFILE14       = ADDON.getSetting('ADDONDIRECTFILE14')
ADDONDIRECTPLUGIN14     = ADDON.getSetting('ADDONDIRECTPLUGIN14')
ADDONDIRECTREPO14       = ADDON.getSetting('ADDONDIRECTREPO14')
ADDONDIRECTREPOXML14    = ADDON.getSetting('ADDONDIRECTREPOXML14')
ADDONDIRECTREPOURL14    = ADDON.getSetting('ADDONDIRECTREPOURL14')
ADDONDIRECTFNAME15      = ADDON.getSetting('ADDONDIRECTFNAME15')
ADDONDIRECTFILE15       = ADDON.getSetting('ADDONDIRECTFILE15')
ADDONDIRECTPLUGIN15     = ADDON.getSetting('ADDONDIRECTPLUGIN15')
ADDONDIRECTREPO15       = ADDON.getSetting('ADDONDIRECTREPO15')
ADDONDIRECTREPOXML15    = ADDON.getSetting('ADDONDIRECTREPOXML15')
ADDONDIRECTREPOURL15    = ADDON.getSetting('ADDONDIRECTREPOURL15')
ADDONDIRECTFNAME16      = ADDON.getSetting('ADDONDIRECTFNAME16')
ADDONDIRECTFILE16       = ADDON.getSetting('ADDONDIRECTFILE16')
ADDONDIRECTPLUGIN16     = ADDON.getSetting('ADDONDIRECTPLUGIN16')
ADDONDIRECTREPO16       = ADDON.getSetting('ADDONDIRECTREPO16')
ADDONDIRECTREPOXML16    = ADDON.getSetting('ADDONDIRECTREPOXML16')
ADDONDIRECTREPOURL16    = ADDON.getSetting('ADDONDIRECTREPOURL16')
ADDONDIRECTFNAME17      = ADDON.getSetting('ADDONDIRECTFNAME17')
ADDONDIRECTFILE17       = ADDON.getSetting('ADDONDIRECTFILE17')
ADDONDIRECTPLUGIN17     = ADDON.getSetting('ADDONDIRECTPLUGIN17')
ADDONDIRECTREPO17       = ADDON.getSetting('ADDONDIRECTREPO17')
ADDONDIRECTREPOXML17    = ADDON.getSetting('ADDONDIRECTREPOXML17')
ADDONDIRECTREPOURL17    = ADDON.getSetting('ADDONDIRECTREPOURL17')
ADDONDIRECTFNAME18      = ADDON.getSetting('ADDONDIRECTFNAME18')
ADDONDIRECTFILE18       = ADDON.getSetting('ADDONDIRECTFILE18')
ADDONDIRECTPLUGIN18     = ADDON.getSetting('ADDONDIRECTPLUGIN18')
ADDONDIRECTREPO18       = ADDON.getSetting('ADDONDIRECTREPO18')
ADDONDIRECTREPOXML18    = ADDON.getSetting('ADDONDIRECTREPOXML18')
ADDONDIRECTREPOURL18    = ADDON.getSetting('ADDONDIRECTREPOURL18')
ADDONDIRECTFNAME19      = ADDON.getSetting('ADDONDIRECTFNAME19')
ADDONDIRECTFILE19       = ADDON.getSetting('ADDONDIRECTFILE19')
ADDONDIRECTPLUGIN19     = ADDON.getSetting('ADDONDIRECTPLUGIN19')
ADDONDIRECTREPO19       = ADDON.getSetting('ADDONDIRECTREPO19')
ADDONDIRECTREPOXML19    = ADDON.getSetting('ADDONDIRECTREPOXML19')
ADDONDIRECTREPOURL19    = ADDON.getSetting('ADDONDIRECTREPOURL19')
#########################################################
# Text File with apk info in it.  Leave as 'http://' to ignore
APKFILE                 = ADDON.getSetting('APKFILE')
APKFNAME1               = ADDON.getSetting('APKFNAME1')
APKFILE1                = ADDON.getSetting('APKFILE1')
APKFNAME2               = ADDON.getSetting('APKFNAME2')
APKFILE2                = ADDON.getSetting('APKFILE2')
APKFNAME3               = ADDON.getSetting('APKFNAME3')
APKFILE3                = ADDON.getSetting('APKFILE3')
APKFNAME4               = ADDON.getSetting('APKFNAME4')
APKFILE4                = ADDON.getSetting('APKFILE4')
APKFNAME5               = ADDON.getSetting('APKFNAME5')
APKFILE5                = ADDON.getSetting('APKFILE5')
APKFNAME6               = ADDON.getSetting('APKFNAME6')
APKFILE6                = ADDON.getSetting('APKFILE6')
APKFNAME7               = ADDON.getSetting('APKFNAME7')
APKFILE7                = ADDON.getSetting('APKFILE7')
APKFNAME8               = ADDON.getSetting('APKFNAME8')
APKFILE8                = ADDON.getSetting('APKFILE8')
APKFNAME9               = ADDON.getSetting('APKFNAME9')
APKFILE9                = ADDON.getSetting('APKFILE9')
#########################################################
# direct apk
APKDIRECTFNAME1         = ADDON.getSetting('APKDIRECTFNAME1')
APKDIRECTFILE1          = ADDON.getSetting('APKDIRECTFILE1')
APKDIRECTFNAME2         = ADDON.getSetting('APKDIRECTFNAME2')
APKDIRECTFILE2          = ADDON.getSetting('APKDIRECTFILE2')
APKDIRECTFNAME3         = ADDON.getSetting('APKDIRECTFNAME3')
APKDIRECTFILE3          = ADDON.getSetting('APKDIRECTFILE3')
APKDIRECTFNAME4         = ADDON.getSetting('APKDIRECTFNAME4')
APKDIRECTFILE4          = ADDON.getSetting('APKDIRECTFILE4')
APKDIRECTFNAME5         = ADDON.getSetting('APKDIRECTFNAME5')
APKDIRECTFILE5          = ADDON.getSetting('APKDIRECTFILE5')
APKDIRECTFNAME6         = ADDON.getSetting('APKDIRECTFNAME6')
APKDIRECTFILE6          = ADDON.getSetting('APKDIRECTFILE6')
APKDIRECTFNAME7         = ADDON.getSetting('APKDIRECTFNAME7')
APKDIRECTFILE7          = ADDON.getSetting('APKDIRECTFILE7')
APKDIRECTFNAME8         = ADDON.getSetting('APKDIRECTFNAME8')
APKDIRECTFILE8          = ADDON.getSetting('APKDIRECTFILE8')
APKDIRECTFNAME9         = ADDON.getSetting('APKDIRECTFNAME9')
APKDIRECTFILE9          = ADDON.getSetting('APKDIRECTFILE9')
APKDIRECTFNAME10        = ADDON.getSetting('APKDIRECTFNAME10')
APKDIRECTFILE10         = ADDON.getSetting('APKDIRECTFILE10')
APKDIRECTFNAME11        = ADDON.getSetting('APKDIRECTFNAME11')
APKDIRECTFILE11         = ADDON.getSetting('APKDIRECTFILE11')
APKDIRECTFNAME12        = ADDON.getSetting('APKDIRECTFNAME12')
APKDIRECTFILE12         = ADDON.getSetting('APKDIRECTFILE12')
APKDIRECTFNAME13        = ADDON.getSetting('APKDIRECTFNAME13')
APKDIRECTFILE13         = ADDON.getSetting('APKDIRECTFILE13')
APKDIRECTFNAME14        = ADDON.getSetting('APKDIRECTFNAME14')
APKDIRECTFILE14         = ADDON.getSetting('APKDIRECTFILE14')
APKDIRECTFNAME15        = ADDON.getSetting('APKDIRECTFNAME15')
APKDIRECTFILE15         = ADDON.getSetting('APKDIRECTFILE15')
APKDIRECTFNAME16        = ADDON.getSetting('APKDIRECTFNAME16')
APKDIRECTFILE16         = ADDON.getSetting('APKDIRECTFILE16')
APKDIRECTFNAME17        = ADDON.getSetting('APKDIRECTFNAME17')
APKDIRECTFILE17         = ADDON.getSetting('APKDIRECTFILE17')
APKDIRECTFNAME18        = ADDON.getSetting('APKDIRECTFNAME18')
APKDIRECTFILE18         = ADDON.getSetting('APKDIRECTFILE18')
APKDIRECTFNAME19        = ADDON.getSetting('APKDIRECTFNAME19')
APKDIRECTFILE19         = ADDON.getSetting('APKDIRECTFILE19')
#########################################################
# direct repo
REPONAME1       = ADDON.getSetting('REPONAME1')
REPOFILE1       = ADDON.getSetting('REPOFILE1')
REPONAME2       = ADDON.getSetting('REPONAME2')
REPOFILE2       = ADDON.getSetting('REPOFILE2')
REPONAME3       = ADDON.getSetting('REPONAME3')
REPOFILE3       = ADDON.getSetting('REPOFILE3')
REPONAME4       = ADDON.getSetting('REPONAME4')
REPOFILE4       = ADDON.getSetting('REPOFILE4')
REPONAME5       = ADDON.getSetting('REPONAME5')
REPOFILE5       = ADDON.getSetting('REPOFILE5')
REPONAME6       = ADDON.getSetting('REPONAME6')
REPOFILE6       = ADDON.getSetting('REPOFILE6')
REPONAME7       = ADDON.getSetting('REPONAME7')
REPOFILE7       = ADDON.getSetting('REPOFILE7')
REPONAME8       = ADDON.getSetting('REPONAME8')
REPOFILE8       = ADDON.getSetting('REPOFILE8')
REPONAME9       = ADDON.getSetting('REPONAME9')
REPOFILE9       = ADDON.getSetting('REPOFILE9')
REPONAME10      = ADDON.getSetting('REPONAME10')
REPOFILE10      = ADDON.getSetting('REPOFILE10')
REPONAME11      = ADDON.getSetting('REPONAME11')
REPOFILE11      = ADDON.getSetting('REPOFILE11')
REPONAME12      = ADDON.getSetting('REPONAME12')
REPOFILE12      = ADDON.getSetting('REPOFILE12')
REPONAME13      = ADDON.getSetting('REPONAME13')
REPOFILE13      = ADDON.getSetting('REPOFILE13')
REPONAME14      = ADDON.getSetting('REPONAME14')
REPOFILE14      = ADDON.getSetting('REPOFILE14')
REPONAME15      = ADDON.getSetting('REPONAME15')
REPOFILE15      = ADDON.getSetting('REPOFILE15')
REPONAME16      = ADDON.getSetting('REPONAME16')
REPOFILE16      = ADDON.getSetting('REPOFILE16')
REPONAME17      = ADDON.getSetting('REPONAME17')
REPOFILE17      = ADDON.getSetting('REPOFILE17')
REPONAME18      = ADDON.getSetting('REPONAME18')
REPOFILE18      = ADDON.getSetting('REPOFILE18')
REPONAME19      = ADDON.getSetting('REPONAME19')
REPOFILE19      = ADDON.getSetting('REPOFILE19')
