# -*- coding: utf-8 -*-
# http://aftermathwizard.net/GettingStarted/
# http://aftermathwizard.net/FAQS/
import os, xbmc, xbmcaddon, xbmcvfs
xbmc.log(msg='Run uservar.py', level=xbmc.LOGNOTICE)
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDON          = xbmcaddon.Addon(ADDON_ID)
ADDON_DATA     = xbmc.translatePath(os.path.join('special://profile', 'addon_data'))
ADDONPATH      = xbmc.translatePath(os.path.join('special://home/addons', ADDON_ID))
BASEPATH       = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
EXTRAPATH      = xbmc.translatePath(os.path.join(ADDONPATH, 'resources', 'data'))
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds')
REPOID         = ADDON.getSetting('REPOID')
ADDONTITLE     = ADDON.getSetting('ADDONTITLE')
MODURL         = 'http://mirrors.kodi.tv/addons/krypton/'
MODURL2        = 'http://mirrors.kodi.tv/addons/jarvis/'
FONTBIG        = 'Font14'
FONT           = 'Font13'
FONTSMALL      = 'Font10'
# repo url
repo_url       = ADDON.getSetting('repo.url')
# spmc releases
spmcurl1       = 'https://github.com/koying/SPMC/releases/'

##### Sys info tags
# find kodi ver
xbmc_version=xbmc.getInfoLabel('System.BuildVersion')
version=float(xbmc_version[:4])
if version >= 18.0 and version <= 18.9: kodi_version = '18'
if version >= 17.0 and version <= 17.9: kodi_version = '17'
if version >= 16.0 and version <= 16.9: kodi_version = '16'
if version >= 15.0 and version <= 15.9: kodi_version = '15'
if version >= 14.0 and version <= 14.9: kodi_version = '14'
'''
# python version
import platform
pythonver = platform.python_version()
# platform version ie windows or android
osinfo = platform.system()+' '+platform.release()
'''
#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'media')
# If you want to use locally stored icons the place them in the Resources/media/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://place.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'maintenance.png')
ICONAPK        = os.path.join(ART, 'android.png')
ICONADDONS     = os.path.join(ART, 'addons.png')
ICONYOUTUBE    = os.path.join(ART, 'youtube.png')
ICONSAVE       = os.path.join(ART, 'download.png')
ICONTRAKT      = os.path.join(ART, 'trakt.png')
ICONREAL       = os.path.join(ART, 'dabrid.png')
ICONLOGIN      = os.path.join(ART, 'contact.png')
ICONCONTACT    = os.path.join(ART, 'contact.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
ICONRESTORE    = os.path.join(ART, 'restore.png')
ICONRESTOREALL = os.path.join(ART, 'restore_all.png')
ICONBACKUP     = os.path.join(ART, 'backup.png')
ICONDELETE     = os.path.join(ART, 'delete.png')
ICONEMAIL      = os.path.join(ART, 'email.png')
ICONFORCECLOSE = os.path.join(ART, 'forceclose.png')
ICONFRESHSTART = os.path.join(ART, 'freshstart.png')
ICONLOG        = os.path.join(ART, 'log.png')
ICONSEARCH     = os.path.join(ART, 'search.png')
ICONXML        = os.path.join(ART, 'xml.png')
ICONFTMC       = os.path.join(ART, 'ftmc.png')
ICONSPMC       = os.path.join(ART, 'spmc.png')
ICONCLEAN      = os.path.join(ART, 'clean.png')
ICONCLEANALL   = os.path.join(ART, 'cleanall.png')
ICONFILE       = os.path.join(ART, 'file.png')
ICONFIX        = os.path.join(ART, 'paramedic.png')
ICONSKIN       = os.path.join(ART, 'skin.png')
ICONTWEAKS     = os.path.join(ART, 'tweaks.png')
ICONZIP        = os.path.join(ART, 'zip.png')
ICONSPACER     = os.path.join(ART, 'spacer.png')
ICONINFO       = os.path.join(ART, 'info.png')
ICONTVGFS      = os.path.join(ART, 'tvgfs.png')
ICONINI        = os.path.join(ART, 'ini.png')
ICONGITHUB     = os.path.join(ART, 'github.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '*'
# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'green'
COLOR4         = 'red'
COLOR5         = 'orange'
COLOR6         = 'dodgerblue'
COLOR7         = 'skyblue'
COLOR8         = 'grey'
# menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'
#THEME1        = '[COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR7+']%s[/COLOR]'
# white items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR]    [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'
# Menu Spacer / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR6+']%s[/COLOR]'
# Warning Flag / %s is the menu item and is required
THEME7        = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR4+']WARNING[/COLOR])[/B][/COLOR]  [COLOR '+COLOR8+']%s[/COLOR][/I]'
# zips / %s is the menu item and is required
THEME8         = '[COLOR '+COLOR1+'][B]([COLOR '+COLOR7+']Zip[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'
# Toggle menu items   / %s is the menu item and is required
THEME9         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR8+']Toggle[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'
# install prorams and build / %s is the menu item and is required
THEME10        = '[COLOR '+COLOR8+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/I][/COLOR]  Install Programs   [COLOR '+COLOR8+'](Current Build:[/COLOR] [COLOR '+COLOR5+']%s[/COLOR][COLOR '+COLOR8+'] )[/COLOR]'


#########################################################
# How often you would like it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
#UPDATECHECKF    = ADDON.getSetting('UPDATECHECK')
#UPDATECHECK     = UPDATECHECKF if str(UPDATECHECKF).isdigit() else 1

#wip
#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE      = ADDON.getSetting('AUTOUPDATE')
# Url to wizard version
#WIZARDFILE      = ADDON.getSetting('WIZARDFILE')
WIZARDFILE      = ADDON.getSetting('BUILDFILE')
if WIZARDFILE == 'http://': WIZARDFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_zips.txt'))


#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
#AUTOINSTALL    = 'Yes'
AUTOINSTALL     = ADDON.getSetting('AUTOINSTALL')
# Addon ID for the repository
ICONREPO        = xbmc.translatePath(os.path.join('special://home/addons', REPOID, 'icon.png'))
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML    = repo_url+REPOID+'/addon.xml'
# Url to folder zip is located in
#REPOZIPURL     = 'https://raw.githubusercontent.com/username/_repo/master/_zips/plugin.program.addonname/'
REPOZIPURL      = repo_url+REPOID+'/'





#startup notify.txt
#########################################################
### NOTIFICATION and BLACKLIST WINDOW###################
#   First Run Window and Blacklist
#########################################################
# Enable Notification screen Yes or No
#ENABLE         = 'No'
ENABLE          = ADDON.getSetting('ENABLE')
# Use either 'Text' or 'Image'
HEADERTYPE      = ADDON.getSetting('HEADERTYPE')
HEADERMESSAGE   = 'Firstrun Wizard Message'
# url to image if using Image 424x180
HEADERIMAGE     = 'http://'
# Background for Notification Window
BACKGROUND     = 'http://'
# Notification Source
NOTIFICATIONtype = ADDON.getSetting('NOTIFICATION.type')
if NOTIFICATIONtype == 1:
    NOTIFICATION = ADDON.getSetting('NOTIFICATION.url')
else:
    NOTIFICATION = 'http://'
NOTIFICATIONFtest =   ADDON.getSetting('NOTIFICATION.file')
NOTIFICATIONF     =   xbmc.translatePath(os.path.join(EXTRAPATH, NOTIFICATIONFtest))
if not os.path.exists(NOTIFICATIONF): NOTIFICATIONF = 'http://'




#startup zip.txt
#########################################################
#### Text File with build info in it.
'''
BUILDFILEtype = ADDON.getSetting('BUILDFILE.type')
if BUILDFILEtype == 1:
    BUILDFILE = ADDON.getSetting('BUILDFILE.url')
    #THEMEFILE = 'http://'
else:
    BUILDFILE = 'http://'
    #THEMEFILE = 'http://'

BUILDFILEF =      ADDON.getSetting('BUILDFILE.file')
#BUILDFILE  =      xbmc.translatePath(os.path.join(EXTRAPATH, BUILDFILEF))
if not os.path.exists(BUILDFILE): BUILDFILEF = 'http://'

THEMEFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_theme.txt'))
if not os.path.exists(THEMEFILE): THEMEFILE = 'http://'
'''

#ADDONFILE = ADDON.getSetting('ADDONFILE')
#ADDONFILEFtest =  ADDON.getSetting('ADDONFILE.file')
#ADDONFILEF     =  xbmc.translatePath(os.path.join(EXTRAPATH, ADDONFILEFtest))
#if not os.path.exists(ADDONFILEF): ADDONFILEF = 'http://'

BUILDFILE = ADDON.getSetting('BUILDFILE')
BUILDFILEtest =  ADDON.getSetting('BUILDFILE.file')
BUILDFILEF     =  xbmc.translatePath(os.path.join(EXTRAPATH, BUILDFILEtest))
if not os.path.exists(BUILDFILEF): BUILDFILEF = 'http://'

THEMEFILE = ADDON.getSetting('THEMEFILE')
THEMEFILEtest =  ADDON.getSetting('THEMEFILE.file')
THEMEFILEF     =  xbmc.translatePath(os.path.join(EXTRAPATH, THEMEFILEtest))
if not os.path.exists(THEMEFILEF): THEMEFILEF = 'http://'

#########################################################
# Built In Builds using zips_url Defaults
versionbuiltin         = '0.0.0'
kodibuiltin            = '0.0'
adultbuiltin           ='No'
namebuiltin            = ADDONTITLE+' Default '
#########################################################
# ie: zips_url + url_addons_repo
zips_url                 = ADDON.getSetting('zips.url')
url_addons_repo          = ADDON.getSetting('url_addons_repo')
url_addons_audio         = ADDON.getSetting('url_addons_audio')
url_addons_program       = ADDON.getSetting('url_addons_program')
url_addons_video         = ADDON.getSetting('url_addons_video')
url_addons_iptv          = ADDON.getSetting('url_addons_iptv')
url_addons_sub           = ADDON.getSetting('url_addons_sub')
url_guisettings_18       = ADDON.getSetting('url_guisettings_18')
url_theme_18             = ADDON.getSetting('url_theme_18')
url_guisettings_17       = ADDON.getSetting('url_guisettings_17')
url_theme_17             = ADDON.getSetting('url_theme_17')
url_guisettings_16       = ADDON.getSetting('url_guisettings_16')
url_theme_16             = ADDON.getSetting('url_theme_16')
url_guisettings_15       = ADDON.getSetting('url_guisettings_15')
url_theme_15             = ADDON.getSetting('url_theme_15')
url_guisettings_14       = ADDON.getSetting('url_guisettings_14')
url_theme_14             = ADDON.getSetting('url_theme_14')
# your OS defaults
if kodi_version == '18': url_guisettings  = url_guisettings_18
if kodi_version == '18': url_theme        = url_theme_18
if kodi_version == '17': url_guisettings  = url_guisettings_17
if kodi_version == '17': url_theme        = url_theme_17
if kodi_version == '16': url_guisettings  = url_guisettings_16
if kodi_version == '16': url_theme        = url_theme_16
if kodi_version == '15': url_guisettings  = url_guisettings_15
if kodi_version == '15': url_theme        = url_theme_15
if kodi_version == '14': url_guisettings  = url_guisettings_14
if kodi_version == '14': url_theme        = url_theme_14


#########################################################
# autounattend sql credentials
sql_host = ADDON.getSetting('sql.host')
sql_user = ADDON.getSetting('sql.user')
sql_pass = ADDON.getSetting('sql.pass')

#########################################################
# Default addons 
DEFAULTPLUGINS = ['metadata.album.universal',
                  'metadata.artists.universal',
                  'metadata.common.fanart.tv',
                  'metadata.common.imdb.com',
                  'metadata.common.musicbrainz.org',
                  'metadata.themoviedb.org',
                  'metadata.tvdb.com',
                  'service.xbmc.versioncheck']
                  
#########################################################
# Whitelist addons to save when wiping 
EXCLUDES1 = ADDON.getSetting('EXCLUDES1')
EXCLUDES2 = ADDON.getSetting('EXCLUDES2')
EXCLUDES3 = ADDON.getSetting('EXCLUDES3')
EXCLUDES4 = ADDON.getSetting('EXCLUDES4')
EXCLUDES5 = ADDON.getSetting('EXCLUDES5')
EXCLUDES6 = ADDON.getSetting('EXCLUDES6')
EXCLUDES7 = ADDON.getSetting('EXCLUDES7')
EXCLUDES8 = ADDON.getSetting('EXCLUDES8')
EXCLUDES  = [ADDON_ID,
             REPOID,
             EXCLUDES1,
             EXCLUDES2,
             EXCLUDES3,
             EXCLUDES4,
             EXCLUDES5,
             EXCLUDES6,
             EXCLUDES7,
             EXCLUDES8]
#########################################################
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = '[COLOR red]YOU[/COLOR][COLOR white]TUBE[/COLOR] Videos'
YOUTUBEFILE    = ADDON.getSetting('YOUTUBEFILE')
if YOUTUBEFILE == 'http://': YOUTUBEFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_youtube.txt'))



#########################################################
### Message for Contact Page ############################
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT     = ADDON.getSetting('HIDECONTACT')
CONTACT         = ADDON.getSetting('CONTACT')
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON     = ICONCONTACT
CONTACTFANART   = 'http://'



#########################################################
#### Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = ADDON.getSetting('ADVANCEDFILE')
#if ADVANCEDFILE == 'http://': ADVANCEDFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_advanced.txt'))



#########################################################
# Text File for addon installer.  Leave as 'http://' to ignore
#ADDONFILE      = ADDON.getSetting('ADDONFILE')
#if ADDONFILE == 'http://': ADDONFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_addons.txt'))
# ADDONFILE Source
#ADDONFILEtype = ADDON.getSetting('ADDONFILE.type')
'''
if ADDONFILEtype == 0:
    ADDONFILE = ADDON.getSetting('ADDONFILE.url')
else:
    ADDONFILE = 'http://'
'''
ADDONFILE = ADDON.getSetting('ADDONFILE')
ADDONFILEFtest =  ADDON.getSetting('ADDONFILE.file')
ADDONFILEF     =  xbmc.translatePath(os.path.join(EXTRAPATH, ADDONFILEFtest))
if not os.path.exists(ADDONFILEF): ADDONFILEF = 'http://'



#########################################################
# Text File with apk info in it.  Leave as 'http://' to ignore
#APKFILE                 = ADDON.getSetting('APKFILE')
#if APKFILE == 'http://': APKFILE = xbmc.translatePath(os.path.join(EXTRAPATH, '_apks.txt'))
#APKFILEtype = ADDON.getSetting('APKFILE.type')
#if APKFILEtype == 0:
#    APKFILE = ADDON.getSetting('APKFILE.url')
#else:
#    APKFILE = 'http://'
APKFILE      = ADDON.getSetting('APKFILE')
APKFILEFtest =  ADDON.getSetting('APKFILE.file')
APKFILEF     =  xbmc.translatePath(os.path.join(EXTRAPATH, APKFILEFtest))
if not os.path.exists(APKFILEF): APKFILEF = 'http://'


