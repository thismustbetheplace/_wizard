# -*- coding: utf-8 -*-
# http://aftermathwizard.net/GettingStarted/
# http://aftermathwizard.net/FAQS/
import os, xbmc, xbmcaddon
#xbmc.log(msg='|  \/  | / \  |_ _|| \| ||_   _| __| \| | / \  | \| | / __| __|', level=xbmc.LOGNOTICE)
#xbmc.log(msg='| |\/| |/ _ \  | | | .` |  | | | _|| .` |/ _ \ | .` || (__| _| ', level=xbmc.LOGNOTICE)
#xbmc.log(msg='|_|  |_/_/ \_\|___||_|\_|  |_| |___|_|\_/_/ \_\|_|\_| \___|___|', level=xbmc.LOGNOTICE)
#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDON          = xbmcaddon.Addon(ADDON_ID)
ADDON_DATA     = xbmc.translatePath(os.path.join('special://profile', 'addon_data'))
addonPath      = xbmc.translatePath(os.path.join('special://home/addons', ADDON_ID))
basePath       = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
extrapath      = xbmc.translatePath(os.path.join(addonPath, 'resources', 'data'))
REPOID         = ADDON.getSetting('REPOID')
ADDONTITLE     = ADDON.getSetting('ADDONTITLE')

# whitelist  addons to save
#EXCLUDES      = ADDON.getSetting('EXCLUDES')
#EXCLUDES       = [ADDON_ID, REPOID, 'script.tvguide.fullscreen', 'script.tvguide.fullscreen.skin.cake']
EXCLUDES       = [ADDON_ID, REPOID]

# blacklist  addons to delete
#BLACKLIST     = ADDON.getSetting('BLACKLIST')
BLACKLIST      = ['script.IPTVGuide', 'script._IPTVGuide', 'script._TVGuide', 'plugin.video.covenant','plugin.video.MaverickTV','plugin.video.rebirth']
# Text File for BLACKLIST txt FILE.  Leave as 'http://' to ignore
#BLACKLISTFILE  = ADDON.getSetting('BLACKLISTFILE')
BLACKLISTFILE  = ADDON.getSetting('NOTIFICATION')

# repo url
repo_url                       = ADDON.getSetting('repo.url')
# spmc releases
spmcurl1                       = 'https://github.com/koying/SPMC/releases/'
# ie: zips_url + url_addons_repo
zips_url                       = ADDON.getSetting('zips.url')
url_addons_repo                = 'addons_repo.zip'
url_addons_audio               = 'addons_audio.zip'
url_addons_program             = 'addons_program.zip'
url_addons_video               = 'addons_video.zip'
url_addons_iptv                = 'addons_iptv.zip'
url_addons_sub                 = 'addons_sub.zip'
url_guisettings_14             = '14_guisettings.zip'
url_guisettings_15             = '15_guisettings.zip'
url_guisettings_16             = '16_guisettings.zip'
url_guisettings_17             = '17_guisettings.zip'
url_guisettings_18             = '18_guisettings.zip'
url_theme_14                   = '14_theme.zip'
url_theme_15                   = '15_theme.zip'
url_theme_16                   = '16_theme.zip'
url_theme_17                   = '17_theme.zip'
url_theme_18                   = '18_theme.zip'
#
url_addon_data                 = '17_guisettings.zip'


# sources.xml builtin files
sourcesxml1 = ADDON.getSetting('sourcesxml1')
sourcesxml2 = ADDON.getSetting('sourcesxml2')
sourcesxml3 = ADDON.getSetting('sourcesxml3')
# RssFeeds.xml builtin files
rss1 = ADDON.getSetting('rss1')
rss2 = ADDON.getSetting('rss2')
rss3 = ADDON.getSetting('rss3')
rss4 = ADDON.getSetting('rss4')
# playercorefactory.xml builtin files
playercorefactory1 = ADDON.getSetting('playercorefactory1')
playercorefactory2 = ADDON.getSetting('playercorefactory2')
playercorefactory3 = ADDON.getSetting('playercorefactory3')
playercorefactory4 = ADDON.getSetting('playercorefactory4')
playercorefactory5 = ADDON.getSetting('playercorefactory5')
playercorefactory6 = ADDON.getSetting('playercorefactory6')
playercorefactory7 = ADDON.getSetting('playercorefactory7')
playercorefactory8 = ADDON.getSetting('playercorefactory8')

# autounattend sql
sql_host = ADDON.getSetting('sql.host')
sql_user = ADDON.getSetting('sql.user')
sql_pass = ADDON.getSetting('sql.pass')


# Text File with build info in it.
BUILDFILE       = ADDON.getSetting('BUILDFILE')


# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE       = ADDON.getSetting('ADDONFILE')


# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE    = ADDON.getSetting('ADVANCEDFILE')


# Text File with apk info in it.
#APKFILE        = text_url+'_apks.txt'
APKFILE         = ADDON.getSetting('APKFILE')


# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = '[COLOR red]YOU[/COLOR][COLOR white]TUBE[/COLOR] Videos'
YOUTUBEFILE    = ADDON.getSetting('YOUTUBEFILE')



# How often you would like it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
#UPDATECHECK   = ADDON.getSetting('UPDATECHECK')
# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'media')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/media/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://place.net/repo/wizard/settings.png'
# Leave as http:// for default icon
'''
ICONBUILDS     = 'http://'
ICONMAINT      = 'http://'
ICONAPK        = 'http://'
ICONADDONS     = 'http://'
ICONYOUTUBE    = 'http://'
ICONSAVE       = 'http://'
ICONTRAKT      = 'http://'
ICONREAL       = 'http://'
ICONLOGIN      = 'http://'
ICONCONTACT    = 'http://'
ICONSETTINGS   = 'http://'
'''
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'maintenance.png')
ICONAPK        = os.path.join(ART, 'android.png')
ICONADDONS     = os.path.join(ART, 'addons.png')
ICONYOUTUBE    = os.path.join(ART, 'youtube.png')
ICONSAVE       = os.path.join(ART, 'download.png')
ICONTRAKT      = os.path.join(ART, 'trakt.png')
ICONREAL       = os.path.join(ART, 'dabrid.png')
ICONLOGIN      = os.path.join(ART, 'contact.png')
ICONCONTACT    = os.path.join(ART, 'contact.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
ICONRESTORE    = os.path.join(ART, 'restore.png')
ICONRESTOREALL = os.path.join(ART, 'restore_all.png')
ICONBACKUP     = os.path.join(ART, 'backup.png')
ICONDELETE     = os.path.join(ART, 'delete.png')
ICONEMAIL      = os.path.join(ART, 'email.png')
ICONFORCECLOSE = os.path.join(ART, 'forceclose.png')
ICONFRESHSTART = os.path.join(ART, 'freshstart.png')
ICONLOG        = os.path.join(ART, 'log.png')
ICONSEARCH     = os.path.join(ART, 'search.png')
ICONXML        = os.path.join(ART, 'xml.png')
ICONFTMC       = os.path.join(ART, 'ftmc.png')
ICONSPMC       = os.path.join(ART, 'spmc.png')
ICONCLEAN      = os.path.join(ART, 'clean.png')
ICONCLEANALL   = os.path.join(ART, 'cleanall.png')
ICONFILE       = os.path.join(ART, 'file.png')
ICONFIX        = os.path.join(ART, 'paramedic.png')
ICONSKIN       = os.path.join(ART, 'skin.png')
ICONTWEAKS     = os.path.join(ART, 'tweaks.png')
ICONZIP        = os.path.join(ART, 'zip.png')
ICONSPACER     = os.path.join(ART, 'spacer.png')
ICONHAPPY      = os.path.join(ART, 'happy.png')
ICONHAPPYSAD   = os.path.join(ART, 'happy-sad.png')
ICONHAPPYSTONED =os.path.join(ART, 'happy-stoned.png')
ICONHAPPYEXTRA = os.path.join(ART, 'happy-extra.png')
ICONHAPPYWHITE = os.path.join(ART, 'happy-white.png')
ICONINFO       = os.path.join(ART, 'info.png')
ICONTVGFS      = os.path.join(ART, 'tvgfs.png')
ICONINI        = os.path.join(ART, 'ini.png')
ICONGITHUB     = os.path.join(ART, 'github.png')

# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '*'

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'green'
COLOR4         = 'red'
COLOR5         = 'orange'
COLOR6         = 'steelblue'
COLOR7         = 'blue'
COLOR8         = 'grey'

# menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'
#THEME1        = '[COLOR '+COLOR2+']%s[/COLOR]'

# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR7+']%s[/COLOR]'

# white items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'

# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'

# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'

# Menu Spacer / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR6+']%s[/COLOR]'

# Warning Flag / %s is the menu item and is required
THEME7        = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR4+']WARNING[/COLOR])[/B][/COLOR]  [COLOR '+COLOR8+']%s[/COLOR][/I]'

# zips / %s is the menu item and is required
THEME8         = '[COLOR '+COLOR1+'][B]([COLOR '+COLOR7+']Install Zip[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR]'

# Toggle menu items   / %s is the menu item and is required
THEME9         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR8+']Toggle[/COLOR])[/B][/COLOR]  [COLOR '+COLOR2+']%s[/COLOR][/I]'

# install prorams and build / %s is the menu item and is required
THEME10        = '[COLOR '+COLOR8+'][B][I]([COLOR '+COLOR3+']Menu[/COLOR])[/B][/I][/COLOR]  Install Programs   [COLOR '+COLOR8+'](Current Build:[/COLOR] [COLOR '+COLOR5+']%s[/COLOR][COLOR '+COLOR8+'] )[/COLOR]'

#########################################################
### Message for Contact Page ############################
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
#HIDECONTACT    = 'Yes'
HIDECONTACT     = ADDON.getSetting('HIDECONTACT')
# You can add \n to do line breaks
#CONTACT        = 'Thank you for choosing my WIZARD\r\n\r\n Not affiliated with Kodi'
CONTACT         = ADDON.getSetting('CONTACT')
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON     = ICONCONTACT
#CONTACTFANART  = 'http://'
CONTACTFANART   = 'http://'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
#AUTOUPDATE     = 'Yes'
AUTOUPDATE      = ADDON.getSetting('AUTOUPDATE')
# Url to wizard version
#WIZARDFILE     = ''
#WIZARDFILE      = ADDON.getSetting('WIZARDFILE')
WIZARDFILE      = ADDON.getSetting('BUILDFILE')
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
#AUTOINSTALL    = 'Yes'
AUTOINSTALL     = ADDON.getSetting('AUTOINSTALL')
# Addon ID for the repository
#REPOID         = ADDON.getSetting('REPOID')
ICONREPO        = xbmc.translatePath(os.path.join('special://home/addons', REPOID, 'icon.png'))
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
#REPOADDONXML   = 'https://raw.githubusercontent.com/username/_repo/master/_zips/addons.xml'
REPOADDONXML    = repo_url+REPOID+'/addon.xml'
# Url to folder zip is located in
#REPOZIPURL     = 'https://raw.githubusercontent.com/username/_repo/master/_zips/plugin.program.addonname/'
REPOZIPURL      = repo_url+REPOID+'/'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#   First Run Window
#########################################################
# Enable Notification screen Yes or No
#ENABLE         = 'No'
ENABLE          = ADDON.getSetting('ENABLE')
# Url to notification file
#NOTIFICATION   = 'https://notify.txt'
NOTIFICATION    = ADDON.getSetting('NOTIFICATION')
FONTSETTINGS    = 'Font13'
FONTHEADER      = 'Font13'
# Use either 'Text' or 'Image'
#HEADERTYPE     = 'Text'
HEADERTYPE      = ADDON.getSetting('HEADERTYPE')
HEADERMESSAGE   = 'Firstrun Wizard Message'
# url to image if using Image 424x180
HEADERIMAGE     = 'http://'
# Background for Notification Window
BACKGROUND     = 'http://'
#BACKGROUND      = zips_url+'icon.png'
#########################################################
DEFAULTPLUGINS   = ['metadata.album.universal', 'metadata.artists.universal', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.musicbrainz.org', 'metadata.themoviedb.org', 'metadata.tvdb.com', 'service.xbmc.versioncheck']
