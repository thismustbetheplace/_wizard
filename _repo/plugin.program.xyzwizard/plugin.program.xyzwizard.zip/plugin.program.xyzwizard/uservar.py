# -*- coding: utf-8 -*-
#########################################################
### User Edit Variables #################################
#########################################################
import os, xbmc, xbmcaddon, shutil
ADDONTITLE       = 'XYZ'
ADDON_ID         = xbmcaddon.Addon().getAddonInfo('id')
ADDON            = xbmcaddon.Addon(id=ADDON_ID)
NAME             = ADDON.getAddonInfo('name')
VERSION          = ADDON.getAddonInfo('version')
PROFILE          = ADDON.getAddonInfo('profile').decode('utf-8')
#PROFILE         = xbmc.translatePath('special://profile/')
ADDONPATH        = ADDON.getAddonInfo('path').decode('utf-8')
LANGUAGE         = ADDON.getLocalizedString
LOG              = xbmc.translatePath('special://logpath/')
TEMPDIR          = xbmc.translatePath('special://temp')
XBMC             = xbmc.translatePath('special://xbmc/')
HOME             = xbmc.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
PLUGIN           = os.path.join(ADDONS,     ADDON_ID)
PACKAGES         = os.path.join(ADDONS,    'packages')
USERDATA         = os.path.join(HOME,      'userdata')
ADDOND           = os.path.join(USERDATA,  'addon_data')
ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADDONTEMPFOLDER  = os.path.join(ADDONS,    'temp')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
SPEEDTESTFOLD    = os.path.join(ADDONDATA, 'SpeedTest')
WHITELIST        = os.path.join(ADDONDATA, 'whitelist.txt')
QRCODES          = os.path.join(ADDONDATA, 'QRCodes')
TEXTCACHE        = os.path.join(ADDONDATA, 'Cache')
ARCHIVE_CACHE    = os.path.join(TEMPDIR,   'archive_cache')
kodi_version     = xbmc.getInfoLabel('System.BuildVersion')  # as a number in quotes
KODIV            = float(kodi_version[:4])                   # as a red number
#KODIV           = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
# main art
ART              = os.path.join(ADDONPATH, 'resources', 'art')
#ICON             = ADDON..getAddonInfo('icon')
#FANART           = ADDON..getAddonInfo('fanart')
ICON             = os.path.join(ART,       'icon.gif')
FANART           = os.path.join(ART,       'fanart.jpg')

# builtin txt menu paths #######################################################
EXTRAPATH        = os.path.join(ADDONPATH, 'resources', 'extras')
DATAPATH         = os.path.join(ADDONPATH, 'resources', 'data')
#linkortxt        = '.link'
linkortxt         = '.txt'
DATAPATHUSERDATA = os.path.join(ADDONDATA, 'data')
ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
SOURCES          = os.path.join(USERDATA,  'sources.xml')
PLAYERCORE       = os.path.join(USERDATA,  'playercorefactory.xml')
RSSFEED          = os.path.join(USERDATA,  'RssFeeds.xml')
FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
PROFILES         = os.path.join(USERDATA,  'profiles.xml')
GUISETTINGS      = os.path.join(USERDATA,  'guisettings.xml')
KEYBOARD_FILE    = os.path.join(USERDATA,  'keymaps', 'keyboard.xml')

# ie  home\userdata\addon_data\ADDONPATH\resources\data\sites
#'''
#addonsXMLFolder    = os.path.join(DATAPATHUSERDATA, 'addonsxml')
addonsTXTFolder    = os.path.join(DATAPATHUSERDATA, 'addons')
#addons2TXTFolder   = os.path.join(DATAPATHUSERDATA, 'addons2')
reposTXTFolder     = os.path.join(DATAPATHUSERDATA, 'repos')
#depsTXTFolder      = os.path.join(DATAPATHUSERDATA, 'deps')
pluginsTXTFolder   = os.path.join(DATAPATHUSERDATA, 'plugins')
apksTXTFolder      = os.path.join(DATAPATHUSERDATA, 'apks')
buildsTXTFolder    = os.path.join(DATAPATHUSERDATA, 'builds')
m3usTXTFolder      = os.path.join(DATAPATHUSERDATA, 'm3us')
playlistsTXTFolder = os.path.join(DATAPATHUSERDATA, 'playlists')
rompacksTXTFolder  = os.path.join(DATAPATHUSERDATA, 'rompacks')
sitesTXTFolder     = os.path.join(DATAPATHUSERDATA, 'sites')
themesTXTFolder    = os.path.join(DATAPATHUSERDATA, 'themes')
youtubeTXTFolder   = os.path.join(DATAPATHUSERDATA, 'youtube')
'''
################################################################################
#addonsXMLFolder    = os.path.join(DATAPATH, 'addonsxml')
addonsTXTFolder    = os.path.join(DATAPATH, 'addons')
#addons2TXTFolder   = os.path.join(DATAPATH, 'addons2')
reposTXTFolder     = os.path.join(DATAPATH, 'repos')
#depsTXTFolder      = os.path.join(DATAPATH, 'deps')
pluginsTXTFolder   = os.path.join(DATAPATH, 'plugins')
apksTXTFolder      = os.path.join(DATAPATH, 'apks')
buildsTXTFolder    = os.path.join(DATAPATH, 'builds')
m3usTXTFolder      = os.path.join(DATAPATH, 'm3us')
playlistsTXTFolder = os.path.join(DATAPATH, 'playlists')
rompacksTXTFolder  = os.path.join(DATAPATH, 'rompacks')
sitesTXTFolder     = os.path.join(DATAPATH, 'sites')
themesTXTFolder    = os.path.join(DATAPATH, 'themes')
youtubeTXTFolder   = os.path.join(DATAPATH, 'youtube')
'''


### if firstrun
if ADDON.getSetting('firstrun') == 'true':
    try: import firstrun;firstrun.firstrun()
    except: pass
    ADDON.setSetting('firstrun', 'false')
    
# copy main txt files to userdata
if not os.path.exists(DATAPATHUSERDATA):
    for item in os.listdir(DATAPATH):
        s = os.path.join(DATAPATH, item)
        d = os.path.join(DATAPATHUSERDATA, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks=False, ignore=None)
        else:
            shutil.copy2(s, d)
            
#if not os.path.exists(addonsXMLFolder):        shutil.copytree(os.path.join(DATAPATH, 'addonsxml'),addonsXMLFolder,  symlinks=False, ignore=None)
if not os.path.exists(addonsTXTFolder):        shutil.copytree(os.path.join(DATAPATH, 'addons'),addonsTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(reposTXTFolder):         shutil.copytree(os.path.join(DATAPATH, 'repos'),reposTXTFolder, symlinks=False, ignore=None)
#if not os.path.exists(depsTXTFolder):          shutil.copytree(os.path.join(DATAPATH, 'deps'),depsTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(pluginsTXTFolder):       shutil.copytree(os.path.join(DATAPATH, 'plugins'),pluginsTXTFolder, symlinks=False, ignore=None)
if not os.path.exists(apksTXTFolder):          shutil.copytree(os.path.join(DATAPATH, 'apks'),apksTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(buildsTXTFolder):        shutil.copytree(os.path.join(DATAPATH, 'builds'),buildsTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(m3usTXTFolder):          shutil.copytree(os.path.join(DATAPATH, 'm3us'),m3usTXTFolder,  symlinks=False, ignore=None)
#if not os.path.exists(playlistsTXTFolder):    shutil.copytree(os.path.join(DATAPATH, 'playlists'),playlistsTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(rompacksTXTFolder):      shutil.copytree(os.path.join(DATAPATH, 'rompacks'),rompacksTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(sitesTXTFolder):         shutil.copytree(os.path.join(DATAPATH, 'sites'),sitesTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(themesTXTFolder):        shutil.copytree(os.path.join(DATAPATH, 'themes'),themesTXTFolder,  symlinks=False, ignore=None)
if not os.path.exists(youtubeTXTFolder):       shutil.copytree(os.path.join(DATAPATH, 'youtube'),youtubeTXTFolder,  symlinks=False, ignore=None)
    
    
# backup - restore
My_Builds        = 'My_Builds'
BACKUPLOCATION   = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'+My_Builds+'/'
#MYBUILDS        = xbmc.translatePath(BACKUPLOCATION)
MYBUILDS         = xbmc.translatePath(os.path.join(BACKUPLOCATION))
if not os.path.exists(MYBUILDS): import xbmcvfs; xbmcvfs.mkdirs(MYBUILDS)
#
MYADDONS        = xbmc.translatePath(os.path.join(ADDON.getSetting('MYADDONS'))) if not xbmc.translatePath(os.path.join(ADDON.getSetting('MYADDONS'))) == '' else xbmc.translatePath(os.path.join(BACKUPLOCATION, 'addons'))
MYAPKS          = xbmc.translatePath(os.path.join(ADDON.getSetting('MYAPKS'))) if not xbmc.translatePath(os.path.join(ADDON.getSetting('MYAPKS'))) == '' else xbmc.translatePath(os.path.join(BACKUPLOCATION, 'apks'))
MYZIPS          = xbmc.translatePath(os.path.join(ADDON.getSetting('MYZIPS'))) if not xbmc.translatePath(os.path.join(ADDON.getSetting('MYZIPS'))) == '' else xbmc.translatePath(os.path.join(BACKUPLOCATION, 'zips'))
if ADDON.getSetting('SAVEDL') == 'true': SAVEDL = BACKUPLOCATION
else: SAVEDL = PACKAGES
#if not os.path.exists(MYADDONS): import xbmcvfs; xbmcvfs.mkdirs(MYADDONS)
#if not os.path.exists(MYAPKS): import xbmcvfs; xbmcvfs.mkdirs(MYAPKS)
#if not os.path.exists(MYZIPS): import xbmcvfs; xbmcvfs.mkdirs(MYZIPS)
#
#
ENABLEONLINE   =    ADDON.getSetting('ENABLEONLINE')  # bool
ENABLEOFFLINE  =    ADDON.getSetting('ENABLEOFFLINE') # bool
ENABLEXML      =    ADDON.getSetting('ENABLEXML')     # bool

# Use either 'Text' or 'Image'
#HEADERTYPE       = 'Text'
HEADERTYPE        = ADDON.getSetting('HEADERTYPE')
# Font size of header
FONTHEADER        = 'Font14'
HEADERMESSAGE     = '[B][COLOR cadetblue]'+ADDONTITLE+'[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
# url to image if using Image 424x180
HEADERIMAGE       = 'http://'
# Font for Notification Window
FONTSETTINGS      = 'Font13'
# Background for Notification Window
BACKGROUND        = 'http://'


# Text File with build info in it.
#BUILDFILE      = 'http://cb.srfx.in/builds.txt' # aftermath new
BUILDFILE   =    ADDON.getSetting('BUILDFILE')  # txt
# How often would you like it to check for build updates in days
# 0 being every startup of kodi
#UPDATECHECK    = 0
UPDATECHECK    = ADDON.getSetting('UPDATECHECK') 
UPDATECHECK    = int(float(UPDATECHECK)) if UPDATECHECK.isdigit() else 0
USER_AGENT     = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0' # custom
#USER_AGENT    = 'Mozilla/5.0 (Linux; U; Android 4.2.2; en-us; AFTB Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'

# Text File for addon installer.  Leave as 'http://' to ignore
#ADDONFILE      = 'http://cb.srfx.in/addons.txt'
ADDONFILE      = ADDON.getSetting('ADDONFILE')

# Text File with apk info in it.  Leave as 'http://' to ignore
#APKFILE       = 'http://cb.srfx.in/apks.txt'
APKFILE        = ADDON.getSetting('APKFILE')

# Text File for advanced settings.  Leave as 'http://' to ignore
#ADVANCEDFILE   = 'http://aftermathwizard.net/testtext/advanced.txt'
ADVANCEDFILE    = ADDON.getSetting('ADVANCEDFILE')
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = 'YouTUBE'
#YOUTUBEFILE    = 'http://'
YOUTUBEFILE    = ADDON.getSetting('YOUTUBEFILE')

#########################################################
# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
#HIDECONTACT    = 'No'
HIDECONTACT    = ADDON.getSetting('HIDECONTACT')
# You can add \n to do line breaks
#CONTACT        = 'Contact us on facebook at\n\nhttp://facebook.com'
CONTACT         = ADDON.getSetting('CONTACT')
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = os.path.join(ART, 'qricon.png')
CONTACTFANART  = 'http://'

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
#AUTOUPDATE    = 'No'
AUTOUPDATE     = ADDON.getSetting('AUTOUPDATE')
# Url to wizard version
#WIZARDFILE     = ''
WIZARDFILE     = ADDON.getSetting('WIZARDFILE')
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
#AUTOINSTALL    = 'Yes'
AUTOINSTALL     = ADDON.getSetting('AUTOINSTALL')
# Addon ID for the repository
#REPOID         = 'repository.aftermath'
REPOID          = ADDON.getSetting('REPOID')
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
#REPOADDONXML   = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/repository.aftermath/addon.xml'
REPOADDONXML    = ADDON.getSetting('REPOADDONXML')
# Addon ID for the repository
ICONREPO        = xbmc.translatePath(os.path.join('special://home/addons', REPOID, 'icon.png'))
# Url to folder zip is located in
#REPOZIPURL     = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/repository.aftermath/'
REPOZIPURL      = ADDON.getSetting('REPOZIPURL')

#########################################################
# Enable/Disable the text file caching with 'Yes' or 'No' and age being how often it rechecks in minutes
#CACHETEXT     = 'Yes'
CACHETEXT      = ADDON.getSetting('CACHETEXT')
#CACHEAGE      = 30
CACHEAGE       = ADDON.getSetting('CACHEAGE') 
CACHEAGE       = int(float(CACHEAGE)) if CACHEAGE.isdigit() else 30
# Whitelist addons to save when wiping 
EXCLUDES1 = ADDON.getSetting('EXCLUDES1')
EXCLUDES2 = ADDON.getSetting('EXCLUDES2')
EXCLUDES3 = ADDON.getSetting('EXCLUDES3')
EXCLUDES4 = ADDON.getSetting('EXCLUDES4')
EXCLUDES5 = ADDON.getSetting('EXCLUDES5')
EXCLUDES6 = ADDON.getSetting('EXCLUDES6')
EXCLUDES7 = ADDON.getSetting('EXCLUDES7')
EXCLUDES8 = ADDON.getSetting('EXCLUDES8')
EXCLUDES  = [ADDON_ID,REPOID,EXCLUDES1,EXCLUDES2,EXCLUDES3,EXCLUDES4,EXCLUDES5,EXCLUDES6,EXCLUDES7,EXCLUDES8]
# Default addons 
DEFAULTPLUGINS = ['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
#ENABLE           = 'Yes'
ENABLE            = ADDON.getSetting('ENABLE')
# Url to notification file
#NOTIFICATION     = 'http://cb.srfx.in/notify.txt'
NOTIFICATION      = ADDON.getSetting('NOTIFICATION')

#########################################################

# dependancies
MODURL                     = 'http://mirrors.kodi.tv/addons/krypton/'
# dependancies fallback
if KODIV >= 17.0: MODURL2  = 'http://mirrors.kodi.tv/addons/krypton/'
else:             MODURL2  = 'http://mirrors.kodi.tv/addons/jarvis/'

spmcurl1        = 'https://github.com/koying/SPMC/releases'
kodiurl1        = 'http://mirrors.kodi.tv/releases/android/arm/'
kodiurl2        = 'http://mirrors.kodi.tv/releases/android/arm/old/'


#########################################################
### THEMING MENU ITEMS ##################################
#########################################################

####################################
## Colors 
####################################
SPACER             = ADDON.getSetting('SPACER') # custom
HIDESPACERS        = 'Yes'
COLORTXT           = 'white'                                                    # COLOR2
COLORSPACER        = 'darkgrey'
COLORSIZES         = 'lightgreen'
COLORWARNING       = 'orange'
COLORONLINE        = 'steelblue'
COLOROFFLINE       = 'cadetblue'
COLORON            = 'limegreen'
COLOROFF           = 'red'
#
COLORMENU          = 'goldenrod'
COLORSUBMENU       = 'darkgreen'
COLORSUBTITLE      = 'grey'
COLORDESC          = 'cadetblue'
#
COLORHEADER        = 'gold'                                                     # COLOR1
COLORHEADERTXT     = 'white'                                                    # COLOR2 (can be 2 wip)
COLORHEADERINFO    = 'lightblue'                                                # COLOR3
#
#COLOR1             = 'purple'
#COLOR1            = 'dodgerblue'
#COLOR2             = 'pink'
#COLOR3             = 'brown'
#COLOR1             = 'skyblue'
#COLOR1            = 'dodgerblue'
#COLOR2             = 'white'
#COLOR3             = 'gold'

####################################
## Icons
####################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'maintenance.png')
ICONAPK        = os.path.join(ART, 'apkinstaller.png')
ICONADDONS     = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE    = os.path.join(ART, 'youtube.png')
ICONSAVE       = os.path.join(ART, 'savedata.png')
ICONTRAKT      = os.path.join(ART, 'keeptrakt.png')
ICONREAL       = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN      = os.path.join(ART, 'keeplogin.png')
ICONCONTACT    = os.path.join(ART, 'information.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
# custom
ICONCLEAN      = os.path.join(ART, 'clean.png')
ICONCLOSE      = os.path.join(ART, 'close.png')
ICONDELETE     = os.path.join(ART, 'delete.png')
ICONBACKUP     = os.path.join(ART, 'backup.png')
ICONLOG        = os.path.join(ART, 'log.png')
ICONXML        = os.path.join(ART, 'xml.png')
ICONVIDEO      = os.path.join(ART, 'video.png')
ICONGITHUB     = os.path.join(ART, 'github.png')
ICONURL        = os.path.join(ART, 'url.png')
ICONINFO       = os.path.join(ART, 'information.png')
ICONOS         = os.path.join(ART, 'os.png')

####################################
## Spacers - special unicode characters
# -  decode here to keep default.py clean
# -- these arent needed just cool
####################################
#
## shade
SHADEFULL       = '█' # Full block
SHADEDARK       = '▓' # Dark shade
SHADEMEDIUM     = '▒' # Medium shade
SHADELIGHT      = '░' # Light shade
SPACERSHADE     = '█▓▒░' # all 4 shades
#
## direction
SPACERUP        = '▲' # Black up triangle U+25B2
SPACERDOWN      = '▼' # Black d triangle U+25BC
SPACERRIGHT     = '►' # Black right p U+25BA
SPACERLEFT      = '◄' # Black left p U+25C4
#
## big
SPACERSQUARE  = '■' #Black square U+25A0-------------------------best
SPACERSQUAREL = '▪' #Black s square U+25AA
SPACERCIRCLE  = '●' #Black circle U+25CF-------------------------best
SPACERCIRCLEL = '•' #Black circle small U+2022
SPACERSTAR    = '☼' #star
SPACERCICLELINE='Ѳ' #Cyrillic Capital circle with line through it
SPACERDASH    = '▬' #Black rec U+25AC
SPACERRIGHTWARD='»' #rightwards bullet
SPACERNO      = 'ӿ' #Cyrillic Small Letter
SPACERYES     = '√' #seperator checkmark
SPACERSEP     = '⁞' #seperator bullet
SPACERTRIANGLE= '∆' #seperator triangle
#
#SPACERCIRCLEW = '○' #White circle U+25CB    -hard to see
#SPACERCIRCLEWL= '◦' #White bullet U+25E6    -hard to see
#SPACERSQUAREWL= '▫' #White s square U+25AB  -hard to see
#SPACERCIRCLESMALLEST = '∙' #smallest bullet U+2219 -hard to see
#
#SPACERCOPYRIGHT = '©' #copyright
#SPACERHAPPY     = '☺' #happy face clear
#SPACERHAPPYW    = '☻' #happy face white
#

# Default failsafes
#THEME1              = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR2+']'+SPACER+'[/COLOR])[/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR][/I]' # Default Menu global
#THEME2              = '[COLOR '+COLOR2+']%s[/COLOR]'  # Default global white   regular
#THEME3              = '[COLOR '+COLOR1+']%s[/COLOR]'  # Default global skyblue alternate
#THEMEBUILDNAME     = '[COLOR '+COLORHEADERINFO+']%s[/COLOR]'
#THEME4              = '[COLOR '+COLOR1+']Build:[/COLOR]  '+SPACER+'  [COLOR '+COLOR2+']%s[/COLOR]' # Default global
#THEME5              = '[COLOR '+COLOR1+']Theme:[/COLOR]  '+SPACER+'  [COLOR '+COLOR2+']%s[/COLOR]' # Default global
####################################
## Themes - Special
####################################
# online flags
ONLINEFLAG       = '[COLOR '+COLORONLINE+ '](URL)[/COLOR]'
OFFLINEFLAG      = '[COLOR '+COLOROFFLINE+'](TXT)[/COLOR] '
OFFLINEXMLFLAG   = '[COLOR '+COLOROFFLINE+'](XML)[/COLOR]'
#
## on off toggle
SPACEROFF        = 'Ѳ'  # Inverse bullet U+25D8  - off # 2 spaces character
SPACERON         = '√ ' #Inverse circle U+25D9   - on  # 2 spaces cheat
#off              = '[COLOR '+COLOROFF+']'+SPACERRIGHT+SPACEROFF+'[/COLOR]'# 3 spaces
#on               = '[COLOR '+COLORON +']'+SPACERRIGHT+SPACERON+ '[/COLOR]'# 3 spaces
#offitem          = '[COLOR '+COLOROFF+']'+SPACERDOWN+SPACEROFF+'[/COLOR]' # 3 spaces
#onitem           = '[COLOR '+COLORON +']'+SPACERDOWN+SPACERON+ '[/COLOR]' # 3 spaces
off              = '[COLOR '+COLOROFF+']'+SPACEROFF+SPACERRIGHT+'[/COLOR]'# 3 spaces
on               = '[COLOR '+COLORON +']'+SPACERON+SPACERRIGHT+ '[/COLOR]'# 3 spaces
offitem          = '[COLOR '+COLOROFF+']'+SPACEROFF+SPACERDOWN+'[/COLOR]' # 3 spaces
onitem           = '[COLOR '+COLORON +']'+SPACERON+SPACERDOWN+ '[/COLOR]' # 3 spaces

# special themes
THEMESPACER         = '[COLOR '+COLORSPACER +']%s[/COLOR]'
THEMEWARNING        = '[B][I][COLOR '+COLORWARNING+']WARNING[/COLOR][/I][/B]   [COLOR '+COLORDESC+']'+SPACER+'[/COLOR]   [COLOR '+COLORSUBTITLE+']%s[/COLOR]'

# custom theme header items   / %s is the menu item and is required
#THEMEDEFAULT        = '[I][COLOR '   +COLORTXT+']%s[/COLOR][/I]'
THEMEDEFAULT        = '[COLOR '      +COLORTXT+']%s[/COLOR]'
THEMEDEFAULTI       = '[I][COLOR '   +COLORTXT+']%s[/COLOR][/I]'
THEMEDEFAULTB       = '[B][I][COLOR '+COLORTXT+']%s[/COLOR][/I][/B]'

#THEMEMENU          = '[COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]   [COLOR '+COLORTXT+']%s[/COLOR]'  #■   %s
THEMEMENU           = '[COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]   [COLOR '+COLORTXT+']%s[/COLOR]'  #■   %s
THEMEMENUB          = '[COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]   [B][COLOR '+COLORTXT+']%s[/COLOR][/B]'  #■   %s
#THEMETOGGLE         = '[COLOR '+COLORTXT+ ']%s[/COLOR]   [COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]   [I][COLOR '+COLORSPACER+'](Toggle)[/COLOR][/I]'    #√▼  %s   (Toggle)
THEMETOGGLE         = '[COLOR '+COLORTXT+ ']%s[/COLOR]   [COLOR '+COLORMENU+']'+SPACERSQUARE+SPACERSQUARE+SPACERSQUARE+'[/COLOR]   [I][COLOR '+COLORSPACER+'](Toggle)[/COLOR][/I]'    #√▼  %s   (Toggle)
THEMEMENUITEM       = '[COLOR '+COLORSUBMENU+']'+SPACER+SPACERRIGHTWARD+'[/COLOR]    [COLOR '+COLORTXT+']%s[/COLOR]' 

THEMESUBMENU        = '[COLOR '+COLORON+']'+SPACER+'[/COLOR][COLOR '+COLORSUBMENU+']'+SPACER+'[/COLOR][COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]    [COLOR '+COLORTXT+']%s[/COLOR]'  #☼●»
THEMESUBMENUB       = '[COLOR '+COLORON+']'+SPACER+'[/COLOR][COLOR '+COLORSUBMENU+']'+SPACER+'[/COLOR][COLOR '+COLORMENU+']'+SPACERSQUARE+'[/COLOR]    [B][COLOR '+COLORTXT+']%s[/COLOR][/B]'  #☼●»
THEMESUBMENUITEM    = '[COLOR '+COLORON+']'+SPACER+'[/COLOR][COLOR '+COLORSUBMENU+']'+SPACER+SPACERRIGHTWARD+'[/COLOR]    [COLOR '+COLORTXT+']%s[/COLOR]'  #☼●»
THEMESUBMENUITEMB   = '[COLOR '+COLORON+']'+SPACER+'[/COLOR][COLOR '+COLORSUBMENU+']'+SPACER+SPACERRIGHTWARD+'[/COLOR]    [B][COLOR '+COLORTXT+']%s[/COLOR][/B]'  #☼●»

THEMECURRENTBUILD  = '[COLOR '+COLORHEADER+']Build:[/COLOR]  [COLOR '+COLORHEADERINFO+']%s[/COLOR]'
THEMECURRENTSKIN   = '[COLOR '+COLORHEADER+']Theme:[/COLOR]  [COLOR '+COLORHEADERINFO+']%s[/COLOR]'


'''
import os, xbmc, xbmcaddon
#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
EXCLUDES       = [ADDON_ID, 'repository.aftermath']
# Enable/Disable the text file caching with 'Yes' or 'No' and age being how often it rechecks in minutes
CACHETEXT      = 'Yes'
CACHEAGE       = 30
# Text File with build info in it.
BUILDFILE      = 'http://cb.srfx.in/builds.txt'
# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.  Leave as 'http://' to ignore
APKFILE        = 'http://cb.srfx.in/apks.txt'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = ''
YOUTUBEFILE    = 'http://'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = 'http://cb.srfx.in/addons.txt'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = 'http://aftermathwizard.net/testtext/advanced.txt'

# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'Maintenance.png')
ICONAPK        = os.path.join(ART, 'apkinstaller.png')
ICONADDONS     = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE    = 'http://'
ICONSAVE       = os.path.join(ART, 'savedata.png')
ICONTRAKT      = os.path.join(ART, 'keeptrakt.png')
ICONREAL       = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN      = os.path.join(ART, 'keeplogin.png')
ICONCONTACT    = os.path.join(ART, 'information.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '='

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'dodgerblue'
COLOR2         = 'white'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B][I]([COLOR '+COLOR2+']Aftermath[/COLOR])[/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR][/I]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = 'Thank you for choosing Aftermath Wizard.\n\nContact us on facebook at http://facebook.com'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = os.path.join(ART, 'qricon.png')
CONTACTFANART  = 'http://'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'No'
# Url to wizard version
WIZARDFILE     = ''
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'Yes'
# Addon ID for the repository
REPOID         = 'repository.aftermath'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/repository.aftermath/addon.xml'
# Url to folder zip is located in
REPOZIPURL     = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/repository.aftermath/'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'http://cb.srfx.in/notify.txt'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
# Font size of header
FONTHEADER     = 'Font14'
HEADERMESSAGE  = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Font for Notification Window
FONTSETTINGS   = 'Font13'
# Background for Notification Window
BACKGROUND     = 'http://cb.srfx.in/img/fanart.jpg'
'''
