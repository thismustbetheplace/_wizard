# -*- coding: utf-8 -*-
import os, xbmc, xbmcaddon, xbmcgui, xbmcvfs
try: from uservar import ADDON_ID
except ImportError: ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON              = xbmcaddon.Addon(ADDON_ID)
ADDON_DATA         = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDON_ID))
ADDONPATH          = xbmc.translatePath(os.path.join('special://home/addons', ADDON_ID))
EXTRAPATH          = xbmc.translatePath(os.path.join(ADDON.getSetting('EXTRAPATH')))
DATAPATH           = xbmc.translatePath(os.path.join(ADDON.getSetting('DATAPATH')))
ART                = xbmc.translatePath(os.path.join(ADDONPATH, 'resources', 'media'))
ICON               = xbmc.translatePath(os.path.join(ART, 'icon.png'))

def fallback_files():
    ADDON.setSetting('firstrun', 'false')
    _notify('Fallback Files','Copy txt Files', ICON)
    progress = xbmcgui.DialogProgressBG()
    progress.create('Failsafes','Parsing Fallbacks...')
    
    ############################################################################
    ###### add custom settings to settings.xml
    ############################################################################
    setsettings = True
    if setsettings == True:
        ################################################################################################################################################
        ######  Set the main txt file path defaults  (online and off)  #################################################################################
        ################################################################################################################################################
        #_notify('Fallback Files','txt Paths', ICON)

        ########################################################################
        progress.update(5, 'Failsafes','Set Wizard Defaults')
        ###### main repo
        setS('ADDONTITLE',    'Wizard XYZ')
        setS('ADDONID',       'plugin.program.xyzwizard')
        setS('REPOID',        'repository._xyz')
        setS('repo.url',      'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/repo/')
        ########################################################################
        ###### notify online welcome txt and blacklist
        setS('NOTIFICATION',   'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/notify.txt')
        #setS('NOTIFICATION',  'http://aftermathwizard.net/repo/wizard/notify.txt')
        ###### notify offline
        #copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'notify.txt')),      xbmc.translatePath(os.path.join(DATAPATH,'notify.txt')))
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'blacklist.txt')),   xbmc.translatePath(os.path.join(DATAPATH,'blacklist.txt')))
        setS('NOTIFICATIONT',   xbmc.translatePath(os.path.join(EXTRAPATH,'notify.txt')))
        setS('BLACKLIST',       xbmc.translatePath(os.path.join(DATAPATH,'blacklist.txt')))
        ########################################################################
        ######  Whitelist Exclude files from Wipe  (This addon and main Repo already included)
        setS('EXCLUDES1',   'resource.images.studios.white')  # accent problem with foreign letter.  futures unicode blah blah blah causes errors in the main py so im stumped.
        ########################################################################
        ######  WIP Blacklist files for Wipe  (Screw these guys)
        #setS('BLACKLIST1',   'plugin.program.xbmchub.notifications')
        ########################################################################
        
        
        ########################################################################
        ###### advanced online
        #setS('ADVANCEDFILE',  'http://aftermathwizard.net/repo/wizard/advanced.txt')
        #copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'advanced.txt')),    xbmc.translatePath(os.path.join(DATAPATH,'advanced.txt')))
        #setS('ADVANCEDFILE',  'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_advanced.txt')
        ########################################################################
        progress.update(10, 'Failsafes','Addon Paths Online')
        ###### addons txt online 1- 10
        #setS('ADDONNAME1',    'addons2.txt   (aftermathwizard Example)');setS('ADDONFILE',   'http://aftermathwizard.net/repo/wizard/addons2.txt')
        setS('ADDONNAME',     '_addons.txt');                             setS('ADDONFILE',   'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_addons.txt')
        setS('ADDONNAME1',    '_addons2.txt');                            setS('ADDONFILE1',  'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_addons2.txt')
        setS('ADDONNAME2',    '_addons_Top10.txt');                       setS('ADDONFILE2',  'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_addons_Top10.txt')
        setS('ADDONNAME100',  'addons.txt');                              setS('ADDONFILE00', 'http://aftermathwizard.net/repo/wizard/addons2.txt')
        ########################################################################
        progress.update(15, 'Failsafes','Addon Paths Oflline')
        ########################################################################
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'addons.txt')),       xbmc.translatePath(os.path.join(DATAPATH,'addons.txt')))
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'addons2.txt')),      xbmc.translatePath(os.path.join(DATAPATH,'addons2.txt')))
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'addons_Top10.txt')), xbmc.translatePath(os.path.join(DATAPATH,'addons_Top10.txt')))
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'addons_test.txt')),  xbmc.translatePath(os.path.join(DATAPATH,'addons_test.txt')))
        ###### addons txt offline 1- 10
        setS('ADDONTNAME1',   'addons.txt');                              setS('ADDONTFILE1',  xbmc.translatePath(os.path.join(DATAPATH,'addons.txt')))
        setS('ADDONTNAME2',   'addons2.txt');                             setS('ADDONTFILE2',  xbmc.translatePath(os.path.join(DATAPATH,'addons2.txt')))
        setS('ADDONTNAME3',   'addons_Top10.txt');                        setS('ADDONTFILE3',  xbmc.translatePath(os.path.join(DATAPATH,'addons_Top10.txt')))
        setS('ADDONTNAME4',   'addons_test.txt');                         setS('ADDONTFILE4',  xbmc.translatePath(os.path.join(DATAPATH,'addons_test.txt')))
        ########################################################################
        progress.update(20, 'Failsafes','Addon Paths xml')
        ########################################################################
        #_notify('Fallback Files','ADDONS', os.path.join(ART, 'addons.png'))
        ###### addons xml 1- 100
        ## section
        setS('ADDONXSECT1', 'true'); setS('ENABLEADDONX1', 'true'); setS('ADDONXNAME1','Firestickplusman'); setS('ADDONXFILE1','http://firestickplusmancomlu.com/wizard/Advanced%20wizard/addons.txt'); setS('ADDONXICONURL1','http://')
        setS('ADDONXPLUGIN1', 'section'); setS('ADDONXREPO1', 'none'); setS('ADDONXREPOXML1', 'http://'); setS('ADDONXREPOURL1', 'http://')
        #
        setS('ADDONXSECT20', 'false'); setS('ENABLEADDONX20', 'true'); setS('ADDONXNAME20','script.tvguide.fullscreen 17 Krypton'); setS('ADDONXFILE20','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/krypton/script.tvguide.fullscreen/'); setS('ADDONXICONURL20','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/krypton/script.tvguide.fullscreen/icon.png')
        setS('ADDONXPLUGIN20', 'script.tvguide.fullscreen'); setS('ADDONXREPO20', 'repository.primaeval'); setS('ADDONXREPOXML20', 'https://github.com/primaeval/repository.primaeval/raw/master/primaeval-addons.xml'); setS('ADDONXREPOURL20', 'https://github.com/primaeval/repository.primaeval/raw/master/zips/repository.primaeval/') 
        #
        setS('ADDONXSECT21', 'false'); setS('ENABLEADDONX21', 'true'); setS('ADDONXNAME21','script.tvguide.fullscreen 16 Jarvis'); setS('ADDONXFILE21','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/jarvis/script.tvguide.fullscreen/'); setS('ADDONXICONURL21','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/jarvis/script.tvguide.fullscreen/icon.png')
        setS('ADDONXPLUGIN21', 'script.tvguide.fullscreen'); setS('ADDONXREPO21', 'repository.primaeval'); setS('ADDONXREPOXML21', 'https://github.com/primaeval/repository.primaeval/raw/master/primaeval-addons.xml'); setS('ADDONXREPOURL21', 'https://github.com/primaeval/repository.primaeval/raw/master/zips/repository.primaeval/') 
        #
        setS('ADDONXSECT22', 'false'); setS('ENABLEADDONX22', 'true'); setS('ADDONXNAME22','Sports Fixtures'); setS('ADDONXFILE22','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/jarvis/plugin.program.fixtures/'); setS('ADDONXICONURL22','https://raw.githubusercontent.com/primaeval/repository.primaeval/master/jarvis/plugin.program.fixtures/icon.png')
        setS('ADDONXPLUGIN22', 'script.tvguide.fullscreen'); setS('ADDONXREPO22', 'repository.primaeval'); setS('ADDONXREPOXML22', 'https://github.com/primaeval/repository.primaeval/raw/master/primaeval-addons.xml'); setS('ADDONXREPOURL22', 'https://github.com/primaeval/repository.primaeval/raw/master/zips/repository.primaeval/') 
        ########################################################################
        
        
        
        
        ########################################################################
        progress.update(25, 'Failsafes','Apk Online')
        ########################################################################
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'apks.txt')),        xbmc.translatePath(os.path.join(DATAPATH,'apks.txt')))
        ###### apk online 1- 10
        #setS('APKNAME1',      'apk.txt  (aftermathwizard Example)');     setS('APKFILE',      'http://aftermathwizard.net/repo/wizard/apk.txt')
        setS('APKNAME',           '_apks.txt');                           setS('APKFILE',      'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/apks.txt')
        setS('APKNAME1',          'Latest Official Kodi Apk');            setS('APKFILE1',     'https://archive.org/download/LatestKodi_201707/latest%20kodi.txt')
        setS('APKNAME2',          'Merlin Wizard');                       setS('APKFILE2',     'http://mwiz.uk/data/apks.txt')
        setS('APKNAME3',          'Genius Tv');                           setS('APKFILE3',     'http://alluregrill.com/apk/gen.txt')
        setS('APKNAME4',          'Zerotolerance');                       setS('APKFILE4',     'http://builds.zerotolerance.gq/xmls/texts/apks.txt')
        setS('APKNAME5',          'Supreme Builds');                      setS('APKFILE5',     'https://wizard.supremebuilds.com/texts/apks.txt')
        setS('APKNAME6',          'Firestickplus');                       setS('APKFILE6',     'http://firestickplusmancomlu.com/wizard/Advanced%20wizard/apk.txt')
        setS('APKNAME7',          'Ezzerman');                            setS('APKFILE7',     'http://www.miniaturelife.org/APKFiles/apk.txt')
        setS('APKNAME8',          'MaverickTV');                          setS('APKFILE8',     'http://mavericktv.net/wiz/apk.txt')
        setS('APKNAME9',          'Zerotolerance EMUs');                  setS('APKFILE9',     'http://builds.zerotolerance.gq/xmls/texts/emu.txt')
        ########################################################################
        progress.update(30, 'Failsafes','Apk Offline')
        ########################################################################
        ###### apk offline 1- 10
        setS('APKTNAME1',     'apks.txt');                                setS('APKTFILE1',     xbmc.translatePath(os.path.join(DATAPATH,'apks.txt')))
        ########################################################################
        progress.update(35, 'Failsafes','Apk xml')
        #_notify('Fallback Files','APKS', os.path.join(ART, 'android.png'))
        ########################################################################
        ###### apks direct links
        setS('APKXSECT1','false'); setS('ENABLEAPKX1','true');  setS('APKXNAME1',   'IPTV Subs  (Needs subscription)');     setS('APKXFILE1',  'https://iptvsubs.is/android/iptvsubs.apk')
        setS('APKXSECT2','false'); setS('ENABLEAPKX2','true');  setS('APKXNAME2',   'VaderTV    (Needs subscription)');     setS('APKXFILE2',  'http://vaderstream.com/resources/vaders-v1.0.2.apk')
        setS('APKXSECT3','false'); setS('ENABLEAPKX3','true');  setS('APKXNAME3',   'USTV Now   (Needs free subscription)');setS('APKXFILE3',  'http://bit.ly/2rOTS04')
        setS('APKXSECT4','false'); setS('ENABLEAPKX4','true');  setS('APKXNAME4',   'MOBDRO');                              setS('APKXFILE4',  'https://www.mobdro.to/mobdro.apk')
        setS('APKXSECT5','false'); setS('ENABLEAPKX5','true');  setS('APKXNAME5',   'ShowBox');                             setS('APKXFILE5',  'http://showboxappdownloads.com/wp-content/uploads/2017/06/Showbox%204.920.apk')
        setS('APKXSECT6','false'); setS('ENABLEAPKX6','true');  setS('APKXNAME6',   'Pluto TV');                            setS('APKXFILE6',  'http://bit.ly/2t83wzB')
        setS('APKXSECT7','false'); setS('ENABLEAPKX7','true');  setS('APKXNAME7',   'NBC Sports Live Extra');               setS('APKXFILE7',  'https://appraw.com/dl/4pHQqCxVT7')


        ########################################################################
        #_notify('Fallback Files','Builds', os.path.join(ART, 'builds.png'))
        progress.update(40, 'Failsafes','Build Paths')
        ########################################################################
        ######  build txt menus
        setS('THIRDNAME1',     'Zerotolerance');                          setS('THIRDURL1',   'http://builds.zerotolerance.gq/xmls/texts/builds.txt')
        setS('THIRDNAME2',     'Firestickplus');                          setS('THIRDURL2',   'http://firestickplusmancomlu.com/wizard/Advanced%20wizard/autobuilds.txt')
        setS('THIRDNAME3',     'Steventv Wizard');                        setS('THIRDURL3',   'http://www.steventvwizard.xyz/build/builds12.txt')
        setS('THIRDNAME4',     'MaverickTV');                             setS('THIRDURL4',   'http://mavericktv.net/wiz/wizard.txt')
        setS('THIRDNAME5',     'Supremebuilds');                          setS('THIRDURL5',   'https://wizard.supremebuilds.com/texts/builds.txt')
        setS('THIRDNAME6',     'Zerotolerance Emulators');                setS('THIRDURL6',   'http://builds.zerotolerance.gq/xmls/texts/rompacks.txt')
        setS('THIRDNAME7',     'Brettusbuilds Community');                setS('THIRDURL7',   'http://brettusbuilds.com/Brettus%20Builds/community.txt')
        setS('THIRDNAME8',     'Brettusbuilds Brett');                    setS('THIRDURL8',   'http://brettusbuilds.com/Brettus%20Builds/brett.txt')
        setS('THIRDNAME9',     'Brettusbuilds BrettusAdmin');             setS('THIRDURL9',   'http://brettusbuilds.com/Brettus%20Builds/BrettusAdmin.txt')
        ########################################################################
        progress.update(45, 'Failsafes','Build Direct Paths')
        ########################################################################
        ###### build zips (straight links)
        setS('BUILDNAME1',     'Video Addons    (Mini Zip Of Addons)');   setS('BUILDURL1', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/addons_video.zip')
        setS('BUILDNAME2',     'Program Addons  (Mini Zip Of Addons)');   setS('BUILDURL2', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/addons_program.zip')
        setS('BUILDNAME3',     'Audio Addons    (Mini Zip Of Addons)');   setS('BUILDURL3', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/addons_audio.zip')
        setS('BUILDNAME4',     'Repos Addons    (Mini Zip Of Addons)');   setS('BUILDURL4', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/addons_repo.zip')
        ########################################################################
        progress.update(50, 'Failsafes','Zip Paths')
        ########################################################################
        ###### zips builtin paths
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'zips.txt')),        xbmc.translatePath(os.path.join(DATAPATH,'zips.txt')))
        setS('zips.url',      'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/')
        ########################################################################
        progress.update(55, 'Failsafes','Theme Paths')
        ########################################################################
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'theme.txt')),       xbmc.translatePath(os.path.join(DATAPATH,'theme.txt')))
        ###### theme zips (straight links)
        setS('THEMENAME1',     'Estuary 18 Leia Tweaked Theme');          setS('THEMEURL1', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/18_theme.zip')
        setS('THEMENAME2',     'Estuary 17 Krypton Tweaked Theme');       setS('THEMEURL2', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/17_theme.zip')
        setS('THEMENAME3',     'Estuary 16 Jarvis Tweaked Theme');        setS('THEMEURL3', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/16_theme.zip')
        #setS('THEMENAME4',    'Confluence 17 Krypton');                  setS('THEMEURL4', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/17_theme.zip')
        #setS('THEMENAME5',    'Confluence 16 Jarvis Tweaked');           setS('THEMEURL5', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/16_theme.zip')
        ########################################################################
        progress.update(60, 'Failsafes','Build txt')
        ########################################################################
        ###### build txt online
        #setS('BUILDFILE',     'http://aftermathwizard.net/repo/wizard/autobuilds.txt')
        setS('BUILDFILE',     'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/zips.txt')
        #setS('BUILDFILE',    'http://aftermathwizard.net/repo/wizard/autobuilds.txt')
        #setS('THEMEFILE',    'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_notify.txt')
        #setS('THEMEFILE1',   'http://aftermathwizard.net/repo/wizard/test1themes.txt')
        ########################################################################
        progress.update(65, 'Failsafes','Rompack txt')
        ########################################################################
        ###### rompack txts
        setS('ROMPACKFILE1',  'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/rompacks.txt')
        #setS('ROMPACKFILE2',  'http://builds.zerotolerance.gq/xmls/texts/emu.txt')
        # offline
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'rompacks.txt')),    xbmc.translatePath(os.path.join(DATAPATH,'rompacks.txt')))
        setS('ROMPACKTFILE1',  xbmc.translatePath(os.path.join(DATAPATH,'rompacks.txt')))
        ########################################################################
        progress.update(70, 'Failsafes','M3U')
        ########################################################################
        ######  m3u direct urls
        setS('M3UNAME1',     'fluxustv');        setS('M3UENABLE1', 'true');    setS('M3UURL1',   'https://raw.githubusercontent.com/fluxustv/IPTV/master/list.m3u')
        setS('M3UNAME2',     'CrachTvListPro');  setS('M3UENABLE2', 'true');    setS('M3UURL2',   'https://raw.githubusercontent.com/Crach1015/CrachTvListPro/master/LIstas/DEPORTES.M3U')
        ###### m3u offline file
        #setS('M3UTNAME1',     'Radio');         setS('M3UTENABLE1', 'true');    setS('M3UTURL1',  'special://home/addons/plugin.program/resources/data/m3u/Radio.m3u')
        setS('M3UTNAME1',      'Radio');         setS('M3UTENABLE1', 'true');     setS('M3UTURL1',   xbmc.translatePath(os.path.join(EXTRAPATH, 'm3u', 'Radio.m3u')))
        ########################################################################
        progress.update(75, 'Failsafes','Youtube Online txt')
        ########################################################################
        ###### youtube online
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'youtube.txt')),     xbmc.translatePath(os.path.join(DATAPATH,'youtube.txt')))
        #setS('YOUTUBEFILE',   'http://aftermathwizard.net/repo/wizard/youtube2.txt')
        setS('YOUTUBEFILE',   'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/youtube.txt')
        ########################################################################
        progress.update(80, 'Failsafes','Youtube Offline txt')
        ########################################################################
        ###### youtube offline
        #setS('YOUTUBETFILE', 'special://home/userdata/addon_data/plugin.program/data/_youtube.txt')
        setS('YOUTUBETFILE',   xbmc.translatePath(os.path.join(DATAPATH,'youtube.txt')))
        ########################################################################
        progress.update(85, 'Failsafes','Youtube Direct')
        ########################################################################
        ######  youtube direct urls
        setS('YOUTUBENAME1',     'Big Buck Bunny (Test 60fps 4K)');       setS('YOUTUBEURL1',   'https://www.youtube.com/watch?v=aqz-KE-bpKQ'); setS('YOUTUBEENABLE1', 'true')
        setS('YOUTUBENAME2',     'How to Install a Kodi Addon');          setS('YOUTUBEURL2',   'https://www.youtube.com/watch?v=83t7aZH-eH0'); setS('YOUTUBEENABLE2', 'true')
        ########################################################################
        progress.update(90, 'Failsafes','Chrome urls')
        ########################################################################
        ######  Chrome launcher direct urls
        setS('CHROMEURL1',   'https://www.google.com/')
        setS('CHROMEURL2',   'https://kodi.tv/')
        setS('CHROMEURL3',   'https://www.reddit.com/r/Addons4Kodi/')
        setS('CHROMEURL4',   'https://kodiapps.com/addons-chart')
        ########################################################################
        progress.update(93, 'Failsafes','Keymap xml')
        ########################################################################
        ###### keymaps online
        #setS('KEYMAPSFILE',   'http://indigo.tvaddons.co/keymaps/customkeys.txt')
        setS('KEYMAPSFILE',   'http://indigo.tvaddons.co/keymaps/customkeys.txt')
        ###### keymaps offline
        copyfile(xbmc.translatePath(os.path.join(EXTRAPATH,'keymap.txt')),      xbmc.translatePath(os.path.join(DATAPATH,'keymap.txt')))
        setS('KEYMAPSTFILE',   xbmc.translatePath(os.path.join(DATAPATH,'keymap.txt'))) 
        ########################################################################
        progress.update(96, 'Failsafes','Playercorefactory xml')
        ########################################################################
        ######  playerfactorycore links (android)
        setS('PLAYERCFNAME1',     'LocalCast');                           setS('PLAYERCFFILE1',   'de.stefanpledl.localcast')
        setS('PLAYERCFNAME2',     'SopCast');                             setS('PLAYERCFFILE2',   'org.sopcast.android')
        setS('PLAYERCFNAME3',     'VLCPlayer');                           setS('PLAYERCFFILE3',   'com.vlcforandroid.vlcdirectprofree')
        setS('PLAYERCFNAME4',     'MXPlayerFree');                        setS('PLAYERCFFILE4',   'com.mxtech.videoplayer.ad')
        setS('PLAYERCFNAME5',     'MXPlayerPro');                         setS('PLAYERCFFILE5',   'com.mxtech.videoplayer.pro')
        setS('PLAYERCFNAME6',     'WondersharePlayer');                   setS('PLAYERCFFILE6',   'com.wondershare.player')
        setS('PLAYERCFNAME7',     'BSPlayerFree');                        setS('PLAYERCFFILE7',   'com.bsplayer.bspandroid.free')
        setS('PLAYERCFNAME8',     'Tiantian Player');                     setS('PLAYERCFFILE8',   'com.tiantian.android.player.app')
        ########################################################################
        progress.update(98, 'Failsafes','RSS')
        ########################################################################
        #_notify('Fallback Files','Extra Paths', ICON)
        ######  rss reed urls
        setS('RSS1',   'http://rarbg.to/rssdd.php?categories=14')
        setS('RSS2',   'http://rarbg.to/rssdd.php?categories=18')
        setS('RSS3',   'http://rss.cnn.com/rss/cnn_latest.rss')
        setS('RSS4',   'http://www.cbsnews.com/feeds/rss/main.rss')
        setS('RSS5',   'http://rss.cnn.com/rss/cnn_showbiz.rss')
        ########################################################################
        
        #### DONE
        ########################################################################
        # set setting to not run again until settings.xml is set to default
        progress.close()
        _notify('Fallback Files','Done!', os.path.join(ADDONPATH, 'icon.png'))
        #xbmc.executebuiltin('Container.Refresh()')
#
# functions #
def getS(name):
    try: return ADDON.getSetting(name)
    except: return False
def setS(name, value):
    try: ADDON.setSetting(name, value)
    except: return False
def copyfile(src, dest, over=False):
    if over == False:
        if os.path.exists(dest): return
        if os.path.exists(src):
            try:    xbmcvfs.copy(src, dest)
            except: pass
    else:
        if os.path.exists(dest): os.remove(dest)
        if os.path.exists(src):
            try:    xbmcvfs.copy(src, dest)
            except: pass
def _notify(header,msg,icon_path,duration=2000, sound=False):
    #xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)
    xbmc.executebuiltin('XBMC.Notification(%s,%s, %s, %s)' % (header, msg, duration, icon_path))
    