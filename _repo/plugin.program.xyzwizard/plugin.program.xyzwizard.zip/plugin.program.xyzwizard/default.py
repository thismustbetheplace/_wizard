# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import os, sys
import glob
import shutil
import urllib2,urllib
import re
import zipfile
import uservar
import fnmatch
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta
from urlparse import urljoin
from resources.lib import extract, downloader, notify, debridit, traktit, loginit, skinSwitch, uploadLog, yt, wizard as wiz
ADDONTITLE       = uservar.ADDONTITLE
ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
addonPath        = xbmc.translatePath(os.path.join('special://home', 'addons', ADDON_ID))
basePath         = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDON_ID))
extrapath        = xbmc.translatePath(os.path.join(addonPath, 'resources', 'data'))
VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
PLAYERCORE       = os.path.join(USERDATA,  'playercorefactory.xml')
RSSFILE          = os.path.join(USERDATA,  'RssFeeds.xml')
SOURCES          = os.path.join(USERDATA,  'sources.xml')
FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
PROFILES         = os.path.join(USERDATA,  'profiles.xml')
GUISETTINGS      = os.path.join(USERDATA,  'guisettings.xml')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
ICON             = os.path.join(ADDONPATH, 'icon.png')
ART              = os.path.join(ADDONPATH, 'resources', 'media')
WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
SKIN             = xbmc.getSkinDir()
BUILDNAME        = wiz.getS('buildname')
DEFAULTSKIN      = wiz.getS('defaultskin')
DEFAULTNAME      = wiz.getS('defaultskinname')
DEFAULTIGNORE    = wiz.getS('defaultskinignore')
BUILDVERSION     = wiz.getS('buildversion')
BUILDTHEME       = wiz.getS('buildtheme')
BUILDLATEST      = wiz.getS('latestversion')
INSTALLMETHOD    = wiz.getS('installmethod')
SHOW15           = wiz.getS('show15')
SHOW16           = wiz.getS('show16')
SHOW17           = wiz.getS('show17')
SHOW18           = wiz.getS('show18')
SHOWADULT        = wiz.getS('adult')
SHOWMAINT        = wiz.getS('showmaint')
AUTOCLEANUP      = wiz.getS('autoclean')
AUTOCACHE        = wiz.getS('clearcache')
AUTOPACKAGES     = wiz.getS('clearpackages')
AUTOTHUMBS       = wiz.getS('clearthumbs')
AUTOFEQ          = wiz.getS('autocleanfeq')
AUTONEXTRUN      = wiz.getS('nextautocleanup')
INCLUDEVIDEO     = wiz.getS('includevideo')
INCLUDEALL       = wiz.getS('includeall')
INCLUDE1CHANNEL  = wiz.getS('include1channel')
INCLUDEALLUC     = wiz.getS('includealluc')
INCLUDEBENNU     = wiz.getS('includebennu')
INCLUDEBOBUNLEASHED = wiz.getS('includebobunleashed')
INCLUDEBUBBLES   = wiz.getS('includebubbles')
INCLUDECOVENANT  = wiz.getS('includecovenant')
INCLUDEELYSIUM   = wiz.getS('includeelysium')
INCLUDEXODUS     = wiz.getS('includeexodus')
INCLUDEGURZIL    = wiz.getS('includegurzil')
INCLUDEICEFILMS  = wiz.getS('includeicefilms')
INCLUDESPECTO    = wiz.getS('includespecto')
INCLUDETINKLEPAD = wiz.getS('includetinklepad')
INCLUDEUGOTTOC   = wiz.getS('includeugottoc')
INCLUDEXXXODUS   = wiz.getS('includexxxodus')
INCLUDESALTS     = wiz.getS('includesalts')
INCLUDEALLUC     = wiz.getS('includealluc')
INCLUDEONECHANNEL= wiz.getS('includeonechannel')
INCLUDEUGOOTTOOC = wiz.getS('includeugottoc')
SEPERATE         = wiz.getS('seperate')
NOTIFY           = wiz.getS('notify')
NOTEID           = wiz.getS('noteid')
NOTEDISMISS      = wiz.getS('notedismiss')
TRAKTSAVE        = wiz.getS('traktlastsave')
REALSAVE         = wiz.getS('debridlastsave')
LOGINSAVE        = wiz.getS('loginlastsave')
KEEPFAVS         = wiz.getS('keepfavourites')
KEEPSOURCES      = wiz.getS('keepsources')
KEEPPROFILES     = wiz.getS('keepprofiles')
KEEPADVANCED     = wiz.getS('keepadvanced')
KEEPREPOS        = wiz.getS('keeprepos')
KEEPSUPER        = wiz.getS('keepsuper')
KEEPWHITELIST    = wiz.getS('keepwhitelist')
KEEPTRAKT        = wiz.getS('keeptrakt')
KEEPREAL         = wiz.getS('keepdebrid')
KEEPLOGIN        = wiz.getS('keeplogin')
LOGINSAVE        = wiz.getS('loginlastsave')
DEVELOPER        = wiz.getS('developer')
THIRDPARTY       = wiz.getS('enable3rd')
THIRD1NAME       = wiz.getS('wizard1name')
THIRD1URL        = wiz.getS('wizard1url')
THIRD2NAME       = wiz.getS('wizard2name')
THIRD2URL        = wiz.getS('wizard2url')
THIRD3NAME       = wiz.getS('wizard3name')
THIRD3URL        = wiz.getS('wizard3url')
THIRD4NAME       = wiz.getS('wizard4name')
THIRD4URL        = wiz.getS('wizard4url')
THIRD5NAME       = wiz.getS('wizard5name')
THIRD5URL        = wiz.getS('wizard5url')
THIRD6NAME       = wiz.getS('wizard6name')
THIRD6URL        = wiz.getS('wizard6url')
THIRD7NAME       = wiz.getS('wizard7name')
THIRD7URL        = wiz.getS('wizard7url')
THIRD8NAME       = wiz.getS('wizard8name')
THIRD8URL        = wiz.getS('wizard8url')
THIRD9NAME       = wiz.getS('wizard9name')
THIRD9URL        = wiz.getS('wizard9url')


BACKUPLOCATION   = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'
MYBUILDS         = os.path.join(BACKUPLOCATION, 'My_Builds', '')
AUTOFEQ          = int(float(AUTOFEQ)) if AUTOFEQ.isdigit() else 0
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
MCNAME           = wiz.mediaCenter()
EXCLUDES         = uservar.EXCLUDES
BLACKLIST        = uservar.BLACKLIST
BLACKLISTFILE    = uservar.BLACKLISTFILE
BUILDFILE        = uservar.BUILDFILE
APKFILE          = uservar.APKFILE
YOUTUBETITLE     = uservar.YOUTUBETITLE
YOUTUBEFILE      = uservar.YOUTUBEFILE
ADDONFILE        = uservar.ADDONFILE
ADVANCEDFILE     = uservar.ADVANCEDFILE
spmcurl1         = uservar.spmcurl1
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
ENABLE           = uservar.ENABLE
HEADERMESSAGE    = uservar.HEADERMESSAGE
AUTOUPDATE       = uservar.AUTOUPDATE
WIZARDFILE       = uservar.WIZARDFILE
HIDECONTACT      = uservar.HIDECONTACT
CONTACT          = uservar.CONTACT
CONTACTICON      = uservar.CONTACTICON if not uservar.CONTACTICON == 'http://' else ICON 
CONTACTFANART    = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
HIDESPACERS      = uservar.HIDESPACERS
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
COLOR3           = uservar.COLOR3
COLOR4           = uservar.COLOR4
COLOR5           = uservar.COLOR5
COLOR6           = uservar.COLOR6
COLOR7           = uservar.COLOR7
COLOR8           = uservar.COLOR8
#
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
THEME4           = uservar.THEME4
THEME5           = uservar.THEME5
THEME6           = uservar.THEME6
THEME7           = uservar.THEME7
THEME8           = uservar.THEME8
THEME9           = uservar.THEME9
THEME10          = uservar.THEME10
#
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON
ICONMAINT        = uservar.ICONMAINT if not uservar.ICONMAINT == 'http://' else ICON
ICONAPK          = uservar.ICONAPK if not uservar.ICONAPK == 'http://' else ICON
ICONADDONS       = uservar.ICONADDONS if not uservar.ICONADDONS == 'http://' else ICON
ICONYOUTUBE      = uservar.ICONYOUTUBE if not uservar.ICONYOUTUBE == 'http://' else ICON
ICONSAVE         = uservar.ICONSAVE if not uservar.ICONSAVE == 'http://' else ICON
ICONTRAKT        = uservar.ICONTRAKT if not uservar.ICONTRAKT == 'http://' else ICON
ICONREAL         = uservar.ICONREAL if not uservar.ICONREAL == 'http://' else ICON
ICONLOGIN        = uservar.ICONLOGIN if not uservar.ICONLOGIN == 'http://' else ICON
ICONCONTACT      = uservar.ICONCONTACT if not uservar.ICONCONTACT == 'http://' else ICON
ICONSETTINGS     = uservar.ICONSETTINGS if not uservar.ICONSETTINGS == 'http://' else ICON
ICONREPO         = uservar.ICONREPO if not uservar.ICONREPO == 'http://' else ICON
ICONRESTORE      = uservar.ICONRESTORE if not uservar.ICONRESTORE == 'http://' else ICON
ICONRESTOREALL   = uservar.ICONRESTOREALL if not uservar.ICONRESTOREALL == 'http://' else ICON
ICONBACKUP       = uservar.ICONBACKUP if not uservar.ICONBACKUP == 'http://' else ICON
ICONDELETE       = uservar.ICONDELETE if not uservar.ICONDELETE == 'http://' else ICON
ICONEMAIL        = uservar.ICONEMAIL if not uservar.ICONEMAIL == 'http://' else ICON
ICONFORCECLOSE   = uservar.ICONFORCECLOSE if not uservar.ICONFORCECLOSE == 'http://' else ICON
ICONFRESHSTART   = uservar.ICONFRESHSTART if not uservar.ICONFRESHSTART == 'http://' else ICON
ICONLOG          = uservar.ICONLOG if not uservar.ICONLOG == 'http://' else ICON
ICONSEARCH       = uservar.ICONSEARCH if not uservar.ICONSEARCH == 'http://' else ICON
ICONXML          = uservar.ICONXML if not uservar.ICONXML == 'http://' else ICON
ICONFTMC         = uservar.ICONFTMC if not uservar.ICONFTMC == 'http://' else ICON
ICONSPMC         = uservar.ICONSPMC if not uservar.ICONSPMC == 'http://' else ICON
ICONCLEAN        = uservar.ICONCLEAN if not uservar.ICONCLEAN == 'http://' else ICON
ICONCLEANALL     = uservar.ICONCLEANALL if not uservar.ICONCLEANALL == 'http://' else ICON
ICONFILE         = uservar.ICONFILE if not uservar.ICONFILE == 'http://' else ICON
ICONFIX          = uservar.ICONFIX if not uservar.ICONFIX == 'http://' else ICON
ICONSKIN         = uservar.ICONSKIN if not uservar.ICONSKIN == 'http://' else ICON
ICONTWEAKS       = uservar.ICONTWEAKS if not uservar.ICONTWEAKS == 'http://' else ICON
ICONZIP          = uservar.ICONZIP if not uservar.ICONZIP == 'http://' else ICON
ICONSPACER       = uservar.ICONSPACER if not uservar.ICONSPACER == 'http://' else ICON
ICONHAPPY        = uservar.ICONHAPPY if not uservar.ICONHAPPY == 'http://' else ICON
ICONHAPPYSAD     = uservar.ICONHAPPYSAD if not uservar.ICONHAPPYSAD == 'http://' else ICON
ICONHAPPYSTONED  = uservar.ICONHAPPYSTONED if not uservar.ICONHAPPYSTONED == 'http://' else ICON
ICONHAPPYEXTRA   = uservar.ICONHAPPYEXTRA if not uservar.ICONHAPPYEXTRA == 'http://' else ICON
ICONHAPPYWHITE   = uservar.ICONHAPPYWHITE if not uservar.ICONHAPPYWHITE == 'http://' else ICON
ICONINFO         = uservar.ICONINFO if not uservar.ICONINFO == 'http://' else ICON
ICONTVGFS        = uservar.ICONTVGFS if not uservar.ICONTVGFS == 'http://' else ICON
ICONINI          = uservar.ICONINI if not uservar.ICONINI == 'http://' else ICON
ICONGITHUB       = uservar.ICONGITHUB if not uservar.ICONGITHUB == 'http://' else ICON
#
LOGFILES         = wiz.LOGFILES
TRAKTID          = traktit.TRAKTID
DEBRIDID         = debridit.DEBRIDID
LOGINID          = loginit.LOGINID
#MODURL          = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
MODURL           = 'http://'
MODURL2          = 'http://mirrors.kodi.tv/addons/jarvis/'
#
INSTALLMETHODS   = ['Always Ask', 'Reload Profile', 'Force Close']
#DEFAULTPLUGINS   = ['metadata.album.universal', 'metadata.artists.universal', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.musicbrainz.org', 'metadata.themoviedb.org', 'metadata.tvdb.com', 'service.xbmc.versioncheck']
DEFAULTPLUGINS   = uservar.DEFAULTPLUGINS

# memory
freemem = xbmc.getInfoLabel('System.FreeMemory')
# find kodi ver
xbmc_version=xbmc.getInfoLabel('System.BuildVersion')
version=float(xbmc_version[:4])
if version >= 18.0 and version <= 18.9: kodi_version = '18'
if version >= 17.0 and version <= 17.9: kodi_version = '17'
if version >= 16.0 and version <= 16.9: kodi_version = '16'
if version >= 15.0 and version <= 15.9: kodi_version = '15'
if version >= 14.0 and version <= 14.9: kodi_version = '14'
# python version
import platform
pythonver = platform.python_version()
# platform version ie windows or android
osinfo = platform.system()+' '+platform.release()


#git installer
#from libs import kodi
#
#Addon Installer
import time
import json
from urllib import FancyURLopener
from resources.lib.installer import kodi
from resources.lib.installer import addon_able
from resources.lib.installer import viewsetter
from resources.lib import requests
REPOID                 = uservar.REPOID
repo_url               = uservar.repo_url
#apks_url               = uservar.apks_url
zips_url               = uservar.zips_url
url_addons_repo        = uservar.url_addons_repo
url_addons_audio       = uservar.url_addons_audio
url_addons_program     = uservar.url_addons_program
url_addons_video       = uservar.url_addons_video
url_addons_iptv        = uservar.url_addons_iptv
url_addons_sub         = uservar.url_addons_sub
url_guisettings_14     = uservar.url_guisettings_14
url_guisettings_15     = uservar.url_guisettings_15
url_guisettings_16     = uservar.url_guisettings_16
url_guisettings_17     = uservar.url_guisettings_17
url_guisettings_18     = uservar.url_guisettings_18
url_theme_14           = uservar.url_theme_14
url_theme_15           = uservar.url_theme_15
url_theme_16           = uservar.url_theme_16
url_theme_17           = uservar.url_theme_17
url_theme_18           = uservar.url_theme_18
#url_addon_data         = uservar.url_addon_data
url_addon_data         = ''
if kodi_version == '18': url_addon_data = uservar.url_guisettings_18
if kodi_version == '17': url_addon_data = uservar.url_guisettings_17
if kodi_version == '16': url_addon_data = uservar.url_guisettings_16

# sources.xml builtin files
sourcesxml1            = uservar.sourcesxml1
sourcesxml2            = uservar.sourcesxml2
sourcesxml3            = uservar.sourcesxml3
# RssFeeds.xml builtin files
rss1                   = uservar.rss1
rss2                   = uservar.rss2
rss3                   = uservar.rss3
rss4                   = uservar.rss4
# playercorefactory.xml builtin files
playercorefactory1     = uservar.playercorefactory1
playercorefactory2     = uservar.playercorefactory2
playercorefactory3     = uservar.playercorefactory3
playercorefactory4     = uservar.playercorefactory4
playercorefactory5     = uservar.playercorefactory5
playercorefactory6     = uservar.playercorefactory6
playercorefactory7     = uservar.playercorefactory7
playercorefactory8     = uservar.playercorefactory8

# sql advancedsettings.xml
sql_host               = uservar.sql_host
sql_user               = uservar.sql_user
sql_pass               = uservar.sql_pass



###########################
###### Main Menu Items ####
###########################
#addDir (display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
#addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
def index():
    # http://www.kammerl.de/ascii/AsciiSignature.php
    # fire_font-s
    #xbmc.log(msg='|  \/  | / \  |_ _|| \| ||_   _| __| \| | / \  | \| | / __| __|', level=xbmc.LOGNOTICE)
    #xbmc.log(msg='| |\/| |/ _ \  | | | .` |  | | | _|| .` |/ _ \ | .` || (__| _| ', level=xbmc.LOGNOTICE)
    #xbmc.log(msg='|_|  |_/_/ \_\|___||_|\_|  |_| |___|_|\_/_/ \_\|_|\_| \___|___|', level=xbmc.LOGNOTICE)
    xbmc.log(msg='##['+ADDON_ID+'] **MAIN MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    #thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
    blacklist_check()
    #addDir ('Install Programs'                                      ,'indexinstallthings'  ,description='Install various Kodi Programs, Addons, Android apks or Kodi itself.'       ,icon=ICONADDONS     ,themeit=THEME1)
    if len(BUILDNAME) > 0:
        version = wiz.checkBuild(BUILDNAME, 'version')
        build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
        if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
        addDir(build,'indexinstallthings', BUILDNAME, themeit=THEME10)
        themefile = wiz.themeCount(BUILDNAME)
        if not themefile == False:
            addFile('Install Programs' if BUILDTHEME == "" else BUILDTHEME, 'theme',  BUILDNAME, themeit=THEME5)
    else: addDir('None', 'indexinstallthings', description='Install Kodi 3rd party addons and builds.', icon=ICONBUILDS,  themeit=THEME10)
    #
    addFile('[COLOR yellow]*[/COLOR]Clean Kodi Files Now  [B][COLOR blue](Cache\Packages\Thumbs)[/COLOR]:[/B]  [COLOR lightgreen][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize) ,'fullclean'  ,description='Clean NOW the Kodi files like Cache\Packages\Thumbs that slow your system down over time.' ,icon=ICONCLEANALL, themeit=THEME3)
    addDir ('Clean Files    [COLOR grey](%s Version: %s)[/COLOR]' % (MCNAME, KODIV)        ,'indexcleaning'       ,description='Clean common Kodi files like Cache\Packages\Thumbs that slow your system down over time.'       ,icon=ICONCLEAN      ,themeit=THEME1)
    addDir ('Maintenance Tools and Fixes'                           ,'maint'               ,description='Various Kodi Maintenance Tools and Fixes'       ,icon=ICONMAINT      ,themeit=THEME1)
    addDir ('Backup \ Restore'                                      ,'indexbackup'         ,description='Backup or Restore a zip file backup of your Kodi system setup and addons'       ,icon=ICONBACKUP     ,themeit=THEME1)
    addDir ('XMLs  (playerfactorycore \\ advancedsettings)'            ,'indexinstallxml'     ,description='Install an XML file like advancedsettings or playercorefactory to increse Kodi performance or features.'       ,icon=ICONXML        ,themeit=THEME1)
    addDir ('Log  (Errors)'                                         ,'indexlog'            ,description='View or upload your Kodi log file to diagnose errors'       ,icon=ICONLOG        ,themeit=THEME1)
    if HIDECONTACT == 'No': addFile('Help With Server and Donate via https://www.paypal.me/name'   ,'contact'     ,description='If you are gullible pay me'      ,icon=ICONCONTACT, themeit=THEME1)
    addDir ('System Info   [COLOR grey](py [B]'+pythonver+'[/B] 2.7.9+ TLS\https)[/COLOR]'  ,'systeminfo'      ,description='View system information like your CPU, free memory and space.'       ,icon=ICONINFO, themeit=THEME1)
    addDir ('Repo [COLOR grey]'+REPOID+'[/COLOR]'                  ,'Repolink'            ,description='Browse the '+REPOID+' Default Repo for Addons and Skins'      ,icon=ICONREPO        ,themeit=THEME3)
    addFile('Settings  [COLOR grey]' +ADDONTITLE+'  ('+ADDON_ID+')[/COLOR]' ,'settings'   ,description='Open the settings for '+ADDON_ID   ,icon=ICONSETTINGS    ,themeit=THEME3)
    #addFile('Force Close Kodi'                                      ,'forceclose'         ,description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly'       ,icon=ICONFORCECLOSE  ,themeit=THEME3)
    #addFile('Fresh Start',  'freshstart',  icon=ICONFRESHSTART, themeit=THEME7)
    setView('files', 'viewType')


###########################
###### Menu Install Programs and addons #
###########################
def index_installthings(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Install Things MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    thirdparty  = 'true' if THIRDPARTY  == 'true' else 'false'
    if AUTOUPDATE == 'Yes':
        if wiz.workingURL(WIZARDFILE) == True:
            ver = wiz.checkWizard('version')
            if ver > VERSION: addFile('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (ADDONTITLE, VERSION, ver), 'wizardupdate',description='Update this addon', themeit=THEME2)
            #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
        #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
    #else: addFile('[COLOR yellow]This Addon:[/COLOR]      %s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME3)
    
    if len(BUILDNAME) > 0:
        version = wiz.checkBuild(BUILDNAME, 'version')
        build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
        if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
        addDir(build,'viewbuild', BUILDNAME, themeit=THEME4)
        themefile = wiz.themeCount(BUILDNAME)
        if not themefile == False:
            addFile('None' if BUILDTHEME == "" else BUILDTHEME, 'theme',  BUILDNAME, themeit=THEME5)
    else: addDir('None', 'builds', description='No build installed wich is generally considered a good thing unless it is constantly updated.', icon=ICONBUILDS,  themeit=THEME4)
    addDir ('Community Builds'  ,'builds', description='3rd Party pre fabricated builds or zips of preset Kodi configurations',  icon=ICONBUILDS,   themeit=THEME1)
    
    addDir ('Restore zip of addons, repos and settings'     ,'indexzipinstaller', description='Choose a zip of addons to restore.  This allows more control than a build.',  icon=ICONZIP,   themeit=THEME1)

    if not ADDONFILE == 'http://': addDir ('Addon And Repo Installer' ,'addons', description='Install Kodi addons directly from their source repositories.  These are the people you owe a beer to.',icon=ICONADDONS, themeit=THEME1)
    addDir ('Android Apk Installer' ,'apk', description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPK, themeit=THEME1)
    #if wiz.platform() == 'android' == 'true': addDir ('Android Apk Installer' ,'apk',description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore', icon=ICONAPK, themeit=THEME1)
    addDir ('Github Search'   ,'githubmain', description='Search the common addon www host Github for addons', icon=ICONGITHUB,   themeit=THEME1)

    addDir ('Addon Fixes'   ,'indexaddonfixes', description='Fix common problems that make you pull your hair out in frustration', icon=ICONADDONS,   themeit=THEME1)
    addFile('Force Close Kodi'                                      ,'forceclose'          ,description='Force Kodi to exit instead of the normal way to force it to retain and custom settings you just applied that may need athis to save properly'       ,icon=ICONFORCECLOSE  ,themeit=THEME3)
    addFile('Fresh Start',                    'freshstart',  description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings',    icon=ICONFRESHSTART, themeit=THEME7)

    #addFile('Third Party Wizards: %s' % thirdparty.replace('true',on).replace('false',off) ,'togglesetting', 'enable3rd', description='Turn on extra 3rd party build paths',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
    '''
    if thirdparty == 'true':
        first = THIRD1NAME if not THIRD1NAME == '' else 'Not Set'
        secon = THIRD2NAME if not THIRD2NAME == '' else 'Not Set'
        third = THIRD3NAME if not THIRD3NAME == '' else 'Not Set'
        fouth = THIRD4NAME if not THIRD4NAME == '' else 'Not Set'
        fifth = THIRD5NAME if not THIRD5NAME == '' else 'Not Set'
        sixth = THIRD6NAME if not THIRD6NAME == '' else 'Not Set'
        seven = THIRD7NAME if not THIRD7NAME == '' else 'Not Set'
        eight = THIRD8NAME if not THIRD8NAME == '' else 'Not Set'
        ninth = THIRD9NAME if not THIRD9NAME == '' else 'Not Set'
        addFile('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]' % (COLOR2, first), 'editthird', '1', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]' % (COLOR2, secon), 'editthird', '2', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]' % (COLOR2, third), 'editthird', '3', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 4: [COLOR %s]%s[/COLOR]' % (COLOR2, fouth), 'editthird', '4', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 5: [COLOR %s]%s[/COLOR]' % (COLOR2, fifth), 'editthird', '5', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 6: [COLOR %s]%s[/COLOR]' % (COLOR2, sixth), 'editthird', '6', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 7: [COLOR %s]%s[/COLOR]' % (COLOR2, seven), 'editthird', '7', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 8: [COLOR %s]%s[/COLOR]' % (COLOR2, eight), 'editthird', '8', icon=ICONBUILDS, themeit=THEME3)
        addFile('Edit Third Party Wizard 9: [COLOR %s]%s[/COLOR]' % (COLOR2, ninth), 'editthird', '9', icon=ICONBUILDS, themeit=THEME3)
    '''
    setView('files', 'viewType')

###########################
###### Menu my zip builds #
###########################
def index_zipinstaller(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Zip addon installer MENU**', level=xbmc.LOGNOTICE)
    addDir ('[B][COLOR green]Full[/COLOR][/B] restore of addons, repos and settings.'   ,'InstallAll',  description='Restore all possible addon zips below', icon=ICONRESTOREALL,   themeit=THEME8)
    addDir ('Repos (Needed for programs and updates)'   ,'ReposInstall',   description='Restore Repositories',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('Video Addons  (Various popular)' ,'videoAddonsInstall',   description='Restore Video Addons',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('IPTV Addons  (LiveTV)'       ,'IPTVAddonsInstall',   description='Restore IPTV Live TV Addons',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('IPTV Paid Addons  (LiveTV)'  ,'IPTVSubbedAddonsInstall',   description='Restore IPTV Live TV Addons that require a password and subscription',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('Program Addons'  ,'programAddonsInstall',  description='Restore Program Addons',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('Audio Addons'  ,'audioAddonsInstall',  description='Restore Music Addons',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('Theme (Skin)'  ,'themeAddonsInstall',  description='Restore the defaul XYZ skin theme',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('Addon_Data (Tweaks addon Settings)'  ,'AddonDataInstall',  description='Restore guisettings and user data settings',  icon=ICONRESTORE,   themeit=THEME8)
    addDir ('[B]Addon Tools[/B]',        'maint', 'addon',  description='Fix or perform maintenence on Addons', icon=ICONADDONS, themeit=THEME1)
    addFile('Force Close Kodi (Exit)',   'forceclose',   description='Shut down Kodi forcefully so that it retains your applied settings properly',    icon=ICONFORCECLOSE, themeit=THEME3)
    addFile('Fresh Start',  'freshstart',  description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings', icon=ICONFRESHSTART, themeit=THEME7)
    setView('files', 'viewType')





###########################
###### Menu addonfixes    #
###########################
def index_addonfixes(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **addonfixes MENU**', level=xbmc.LOGNOTICE)
    if kodi_version == '18': addFile('Enable All Addons (Kodi 18)'                          ,'kodi17fix',       icon=ICONSETTINGS, themeit=THEME3)
    if kodi_version == '18': addDir ('Enable RTMP for Streaming (Kodi 18)'  ,'EnableRTMP',   icon=ICONSETTINGS,   themeit=THEME3)
    if kodi_version == '17': addFile('Enable All Addons (Kodi 17)'                          ,'kodi17fix',       icon=ICONSETTINGS, themeit=THEME3)
    if kodi_version == '17': addDir ('Enable RTMP for Streaming (Kodi 17)'  ,'EnableRTMP',   icon=ICONSETTINGS,   themeit=THEME3)
    addFile('Remove Addons',                  'removeaddons',    icon=ICONDELETE, themeit=THEME3)
    addDir ('Remove Addon Data',              'removeaddondata', icon=ICONDELETE, themeit=THEME3)
    addDir ('Enable/Disable Addons',          'enableaddons',    icon=ICONSETTINGS, themeit=THEME3)
    addFile('Enable/Disable Adult Addons',    'toggleadult',     icon=ICONSETTINGS, themeit=THEME3)
    addFile('Force Update Addons',            'forceupdate',     icon=ICONSETTINGS, themeit=THEME3)
    setView('files', 'viewType')


###########################
###### Menu Clean         #
###########################
def index_cleaning(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Clean MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    autoclean   = 'true' if AUTOCLEANUP    == 'true' else 'false'
    cache       = 'true' if AUTOCACHE      == 'true' else 'false'
    packages    = 'true' if AUTOPACKAGES   == 'true' else 'false'
    thumbs      = 'true' if AUTOTHUMBS     == 'true' else 'false'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    includevid  = 'true' if INCLUDEVIDEO   == 'true' else 'false'
    includeall  = 'true' if INCLUDEALL     == 'true' else 'false'
    if includeall == 'true':
        include1ch = 'true'
        includeall = 'true' 
        includeben = 'true' 
        includebob = 'true'
        includebub = 'true' 
        includecov = 'true' 
        includeely = 'true' 
        includeexo = 'true' 
        includegur = 'true' 
        includeice = 'true' 
        includespe = 'true' 
        includetin = 'true' 
        includeugo = 'true'
        includexxx = 'true' 
        includesal = 'true' 
        includeall = 'true' 
        includeone = 'true' 
        includeugo = 'true' 
    else:
        include1ch = 'true' if INCLUDE1CHANNEL == 'true' else 'false'
        includeall = 'true' if INCLUDEALLUC == 'true' else 'false'
        includeben = 'true' if INCLUDEBENNU  == 'true' else 'false'
        includebob = 'true' if INCLUDEBOBUNLEASHED == 'true' else 'false'
        includebub = 'true' if INCLUDEBUBBLES == 'true' else 'false'
        includecov = 'true' if INCLUDECOVENANT == 'true' else 'false'
        includeely = 'true' if INCLUDEELYSIUM   == 'true' else 'false'
        includeexo = 'true' if INCLUDEXODUS == 'true' else 'false'
        includegur = 'true' if INCLUDEGURZIL == 'true' else 'false'
        includeice = 'true' if INCLUDEICEFILMS == 'true' else 'false'
        includespe = 'true' if INCLUDESPECTO == 'true' else 'false'
        includetin = 'true' if INCLUDETINKLEPAD == 'true' else 'false'
        includeugo = 'true' if INCLUDEUGOTTOC == 'true' else 'false'
        includexxx = 'true' if INCLUDEXXXODUS == 'true' else 'false'
        includesal = 'true' if INCLUDESALTS == 'true' else 'false'
        includeall = 'true' if INCLUDEALLUC == 'true' else 'false'
        includeone = 'true' if INCLUDEONECHANNEL == 'true' else 'false'
    #
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    #
    if view == "clean" or SHOWMAINT == 'true': 
        addFile('Total Clean Up (Cache\Packages\Thumbs): [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize)  ,'fullclean',  description='Clean NOW the Kodi files like Cache\Packages\Thumbs that slow your system down over time.',     icon=ICONCLEANALL, themeit=THEME3)
        addFile('Clear Cache: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizecache)     ,'clearcache',      icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Packages: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizepack)   ,'clearpackages',   icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Thumbnails: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizethumb),'clearthumb',      icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Old Thumbnails', 'oldThumbs',      icon=ICONCLEAN, themeit=THEME3)
        addFile('Clear Crash Logs',               'clearcrash',      icon=ICONCLEAN, themeit=THEME3)
        addFile('Purge Databases',                'purgedb',         icon=ICONCLEAN, themeit=THEME3)
        #addFile('Fresh Start',                    'freshstart',      icon=ICONFRESHSTART, themeit=THEME7)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep('TOGGLE AUTO CLEAN SETTINGS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Auto Clean Up On Startup: %s' % autoclean.replace('true',on).replace('false',off) ,'togglesetting', 'autoclean',   icon=ICONSETTINGS, themeit=THEME3)
    if autoclean == 'true':
        addFile('--- Auto Clean Fequency: [B][COLOR green]%s[/COLOR][/B]' % feq[AUTOFEQ], 'changefeq', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Clear Cache on Startup: %s' % cache.replace('true',on).replace('false',off), 'togglesetting', 'clearcache', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Clear Packages on Startup: %s' % packages.replace('true',on).replace('false',off), 'togglesetting', 'clearpackages', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Clear Old Thumbs on Startup: %s' % thumbs.replace('true',on).replace('false',off), 'togglesetting', 'clearthumbs', icon=ICONSETTINGS, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep('TOGGLE VIDEO CACHE SETTINGS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Include Video Cache in Clear Cache: %s' % includevid.replace('true',on).replace('false',off), 'togglecache', 'includevideo', icon=ICONSETTINGS, themeit=THEME3)
    if includevid == 'true':
        addFile('--- Enable All Video Addons', 'togglecache', 'true', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Disable All Video Addons', 'togglecache', 'false', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include All Video Addons: %s' % includeall.replace('true',on).replace('false',off), 'togglecache', 'includeall', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include 1Channel: %s' % include1ch.replace('true',on).replace('false',off), 'togglecache', 'include1channel', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Alluc: %s' % includeall.replace('true',on).replace('false',off), 'togglecache', 'includealluc', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Bennu: %s' % includeben.replace('true',on).replace('false',off), 'togglecache', 'includebennu', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include BOB Unleashed: %s' % includebob.replace('true',on).replace('false',off), 'togglecache', 'includebobunleashed', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Bubbles: %s' % includebub.replace('true',on).replace('false',off), 'togglecache', 'includebubbles', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Covenant: %s' % includecov.replace('true',on).replace('false',off), 'togglecache', 'includecovenant', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Elysium: %s' % includeely.replace('true',on).replace('false',off), 'togglecache', 'includeelysium', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Exodus: %s' % includeexo.replace('true',on).replace('false',off), 'togglecache', 'includeexodus', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Gurzil: %s' % includegur.replace('true',on).replace('false',off), 'togglecache', 'includegurzil', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Icefilms: %s' % includeice.replace('true',on).replace('false',off), 'togglecache', 'includeicefilms', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Specto: %s' % includespe.replace('true',on).replace('false',off), 'togglecache', 'includespecto', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include Tinklepad: %s' % includetin.replace('true',on).replace('false',off), 'togglecache', 'includetinklepad', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include UGOTTOC: %s' % includeugo.replace('true',on).replace('false',off), 'togglecache', 'includeugottoc', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include XXXODUS: %s' % includexxx.replace('true',on).replace('false',off), 'togglecache', 'includexxxodus', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include SALTS: %s' % includesal.replace('true',on).replace('false',off), 'togglecache', 'includesalts', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include ALLUC: %s' % includeall.replace('true',on).replace('false',off), 'togglecache', 'includealluc', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include ONECHANNEL: %s' % includeone.replace('true',on).replace('false',off), 'togglecache', 'includeonechannel', icon=ICONSETTINGS, themeit=THEME3)
        addFile('--- Include UGOTTOC: %s' % includeugo.replace('true',on).replace('false',off), 'togglecache', 'includeugottoc', icon=ICONSETTINGS, themeit=THEME3)        
    setView('files', 'viewType')


###########################
###### Menu Maintenance   #
###########################
def maintMenu(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Maintenence MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
    if wiz.Grab_Log(True) == False: kodilog = 0
    else: kodilog = errorChecking(wiz.Grab_Log(True), True, True)
    if wiz.Grab_Log(True, True) == False: kodioldlog = 0
    else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True, True)
    errorsinlog = int(kodilog) + int(kodioldlog)
    errorsfound = str(errorsinlog) + ' Error(s) Found' if errorsinlog > 0 else 'None Found'
    wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    
    #addFile('Force Close Kodi',               'forceclose',      icon=ICONFORCECLOSE, themeit=THEME3)
    addDir ('System Information',             'systeminfo',    description='Sys Info',  icon=ICONINFO, themeit=THEME3)
    addFile('Scan For Broken Repositories',   'checkrepos',      icon=ICONMAINT, themeit=THEME3)
    addFile('Scan Sources for broken links',  'checksources',    icon=ICONMAINT, themeit=THEME3)
    if view == "tweaks" or SHOWMAINT == 'true': 
        #if HIDESPACERS == 'No': addFile(wiz.sep('SYSTEM TWEAKS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        addFile('Fix Addons Not Updating',        'fixaddonupdate',  icon=ICONMAINT, themeit=THEME3)
        addFile('Remove Non-Ascii filenames',     'asciicheck',      icon=ICONMAINT, themeit=THEME3)
        addFile('Convert Paths to special',       'convertpath',     icon=ICONMAINT, themeit=THEME3)
    #
    if view == "misc" or SHOWMAINT == 'true': 
        addFile('Hide Passwords On Keyboard Entry',   'hidepassword',   icon=ICONSETTINGS, themeit=THEME3)
        addFile('Unhide Passwords On Keyboard Entry', 'unhidepassword', icon=ICONSETTINGS, themeit=THEME3)
        addFile('Reload Skin',                    'forceskin',       icon=ICONSETTINGS, themeit=THEME3)
        addFile('Reload Profile',                 'forceprofile',    icon=ICONSETTINGS, themeit=THEME3)
    #addFile('Show All Maintenance: %s' % maint.replace('true',on).replace('false',off) ,'togglesetting', 'showmaint', icon=ICONSETTINGS, themeit=THEME9)
    if DEVELOPER == 'true': addDir('Developer Menu','developer', icon=ICONSETTINGS, themeit=THEME1)
    setView('files', 'viewType')


###########################
###### Menu backup   #
###########################
def index_backup(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Backup MENU**', level=xbmc.LOGNOTICE)
    #addDir ('[COLOR green]Multiple Addons[/COLOR]:  Full restore of addons, repos and settings.'   ,'InstallAll',   icon=ICONRESTORE,   themeit=THEME1)
    #addDir ('[B]Back-up[/B]'     ,'maint', 'backup',   icon=ICONBACKUP, themeit=THEME1)
    if view == "backup" or SHOWMAINT == 'true':
        addFile('Back Up Zip Location: [COLOR %s]%s[/COLOR]' % (COLOR3, MYBUILDS),'settings', 'Maintenance',  description='Where to save or restore zip backups from', icon=ICONBACKUP, themeit=THEME3)
        addFile('Clean Back Up Folder  [COLOR red](Delete all Zips)[/COLOR]',        'clearbackup',     icon=ICONDELETE,   themeit=THEME3)
        if HIDESPACERS == 'No': addFile(wiz.sep('MAKE BACKUP FILES (BUILD)'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Build',               'backupbuild',     icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] GuiFix',              'backupgui',       icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Theme',               'backuptheme',     icon=ICONBACKUP,   themeit=THEME3)
        addFile('[COLOR blue][B]Back Up:[/B][/COLOR] Addon_data',          'backupaddon',     icon=ICONBACKUP,   themeit=THEME3)
        addDir('Save Debrid And Trakt Data',     'savedata', icon=ICONTRAKT,     themeit=THEME1)
        if HIDESPACERS == 'No': addFile(wiz.sep('RESTORE BACKUP ZIP (BUILD)'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        #addDir('[B]Restore[/B]',                 'maint', 'backup',   icon=ICONRESTORE, themeit=THEME1)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Build',         'restorezip',      icon=ICONRESTORE,   themeit=THEME3)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local GuiFix',        'restoregui',      icon=ICONRESTORE,   themeit=THEME3)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] Local Addon_data',    'restoreaddon',    icon=ICONRESTORE,   themeit=THEME3)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Build',      'restoreextzip',   icon=ICONRESTORE,   themeit=THEME3)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] External GuiFix',     'restoreextgui',   icon=ICONRESTORE,   themeit=THEME3)
        addFile('[COLOR blue][B]Restore:[/B][/COLOR] External Addon_data', 'restoreextaddon', icon=ICONRESTORE,   themeit=THEME3)
    setView('files', 'viewType')



###########################
###### Menu Log           #
###########################
def index_log(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Log MENU**', level=xbmc.LOGNOTICE)
    if wiz.Grab_Log(True) == False: kodilog = 0
    else: kodilog = errorChecking(wiz.Grab_Log(True), True, True)
    if wiz.Grab_Log(True, True) == False: kodioldlog = 0
    else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True, True)
    errorsinlog = int(kodilog) + int(kodioldlog)
    errorsfound = str(errorsinlog) + ' Error(s) Found' if errorsinlog > 0 else 'None Found'
    wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
    addFile('View Log File',                          'viewlog',       description='View the contents of the Logfile to check for Kodi addon errors',  icon=ICONLOG, themeit=THEME3)
    addFile('View Errors in Log: %s' % (errorsfound), 'viewerrorlog',    icon=ICONLOG, themeit=THEME3)
    addFile('View Wizard Log File',                   'viewwizlog',      icon=ICONLOG, themeit=THEME3)
    addFile('Clear Wizard Log File%s' % wizlogsize,   'clearwizlog',     icon=ICONLOG, themeit=THEME3)
    addDir ('Email Log to yourself',                  'emaillog',        icon=ICONLOG, themeit=THEME3)
    addFile('Upload Kodi.log to random Pastebin',     'uploadlog',       icon=ICONEMAIL, themeit=THEME3)
    setView('files', 'viewType')


###########################
###### Menu XML           #
###########################
def index_installxml(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **XML MENU**', level=xbmc.LOGNOTICE)
    addDir ('Create Custom Advancedsettings.xml'   ,'advancedsetting',       description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEME3)
    addDir ('advancedsettings.xml'                 ,'indexadvancedsettings', description='Install an advancedsettings.xml file to improve performance',  icon=ICONXML,   themeit=THEME1)
    addDir ('sources.xml'                          ,'indexsourcesxml',       description='Install a sources.xml file to add repo sources',  icon=ICONXML,   themeit=THEME1)
    addDir ('RssFeeds.xml'                         ,'indexrss',              description='Install a better RSS feed xml to be more informed',  icon=ICONXML,   themeit=THEME1)
    addDir ('playercorefactory.xml'                ,'indexplayercorefactory', description='Install a playercorefactory.xml file to allow playing media from a 3rd party player like chromecast', icon=ICONXML,   themeit=THEME1)
    setView('files', 'viewType')


###########################
###### sources.xml menu
###########################
def index_sourcesxml(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Sources XML MENU**', level=xbmc.LOGNOTICE)
    corefile='sources.xml'
    corefiledir = 'sources'
    # check sources.xml
    SOURCES_SET = xbmc.translatePath('special://userdata/sources.xml')
    if os.path.isfile(SOURCES_SET):SOURCES_SET_EN_DIS = "  [COLOR yellowgreen][B]ENABLED[/COLOR][/B]"
    else:SOURCES_SET_EN_DIS = "  [COLOR lightskyblue][B]DISABLED[/COLOR][/B]"
    #       
    choicesourcesxml = DIALOG.select('sources.xml - Library paths, repos, and poscasts', ['[COLOR yellow]Close[/COLOR]',
                                                       'Delete sources.xml'+SOURCES_SET_EN_DIS,
                                                       'View sources.xml',
                                                       'Copy '+sourcesxml1+'  (Extra Addon Sources)',
                                                       'Copy '+sourcesxml2+'  (SQL Database Template)',
                                                       'Copy '+sourcesxml3])
    if choicesourcesxml == 0: sys.exit(0)
    if choicesourcesxml == 1: xbmcvfs.delete('special://profile/sources.xml')
    if choicesourcesxml == 2: import main_TextViewer as main_TextViewer;main_TextViewer.text_view(xbmc.translatePath(os.path.join('special://profile', 'sources.xml')))
    if choicesourcesxml == 3: corefile_replace(sourcesxml1,corefiledir,corefile)
    if choicesourcesxml == 4: corefile_replace(sourcesxml2,corefiledir,corefile)
    if choicesourcesxml == 5: corefile_replace(sourcesxml3,corefiledir,corefile)


###########################
###### advanced.xml menu
###########################
def index_advancedsettings(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **advancedsettings XML MENU**', level=xbmc.LOGNOTICE)
    corefile='advancedsettings.xml'
    corefiledir = 'advancedsettings'
    # check advancedsettings.xml
    ADV_SET = xbmc.translatePath('special://userdata/advancedsettings.xml')
    if os.path.isfile(ADV_SET):ADV_SET_EN_DIS = "  [COLOR yellowgreen][B]ENABLED[/COLOR][/B]"
    else:ADV_SET_EN_DIS = "  [COLOR lightskyblue][B]DISABLED[/COLOR][/B]"
    #
    choiceadvancedsettings = DIALOG.select('advancedsettings.xml - forces settings and tweaks like cache', ['Advancedsettings GUI',
                                           'Delete advancedsettings.xml'+ADV_SET_EN_DIS,
                                           'View xml file  '+osinfo,
                                           'Install advancedsettings.xml'])

    if choiceadvancedsettings == 0: showAutoAdvanced()
    if choiceadvancedsettings == 1: xbmcvfs.delete('special://profile/advancedsettings.xml')
    if choiceadvancedsettings == 2: print ''#import main_TextViewer as main_TextViewer;main_TextViewer.text_view(xbmc.translatePath(os.path.join('special://profile', 'advancedsettings.xml')))       
    if choiceadvancedsettings == 3: advancedsettings_write_config(corefiledir)
#
def advancedsettings_write_config(corefiledir):
    #if not xbmc.getCondVisibility('system.platform.windows'): return
    xbmc.log(msg='##['+ADDON_ID+'] dynamic advancedsettings.xml', level=xbmc.LOGNOTICE)
    file = ADVANCED
    file_extras = xbmc.translatePath(os.path.join(extrapath,corefiledir))
    if os.path.exists(file):
        xbmcvfs.copy(file, file+'.last')
        delete_file(file)
    AppendText(xbmc.translatePath(os.path.join(file_extras, '0_start.txt')), file)
    choicesql = DIALOG.select('SQL Server?', ['[COLOR yellow]NO[/COLOR]',
                               'YES (Know what youre doing)'])
    if choicesql == 1: AppendText(xbmc.translatePath(os.path.join(file_extras, '666_sql.txt')), file)
    #AppendText(xbmc.translatePath(os.path.join(file_extras, '666_sql.txt')), file)
    if kodi_version == '18': AppendText(xbmc.translatePath(os.path.join(file_extras, '1_krypton.txt')), file)
    if kodi_version == '17': AppendText(xbmc.translatePath(os.path.join(file_extras, '1_krypton.txt')), file)
    if kodi_version == '16': AppendText(xbmc.translatePath(os.path.join(file_extras, '1_NOT_krypton.txt')), file)
    if kodi_version == '15': AppendText(xbmc.translatePath(os.path.join(file_extras, '1_NOT_krypton.txt')), file)
    if kodi_version == '14': AppendText(xbmc.translatePath(os.path.join(file_extras, '1_NOT_krypton.txt')), file)
    AppendText(xbmc.translatePath(os.path.join(file_extras, '2_main.txt')), file)
    AppendText(xbmc.translatePath(os.path.join(file_extras, '0_end.txt')), file)
    #xbmc.log(msg='##['+ADDON_ID+'] Windows dynamic playercorefactory done', level=xbmc.LOGNOTICE)
    # write new cache if small
    #if totalspace >= '100000': kodi_version = '150'


###########################
###### RSS.xml menu
###########################
def index_rss(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **RSS XML MENU**', level=xbmc.LOGNOTICE)
    corefile='RssFeeds.xml'
    corefiledir = 'rss'
    choicerss = DIALOG.select('RssFeeds.xml - Scrolls Kodi, movie and news headlines.', ['[COLOR yellow]Close[/COLOR]',
                               'Delete RssFeeds.xml',
                               'View RssFeeds.xml',
                               'Copy '+rss1,
                               'Copy '+rss2,
                               'Copy '+rss3,
                               'Copy '+rss4])
    if choicerss == 0: sys.exit(0)
    if choicerss == 1: xbmcvfs.delete('special://profile/RssFeeds.xml')
    if choicerss == 2: print ''#;import main_TextViewer as main_TextViewer;main_TextViewer.text_view(xbmc.translatePath(os.path.join('special://profile', corefile)))    
    if choicerss == 3: corefile_replace(rss1,corefiledir,corefile)
    if choicerss == 4: corefile_replace(rss2,corefiledir,corefile)
    if choicerss == 5: corefile_replace(rss3,corefiledir,corefile)
    if choicerss == 6: corefile_replace(rss4,corefiledir,corefile)


###########################
###### playercorefactory menu
###########################
def index_playercorefactory(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **playercorefactory XML MENU**', level=xbmc.LOGNOTICE)
    corefile='playercorefactory.xml'
    corefiledir = 'playercorefactory'
    #
    # check playercorefactory.xml
    PLAYER_CORE = xbmc.translatePath('special://profile/playercorefactory.xml')
    if os.path.isfile(PLAYER_CORE):PLAYER_CORE_EN_DIS = "  [COLOR yellowgreen][B]ENABLED[/COLOR][/B]"
    else:PLAYER_CORE_EN_DIS = "  [COLOR lightskyblue][B]DISABLED[/COLOR][/B]"
    #
    choiceplayercorefactory = DIALOG.select('playercorefactory.xml - Used to cast, record and use alternate players', ['[COLOR yellow]Close[/COLOR]',
                                                      'Delete playercorefactory.xml',
                                                      'View playercorefactory.xml'+PLAYER_CORE_EN_DIS,
                                                      'Windows - AutoScan and use all possible players',
                                                      'Copy '+playercorefactory1,
                                                      'Copy '+playercorefactory2,
                                                      'Copy '+playercorefactory3,
                                                      'Copy '+playercorefactory4+' (Needs Rip-Record.exe) '+osinfo,
                                                      '[COLOR lightskyblue][B]Rip-Record and ffmpeg are for Windows Recording[/COLOR][/B]',
                                                      'Open Rip-Record www'])
    if choiceplayercorefactory == 0: sys.exit(0)
    if choiceplayercorefactory == 1: xbmcvfs.delete('special://profile/playercorefactory.xml')
    if choiceplayercorefactory == 2: print''#;import main_TextViewer as main_TextViewer;main_TextViewer.text_view(xbmc.translatePath(os.path.join('special://profile', 'playercorefactory.xml')))
    if choiceplayercorefactory == 3: playerfactorycore_write_config()
    if choiceplayercorefactory == 4: corefile_replace(playercorefactory1,corefiledir,corefile)
    if choiceplayercorefactory == 5: corefile_replace(playercorefactory2,corefiledir,corefile)
    if choiceplayercorefactory == 6: corefile_replace(playercorefactory3,corefiledir,corefile)
    if choiceplayercorefactory == 7: corefile_replace(playercorefactory4,corefiledir,corefile)
    if choiceplayercorefactory == 8: print 'No click sauce for u'
    if choiceplayercorefactory == 9: run_www('https://github.com/NapoleonWils0n/kodi-playercorefactory')
#
def playerfactorycore_write_config():
    if not xbmc.getCondVisibility('system.platform.windows'): return
    xbmc.log(msg='##['+ADDON_ID+'] Windows dynamic playercorefactory.xml', level=xbmc.LOGNOTICE)
    file = xbmc.translatePath(os.path.join('special://profile','playercorefactory.xml'))
    file_extras = xbmc.translatePath(os.path.join(extrapath,'playercorefactory', 'windows'))
    if os.path.exists(file):     
        xbmcvfs.copy(file, file+'.last')
        delete_file(file)
    AppendText(xbmc.translatePath(os.path.join(file_extras, '0_start.txt')), file) 
    # check ffmpeg
    if os.path.exists(xbmc.translatePath('C:/utils/ffmpeg.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'ffmpeg.txt')), file)
    # check vlc
    if os.path.exists(xbmc.translatePath('C:/Program Files (x86)/Videolan/VLC/VLC.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'vlc_x64.txt')), file) 
    if os.path.exists(xbmc.translatePath('C:/Program Files/Videolan/VLC/VLC.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'vlc_x86.txt')), file) 
    # check mpc
    if os.path.exists(xbmc.translatePath('C:/Program Files/MPC-HC64/mpc-hc64.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'mpc_x64.txt')), file)
    if os.path.exists(xbmc.translatePath('C:/Program Files/MPC-HC/mpc-hc.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'mpc_x86.txt')), file)
    # check mpc klite
    if os.path.exists(xbmc.translatePath('C:/Program Files (x86)/K-Lite Codec Pack/MPC-HC64/mpc-hc64.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'mpc_klite_x64.txt')), file)
    if os.path.exists(xbmc.translatePath('C:/Program Files/K-Lite Codec Pack/MPC-HC/mpc-hc.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'mpc_klite_x86.txt')), file)
    # check rip-record
    if os.path.exists(xbmc.translatePath('C:/Program Files (x86)/Rip-Record/Uninstall.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'rip-record.txt')), file)
    if os.path.exists(xbmc.translatePath('C:/Program Files/Rip-Record/Uninstall.exe')): AppendText(xbmc.translatePath(os.path.join(file_extras, 'rip-record.txt')), file)
    #
    AppendText(xbmc.translatePath(os.path.join(file_extras, '0_end.txt')), file)    
    #xbmc.log(msg='##['+ADDON_ID+'] Windows dynamic playercorefactory done', level=xbmc.LOGNOTICE)











######################################################
###### Main Program functions                   ######
######################################################

###########################
###### Menu Builds        #
###########################
def buildMenu(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Buildn MENU**', level=xbmc.LOGNOTICE)
    on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
    WORKINGURL = wiz.workingURL(BUILDFILE)
    if not WORKINGURL == True:
        addFile('[COLOR yellow]%s Version:[/COLOR] %s' % (MCNAME, KODIV), '', icon=ICONSPACER, themeit=THEME6)
        addFile('Third Party Wizards: %s' % thirdparty.replace('true',on).replace('false',off) ,'togglesetting', 'enable3rd', description='Turn on extra 3rd party build paths',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
        addFile('Url for txt file not valid', '', icon=ICONBUILDS, themeit=THEME3)
        addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
    else:
        total, count15, count16, count17, count18, adultcount, hidden = wiz.buildCount()
        third = False; addin = []
        if THIRDPARTY == 'true':
            if not THIRD1NAME == '' and not THIRD1URL == '': third = True; addin.append('1')
            if not THIRD2NAME == '' and not THIRD2URL == '': third = True; addin.append('2')
            if not THIRD3NAME == '' and not THIRD3URL == '': third = True; addin.append('3')
            if not THIRD4NAME == '' and not THIRD4URL == '': third = True; addin.append('4')
            if not THIRD5NAME == '' and not THIRD5URL == '': third = True; addin.append('5')
            if not THIRD6NAME == '' and not THIRD6URL == '': third = True; addin.append('6')
            if not THIRD7NAME == '' and not THIRD7URL == '': third = True; addin.append('7')
            if not THIRD8NAME == '' and not THIRD8URL == '': third = True; addin.append('8')
            if not THIRD9NAME == '' and not THIRD9URL == '': third = True; addin.append('9')
        
        link  = wiz.openURL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"').replace('adult=""', 'adult="no"')
        match = re.compile('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
        if total == 1 and third == False:
            for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                if not DEVELOPER == 'true' and wiz.strTest(name): continue
                viewBuild(match[0][0])
                return
        addFile('%s Version: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEME3)
        addFile('Third Party Wizards: %s' % thirdparty.replace('true',on).replace('false',off) ,'togglesetting', 'enable3rd', description='Turn on extra 3rd party build paths',  fanart=FANART, icon=ICONBUILDS, themeit=THEME9)
        # wizard defaults version free
        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
            kodiv = int(float(kodi))
            if kodiv == 0:
                menu = createMenu('install', '', name)
                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)

        if third == True:
            for item in addin:
                name = eval('THIRD%sNAME' % item)
                addDir ("[B]%s[/B]" % name, 'viewthirdparty', item, icon=ICONBUILDS, themeit=THEME3)
        if len(match) >= 1:
            if SEPERATE == 'true':
                for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    if not DEVELOPER == 'true' and wiz.strTest(name): continue
                    menu = createMenu('install', '', name)
                    addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)
            else:
            
                if count18 > 0:
                    state = '+' if SHOW18 == 'false' else '-'
                    addFile('[B]%s Kodi 18 Leia Builds(%s)[/B]' % (state, count18), 'togglesetting',  'show18', themeit=THEME3)
                    if SHOW18 == 'true':
                        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if not DEVELOPER == 'true' and wiz.strTest(name): continue
                            kodiv = int(float(kodi))
                            if kodiv == 18:
                                menu = createMenu('install', '', name)
                                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)
                if count17 > 0:
                    state = '+' if SHOW17 == 'false' else '-'
                    addFile('[B]%s Kodi 17 Krypton Builds(%s)[/B]' % (state, count17), 'togglesetting',  'show17', themeit=THEME3)
                    if SHOW17 == 'true':
                        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if not DEVELOPER == 'true' and wiz.strTest(name): continue
                            kodiv = int(float(kodi))
                            if kodiv == 17:
                                menu = createMenu('install', '', name)
                                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)
                if count16 > 0:
                    state = '+' if SHOW16 == 'false' else '-'
                    addFile('[B]%s Kodi 16 Jarvis Builds(%s)[/B]' % (state, count16), 'togglesetting',  'show16', themeit=THEME3)
                    if SHOW16 == 'true':
                        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if not DEVELOPER == 'true' and wiz.strTest(name): continue
                            kodiv = int(float(kodi))
                            if kodiv == 16:
                                menu = createMenu('install', '', name)
                                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)
                if count15 > 0:
                    state = '+' if SHOW15 == 'false' else '-'
                    addFile('[B]%s Kodi 15 Isengard and Below Builds(%s)[/B]' % (state, count15), 'togglesetting',  'show15', themeit=THEME3)
                    if SHOW15 == 'true':
                        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if not DEVELOPER == 'true' and wiz.strTest(name): continue
                            kodiv = int(float(kodi))
                            if kodiv <= 15:
                                menu = createMenu('install', '', name)
                                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=FANART,icon=ICON, menu=menu, themeit=THEME2)
        elif hidden > 0: 
            if adultcount > 0:
                addFile('There is currently only Adult builds', '', icon=ICONBUILDS, themeit=THEME3)
                addFile('Enable Show Adults in Addon Settings > Misc', '', icon=ICONBUILDS, themeit=THEME3)
            else:
                addFile('Currently No Builds Offered from %s' % ADDONTITLE, '', icon=ICONBUILDS, themeit=THEME3)
        else: addFile('Text file for builds not formated correctly.', '', icon=ICONBUILDS, themeit=THEME3)
        
    setView('files', 'viewType')

###########################
###### Menu View Builds   #
###########################
def viewBuild(name):
    WORKINGURL = wiz.workingURL(BUILDFILE)
    if not WORKINGURL == True:
        addFile('Url for txt file not valid', '', themeit=THEME3)
        addFile('%s' % WORKINGURL, '', themeit=THEME3)
        return
    if wiz.checkBuild(name, 'version') == False: 
        addFile('Error reading the txt file.', '', themeit=THEME3)
        addFile('%s was not found in the builds list.' % name, '', themeit=THEME3)
        return
    link = wiz.openURL(BUILDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"')
    match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % name).findall(link)
    for version, url, gui, kodi, themefile, icon, fanart, preview, adult, description in match:
        icon        = icon   if wiz.workingURL(icon)   else ICON
        fanart      = fanart if wiz.workingURL(fanart) else FANART
        build       = '%s (v%s)' % (name, version)
        if BUILDNAME == name and version > BUILDVERSION:
            build = '%s [COLOR red][CURRENT v%s][/COLOR]' % (build, BUILDVERSION)

        #addFile(build, '', description=description, fanart=FANART, icon=ICON, themeit=THEME4)
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
        #if HIDESPACERS == 'No': addFile(wiz.sep('BUILD INFO'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        addFile('Build Information',    'buildinfo', name, description=description, fanart=FANART, icon=ICON, themeit=THEME3)

        temp1 = int(float(KODIV)); temp2 = int(float(kodi))
        if not temp1 == temp2: 
            if temp1 == 16 and temp2 <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            addFile('[COLOR yellow]Build designed for kodi version:[/COLOR]  [I]%s  (installed: %s)[/I]' % (str(kodi), str(KODIV)), '', fanart=FANART, icon=ICON, themeit=THEME3)
            
        #addFile(wiz.sep('INSTALL BUILD'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        
        addFile('Fresh Install  '    +build, 'install', name, 'fresh'  , description=description, fanart=FANART, icon=ICON, themeit=THEME3)
        addFile('Standard Install  ' +build, 'install', name, 'normal' , description=description, fanart=FANART, icon=ICON, themeit=THEME3)
        if not gui == 'http://': addFile('Apply guiFix'    , 'install', name, 'gui'     , description=description, fanart=FANART, icon=ICON, themeit=THEME1)
        if not themefile == 'http://':
            if wiz.workingURL(themefile) == True:
                addFile(wiz.sep('THEMES'), '', fanart=FANART, icon=ICON, themeit=THEME6)
                link  = wiz.openURL(themefile).replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                for themename, themeurl, themeicon, themefanart, themeadult, description in match:
                    if not SHOWADULT == 'true' and themeadult.lower() == 'yes': continue
                    themeicon   = themeicon   if themeicon   == 'http://' else icon
                    themefanart = themefanart if themefanart == 'http://' else fanart
                    addFile(themename if not themename == BUILDTHEME else "[B]%s (Installed)[/B]" % themename, 'theme', name, themename, description=description, fanart=themefanart, icon=themeicon, themeit=THEME3)

        if not preview == "http://": addFile('View Video Preview', 'buildpreview', name, description=description, fanart=FANART, icon=ICON, themeit=THEME3)
        addDir ('Save Data',       'savedata', icon=ICONSAVE,     themeit=THEME1)
    setView('files', 'viewType')

def viewThirdList(number):
    name = eval('THIRD%sNAME' % number)
    url  = eval('THIRD%sURL' % number)
    work = wiz.workingURL(url)
    if not work == True:
        addFile('Url for txt file not valid', '', icon=ICONBUILDS, themeit=THEME3)
        addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
    else:
        type, buildslist = wiz.thirdParty(url)
        addFile("[B]%s[/B]" % name, '', themeit=THEME3)
        if HIDESPACERS == 'No': addFile(wiz.sep(''), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        if type:
            for name, version, url, kodi, icon, fanart, adult, description in buildslist:
                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                addFile("[%s] %s v%s" % (kodi, name, version), 'installthird', name, url, icon=ICON, fanart=FANART, description=description, themeit=THEME2)
        else:
            for name, url, icon, fanart, description in buildslist:
                addFile(name, 'installthird', name, url, icon=ICON, fanart=FANART, description=description, themeit=THEME2)

def editThirdParty(number):
    name  = eval('THIRD%sNAME' % number)
    url   = eval('THIRD%sURL' % number)
    name2 = wiz.getKeyboard(name, 'Enter the Name of the Wizard')
    url2  = wiz.getKeyboard(url, 'Enter the URL of the Wizard Text')
    
    wiz.setS('wizard%sname' % number, name2)
    wiz.setS('wizard%surl' % number, url2)

def apkScraper(name=""):
    if name == 'kodi':
        kodiurl1 = 'http://mirrors.kodi.tv/releases/android/arm/'
        kodiurl2 = 'http://mirrors.kodi.tv/releases/android/arm/old/'
        url1 = wiz.openURL(kodiurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        url2 = wiz.openURL(kodiurl2).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url1)
        match2 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url2)
        
        addFile("Official Kodi Apk\'s", themeit=THEME1)
        rc = False
        for url, name, size, date in match1:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1 and rc == True: continue
            try:
                tempname = name.split('-')
                if not url.find('_') == -1:
                    rc = True
                    name2, v2 = tempname[2].split('_')
                else: 
                    name2 = tempname[2]
                    v2 = ''
                title = "[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], v2.upper(), name2, COLOR2, size.replace(' ', ''), COLOR1, date)
                download = urljoin(kodiurl1, url)
                addFile(title, 'apkinstall', "%s v%s%s %s" % (tempname[0].title(), tempname[1], v2.upper(), name2), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
            
        for url, name, size, date in match2:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1: continue
            try:
                tempname = name.split('-')
                title = "[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], tempname[2], COLOR2, size.replace(' ', ''), COLOR1, date)
                download = urljoin(kodiurl2, url)
                addFile(title, 'apkinstall', "%s v%s %s" % (tempname[0].title(), tempname[1], tempname[2]), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
        if x == 0: addFile("Error Kodi Scraper Is Currently Down.")
    elif name == 'spmc':
        #spmcurl1 = 'https://github.com/koying/SPMC/releases'
        url1 = wiz.openURL(spmcurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall(url1)
        
        addFile("Official SPMC Apk\'s", themeit=THEME1)

        for name, urls in match1:
            tempurl = ''
            match2 = re.compile('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall(urls)
            for apkurl, apksize, apkname in match2:
                if apkname.find('armeabi') == -1: continue
                if apkname.find('launcher') > -1: continue
                tempurl = urljoin('https://github.com', apkurl)
                break
            if tempurl == '': continue
            try:
                name = "SPMC %s" % name
                title = "[COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, name, COLOR2, apksize.replace(' ', ''))
                download = tempurl
                addFile(title, 'apkinstall', name, download)
                x += 1
            except Exception, e:
                wiz.log("Error on: %s / %s" % (name, str(e)))
        if x == 0: addFile("Error SPMC Scraper Is Currently Down.")

def apkMenu(url=None):
    if url == None:
    
        addDir ('Official Kodi Apk\'s', 'apkscrape', 'kodi', icon=ICONAPK, themeit=THEME1)
        addDir ('Official SPMC Apk\'s', 'apkscrape', 'spmc', icon=ICONAPK, themeit=THEME1)
        
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
        if HIDESPACERS == 'No': addFile(wiz.sep('ANDROID PROGRAM PATHS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        # maybe need adddir
        addFile('Android Application Manager', 'androidappmanager', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        addFile('Android Kodi Settings', 'androidkodisettings', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        addFile('Android Programs', 'androidprograms', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        addFile('Android Settings', 'androidsettings', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        addFile('Android Apps', 'androidapps', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        addFile('Program Addons', 'androidprogramaddons', fanart=FANART, icon=ICONAPK, themeit=THEME3)
        
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
        if HIDESPACERS == 'No': addFile(wiz.sep('APK LIST'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    if not APKFILE == 'http://':
        if url == None:
            APKWORKING  = wiz.workingURL(APKFILE)
            TEMPAPKFILE = uservar.APKFILE
        else:
            APKWORKING  = wiz.workingURL(url)
            TEMPAPKFILE = url
        if APKWORKING == True:
            link = wiz.openURL(TEMPAPKFILE).replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for name, section, url, icon, fanart, adult, description in match:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    if section.lower() == 'yes':
                        x += 1
                        addDir ("[B]%s[/B]" % name, 'apk', url, description=description, icon=ICON, fanart=FANART, themeit=THEME3)
                    else:
                        x += 1
                        addFile(name, 'apkinstall', name, url, description=description, icon=ICON, fanart=FANART, themeit=THEME2)
                    if x < 1:
                        addFile("No addons added to this menu yet!", '', themeit=THEME2)
            else: wiz.log("[APK Menu] ERROR: Invalid Format.", xbmc.LOGERROR)
        else: 
            wiz.log("[APK Menu] ERROR: URL for apk list not working.", xbmc.LOGERROR)
            addFile('Url for txt file not valid', '', themeit=THEME3)
            addFile('%s' % APKWORKING, '', themeit=THEME3)
        return
    else: wiz.log("[APK Menu] No APK list added.")
    setView('files', 'viewType')

def addonMenu(url=None):
    if not ADDONFILE == 'http://':
        if url == None:
            ADDONWORKING  = wiz.workingURL(ADDONFILE)
            TEMPADDONFILE = uservar.ADDONFILE
        else:
            ADDONWORKING  = wiz.workingURL(url)
            TEMPADDONFILE = url
        if ADDONWORKING == True:
            link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for name, plugin, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    if plugin.lower() == 'section':
                        x += 1
                        addDir ("[B]%s[/B]" % name, 'addons', url, description=description, icon=ICON, fanart=FANART, themeit=THEME3)
                    else:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        try:
                            add    = xbmcaddon.Addon(id=plugin).getAddonInfo('path')
                            if os.path.exists(add):
                                name   = "[COLOR green][Installed][/COLOR] %s" % name
                        except:
                            pass
                        x += 1
                        addFile(name, 'addoninstall', plugin, TEMPADDONFILE, description=description, icon=ICON, fanart=FANART, themeit=THEME2)
                    if x < 1:
                        addFile("No addons added to this menu yet!", '', themeit=THEME2)
            else: 
                addFile('Text File not formated correctly!', '', themeit=THEME3)
                wiz.log("[Addon Menu] ERROR: Invalid Format.")
        else: 
            wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
            addFile('Url for txt file not valid', '', themeit=THEME3)
            addFile('%s' % ADDONWORKING, '', themeit=THEME3)
    else: wiz.log("[Addon Menu] No Addon list added.")
    setView('files', 'viewType')

def addonInstaller(plugin, url):
    if not ADDONFILE == 'http://':
        ADDONWORKING = wiz.workingURL(url)
        if ADDONWORKING == True:
            link = wiz.openURL(url).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            match = re.compile('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % plugin).findall(link)
            if len(match) > 0:
                for name, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        do        = ['Launch Addon', 'Remove Addon']
                        selected = DIALOG.select("[COLOR %s]Addon already installed what would you like to do?[/COLOR]" % COLOR2, do)
                        if selected == 0:
                            wiz.ebi('RunAddon(%s)' % plugin)
                            xbmc.sleep(500)
                            return True
                        elif selected == 1:
                            wiz.cleanHouse(os.path.join(ADDONS, plugin))
                            try: wiz.removeFolder(os.path.join(ADDONS, plugin))
                            except: pass
                            if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to remove the addon_data for:" % COLOR2, "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, plugin), yeslabel="[B][COLOR green]Yes Remove[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
                                removeAddonData(plugin)
                            wiz.refresh()
                            return True
                        else:
                            return False
                    repo = os.path.join(ADDONS, repository)
                    if not repository.lower() == 'none' and not os.path.exists(repo):
                        wiz.log("Repository not installed, installing it")
                        if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:" % (COLOR2, COLOR1, plugin), "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
                            ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
                            if len(ver) > 0:
                                repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
                                wiz.log(repozip)
                                if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                installAddon(repository, repozip)
                                wiz.ebi('UpdateAddonRepos()')
                                #wiz.ebi('UpdateLocalAddons()')
                                wiz.log("Installing Addon from Kodi")
                                install = installFromKodi(plugin)
                                wiz.log("Install from Kodi: %s" % install)
                                if install:
                                    wiz.refresh()
                                    return True
                            else:
                                wiz.log("[Addon Installer] Repository not installed: Unable to grab url! (%s)" % repository)
                        else: wiz.log("[Addon Installer] Repository for %s not installed: %s" % (plugin, repository))
                    elif repository.lower() == 'none':
                        wiz.log("No repository, installing addon")
                        pluginid = plugin
                        zipurl = url
                        installAddon(plugin, url)
                        wiz.refresh()
                        return True
                    else:
                        wiz.log("Repository installed, installing addon")
                        install = installFromKodi(plugin, False)
                        if install:
                            wiz.refresh()
                            return True
                    if os.path.exists(os.path.join(ADDONS, plugin)): return True
                    ver2 = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': plugin})
                    if len(ver2) > 0:
                        url = "%s%s-%s.zip" % (url, plugin, ver2[0])
                        wiz.log(str(url))
                        if KODIV >= 17: wiz.addonDatabase(plugin, 1)
                        installAddon(plugin, url)
                        wiz.refresh()
                    else: 
                        wiz.log("no match"); return False
            else: wiz.log("[Addon Installer] Invalid Format")
        else: wiz.log("[Addon Installer] Text File: %s" % ADDONWORKING)
    else: wiz.log("[Addon Installer] Not Enabled.")

def installFromKodi(plugin, over=True):
    if over == True:
        xbmc.sleep(2000)
    #wiz.ebi('InstallAddon(%s)' % plugin)
    wiz.ebi('RunPlugin(plugin://%s)' % plugin)
    if not wiz.whileWindow('yesnodialog'):
        return False
    xbmc.sleep(500)
    if wiz.whileWindow('okdialog'):
        return False
    wiz.whileWindow('progressdialog')
    if os.path.exists(os.path.join(ADDONS, plugin)): return True
    else: return False

def installAddon(name, url):
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLOR1, '[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]' % (COLOR1, name, COLOR2)); return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    _notify('Install', name, ICON)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    urlsplit = url.split('/')
    lib=os.path.join(PACKAGES, urlsplit[-1])
    try: os.remove(lib)
    except: pass
    #download(url, lib, DP)
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
    DP.update(0, title,'Extracting Zip', '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
    DP.update(0, title, name, '[COLOR %s]Installing Dependencies[/COLOR]' % COLOR2)
    installed(name)
    installDep(name, DP)
    DP.close()
    wiz.ebi('UpdateAddonRepos()')
    wiz.ebi('UpdateLocalAddons()')
    wiz.refresh()
    

def installDep(name, DP=None):
    dep=os.path.join(ADDONS,name,'addon.xml')
    if os.path.exists(dep):
        source = open(dep,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        for depends in match:
            if not 'xbmc.python' in depends:
                if not DP == None:
                    DP.update(0, '', '[COLOR %s]%s[/COLOR]' % (COLOR1, depends))
                wiz.createTemp(depends)
                '''
                continue
                dependspath=os.path.join(ADDONS, depends)
                if not os.path.exists(dependspath):
                    zipname = '%s-%s.zip' % (depends, match2[match.index(depends)])
                    depzip = urljoin("%s%s/" % (MODURL2, depends), zipname)
                    if not wiz.workingURL(depzip) == True:
                        depzip = urljoin(MODURL, '%s.zip' % depends)
                        if not wiz.workingURL(depzip) == True:
                            wiz.createTemp(depends)
                            if KODIV >= 17: wiz.addonDatabase(depends, 1)
                            continue
                    lib=os.path.join(PACKAGES, '%s.zip' % depends)
                    try: os.remove(lib)
                    except: pass
                    DP.update(0, '[COLOR %s][B]Downloading Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends),'', 'Please Wait')
                    downloader.download(depzip, lib, DP)
                    xbmc.sleep(100)
                    title = '[COLOR %s][B]Installing Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends)
                    DP.update(0, title,'', 'Please Wait')
                    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
                    if KODIV >= 17: wiz.addonDatabase(depends, 1)
                    installed(depends)
                    installDep(depends)
                    xbmc.sleep(100)
                    DP.close()
                '''
                
def installed(addon):
    url = os.path.join(ADDONS,addon,'addon.xml')
    if os.path.exists(url):
        try:
            list  = open(url,mode='r'); g = list.read(); list.close()
            name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': addon})
            icon  = os.path.join(ADDONS,addon,'icon.png')
            wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, name[0]), '[COLOR %s]Addon Enabled[/COLOR]' % COLOR2, '2000', icon)
        except: pass

def youtubeMenu(url=None):
    if not YOUTUBEFILE == 'http://':
        if url == None:
            YOUTUBEWORKING  = wiz.workingURL(YOUTUBEFILE)
            TEMPYOUTUBEFILE = uservar.YOUTUBEFILE
        else:
            YOUTUBEWORKING  = wiz.workingURL(url)
            TEMPYOUTUBEFILE = url
        if YOUTUBEWORKING == True:
            link = wiz.openURL(TEMPYOUTUBEFILE).replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                for name, section, url, icon, fanart, description in match:
                    if section.lower() == "yes":
                        addDir ("[B]%s[/B]" % name, 'youtube', url, description=description, icon=ICON, fanart=FANART, themeit=THEME3)
                    else:
                        addFile(name, 'viewVideo', url=url, description=description, icon=ICON, fanart=FANART, themeit=THEME2)
            else: wiz.log("[YouTube Menu] ERROR: Invalid Format.")
        else: 
            wiz.log("[YouTube Menu] ERROR: URL for YouTube list not working.")
            addFile('Url for txt file not valid', '', themeit=THEME3)
            addFile('%s' % YOUTUBEWORKING, '', themeit=THEME3)
    else: wiz.log("[YouTube Menu] No YouTube list added.")
    setView('files', 'viewType')

def advancedWindow(url=None):
    if not ADVANCEDFILE == 'http://':
        if url == None:
            ADVANCEDWORKING = wiz.workingURL(ADVANCEDFILE)
            TEMPADVANCEDFILE = uservar.ADVANCEDFILE
        else:
            ADVANCEDWORKING  = wiz.workingURL(url)
            TEMPADVANCEDFILE = url
        addFile('Quick Configure AdvancedSettings.xml', 'autoadvanced', icon=ICONMAINT, themeit=THEME3)
        if os.path.exists(ADVANCED): 
            addFile('View Currect AdvancedSettings.xml', 'currentsettings', icon=ICONMAINT, themeit=THEME3)
            addFile('Remove Currect AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEME3)
        if ADVANCEDWORKING == True:
            #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONMAINT, themeit=THEME6)
            if HIDESPACERS == 'No': addFile(wiz.sep('ADVANCEDSETTINGS TXT'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
            link = wiz.openURL(TEMPADVANCEDFILE).replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                for name, section, url, icon, fanart, description in match:
                    if section.lower() == "yes":
                        addDir ("[B]%s[/B]" % name, 'advancedsetting', url, description=description, icon=ICON, fanart=FANART, themeit=THEME3)
                    else:
                        addFile(name, 'writeadvanced', name, url, description=description, icon=ICON, fanart=FANART, themeit=THEME2)
            else: wiz.log("[Advanced Settings] ERROR: Invalid Format.")
        else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING)
    else: wiz.log("[Advanced Settings] not Enabled")

def writeAdvanced(name, url):
    # add sql
    ADVANCEDWORKING = wiz.workingURL(url)
    if ADVANCEDWORKING == True:
        if os.path.exists(ADVANCED): choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Overwrite[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        else: choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Install[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")

        if choice == 1:
            file = wiz.openURL(url)
            f = open(ADVANCED, 'w'); 
            f.write(file)
            f.close()
            DIALOG.ok(ADDONTITLE, '[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]' % COLOR2)
            wiz.killxbmc(True)
        else: wiz.log("[Advanced Settings] install canceled"); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]Write Cancelled![/COLOR]" % COLOR2); return
    else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]URL Not Working[/COLOR]" % COLOR2)

def viewAdvanced():
    f = open(ADVANCED)
    a = f.read().replace('\t', '    ')
    wiz.TextBox(ADDONTITLE, a)
    f.close()

def removeAdvanced():
    if os.path.exists(ADVANCED):
        wiz.removeFile(ADVANCED)
    else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")

def showAutoAdvanced():
    notify.autoConfig()
'''
def getIP():
    site  = 'http://whatismyipaddress.com/'
    if not wiz.workingURL(site): return 'Unknown', 'Unknown', 'Unknown'
    page  = wiz.openURL(site).replace('\n','').replace('\r','')
    if not 'Access Denied' in page:
        ipmatch   = re.compile('whatismyipaddress.com/ip/(.+?)"').findall(page)
        ipfinal   = ipmatch[0] if (len(ipmatch) > 0) else 'Unknown'
        details   = re.compile('"font-size:14px;">(.+?)</td>').findall(page)
        provider  = details[0] if (len(details) > 0) else 'Unknown'
        location  = details[1]+', '+details[2]+', '+details[3] if (len(details) > 2) else 'Unknown'
        return ipfinal, provider, location
    else: return 'Unknown', 'Unknown', 'Unknown'
'''
# bad ip test
def systemInfo():
    infoLabel = ['System.FriendlyName', 
                 'System.BuildVersion', 
                 'System.CpuUsage',
                 'System.ScreenMode',
                 'Network.IPAddress',
                 'Network.MacAddress',
                 'System.Uptime',
                 'System.TotalUptime',
                 'System.FreeSpace',
                 'System.UsedSpace',
                 'System.TotalSpace',
                 'System.Memory(free)',
                 'System.Memory(used)',
                 'System.Memory(total)']
    data      = []; x = 0
    for info in infoLabel:
        temp = wiz.getInfo(info)
        y = 0
        while temp == "Busy" and y < 10:
            temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(200)
        data.append(temp)
        x += 1
    storage_free  = data[8] if 'Una' in data[8] else wiz.convertSize(int(float(data[8][:-8]))*1024*1024)
    storage_used  = data[9] if 'Una' in data[9] else wiz.convertSize(int(float(data[9][:-8]))*1024*1024)
    storage_total = data[10] if 'Una' in data[10] else wiz.convertSize(int(float(data[10][:-8]))*1024*1024)
    ram_free      = wiz.convertSize(int(float(data[11][:-2]))*1024*1024)
    ram_used      = wiz.convertSize(int(float(data[12][:-2]))*1024*1024)
    ram_total     = wiz.convertSize(int(float(data[13][:-2]))*1024*1024)
    #exter_ip, provider, location = getIP()
    
    picture = []; music = []; video = []; programs = []; repos = []; scripts = []; skins = []
    
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            prov   = re.compile("<provides>(.+?)</provides>").findall(a)
            if len(prov) == 0:
                if foldername.startswith('skin'): skins.append(foldername)
                if foldername.startswith('repo'): repos.append(foldername)
                else: scripts.append(foldername)
            elif not (prov[0]).find('executable') == -1: programs.append(foldername)
            elif not (prov[0]).find('video') == -1: video.append(foldername)
            elif not (prov[0]).find('audio') == -1: music.append(foldername)
            elif not (prov[0]).find('image') == -1: picture.append(foldername)

    #addFile('[B]Media Center Info:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[0]), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[1]), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, wiz.platform().title()), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[2]), '', icon=ICONMAINT, themeit=THEME3)
    addFile('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[3]), '', icon=ICONMAINT, themeit=THEME3)
    
    #addFile('[B]Uptime:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[6]), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[7]), '', icon=ICONMAINT, themeit=THEME2)
    
    #addFile('[B]Local Storage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_free), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_used), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_total), '', icon=ICONMAINT, themeit=THEME2)
    
    #addFile('[B]Ram Usage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_free), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_used), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_total), '', icon=ICONMAINT, themeit=THEME2)
    
    #addFile('[B]Network:[/B]', '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[4]), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, exter_ip), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, provider), '', icon=ICONMAINT, themeit=THEME2)
    #addFile('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, location), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[5]), '', icon=ICONMAINT, themeit=THEME2)
    
    totalcount = len(picture) + len(music) + len(video) + len(programs) + len(scripts) + len(skins) + len(repos) 
    addFile('[B]Addons([COLOR %s]%s[/COLOR]):[/B]' % (COLOR1, totalcount), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(video))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(programs))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(music))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(picture))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(repos))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(skins))), '', icon=ICONMAINT, themeit=THEME2)
    addFile('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(scripts))), '', icon=ICONMAINT, themeit=THEME2)

def saveMenu():
    on = '[COLOR green]ON[/COLOR]'; off = '[COLOR red]OFF[/COLOR]'
    trakt      = 'true' if KEEPTRAKT     == 'true' else 'false'
    real       = 'true' if KEEPREAL      == 'true' else 'false'
    login      = 'true' if KEEPLOGIN     == 'true' else 'false'
    sources    = 'true' if KEEPSOURCES   == 'true' else 'false'
    advanced   = 'true' if KEEPADVANCED  == 'true' else 'false'
    profiles   = 'true' if KEEPPROFILES  == 'true' else 'false'
    favourites = 'true' if KEEPFAVS      == 'true' else 'false'
    repos      = 'true' if KEEPREPOS     == 'true' else 'false'
    super      = 'true' if KEEPSUPER     == 'true' else 'false'
    whitelist  = 'true' if KEEPWHITELIST == 'true' else 'false'

    addDir ('Keep Trakt Data',               'trakt',                icon=ICONTRAKT, themeit=THEME1)
    addDir ('Keep Real Debrid',              'realdebrid',           icon=ICONREAL,  themeit=THEME1)
    addDir ('Keep Login Info',               'login',                icon=ICONLOGIN, themeit=THEME1)
    addFile('Import Save Data',              'managedata', 'import', icon=ICONSAVE,  themeit=THEME2)
    addFile('Export Save Data',              'managedata', 'export', icon=ICONSAVE,  themeit=THEME2)
    addFile(wiz.sep('Click to toggle settings'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save Trakt: %s' % trakt.replace('true',on).replace('false',off)                       ,'togglesetting', 'keeptrakt',      icon=ICONTRAKT, themeit=THEME9)
    addFile('Save Real Debrid: %s' % real.replace('true',on).replace('false',off)                  ,'togglesetting', 'keepdebrid',     icon=ICONREAL,  themeit=THEME9)
    addFile('Save Login Info: %s' % login.replace('true',on).replace('false',off)                  ,'togglesetting', 'keeplogin',      icon=ICONLOGIN, themeit=THEME9)
    addFile('Keep \'Sources.xml\': %s' % sources.replace('true',on).replace('false',off)           ,'togglesetting', 'keepsources',    icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Profiles.xml\': %s' % profiles.replace('true',on).replace('false',off)         ,'togglesetting', 'keepprofiles',   icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Advancedsettings.xml\': %s' % advanced.replace('true',on).replace('false',off) ,'togglesetting', 'keepadvanced',   icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep \'Favourites.xml\': %s' % favourites.replace('true',on).replace('false',off)     ,'togglesetting', 'keepfavourites', icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep Super Favourites: %s' % super.replace('true',on).replace('false',off)            ,'togglesetting', 'keepsuper',      icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep Installed Repo\'s: %s' % repos.replace('true',on).replace('false',off)           ,'togglesetting', 'keeprepos',      icon=ICONSETTINGS,  themeit=THEME9)
    addFile('Keep My \'WhiteList\': %s' % whitelist.replace('true',on).replace('false',off)        ,'togglesetting', 'keepwhitelist',  icon=ICONSETTINGS,  themeit=THEME9)
    if whitelist == 'true':
        addFile('Edit My Whitelist',        'whitelist', 'edit',   icon=ICONSETTINGS,  themeit=THEME3)
        addFile('View My Whitelist',        'whitelist', 'view',   icon=ICONSETTINGS,  themeit=THEME3)
        addFile('Clear My Whitelist',       'whitelist', 'clear',  icon=ICONSETTINGS,  themeit=THEME3)
        addFile('Import My Whitelist',      'whitelist', 'import', icon=ICONBACKUP,  themeit=THEME3)
        addFile('Export My Whitelist',      'whitelist', 'export', icon=ICONRESTORE,  themeit=THEME3)
    setView('files', 'viewType')

def traktMenu():
    trakt = '[COLOR green]ON[/COLOR]' if KEEPTRAKT == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(TRAKTSAVE) if not TRAKTSAVE == '' else 'Trakt hasnt been saved yet.'
    addFile('[I]Register FREE Account at http://trakt.tv[/I]', '', icon=ICONTRAKT, themeit=THEME3)
    addFile('Save Trakt Data: %s' % trakt, 'togglesetting', 'keeptrakt', icon=ICONTRAKT, themeit=THEME3)
    if KEEPTRAKT == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONTRAKT, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('TRAKT'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Trakt Data',          'savetrakt',    'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Recover All Saved Trakt Data', 'restoretrakt', 'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Import Trakt Data',            'importtrakt',  'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Clear All Saved Trakt Data',   'cleartrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
    addFile('Clear All Addon Data',         'addontrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONTRAKT, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('TRAKT ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for trakt in traktit.ORDER:
        name   = TRAKTID[trakt]['name']
        path   = TRAKTID[trakt]['path']
        saved  = TRAKTID[trakt]['saved']
        file   = TRAKTID[trakt]['file']
        user   = wiz.getS(saved)
        auser  = traktit.traktUser(trakt)
        icon   = TRAKTID[trakt]['icon']   if os.path.exists(path) else ICONTRAKT
        fanart = TRAKTID[trakt]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Trakt', trakt)
        menu2 = createMenu('save', 'Trakt', trakt)
        menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)' %   (ADDON_ID, trakt)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt', trakt, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authtrakt', trakt, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt', trakt, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt', trakt, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=ICON, fanart=FANART, menu=menu2)
    
    setView('files', 'viewType')

def realMenu():
    real = '[COLOR green]ON[/COLOR]' if KEEPREAL == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(REALSAVE) if not REALSAVE == '' else 'Real Debrid hasnt been saved yet.'
    addFile('[I]http://real-debrid.com is a PAID service.[/I]', '', icon=ICONREAL, themeit=THEME3)
    addFile('Save Real Debrid Data: %s' % real, 'togglesetting', 'keepdebrid', icon=ICONREAL, themeit=THEME3)
    if KEEPREAL == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONREAL, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('REAL DEBRID'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Real Debrid Data',          'savedebrid',    'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Recover All Saved Real Debrid Data', 'restoredebrid', 'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Import Real Debrid Data',            'importdebrid',  'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Clear All Saved Real Debrid Data',   'cleardebrid',   'all', icon=ICONREAL,  themeit=THEME3)
    addFile('Clear All Addon Data',               'addondebrid',   'all', icon=ICONREAL,  themeit=THEME3)    
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONREAL, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('REAL DEBRID ACCOUNT ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for debrid in debridit.ORDER:
        name   = DEBRIDID[debrid]['name']
        path   = DEBRIDID[debrid]['path']
        saved  = DEBRIDID[debrid]['saved']
        file   = DEBRIDID[debrid]['file']
        user   = wiz.getS(saved)
        auser  = debridit.debridUser(debrid)
        icon   = DEBRIDID[debrid]['icon']   if os.path.exists(path) else ICONREAL
        fanart = DEBRIDID[debrid]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Debrid', debrid)
        menu2 = createMenu('save', 'Debrid', debrid)
        menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)' %   (ADDON_ID, debrid)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid', debrid, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authdebrid', debrid, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid', debrid, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid', debrid, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=ICON, fanart=FANART, menu=menu2)
    
    setView('files', 'viewType')

def loginMenu():
    login = '[COLOR green]ON[/COLOR]' if KEEPLOGIN == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(LOGINSAVE) if not LOGINSAVE == '' else 'Login data hasnt been saved yet.'
    addFile('[I]Several of these addons are PAID services.[/I]', '', icon=ICONLOGIN, themeit=THEME3)
    addFile('Save Login Data: %s' % login, 'togglesetting', 'keeplogin', icon=ICONLOGIN, themeit=THEME3)
    if KEEPLOGIN == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONLOGIN, themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('LOGIN'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    addFile('Save All Login Data',          'savelogin',    'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Recover All Saved Login Data', 'restorelogin', 'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Import Login Data',            'importlogin',  'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Clear All Saved Login Data',   'clearlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
    addFile('Clear All Addon Data',         'addonlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
    
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONLOGIN, themeit=THEME6)
    if HIDESPACERS == 'No': addFile(wiz.sep('LOGIN'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
    for login in loginit.ORDER:
        name   = LOGINID[login]['name']
        path   = LOGINID[login]['path']
        saved  = LOGINID[login]['saved']
        file   = LOGINID[login]['file']
        user   = wiz.getS(saved)
        auser  = loginit.loginUser(login)
        icon   = LOGINID[login]['icon']   if os.path.exists(path) else ICONLOGIN
        fanart = LOGINID[login]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Login', login)
        menu2 = createMenu('save', 'Login', login)
        menu.append((THEME2 % '%s Settings' % name, 'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)' %   (ADDON_ID, login)))
        
        addFile('[+]-> %s' % name,     '', icon=ICON, fanart=FANART, themeit=THEME3)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=ICON, fanart=FANART, menu=menu)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin', login, icon=ICON, fanart=FANART, menu=menu)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authlogin', login, icon=ICON, fanart=FANART, menu=menu)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin', login, icon=ICON, fanart=FANART, menu=menu2)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin', login, icon=ICON, fanart=FANART, menu=menu2)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=ICON, fanart=FANART, menu=menu2)


    setView('files', 'viewType')

def fixUpdate():
    if KODIV < 17: 
        dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
        try:
            os.remove(dbfile)
        except Exception, e:
            wiz.log("Unable to remove %s, Purging DB" % dbfile)
            wiz.purgeDb(dbfile)
    else:
        xbmc.log("Requested Addons.db be removed but doesnt work in Kod17")

def removeAddonMenu():
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        elif foldername in DEFAULTPLUGINS: continue
        elif foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            match  = wiz.parseDOM(a, 'addon', ret='id')

            addid  = foldername if len(match) == 0 else match[0]
            try: 
                add = xbmcaddon.Addon(id=addid)
                addonnames.append(add.getAddonInfo('name'))
                addonids.append(addid)
            except:
                pass
    if len(addonnames) == 0:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No Addons To Remove[/COLOR]" % COLOR2)
        return
    if KODIV > 16:
        selected = DIALOG.multiselect("%s: Select the addons you wish to remove." % ADDONTITLE, addonnames)
    else:
        selected = []; choice = 0
        tempaddonnames = ["-- Click here to Continue --"] + addonnames
        while not choice == -1:
            choice = DIALOG.select("%s: Select the addons you wish to remove." % ADDONTITLE, tempaddonnames)
            if choice == -1: break
            elif choice == 0: break
            else: 
                choice2 = (choice-1)
                if choice2 in selected:
                    selected.remove(choice2)
                    tempaddonnames[choice] = addonnames[choice2]
                else:
                    selected.append(choice2)
                    tempaddonnames[choice] = "[B][COLOR %s]%s[/COLOR][/B]" % (COLOR1, addonnames[choice2])
    if selected == None: return
    if len(selected) > 0:
        wiz.addonUpdates('set')
        for addon in selected:
            removeAddon(addonids[addon], addonnames[addon], True)

        xbmc.sleep(500)
        
        if INSTALLMETHOD == 1: todo = 1
        elif INSTALLMETHOD == 2: todo = 0
        else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
        if todo == 1: wiz.reloadFix('remove addon')
        else: wiz.addonUpdates('reset'); wiz.killxbmc(True)

def removeAddonDataMenu():
    if os.path.exists(ADDOND):
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data', 'removedata', 'all', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons', 'removedata', 'uninstalled', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data', 'removedata', 'empty', themeit=THEME2)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data' % ADDONTITLE, 'resetaddon', themeit=THEME2)
        #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME6)
        if HIDESPACERS == 'No': addFile(wiz.sep('ADDONS'), '', fanart=FANART, icon=ICONSPACER, themeit=THEME6)
        fold = glob.glob(os.path.join(ADDOND, '*/'))
        for folder in sorted(fold, key = lambda x: x):
            foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
            icon = os.path.join(folder.replace(ADDOND, ADDONS), 'icon.png')
            fanart = os.path.join(folder.replace(ADDOND, ADDONS), 'fanart.png')
            folderdisplay = foldername
            replace = {'audio.':'[COLOR orange][AUDIO] [/COLOR]', 'metadata.':'[COLOR cyan][METADATA] [/COLOR]', 'module.':'[COLOR orange][MODULE] [/COLOR]', 'plugin.':'[COLOR blue][PLUGIN] [/COLOR]', 'program.':'[COLOR orange][PROGRAM] [/COLOR]', 'repository.':'[COLOR gold][REPO] [/COLOR]', 'script.':'[COLOR green][SCRIPT] [/COLOR]', 'service.':'[COLOR green][SERVICE] [/COLOR]', 'skin.':'[COLOR dodgerblue][SKIN] [/COLOR]', 'video.':'[COLOR orange][VIDEO] [/COLOR]', 'weather.':'[COLOR yellow][WEATHER] [/COLOR]'}
            for rep in replace:
                folderdisplay = folderdisplay.replace(rep, replace[rep])
            if foldername in EXCLUDES: folderdisplay = '[COLOR green][B][PROTECTED][/B][/COLOR] %s' % folderdisplay
            else: folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] %s' % folderdisplay
            addFile(' %s' % folderdisplay, 'removedata', foldername, icon=ICON, fanart=FANART, themeit=THEME2)
    else:
        addFile('No Addon data folder found.', '', themeit=THEME3)
    setView('files', 'viewType')

def enableAddons():
    addFile("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]", '', icon=ICONMAINT)
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    x = 0
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        if foldername in DEFAULTPLUGINS: continue
        addonxml = os.path.join(folder, 'addon.xml')
        if os.path.exists(addonxml):
            x += 1
            fold   = folder.replace(ADDONS, '')[1:-1]
            f      = open(addonxml)
            a      = f.read().replace('\n','').replace('\r','').replace('\t','')
            match  = wiz.parseDOM(a, 'addon', ret='id')
            match2 = wiz.parseDOM(a, 'addon', ret='name')
            try:
                pluginid = match[0]
                name = match2[0]
            except:
                continue
            try:
                add    = xbmcaddon.Addon(id=pluginid)
                state  = "[COLOR green][Enabled][/COLOR]"
                goto   = "false"
            except:
                state  = "[COLOR red][Disabled][/COLOR]"
                goto   = "true"
                pass
            icon   = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ICON
            fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else FANART
            addFile("%s %s" % (state, name), 'toggleaddon', fold, goto, icon=ICON, fanart=FANART)
            f.close()
    if x == 0:
        addFile("No Addons Found to Enable or Disable.", '', icon=ICONMAINT)
    setView('files', 'viewType')

def changeFeq():
    feq        = ['Every Startup', 'Every Day', 'Every Three Days', 'Every Weekly']
    change     = DIALOG.select("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]" % COLOR2, feq)
    if not change == -1: 
        wiz.setS('autocleanfeq', str(change))
        wiz.LogNotify('[COLOR %s]Auto Clean Up[/COLOR]' % COLOR1, '[COLOR %s]Fequency Now %s[/COLOR]' % (COLOR2, feq[change]))

def developer():
    addFile('Convert Text Files to 0.1.7',         'converttext',           themeit=THEME3)
    addFile('Test Notifications',                  'testnotify',            themeit=THEME3)
    addFile('Test Update',                         'testupdate',            themeit=THEME3)
    addFile('Test First Run',                      'testfirst',             themeit=THEME3)
    addFile('Test First Run Settings',             'testfirstrun',          themeit=THEME3)
    addFile('Test APk',                            'testapk',               themeit=THEME3)
    
    setView('files', 'viewType')

###########################
###### Build Install ######
###########################
def buildWizard(name, type, theme=None, over=False):
    if over == False:
        testbuild = wiz.checkBuild(name, 'url')
        if testbuild == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Unabled to find build[/COLOR]" % COLOR2)
            return
        testworking = wiz.workingURL(testbuild)
        if testworking == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Build Zip Error: %s[/COLOR]" % (COLOR2, testworking))
            return
    if type == 'gui':
        if name == BUILDNAME:
            if over == True: yes = 1
            else: yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to apply the guifix for:' % COLOR2, '[COLOR %s]%s[/COLOR]?[/COLOR]' % (COLOR1, name), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        else: 
            yes = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, "[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed." % (COLOR2, COLOR1, name), "Would you like to apply the guiFix anyways?.[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        if yes:
            buildzip = wiz.checkBuild(name,'gui')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]' % COLOR2); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading GuiFix:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
            try: os.remove(lib)
            except: pass
            #download(buildzip, lib, DP)
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
            DP.update(0, title,'', 'Please Wait')
            extract.all(lib,USERDATA,DP, title=title)
            DP.close()
            wiz.defaultSkin()
            wiz.lookandFeelData('save')
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Gui fix has been installed.  Would you like to Reload the profile or Force Close Kodi?[/COLOR]" % COLOR2, yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix()
            else: DIALOG.ok(ADDONTITLE, "[COLOR %s]To save changes you now need to force close Kodi, Press OK to force close Kodi[/COLOR]" % COLOR2); wiz.killxbmc('true')
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Cancelled![/COLOR]' % COLOR2)
    elif type == 'fresh':
        freshStart(name)
    elif type == 'normal':
        if url == 'normal':
            if KEEPTRAKT == 'true':
                traktit.autoUpdate('all')
                wiz.setS('traktlastsave', str(THREEDAYS))
            if KEEPREAL == 'true':
                debridit.autoUpdate('all')
                wiz.setS('debridlastsave', str(THREEDAYS))
            if KEEPLOGIN == 'true':
                loginit.autoUpdate('all')
                wiz.setS('loginlastsave', str(THREEDAYS))
        temp_kodiv = int(KODIV); buildv = int(float(wiz.checkBuild(name, 'kodi')))
        if not temp_kodiv == buildv: 
            if temp_kodiv == 16 and buildv <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            yes_pressed = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, '[COLOR %s]There is a chance that the skin will not appear correctly' % COLOR2, 'When installing a %s build on a Kodi %s install' % (wiz.checkBuild(name, 'kodi'), KODIV), 'Would you still like to install: [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        else:
            if not over == False: yes_pressed = 1
            else: yes_pressed = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to Download and Install:' % COLOR2, '[COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        if yes_pressed:
            wiz.clearS('build')
            buildzip = wiz.checkBuild(name, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Build Install: Invalid Zip Url![/COLOR]' % COLOR2); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version')),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            #download(buildzip, lib, DP)
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            if int(float(percent)) > 0:
                wiz.fixmetas()
                #wiz.lookandFeelData('save')
                wiz.defaultSkin()
                #wiz.addonUpdates('set')
                wiz.setS('buildname', name)
                wiz.setS('buildversion', wiz.checkBuild( name,'version'))
                wiz.setS('buildtheme', '')
                wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                wiz.setS('lastbuildcheck', str(NEXTCHECK))
                wiz.setS('installed', 'true')
                wiz.setS('extract', str(percent))
                wiz.setS('errors', str(errors))
                wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
                try: os.remove(lib)
                except: pass
                if int(float(errors)) > 0:
                    yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild( name,'version')), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]', yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
                    if yes:
                        if isinstance(errors, unicode):
                            error = error.encode('utf-8')
                        wiz.TextBox(ADDONTITLE, error)
                DP.close()
                themefile = wiz.themeCount(name)
                if not themefile == False:
                    buildWizard(name, 'theme')
                if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
                if INSTALLMETHOD == 1: todo = 1
                elif INSTALLMETHOD == 2: todo = 0
                else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
                if todo == 1: wiz.reloadFix()
                else: wiz.killxbmc(True)
            else:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox("%s: Error Installing Build" % ADDONTITLE, error)
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Build Install: Cancelled![/COLOR]' % COLOR2)
    elif type == 'theme':
        if theme == None:
            themefile = wiz.checkBuild(name, 'theme')
            themelist = []
            if not themefile == 'http://' and wiz.workingURL(themefile) == True:
                themelist = wiz.themeCount(name, False)
                if len(themelist) > 0:
                    if DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes" % (COLOR2, COLOR1, name, COLOR1, len(themelist)), "Would you like to install one now?[/COLOR]", yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]"):
                        wiz.log("Theme List: %s " % str(themelist))
                        ret = DIALOG.select(ADDONTITLE, themelist)
                        wiz.log("Theme install selected: %s" % ret)
                        if not ret == -1: theme = themelist[ret]; installtheme = True
                        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
            else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: None Found![/COLOR]' % COLOR2)
        else: installtheme = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to install the theme:' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, theme), 'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
        if installtheme:
            themezip = wiz.checkTheme(name, theme, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(themezip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]' % COLOR2); return False
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            #download(themezip, lib, DP)
            downloader.download(themezip, lib, DP)
            xbmc.sleep(500)
            DP.update(0,"", "Installing %s " % name)
            test = False
            if url not in ["fresh", "normal"]:
                test = testTheme(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                test2 = testGui(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                if test == True:
                    wiz.lookandFeelData('save')
                    skin     = 'skin.confluence' if KODIV < 17 else 'skin.estuary'
                    gotoskin = xbmc.getSkinDir()
                    #if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Installing the theme [COLOR %s]%s[/COLOR] requires the skin to be swaped back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, theme, COLOR1, skin[5:]), "Would you like to switch the skin?[/COLOR]", yeslabel="[B][COLOR green]Switch Skin[/COLOR][/B]", nolabel="[B][COLOR red]Don't Switch[/COLOR][/B]"):
                    skinSwitch.swapSkins(skin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)
                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                    xbmc.sleep(500)
            title = '[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme)
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            wiz.setS('buildtheme', theme)
            wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
            DP.close()
            if url not in ["fresh", "normal"]: 
                wiz.forceUpdate()
                if KODIV >= 17: wiz.kodi17Fix()
                if test2 == True:
                    wiz.lookandFeelData('save')
                    wiz.defaultSkin()
                    gotoskin = wiz.getS('defaultskin')
                    skinSwitch.swapSkins(gotoskin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)

                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    wiz.lookandFeelData('restore')
                elif test == True:
                    skinSwitch.swapSkins(gotoskin)
                    x = 0
                    xbmc.sleep(1000)
                    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                        x += 1
                        xbmc.sleep(200)

                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        wiz.ebi('SendClick(11)')
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
                    wiz.lookandFeelData('restore')
                else:
                    wiz.ebi("ReloadSkin()")
                    xbmc.sleep(1000)
                    wiz.ebi("Container.Refresh") 
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2)

def thirdPartyInstall(name, url):
    if not wiz.workingURL(url):
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Invalid URL for Build[/COLOR]' % COLOR2); return
    type = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]" % (COLOR2, COLOR1, COLOR1), "[COLOR %s]%s[/COLOR]" % (COLOR1, name), yeslabel="[B][COLOR green]Fresh Install[/COLOR][/B]", nolabel="[B][COLOR red]Normal Install[/COLOR][/B]")
    if type == 1:
        freshStart('third', True)
    wiz.clearS('build')
    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'Please Wait')
    lib=os.path.join(PACKAGES, '%s.zip' % zipname)
    try: os.remove(lib)
    except: pass
    #download(url, lib, DP)
    downloader.download(url, lib, DP)
    xbmc.sleep(500)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
    DP.update(0, title,'', 'Please Wait')
    percent, errors, error = extract.all(lib,HOME,DP, title=title)
    if int(float(percent)) > 0:
        wiz.fixmetas()
        wiz.lookandFeelData('save')
        wiz.defaultSkin()
        #wiz.addonUpdates('set')
        wiz.setS('installed', 'true')
        wiz.setS('extract', str(percent))
        wiz.setS('errors', str(errors))
        wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
        try: os.remove(lib)
        except: pass
        if int(float(errors)) > 0:
            yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
            if yes:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox(ADDONTITLE, error)
    DP.close()
    if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
    if INSTALLMETHOD == 1: todo = 1
    elif INSTALLMETHOD == 2: todo = 0
    else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
    if todo == 1: wiz.reloadFix()
    else: wiz.killxbmc(True)

def testTheme(path):
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        if '/settings.xml' in item.filename:
            return True
    return False

def testGui(path):
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        if '/guisettings.xml' in item.filename:
            return True
    return False

def apkInstaller(apk, url):
    wiz.log(apk)
    wiz.log(url)
    if wiz.platform() == 'android':
        yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install:" % COLOR2, "[COLOR %s]%s[/COLOR]" % (COLOR1, apk), yeslabel="[B][COLOR green]Download[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        if not yes: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ERROR: Install Cancelled[/COLOR]' % COLOR2); return
        display = apk
        if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
        if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]' % COLOR2); return
        DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, display),'', 'Please Wait')
        lib=os.path.join(PACKAGES, "%s.apk" % apk.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', ''))
        try: os.remove(lib)
        except: pass
        #download(url, lib, DP)
        downloader.download(url, lib, DP)
        xbmc.sleep(100)
        DP.close()
        notify.apkInstaller(apk)
        wiz.ebi('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ERROR: None Android Device[/COLOR]' % COLOR2)

###########################
###### Misc Functions######
###########################
def createMenu(type, add, name):
    if   type == 'saveaddon':
        menu_items=[]
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEME2 % name.title(),             ' '))
        menu_items.append((THEME3 % 'Save %s Data' % add3,               'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Restore %s Data' % add3,            'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Clear %s Data' % add3,              'RunPlugin(plugin://%s/?mode=clear%s&name=%s)' %   (ADDON_ID, add2, name2)))
    elif type == 'save'    :
        menu_items=[]
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEME2 % name.title(),             ' '))
        menu_items.append((THEME3 % 'Register %s' % add3,                'RunPlugin(plugin://%s/?mode=auth%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Save %s Data' % add3,               'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Restore %s Data' % add3,            'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Import %s Data' % add3,             'RunPlugin(plugin://%s/?mode=import%s&name=%s)' %  (ADDON_ID, add2, name2)))
        menu_items.append((THEME3 % 'Clear Addon %s Data' % add3,        'RunPlugin(plugin://%s/?mode=addon%s&name=%s)' %   (ADDON_ID, add2, name2)))
    elif type == 'install'  :
        menu_items=[]
        name2 = urllib.quote_plus(name)
        menu_items.append((THEME2 % name,                                'RunAddon(%s, ?mode=viewbuild&name=%s)'  % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Fresh Install',                     'RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'  % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Normal Install',                    'RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)' % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Apply guiFix',                      'RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'    % (ADDON_ID, name2)))
        menu_items.append((THEME3 % 'Build Information',                 'RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'  % (ADDON_ID, name2)))
    menu_items.append((THEME2 % '%s Settings' % ADDONTITLE,              'RunPlugin(plugin://%s/?mode=settings)' % ADDON_ID))
    return menu_items

def toggleCache(state):
    cachelist = ['includevideo', 'includeall', 'include1channel', 'includealluc', 'includebennu', 'includebobunleashed', 'includebubbles', 'includecovenant', 'includeelysium', 'includeexodus', 'includegurzil', 'includeicefilms', 'includespecto', 'includetinklepad', 'includeugottoc', 'includexxxodus', 'includesalts', 'includealluc', 'includeonechannel', 'includeugottoc']
    titlelist = ['Include Video Addons', 'Include All Addons', 'Include 1Channel', 'Include Alluc', 'Include Bennu', 'Include BOB Unleashed', 'Include Bubbles', 'Include Covenant', 'Include Elysium', 'Include Exodus', 'Include Gurzil', 'Include Icefilms', 'Include Specto', 'Include Tinklepad', 'Include UGOTTOC', 'Include XXXODUS', 'Include SALTS', 'Include ALLUC', 'Include ONECHANNEL', 'Include UGOTTOC']
    if state in ['true', 'false']:
        for item in cachelist:
            wiz.setS(item, state)
    else:
        if not state in ['includevideo', 'includeall'] and wiz.getS('includeall') == 'true':
            try:
                item = titlelist[cachelist.index(state)]
                DIALOG.ok(ADDONTITLE, "[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, COLOR1, item))
            except:
                wiz.LogNotify("[COLOR %s]Toggle Cache[/COLOR]" % COLOR1, "[COLOR %s]Invalid id: %s[/COLOR]" % (COLOR2, state))
        else:
            new = 'true' if wiz.getS(state) == 'false' else 'false'
            wiz.setS(state, new)

def playVideo(url):
    if 'watch?v=' in url:
        a, b = url.split('?')
        find = b.split('&')
        for item in find:
            if item.startswith('v='):
                url = item[2:]
                break
            else: continue
    elif 'embed' in url or 'youtu.be' in url:
        a = url.split('/')
        if len(a[-1]) > 5:
            url = a[-1]
        elif len(a[-2]) > 5:
            url = a[-2]
    wiz.log("YouTube URL: %s" % url)
    yt.PlayVideo(url)

def viewLogFile():
    mainlog = wiz.Grab_Log(True)
    oldlog  = wiz.Grab_Log(True, True)
    which = 0; logtype = mainlog
    if not oldlog == False and not mainlog == False:
        which = DIALOG.select(ADDONTITLE, ["View %s" % mainlog.replace(LOG, ""), "View %s" % oldlog.replace(LOG, "")])
        if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
    elif mainlog == False and oldlog == False:
        wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
        return
    elif not mainlog == False: which = 0
    elif not oldlog == False: which = 1
    
    logtype = mainlog if which == 0 else oldlog
    msg     = wiz.Grab_Log(False) if which == 0 else wiz.Grab_Log(False, True)
    
    wiz.TextBox("%s - %s" % (ADDONTITLE, logtype), msg)

def errorChecking(log=None, count=None, all=None):
    if log == None:
        mainlog = wiz.Grab_Log(True)
        oldlog  = wiz.Grab_Log(True, True)
        if not oldlog == False and not mainlog == False:
            which = DIALOG.select(ADDONTITLE, ["View %s: %s error(s)" % (mainlog.replace(LOG, ""), errorChecking(mainlog, True, True)), "View %s: %s error(s)" % (oldlog.replace(LOG, ""), errorChecking(oldlog, True, True))])
            if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
        elif mainlog == False and oldlog == False:
            wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
            return
        elif not mainlog == False: which = 0
        elif not oldlog == False: which = 1
        log = mainlog if which == 0 else oldlog
    if log == False:
        if count == None:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Log File not Found[/COLOR]" % COLOR2)
            return False
        else: 
            return 0
    else:
        if os.path.exists(log):
            f = open(log,mode='r'); a = f.read().replace('\n', '').replace('\r', ''); f.close()
            match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(a)
            if not count == None:
                if all == None: 
                    x = 0
                    for item in match:
                        if ADDON_ID in item: x += 1
                    return x
                else: return len(match)
            if len(match) > 0:
                x = 0; msg = ""
                for item in match:
                    if all == None and not ADDON_ID in item: continue
                    else: 
                        x += 1
                        msg += "[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n" % (x, item.replace('                                          ', '\n').replace('\\\\','\\').replace(HOME, ''))
                if x > 0:
                    wiz.TextBox(ADDONTITLE, msg)
                else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
            else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
        else: wiz.LogNotify(ADDONTITLE, "Log File not Found")
ACTION_PREVIOUS_MENU             =  10    ## ESC action
ACTION_NAV_BACK                 =  92    ## Backspace action
ACTION_MOVE_LEFT                =   1    ## Left arrow key
ACTION_MOVE_RIGHT                 =   2    ## Right arrow key
ACTION_MOVE_UP                     =   3    ## Up arrow key
ACTION_MOVE_DOWN                 =   4    ## Down arrow key
ACTION_MOUSE_WHEEL_UP             = 104    ## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN            = 105    ## Mouse wheel down
ACTION_MOVE_MOUSE                 = 107    ## Down arrow key
ACTION_SELECT_ITEM                =   7    ## Number Pad Enter
ACTION_BACKSPACE                = 110    ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108

def LogViewer(default=None):
    class LogViewer(xbmcgui.WindowXMLDialog):
        def __init__(self,*args,**kwargs):
            self.default = kwargs['default']

        def onInit(self):
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.upload     = 201
            self.kodi       = 202
            self.kodiold    = 203
            self.wizard     = 204 
            self.okbutton   = 205 
            f = open(self.default, 'r')
            self.logmsg = f.read()
            f.close()
            self.titlemsg = "%s: %s" % (ADDONTITLE, self.default.replace(LOG, '').replace(ADDONDATA, ''))
            self.showdialog()

        def showdialog(self):
            self.getControl(self.title).setLabel(self.titlemsg)
            self.getControl(self.msg).setText(wiz.highlightText(self.logmsg))
            self.setFocusId(self.scrollbar)
            
        def onClick(self, controlId):
            if   controlId == self.okbutton: self.close()
            elif controlId == self.upload: self.close(); uploadLog.Main()
            elif controlId == self.kodi:
                newmsg = wiz.Grab_Log(False)
                filename = wiz.Grab_Log(True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.kodiold:  
                newmsg = wiz.Grab_Log(False, True)
                filename = wiz.Grab_Log(True, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.wizard:
                newmsg = wiz.Grab_Log(False, False, True)
                filename = wiz.Grab_Log(True, False, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(ADDONDATA, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
        
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    if default == None: default = wiz.Grab_Log(True)
    lv = LogViewer( "LogViewer.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', default=default)
    lv.doModal()
    del lv

def removeAddon(addon, name, over=False):
    if not over == False:
        yes = 1
    else: 
        yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Are you sure you want to delete the addon:'% COLOR2, 'Name: [COLOR %s]%s[/COLOR]' % (COLOR1, name), 'ID: [COLOR %s]%s[/COLOR][/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Addon[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
    if yes == 1:
        folder = os.path.join(ADDONS, addon)
        wiz.log("Removing Addon %s" % addon)
        wiz.cleanHouse(folder)
        xbmc.sleep(200)
        try: shutil.rmtree(folder)
        except Exception ,e: wiz.log("Error removing %s" % addon, xbmc.LOGNOTICE)
        removeAddonData(addon, name, over)
    if over == False:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]%s Removed[/COLOR]" % (COLOR2, name))

def removeAddonData(addon, name=None, over=False):
    if addon == 'all':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            wiz.cleanHouse(ADDOND)
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    elif addon == 'uninstalled':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = 0
            for folder in glob.glob(os.path.join(ADDOND, '*')):
                foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
                if foldername in EXCLUDES: pass
                elif os.path.exists(os.path.join(ADDONS, foldername)): pass
                else: wiz.cleanHouse(folder); total += 1; wiz.log(folder); shutil.rmtree(folder)
            wiz.LogNotify('[COLOR %s]Clean up Uninstalled[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    elif addon == 'empty':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = wiz.emptyfolder(ADDOND)
            wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
        else: wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
    else:
        addon_data = os.path.join(USERDATA, 'addon_data', addon)
        if addon in EXCLUDES:
            wiz.LogNotify("[COLOR %s]Protected Plugin[/COLOR]" % COLOR1, "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % COLOR2)
        elif os.path.exists(addon_data):  
            if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
                wiz.cleanHouse(addon_data)
                try:
                    shutil.rmtree(addon_data)
                except:
                    wiz.log("Error deleting: %s" % addon_data)
            else: 
                wiz.log('Addon data for %s was not removed' % addon)
    wiz.refresh()

def restoreit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Local Restore Cancelled[/COLOR]" % COLOR2); return
    if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
        wiz.skinToDefault()
    wiz.restoreLocal(type)

def restoreextit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]External Restore Cancelled[/COLOR]" % COLOR2); return
    wiz.restoreExternal(type)

def buildInfo(name):
    if wiz.workingURL(BUILDFILE) == True:
        if wiz.checkBuild(name, 'url'):
            name, version, url, gui, kodi, theme, icon, fanart, preview, adult, description = wiz.checkBuild(name, 'all')
            adult = 'Yes' if adult.lower() == 'yes' else 'No'
            msg  = "[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, name)
            msg += "[COLOR %s]Build Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, version)
            if not theme == "http://":
                themecount = wiz.themeCount(name, False)
                msg += "[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, ', '.join(themecount))
            msg += "[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, kodi)
            msg += "[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, adult)
            msg += "[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, description)
            wiz.TextBox(ADDONTITLE, msg)
        else: wiz.log("Invalid Build Name!")
    else: wiz.log("Build text file not working: %s" % WORKINGURL)

def buildVideo(name):
    if wiz.workingURL(BUILDFILE) == True:
        videofile = wiz.checkBuild(name, 'preview')
        if videofile and not videofile == 'http://': playVideo(videofile)
        else: wiz.log("[%s]Unable to find url for video preview" % name)
    else: wiz.log("Build text file not working: %s" % WORKINGURL)

def dependsList(plugin):
    addonxml = os.path.join(ADDONS, plugin, 'addon.xml')
    if os.path.exists(addonxml):
        source = open(addonxml,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        items  = []
        for depends in match:
            if not 'xbmc.python' in depends:
                items.append(depends)
        return items
    return []

def manageSaveData(do):
    if do == 'import':
        TEMP = os.path.join(ADDONDATA, 'temp')
        if not os.path.exists(TEMP): os.makedirs(TEMP)
        source = DIALOG.browse(1, '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % COLOR2, 'files', '.zip', False, False, HOME)
        if not source.endswith('.zip'):
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Import Data Error![/COLOR]" % (COLOR2))
            return
        tempfile = os.path.join(MYBUILDS, 'SaveData.zip')
        goto = xbmcvfs.copy(source, tempfile)
        wiz.log("%s" % str(goto))
        extract.all(xbmc.translatePath(tempfile), TEMP)
        trakt  = os.path.join(TEMP, 'trakt')
        login  = os.path.join(TEMP, 'login')
        debrid = os.path.join(TEMP, 'debrid')
        x = 0
        if os.path.exists(trakt):
            x += 1
            files = os.listdir(trakt)
            if not os.path.exists(traktit.TRAKTFOLD): os.makedirs(traktit.TRAKTFOLD)
            for item in files:
                old  = os.path.join(traktit.TRAKTFOLD, item)
                temp = os.path.join(trakt, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            traktit.importlist('all')
            traktit.traktIt('restore', 'all')
        if os.path.exists(login):
            x += 1
            files = os.listdir(login)
            if not os.path.exists(loginit.LOGINFOLD): os.makedirs(loginit.LOGINFOLD)
            for item in files:
                old  = os.path.join(loginit.LOGINFOLD, item)
                temp = os.path.join(login, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            loginit.importlist('all')
            loginit.loginIt('restore', 'all')
        if os.path.exists(debrid):
            x += 1
            files = os.listdir(debrid)
            if not os.path.exists(debridit.REALFOLD): os.makedirs(debridit.REALFOLD)
            for item in files:
                old  = os.path.join(debridit.REALFOLD, item)
                temp = os.path.join(debrid, item)
                if os.path.exists(old):
                    if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                    else: os.remove(old)
                shutil.copy(temp, old)
            debridit.importlist('all')
            debridit.debridIt('restore', 'all')
        wiz.cleanHouse(TEMP)
        wiz.removeFolder(TEMP)
        os.remove(tempfile)
        if x == 0: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Failed[/COLOR]" % COLOR2)
        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Complete[/COLOR]" % COLOR2)
    elif do == 'export':
        mybuilds = xbmc.translatePath(MYBUILDS)
        dir = [traktit.TRAKTFOLD, debridit.REALFOLD, loginit.LOGINFOLD]
        traktit.traktIt('update', 'all')
        loginit.loginIt('update', 'all')
        debridit.debridIt('update', 'all')
        source = DIALOG.browse(3, '[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]' % COLOR2, 'files', '', False, True, HOME)
        source = xbmc.translatePath(source)
        tempzip = os.path.join(mybuilds, 'SaveData.zip')
        zipf = zipfile.ZipFile(tempzip, mode='w')
        for fold in dir:
            if os.path.exists(fold):
                files = os.listdir(fold)
                for file in files:
                    zipf.write(os.path.join(fold, file), os.path.join(fold, file).replace(ADDONDATA, ''), zipfile.ZIP_DEFLATED)
        zipf.close()
        if source == mybuilds:
            DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))
        else:
            try:
                xbmcvfs.copy(tempzip, os.path.join(source, 'SaveData.zip'))
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, os.path.join(source, 'SaveData.zip')))
            except:
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))

###########################
###### Fresh Install ######
###########################
def freshStart(install=None, over=False):
    if KEEPTRAKT == 'true':
        traktit.autoUpdate('all')
        wiz.setS('traktlastsave', str(THREEDAYS))
    if KEEPREAL == 'true':
        debridit.autoUpdate('all')
        wiz.setS('debridlastsave', str(THREEDAYS))
    if KEEPLOGIN == 'true':
        loginit.autoUpdate('all')
        wiz.setS('loginlastsave', str(THREEDAYS))
    if over == True: yes_pressed = 1
    elif install == 'restore': yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings", "Before installing the local backup?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    elif install: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings", "Before installing [COLOR %s]%s[/COLOR]?" % (COLOR1, install), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    else: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    if yes_pressed:
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            skin = 'skin.confluence' if KODIV < 17 else 'skin.estuary'
            #yes=DIALOG.yesno(ADDONTITLE, "[COLOR %s]The skin needs to be set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, skin[5:]), "Before doing a fresh install to clear all Texture files,", "Would you like us to do that for you?[/COLOR]", yeslabel="[B][COLOR green]Switch Skins[/COLOR][/B]", nolabel="[B][COLOR red]I'll Do It[/COLOR][/B]";
            #if yes:
            skinSwitch.swapSkins(skin)
            x = 0
            xbmc.sleep(1000)
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                x += 1
                xbmc.sleep(200)
                wiz.ebi('SendAction(Select)')
            if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                wiz.ebi('SendClick(11)')
            else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return False
            xbmc.sleep(1000)
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Failed![/COLOR]' % COLOR2)
            return
        wiz.addonUpdates('set')
        xbmcPath=os.path.abspath(HOME)
        DP.create(ADDONTITLE,"[COLOR %s]Calculating files and folders" % COLOR2,'', 'Please Wait![/COLOR]')
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
        DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
        EXCLUDES.append('My_Builds')
        EXCLUDES.append('archive_cache')
        if KEEPREPOS == 'true':
            repos = glob.glob(os.path.join(ADDONS, 'repo*/'))
            for item in repos:
                repofolder = os.path.split(item[:-1])[1]
                if not repofolder == EXCLUDES:
                    EXCLUDES.append(repofolder)
        if KEEPSUPER == 'true':
            EXCLUDES.append('plugin.program.super.favourites')
        if KEEPWHITELIST == 'true':
            pvr = ''
            whitelist = wiz.whiteList('read')
            if len(whitelist) > 0:
                for item in whitelist:
                    try: name, id, fold = item
                    except: pass
                    if fold.startswith('pvr'): pvr = id 
                    depends = dependsList(fold)
                    for plug in depends:
                        if not plug in EXCLUDES:
                            EXCLUDES.append(plug)
                        depends2 = dependsList(plug)
                        for plug2 in depends2:
                            if not plug2 in EXCLUDES:
                                EXCLUDES.append(plug2)
                    if not fold in EXCLUDES:
                        EXCLUDES.append(fold)
                if not pvr == '': wiz.setS('pvrclient', fold)
        if wiz.getS('pvrclient') == '':
            for item in EXCLUDES:
                if item.startswith('pvr'):
                    wiz.setS('pvrclient', item)
        DP.update(0, "[COLOR %s]Clearing out files and folders:" % COLOR2)
        latestAddonDB = wiz.latestDB('Addons')
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                del_file += 1
                fold = root.replace('/','\\').split('\\')
                x = len(fold)-1
                if name == 'sources.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep Sources: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'favourites.xml' and fold[-1] == 'userdata' and KEEPFAVS == 'true': wiz.log("Keep Favourites: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'profiles.xml' and fold[-1] == 'userdata' and KEEPPROFILES == 'true': wiz.log("Keep Profiles: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'advancedsettings.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep Advanced Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name in LOGFILES: wiz.log("Keep Log File: %s" % name, xbmc.LOGNOTICE)
                elif name.endswith('.db'):
                    try:
                        if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), xbmc.LOGNOTICE)
                        else: os.remove(os.path.join(root,name))
                    except Exception, e: 
                        if not name.startswith('Textures13'):
                            wiz.log('Failed to delete, Purging DB', xbmc.LOGNOTICE)
                            wiz.log("-> %s" % (str(e)), xbmc.LOGNOTICE)
                            wiz.purgeDb(os.path.join(root,name))
                else:
                    DP.update(int(wiz.percentage(del_file, total_files)), '', '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '')
                    try: os.remove(os.path.join(root,name))
                    except Exception, e: 
                        wiz.log("Error removing %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                        wiz.log("-> / %s" % (str(e)), xbmc.LOGNOTICE)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
                return False
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in dirs:
                DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name), '')
                if name not in ["Database","userdata","temp","addons","addon_data"]:
                    shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
                return False
        DP.close()
        wiz.clearS('build')
        if over == True:
            return True
        elif install == 'restore': 
            return True
        elif install: 
            buildWizard(install, 'normal', over=True)
        else:
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix('fresh')
            else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
    else: 
        if not install == 'restore':
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Cancelled![/COLOR]' % COLOR2)
            wiz.refresh()

#############################
###DELETE CACHE##############
####THANKS GUYS @ NaN #######
def clearCache():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Clear Cache[/COLOR][/B]'):
        wiz.clearCache()

def totalClean():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
        wiz.clearCache()
        wiz.clearPackages('total')
        clearThumb('total')

def clearThumb(type=None):
    latest = wiz.latestDB('Textures')
    if not type == None: choice = 1
    else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
    if choice == 1:
        try: wiz.removeFile(os.join(DATABASE, latest))
        except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
        wiz.removeFolder(THUMBS)
        #if not type == 'total': wiz.killxbmc()
    else: wiz.log('Clear thumbnames cancelled')
    wiz.redoThumbs()

def purgeDb():
    DB = []; display = []
    for dirpath, dirnames, files in os.walk(HOME):
        for f in fnmatch.filter(files, '*.db'):
            if f != 'Thumbs.db':
                found = os.path.join(dirpath, f)
                DB.append(found)
                dir = found.replace('\\', '/').split('/')
                display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
    if KODIV >= 16: 
        choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
        if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        else: 
            for purge in choice: wiz.purgeDb(DB[purge])
    else:
        choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
        if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
        else: wiz.purgeDb(DB[purge])

##########################
### DEVELOPER MENU #######
##########################
def testnotify():
    url = wiz.workingURL(NOTIFICATION)
    if url == True:
        try:
            id, msg = wiz.splitNotify(NOTIFICATION)
            if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Notification: Not Formated Correctly[/COLOR]" % COLOR2); return
            notify.notification(msg, True)
        except Exception, e:
            wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Invalid URL for Notification[/COLOR]" % COLOR2)

def testupdate():
    if BUILDNAME == "":
        notify.updateWindow()
    else:
        notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))

def testfirst():
    notify.firstRun()

def testfirstRun():
    notify.firstRunSettings()

####################################################
### END MAIN ADDON #######
####################################################





###########################
###### index_zipinstaller #
###########################
def Install_All():
    if DIALOG.yesno('Restore Multiple Addons?', 'Do you want to restore?  This is like a build and will install multiple repos, addons and dependancies.','You may want to Fresh Start or perform a backup first.', '[B][COLOR red]YOU CANNOT GO BACK !!![/B][/COLOR]'):
        if DIALOG.yesno('Restore XML?', 'Restore and overwrite XMLs?','These are small settings and tweaks to .', 'Answer yes if you dont care.'): XML_All()

        # step 1 do addon data settings
        '''
        try:
            #_notify('Addon_Data','Installing Addon_Data', ICON)
            PATH_ADDON(url_addon_data,zips_url+url_addon_data, xbmc.translatePath(os.path.join('special://home','')))
        except: pass
        '''
        # step 2 repos for addon updates
        try:
            #_notify('Repos','Installing Repos',ICON)
            PATH_ADDON(url_addons_repo, zips_url+url_addons_repo, HOME)
            #installAddon(url_addons_repo, zips_url+url_addons_repo)
        except: pass
        # step 3 addons
        if DIALOG.yesno('Restore Programs?', 'Restore Program Addons?','These are programs like trakt that help manage your local library, but are unneeded if you primarily stream things', 'Answer yes if you dont care.'):
            PATH_ADDON(url_addons_program, zips_url+url_addons_program, HOME)
            #installAddon(url_addons_program, zips_url+url_addons_program)
        #ADDONS_ALL()
        '''
        try:
            PATH_ADDON(url_addons_program,zips_url+url_addons_program, HOME)
        except: pass
        '''
        try:
            PATH_ADDON(url_addons_audio, zips_url+url_addons_audio, HOME)
            #installAddon(url_addons_audio, zips_url+url_addons_audio)
        except: pass
        try:
            #_notify('Addons','Installing Video Addons',ICON)
            PATH_ADDON(url_addons_video, zips_url+url_addons_video, HOME)
            #installAddon(url_addons_video, zips_url+url_addons_video)
        except: pass
        # step 4 live tv addons - optional
        if DIALOG.yesno('IPTV?', 'Do you want LiveTV (IPTV)?','Free IPTV', 'Unpredictable'):
            try:
                PATH_ADDON(url_addons_iptv, zips_url+url_addons_iptv, HOME)
                #installAddon(url_addons_iptv, zips_url+url_addons_iptv)
            except: pass
            if DIALOG.yesno('Paid IPTV Subscriptions?', 'Do you pay for LiveTV (IPTV)?','Subscription IPTV', 'Stable'):
                try:
                    PATH_ADDON(url_addons_sub, zips_url+url_addons_sub, HOME)
                    #installAddon(url_addons_sub, zips_url+url_addons_sub)
                except: pass

        # 
        #xbmc.executebuiltin('ActivateWindow(programs,plugin://script.trakt,return)')
        #xbmc.executebuiltin('ActivateWindow(programs,plugin://script.tvguide.fullscreen,return)')
        #xbmc.executebuiltin('ActivateWindow(programs,plugin://script.tvguide.fullscreen.skin.cake,return)')

        # step 5 kodi version specific fixes
        if kodi_version == '18': 
            try:
                PATH_ADDON(url_guisettings_18, zips_url+url_guisettings_18, USERDATA)
                PATH_ADDON(url_theme_18, zips_url+url_theme_18, HOME)
                #installAddon(url_guisettings_18, zips_url+url_guisettings_18)
                #installAddon(url_theme_18, zips_url+url_theme_18)
                EnableRTMP()
                addon_able.setall_enable()
                #Update_Addons()
            except: pass

        elif kodi_version == '17': 
            try:
                PATH_ADDON(url_guisettings_17, zips_url+url_guisettings_17, USERDATA) 
                PATH_ADDON(url_theme_17, zips_url+url_theme_17, HOME)
                #installAddon(url_guisettings_17, zips_url+url_guisettings_17)
                #installAddon(url_theme_17, zips_url+url_theme_17)
                EnableRTMP()
                addon_able.setall_enable()
                #Update_Addons()
            except: pass
            
        elif kodi_version == '16': 
            try:
                PATH_ADDON(url_guisettings_16, zips_url+url_guisettings_16, USERDATA) 
                PATH_ADDON(url_theme_16, zips_url+url_theme_16, HOME)
                #installAddon(url_guisettings_16, zips_url+url_guisettings_16)
                #installAddon(url_theme_16, zips_url+url_theme_16)
            except: pass
            
        '''
        elif kodi_version == '15': 
            try:
                #PATH_ADDON(url_guisettings_15, zips_url+url_guisettings_15, xbmc.translatePath(os.path.join('special://home','addons'))) 
                #PATH_ADDON(url_theme_15, zips_url+url_theme_15, xbmc.translatePath(os.path.join('special://home','addons')))
                installAddon(url_guisettings_15, zips_url+url_guisettings_15)
                installAddon(url_theme_15, zips_url+url_theme_15)
            except: pass
        
        elif kodi_version == '14': 
           try:
                #PATH_ADDON(url_guisettings_14, zips_url+url_guisettings_14, xbmc.translatePath(os.path.join('special://home','addons')))
                #PATH_ADDON(url_theme_14, zips_url+url_theme_14, xbmc.translatePath(os.path.join('special://home','addons')))
                installAddon(url_guisettings_14, zips_url+url_guisettings_14)
                installAddon(url_theme_14, zips_url+url_theme_14)
           except: pass
        '''
        '''
        try:
            if xbmc.getCondVisibility('system.platform.android'): PATH_ADDON('Addons_Android.zip', zips_url+url_addons_program_android, xbmc.translatePath(os.path.join('special://home','addons')))
            if xbmc.getCondVisibility('system.platform.windows'): PATH_ADDON('Addons_Windows.zip', zips_url+url_addons_program_windows, xbmc.translatePath(os.path.join('special://home','addons')))
        except: pass
        '''
        try:  Remove_Packages()
        except: pass
        # restore custom backup
        #install_custom_backupzip()
        # exit
        _notify('Done','Done Installing',ICON) 
        wiz.killxbmc()#Have.beer()
    #
    # If Not installing anything Return to Main Menu
    sys.exit(0)

def PATH_ADDON(name, url, addonfolder):
    #from installer import kodi
    #from installer import addon_able
    path=xbmc.translatePath(os.path.join('special://home','addons','packages'))
    DP=xbmcgui.DialogProgress()
    DP.create(name,'','Downloading and Configuring '+name,'Please Wait')
    lib=os.path.join(path,name)
    try: os.remove(lib)
    except: pass
    if str(url).endswith('[error]'):
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
    if '[error]' in url:
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
            
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
    DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR2)
    percent, errors, error = extract.all(lib, addonfolder, DP, title=title)
    '''
    download(url,lib,DP)
    DP.update(0,'','Extracting '+name+' Please Wait','')
    unzip(lib,addonfolder,DP)
    '''
    try: os.remove(lib)
    except: pass
    xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
    xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
    wiz.refresh()

def install_custom_backupzip():
    if DIALOG.yesno('Your Backup.zip - addon_data', 'Do you wish to restore a custom backup of your addon_data?'):
        choose =  DIALOG.browse(1, 'Select User_data backup.zip', '')
def addon_refresh():
    xbmc.executebuiltin('ActivateWindow(busydialog)')
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')
    time.sleep(1)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Container.Refresh')
def Update_Addons():
    # this will refresh the list of items warning when using this after video playing or dialog box it will send it in to a contentious loop
    #xbmc.executebuiltin('Container.Refresh')
    # this is a great script to user when using a function like login to the update the list result
    #xbmc.executebuiltin('Container.Update')
    # updates you local addon lists
    xbmc.executebuiltin("UpdateLocalAddons")
    #will update addons repo search for all updates 
    xbmc.executebuiltin("UpdateAddonRepos")
def delete_extra_addons(msgtitle,msgtxt,deletethisfullpath): 
    if os.path.exists(deletethisfullpath):
        if not DIALOG.yesno(msgtitle, msgtxt):
            try:
                shutil.rmtree(deletethisfullpath)
            except: pass
def EnableRTMP():
    from resources.lib.installer import addon_able
    try: addon_able.set_enabled("inputstream.adaptive")
    except: pass
    time.sleep(0.5)
    try: addon_able.set_enabled("inputstream.rtmp")
    except: pass
    time.sleep(0.5)
    xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
def Remove_Packages():
    _notify('Packages','Removing Packages',ICON)
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages'))
    for root, dirs, files in os.walk(packages_cache_path):
        file_count = 0
        file_count += len(files)
        # Count files and give option to delete
        if file_count > 0:
            for f in files:
                try:
                    os.unlink(os.path.join(root, f))
                except: pass
            for d in dirs:
                try:
                    shutil.rmtree(os.path.join(root, d))
                except: pass
def Delete_Userdata():
    addon_data_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', ''))
    for root, dirs, files in os.walk(addon_data_path):
        file_count = 0
        file_count += len(files)
    # Count files and give option to delete
        if file_count >= 0:
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                try:
                    shutil.rmtree(os.path.join(root, d))
                except: pass
def themeAddonsInstall():
      print 'test'
      '''
      if DIALOG.yesno(url_addons_program+'  Program Addons', 'Do you wish to install Program Addons?'):
          PATH_ADDON(url_addons_program, zips_url+url_addons_program, xbmc.translatePath(os.path.join('special://home','addons'))); _notify('Done','Done Installing Program Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
      '''
def Repolink():
    #xbmc.executebuiltin('ActivateWindow(10040,addons://'+ADDON_ID+'/,return)')
    xbmc.executebuiltin('ActivateWindow(10040,addons://'+REPOID+'/,return)')
def ReposInstall():
      if DIALOG.yesno(url_addons_repo+'  Repositories', 'Do you wish to install Repos for addon sources and updates?'):
          PATH_ADDON(url_addons_repo, zips_url+url_addons_repo, HOME)
          #installAddon(url_addons_repo, zips_url+url_addons_repo)
          _notify('Done','Done Installing Repos',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def programAddonsInstall():
      if DIALOG.yesno(url_addons_program+'  Program Addons', 'Do you wish to install Program Addons?'):
          PATH_ADDON(url_addons_program, zips_url+url_addons_program, HOME)
          #installAddon(url_addons_program, zips_url+url_addons_program)
          _notify('Done','Done Installing Program Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def audioAddonsInstall():
      if DIALOG.yesno(url_addons_audio+'  Audio Addons', 'Do you wish to install Audio Addons?'):
          PATH_ADDON(url_addons_audio, zips_url+url_addons_audio, HOME)
          #installAddon(url_addons_audio, zips_url+url_addons_audio)
          _notify('Done','Done Installing Audio Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def videoAddonsInstall():
      if DIALOG.yesno(url_addons_video+'  Video Addons', 'Do you wish to install Video Addons?'):
          PATH_ADDON(url_addons_video, zips_url+url_addons_video, HOME)
          #installAddon(url_addons_video, zips_url+url_addons_video)
          _notify('Done','Done Installing Video Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def IPTVAddonsInstall():
      if DIALOG.yesno(url_addons_iptv+'  IPTV (Live TV)', 'Do you wish to install LiveTV Addons (IPTV)?'):
          PATH_ADDON(url_addons_iptv, zips_url+url_addons_iptv, xbmc.translatePath(os.path.join('special://home','addons')))
          #installAddon(url_addons_iptv, zips_url+url_addons_iptv)
          _notify('Done','Done Installing IPTV Video Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def IPTVSubbedAddonsInstall():
      if DIALOG.yesno(url_addons_sub+'  IPTV Subscriptions', 'Do you wish to install Paid LiveTV Addons (IPTV)?'):
          PATH_ADDON(url_addons_sub, zips_url+url_addons_sub, HOME)
          #installAddon(url_addons_sub, zips_url+url_addons_sub)
          _notify('Done','Done Installing Paid IPTV Video Addons',ICON)
          Remove_Packages()
          if kodi_version == '18': addon_able.setall_enable()
          if kodi_version == '17': addon_able.setall_enable()
          Update_Addons()
      sys.exit(0)
def AddonDataInstall():
      if DIALOG.yesno(url_addon_data, 'Do you wish to install Addon_data common user settings?'):
          PATH_ADDON(url_addon_data, zips_url+url_addon_data, xbmc.translatePath(os.path.join('special://profile','addon_data')))
          #installAddon(url_addon_data, zips_url+url_addon_data)
          _notify('Done','Done Installing Addon_Data',ICON)
          #install_custom_backupzip()
      sys.exit(0)


##############################
#   XML All zip installer  ###
##############################
def XML_All():
    choice = DIALOG.select('Choose or Defaults?', ['Install Defaults','Choose each .xml?'])
    if choice == 0:
        _XML(extrapath+'/sources/sources.xml', xbmc.translatePath('special://profile/sources.xml'))
        if kodi_version == '18': _XML(extrapath+'/advancedsettings/advancedsettings17.xml', xbmc.translatePath('special://profile/advancedsettings.xml'))
        if kodi_version == '17': _XML(extrapath+'/advancedsettings/advancedsettings17.xml', xbmc.translatePath('special://profile/advancedsettings.xml'))
        if kodi_version == '16': _XML(extrapath+'/advancedsettings/advancedsettings16.xml', xbmc.translatePath('special://profile/advancedsettings.xml'))
        _XML(extrapath+'/rss/RssFeeds_Full.xml', xbmc.translatePath('special://profile/RssFeeds.xml'))
        if xbmc.getCondVisibility('system.platform.android'): _XML(extrapath+'/playercorefactory/playercorefactory_ANDROID.xml', xbmc.translatePath('special://profile/playercorefactory.xml'))
        if xbmc.getCondVisibility('system.platform.windows'): playerfactorycore_write_config()
    else:
        showAutoAdvanced()
        #index_advancedsettings()
        index_sourcesxml()
        index_playercorefactory()
        _XML(extrapath+'/rss/RssFeeds_Full.xml', xbmc.translatePath('special://profile/RssFeeds.xml'))
        #index_rss()

def _XML(asFile, asDest):
    if os.path.exists(asFile):
        try:
            s=open(asFile).read()
            f=open(asDest,'w')
            f.write(s)
            f.close()
        except: pass


###########################
## blacklist_check     ####
###########################
def blacklist_check():
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in BLACKLIST:
            deldir = xbmc.translatePath(os.path.join('special://home', 'addons', foldername))
            if os.path.exists(deldir):
                yes = DIALOG.yesno('[COLOR red]Blacklisted Addon[/COLOR]', foldername+' is [COLOR red]Blacklisted[/COLOR].  If the addon made it onto this list it is no longer updated or malicious.', 'Would you like to Delete?')
                if not yes: return
                try: shutil.rmtree(deldir)
                except: pass





###########################
###### Main githubbrowse  #
###########################
def github_main(view=None):
    xbmc.log(msg='##['+ADDON_ID+'] **Github Browser XML MENU**', level=xbmc.LOGNOTICE)
    #github_instructions()
    #kodi.addDir('Search by GitHub Username', 'username', 'github_search', ART + 'search_by_username.png', description="Search for addons by Username. Ex. tvaddonsco")
    #kodi.addDir('Search by GitHub Repository Title', 'repo', 'github_search', ART + 'search_by_repository_title.png', description="Search for addons by Repository Name")
    #kodi.addDir('Search GitHub by Addon ID', 'addon_id', 'github_search', ART + 'searchaddonid.png', description="Search for addons by AddonID. Ex. plugin.video.youtube (Advanced)")
    #kodi.addItem('Update Addons', '', 'github_update', ART + 'update_github.png', description="Update GitHub Addons")
    #viewsetter.set_view("sets")
    addDir('Search by GitHub Username', 'github_search_username',   description='Search Github (the common www source of many addons) for a specific Kodi developers user name',  icon=ICONGITHUB, themeit=THEME3)
    addDir('Search by GitHub Repository Title','github_search_repo', icon=ICONGITHUB, themeit=THEME3)
    addDir('Search GitHub by Addon ID','github_search_addon_id',     icon=ICONGITHUB, themeit=THEME3)
    addDir('GitHub Update Addons','github_update',                   icon=ICONSETTINGS, themeit=THEME3)
    addDir('GitHub instructions','github_instructions',              icon=ICONINFO, themeit=THEME3)
    setView('files', 'viewType')

def _get_keyboard(default="", heading="", hidden=False):  # Start Ketboard Function
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return unicode(keyboard.getText(), "utf-8")
    return default

def SEARCHADDON(url):  # Start Search Function
    vq = _get_keyboard(heading="Search add-ons")
    if (not vq):
        return False, 0
    title = urllib.quote_plus(vq)
    Get_search_results(title)

def Get_search_results(title):
    link = api.search_addons(title)
    my_list = sorted(link, key=lambda k: k['name'].upper())
    for e in link:
        name = e['name']
        repourl = e['repodlpath']
        path = e['addon_zip_path']
        description = e['description']
        icon = path.rsplit('/', 1)[0] + '/icon.png'
        fanart = path.rsplit('/', 1)[0] + '/fanart.jpg'
        if e['extension_point'] != 'xbmc.addon.repository':
            try:
                addHELPDir(name, path, 'addoninstall', icon, fanart, description, 'addon', repourl, '', '', CMi, contextreplace=False)
            except:
                pass
    viewsetter.set_view("sets")

def github_search(url):
    q = _get_keyboard("", "Search GitHub")
    if not q: return
    import json
    from resources.lib.github_installer import github_api
    if url == 'username':
        rtype = 'api'
        response = github_api.find_zips(q)
        if response is None: return
        for r in github_api.sort_results(response['items']):
            if not r['path'].endswith(".zip"): continue
            url = github_api.content_url % (r['repository']['full_name'], r['path'])
            kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'repo':
        rtype = 'api'
        results = github_api.search(q, 'title')
        if results is None: return
        for i in results['items']:
            user = i['owner']['login']
            response = github_api.find_zips(user)
            if response is None: continue
            for r in github_api.sort_results(response['items']):
                if not r['path'].endswith(".zip"): continue
                url = github_api.content_url % (r['repository']['full_name'], r['path'])
                kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'addon_id':
        rtype = 'web'
        results = github_api.web_search(q)
    else:
        rtype = 'api'
        results = github_api.search(q)
    if results is None: return
    for r in results['items']:
        if rtype == 'api':
            kodi.addDir(r['name'], json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
        else:
            kodi.addItem("%s/%s" % (r['owner']['login'], r['name']), json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
    #viewsetter.set_view("list")

def github_results(url):
    import json
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    from resources.lib.github_installer import github_api
    args = json.loads(url)
    #viewsetter.set_view("list")
    if args['rtype'] == 'web':
        from resources.lib.github_installer import kodi as _kodi
        full_name = "%s/%s" % (args['user'], args['repo'])
        c = _kodi.dialog_confirm("Confirm Install", full_name, yes="Install", no="Cancel")
        if not c: return
        url = "https://github.com/%s/%s/archive/master.zip" % (args['user'], args['repo'])
        Ins = github_installer.GitHub_Installer(args['repo'], url, full_name, _kodi.vfs.join("special://home", "addons"), True)
        return
    results = github_api.find_zips(args['user'], args['repo'])
    if results is None: return
    for r in results['items']:
        if r['repository']['name'] != args['repo']: continue
        url = github_api.content_url % (r['repository']['full_name'], r['path'])
        kodi.addItem(r['name'], json.dumps({'file': r['name'], "url": url, "full_name": r['repository']['full_name']}), 'github_install', '', description="")
    #viewsetter.set_view("list")

def github_install(url):
    import re
    import json
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    from resources.lib.github_installer import github_api
    args = json.loads(url)
    if 'file' in args:
        #viewsetter.set_view("list")
        c = _kodi.dialog_confirm("Confirm Install", args['file'])
        if not c: return
        addon_id = re.sub("-[\d\.]+zip$", "", args['file'])
        github_installer.GitHub_Installer(addon_id, args['url'], args['full_name'], _kodi.vfs.join("special://home", "addons"))
        if not DIALOG.yesno(ADDONTITLE, '                     Click Continue to install more addons or',
                            '                    Restart button to finalize addon installation',
                            "                          Brought To You By %s " % ADDONTITLE,
                            nolabel='Restart', yeslabel='Continue'):
            xbmc.executebuiltin('ShutDown')
        #viewsetter.set_view("list")
    else:
        pass

def github_instructions():
    from resources.lib.github_installer import kodi as _kodi
    try:
        KODI_LANGUAGE = xbmc.getLanguage()
    except:
        KODI_LANGUAGE = 'English'
    path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    if not _kodi.vfs.exists(path):
        path = _kodi.vfs.join(_kodi.get_path(), 'resources/lib/github_installer/github_help.txt')
    text = _kodi.vfs.read_file(path)
    _kodi.dialog_textbox('GitHub Browser Instructions', text)

def github_update():
    from resources.lib import github_installer
    from resources.lib.github_installer import kodi as _kodi
    c = _kodi.dialog_confirm("Confirm Update", "Search for updates?")
    if c : github_installer.update_addons()

# new github installer
'''
#@kodi.register('main')
#def main():
def github_main():
    show_about()
    kodi.add_menu_item({'mode': 'search_menu', 'type': "username", 'title': "Search by GitHub Username"}, {'title': "Search by GitHub Username"}, icon='username.png')
    kodi.add_menu_item({'mode': 'search_menu', 'type': "repository", 'title': "Search by GitHub Repository Title"}, {'title': "Search by GitHub Repository Title"}, icon='repository.png')
    kodi.add_menu_item({'mode': 'search_menu', 'type': "addonid",'title': "Search by Addon ID"}, {'title': "Search by Addon ID"}, icon='addonid.png')
    kodi.add_menu_item({'mode': 'update_addons'}, {'title': "Check for Updates"}, icon='update.png', visible=kodi.get_setting('enable_updates') == 'true')
    kodi.add_menu_item({'mode': 'about'}, {'title': "About GitHub Installer"}, icon='about.png')
    kodi.add_menu_item({'mode': 'addon_settings'}, {'title': "Tools and Settings"}, icon='settings.png')
    kodi.eod()

#@kodi.register('search_menu')
def search_menu():
    from libs.database import DB
    kodi.add_menu_item({'mode': 'void'}, {'title': "[COLOR darkorange]%s[/COLOR]" % kodi.arg('title')}, icon='null')
    kodi.add_menu_item({'mode': 'search', 'type': kodi.arg('type')}, {'title': "*** New Search ***"}, icon='null')
    results = DB.query_assoc("SELECT search_id, query FROM search_history WHERE search_type=? ORDER BY ts DESC LIMIT 10", [kodi.arg('type')], silent=True)
    if results is not None:
        for result in results:
            menu = kodi.ContextMenu()
            menu.add('Delete from search history', {"mode": "history_delete", "id": result['search_id']})
            kodi.add_menu_item({'mode': 'search', 'type': kodi.arg('type'), 'query': result['query']}, {'title': result['query']}, menu=menu, icon='null')
    kodi.eod()
    
#@kodi.register('search')
def search():
    from libs.database import DB
    from libs import github_api
    from libs.github_api import re_repository
    q = kodi.arg('query') if kodi.arg('query') else kodi.dialog_input('Search GitHub')
    if q in [None, False, '']: return False
    DB.execute('INSERT INTO search_history(search_type, query) VALUES(?,?)', [kodi.arg('type'), q])
    DB.commit()
    if kodi.arg('type') == 'username':
        rtype = 'api'
        response = github_api.find_zips(q)
        if response is None: return
        for r in github_api.sort_results(response['items']):
            url = github_api.content_url % (r['repository']['full_name'], r['path'])
            menu = kodi.ContextMenu()
            if re_repository.search(r['name']):
                menu.add('Browse Repository Contents', {"mode": "browse_repository", "url": url, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])})
            kodi.add_menu_item({'mode': 'github_install', "url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}, {'title': r['name']}, menu=menu, icon='null')
        kodi.eod()
    elif  kodi.arg('type') == 'repository':
        rtype = 'api'
        results = github_api.search(q, 'title')
        if results is None: return
        for i in results['items']:
            user = i['owner']['login']
            response = github_api.find_zips(user)
            if response is None: continue
            for r in github_api.sort_results(response['items']):
                url = github_api.content_url % (r['repository']['full_name'], r['path'])
                menu = kodi.ContextMenu()
                if re_repository.search(r['name']):
                    menu.add('Browse Repository Contents', {"mode": "browse_repository", "url": url, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])})
                kodi.add_menu_item({'mode': 'github_install', "url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}, {'title': r['name']}, menu=menu, icon='null')
        kodi.eod()
    elif  kodi.arg('type') == 'addonid':
        rtype = 'web'
        results = github_api.web_search(q)
        if results is None: return
        for r in results['items']:
            kodi.add_menu_item({'mode': 'github_install', "user": r['owner']['login'], "repo": r['name'], "rtype": rtype}, {'title': "%s/%s" % (r['owner']['login'], r['name'])}, icon='null')
        kodi.eod()
    
#@kodi.register('github_install')
def github_install():
    if kodi.arg('rtype') == 'web':
        from libs import github_installer
        from libs.github_api import master_url
        full_name = "%s/%s" % (kodi.arg('user'), kodi.arg('repo'))
        c = kodi.dialog_confirm("Confirm Install", full_name, yes="Install", no="Cancel")
        if not c: return
        url = master_url % (kodi.arg('user'), kodi.arg('repo'))
        github_installer.GitHub_Installer(kodi.arg('repo'), url, full_name, kodi.vfs.join("special://home", "addons"), True)
        r = kodi.dialog_confirm(kodi.get_name(), 'Click Continue to install more addons or', 'Restart button to finalize addon installation', yes='Restart', no='Continue')
        if r:
            import sys
            import xbmc
            if sys.platform in ['linux', 'linux2', 'win32']:
                xbmc.executebuiltin('RestartApp')
            else:
                xbmc.executebuiltin('ShutDown')
    else:
        import re
        from libs import github_installer
        from libs import github_api
        c = kodi.dialog_confirm("Confirm Install", kodi.arg('file'), yes="Install", no="Cancel")
        if not c: return
        addon_id = re.sub("-[\d\.]+zip$", "", kodi.arg('file'))
        github_installer.GitHub_Installer(addon_id, kodi.arg('url'), kodi.arg('full_name'), kodi.vfs.join("special://home", "addons"))
        r = kodi.dialog_confirm(kodi.get_name(), 'Click Continue to install more addons or', 'Restart button to finalize addon installation', yes='Restart', no='Continue')
        if r:
            import sys
            import xbmc
            if sys.platform in ['linux', 'linux2', 'win32']:
                xbmc.executebuiltin('RestartApp')
            else:
                xbmc.executebuiltin('ShutDown')

#@kodi.register('about')
def about():
    try:
        import xbmc
        KODI_LANGUAGE = xbmc.getLanguage()
    except:
        KODI_LANGUAGE = 'English'
    path = kodi.vfs.join(kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    if not kodi.vfs.exists(path):
        path = kodi.vfs.join(kodi.get_path(), 'resources/language/English/github_help.txt')
    text = kodi.vfs.read_file(path)
    kodi.dialog_textbox('GitHub Browser Instructions', text)

def show_about():
    interval = int(kodi.get_setting('last_about'))
    if interval == 0:
        interval = 5
        try:
            import xbmc
            KODI_LANGUAGE = xbmc.getLanguage()
        except:
            KODI_LANGUAGE = 'English'
        path = kodi.vfs.join(kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
        if not kodi.vfs.exists(path):
            path = kodi.vfs.join(kodi.get_path(), 'resources/language/English/github_help.txt')
        text = kodi.vfs.read_file(path)
        kodi.dialog_textbox('GitHub Browser Instructions', text)
    else:
        interval -= 1    
    kodi.set_setting('last_about', interval)
            
#@kodi.register('browse_repository')
def browse_repository():
    from libs import github_api
    xml = github_api.browse_repository(kodi.arg('url'))
    
    heading = "%s/%s" % (kodi.arg('full_name'), kodi.arg('file'))
    options = []
    if xml:
        for addon in xml.findAll('addon'):
            options.append("%s (%s)" % (addon['name'], addon['version']))
            
        kodi.dialog_select(heading, sorted(options))

#@kodi.register('history_delete')
def history_delete():
    if not kodi.arg('id'): return
    from libs.database import DB
    DB.execute("DELETE FROM search_history WHERE search_id=?", [kodi.arg('id')])
    DB.commit()    
    kodi.refresh()

#@kodi.register('update_addons')
def update_addons():
    from libs import github_installer
    quiet = True if kodi.arg('quiet') == 'quiet' else False
    if not quiet:
        c = kodi.dialog_confirm("Confirm Update", "Check for updates", yes="Update", no="Cancel")
        if not c: return
    github_installer.update_addons(quiet)
'''
# ********************************************************************

#################################################
# Log Uploader
#################################################
def send_email(LOG):
    xbmc.log(msg='##['+ADDON_ID+'] Email '+LOG, level=xbmc.LOGNOTICE)
    THESMTP ,THEPORT = Servers()
    fromaddr=ADDON.getSetting('email')
    toaddr=fromaddr
    if toaddr =='[COLOR red]Cancel[/COLOR]':
        Show_Dialog('No Email Sent','','Email Cancelled')
    else:
        import datetime
        TODAY=datetime.datetime.today().strftime('[%d-%m-%Y %H:%M]')
        from email.MIMEMultipart import MIMEMultipart
        from email.MIMEText import MIMEText
        fromaddr = '"Hi Message From Yourself" <%s>'% (fromaddr)
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = toaddr
        msg['Subject'] = "Your Kodi Log "+str(TODAY)
        THEHTML = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'data', 'theemail.html'))     
        body = open(THEHTML).read()
        content = MIMEText(body, 'html')
        msg.attach(content)
        try:filename = LOG.rsplit('\\', 1)[1]
        except:filename = LOG.rsplit('/', 1)[1]
        f = file(LOG)
        attachment = MIMEText(f.read())
        attachment.add_header('Content-Disposition', 'attachment', filename=filename.replace('log','txt'))
        msg.attach(attachment)
        import smtplib
        server = smtplib.SMTP(str(THESMTP), int(THEPORT))
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(ADDON.getSetting('email').encode('UTF-8'),ADDON.getSetting('emailpassword').encode('UTF-8'))
        text = msg.as_string()
        server.sendmail(fromaddr, toaddr, text)
        Show_Dialog('Email Sent To','[COLOR green]'+toaddr+'[/COLOR]','Also Check Junk Folder')
def Servers():
    SERVER = ADDON.getSetting('server')
    APPENDED=[]
    server_list   =[('Gmail','smtp.gmail.com','587'),
                    ('Outlook/Hotmail','smtp-mail.outlook.com','587'),
                    ('Office365','smtp.office365.com','587'),
                    ('Yahoo Mail','smtp.mail.yahoo.com','465'),
                    ('Yahoo Mail Plus','smtp.mail.yahoo.co.uk','465'),
                    ('AOL','smtp.att.yahoo.com','465'),
                    ('Verizon','smtp.zoho.com','465'),
                    ('Mail','smtp.mail.com','587'),
                    ('GMX','smtp.gmx.com','465')]
    for server , smtp ,port in server_list:
        if SERVER ==server:
            APPENDED.append([smtp ,port])
    return  APPENDED[0][0],APPENDED[0][1]
def email_log():
    # check email setting
    emailSERVER = ADDON.getSetting('email')
    if not emailSERVER :
        DIALOG.ok('Enter Email and Password in settings', 'Invalid email for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDONID).openSettings()
        sys.exit(0)
    emailpass = ADDON.getSetting('emailpassword')
    if not emailpass :
        DIALOG.ok('Enter password in settings', 'Invalid email PASSWORD for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDON_ID).openSettings()
        sys.exit(0)
    #
    nameSelect=[]
    logSelect=[]
    import glob
    folder = xbmc.translatePath('special://logpath')
    xbmc.log(msg=folder, level=xbmc.LOGNOTICE)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
    LOG = logSelect[xbmcgui.Dialog().select('Please Select Log', nameSelect)]
    send_email(LOG)
def Show_Dialog(line1,line2,line3):
    dialog = xbmcgui.Dialog()
    dialog.ok('Kodi Log Emailer', line1,line2,line3)
#
def platform():
    if xbmc.getCondVisibility('system.platform.android'): return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'): return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'): return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'): return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'): return 'ios'
#
def _notify(header,msg,icon_path):
    try:
        duration=1000
        ##xbmc.executebuiltin('XBMC.Notification(%s,%s, %s, %s)' % (header, msg, duration, icon_path))
        xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)
    except: pass
#
def unzip(_in, _out, dp):
    __in = zipfile.ZipFile(_in,  'r')
    nofiles = float(len(__in.infolist()))
    count   = 0 
    try:
        for item in __in.infolist():
            count += 1
            update = (count / nofiles) * 100
            if DP.iscanceled():
                sys.exit()
            try:
                DP.update(int(update),'','','[COLOR dodgerblue][B]' + str(item.filename) + '[/B][/COLOR]')
                __in.extract(item, _out)
            except Exception, e:
                print str(e)
    except Exception, e:
        print str(e)
        return False    
    return True 
#
def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1
#
def remove_dir(path):
    dirList, flsList = xbmcvfs.listdir(path)
    for fl in flsList:
        xbmcvfs.delete(os.path.join(path, fl))
    for dr in dirList:
        xbmcvfs.delete(xbmc.translatePath(os.path.join(path, '%s')) % dr)
    xbmcvfs.rmdir(path)
#
#Function to do a full wipe.
def Destroy_Path(path):
    DP.create('Delete','Wiping...','', 'Please Wait')
    try:
        shutil.rmtree(path, ignore_errors=True)
    except: pass
# Not Needed
def json_enable(name):
    if version == 17:
        ADDON      =  xbmc.translatePath(os.path.join('special://home/addons',name))
        ADDONICON  =  xbmc.translatePath(os.path.join('special://home/addons',name, 'icon.png'))
        if not os.path.exists(ADDONICON):
            ADDONICON  = ICON
        if os.path.exists(ADDON):
            _notify('Kodi 17','Refresh '+name,ADDONICON)
            addon_refresh()
            try:
                JSON = ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"%s", "enabled":true}, "id": 1}' % name)
                RunJSON = xbmc.executeJSONRPC(JSON)
            except: pass
#
def AppendText(SourceFile, DestFile):
    #xbmc.log(msg='##['+ADDONID+'] Append text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'a')
            f.write(s)
            f.close()
            s.close()
        except: pass
#
def WriteText(SourceFile, DestFile):
    #xbmc.log(msg='##['+ADDONID+'] Write text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'w')
            f.write(s)
            f.close()
            s.close()
        except: pass
#
def corefile_replace(newfile,corefiledir,corefile):
    #if dialog.yesno('Kick the tires?', 'Would you like to view '+newfile+' first?'):
    #    import main_TextViewer
    #    main_TextViewer.text_view(xbmc.translatePath(os.path.join(extrapath,corefiledir,newfile)))
    #if dialog.yesno('Replace?', 'Would you like to install '+newfile+'?'):
        xbmc.log(msg='##['+ADDON_ID+'] Attempt to replace '+corefile, level=xbmc.LOGNOTICE)
        asDest = xbmc.translatePath(os.path.join('special://home','userdata',corefile))
        asFile = xbmc.translatePath(os.path.join(extrapath,corefiledir,newfile))
        if os.path.exists(asDest):
            xbmcvfs.copy(asDest, asDest+'.last')
            delete_file(asDest)
        if os.path.exists(asFile):
           try:
                s=open(asFile).read()
                f=open(asDest,'w')
                f.write(s)
                f.close()
                s.close()
                _notify('XML','Replaced '+corefile,ICONHAPPY)
                xbmc.executebuiltin("XBMC.Container.Refresh")
           except: pass
#
# other DLer
def download_notify(url, destination, dp=None, headers=None, cookies=None, allow_redirects=True, verify=True, timeout=30, auth=None):
    if os.path.exists(destination):
        yes = DIALOG.yesno('Already Exists', "Would you like to Redownload?")
        if not yes:
            return
    try: os.remove(destination)
    except: pass
    dp = xbmcgui.DialogProgressBG()
    dp.create('Downloading')
    try:
        with open(destination, 'wb') as f:
            start = time.time()
            r = requests.get(url, headers=headers, cookies=cookies,
                             allow_redirects=allow_redirects, verify=verify,
                             timeout=timeout, auth=auth, stream=True)
            content_length = int(r.headers.get('content-length'))
            if content_length is None:
                f.write(r.content)
            else:
                dl = 0
                for chunk in r.iter_content(chunk_size=content_length/100):
                    dl += len(chunk)
                    if chunk:
                        f.write(chunk)
                    progress = (dl * 100 / content_length)
                    byte_speed = dl / (time.time() - start)
                    kbps_speed = byte_speed / 1024
                    mbps_speed = kbps_speed / 1024
                    downloaded = float(dl) / (1024 * 1024)
                    file_size = float(content_length) / (1024 * 1024)
                    if byte_speed > 0:
                        eta = (content_length - dl) / byte_speed
                    else:
                        eta = 0
                    line1 = '[COLOR darkgoldenrod]%.1f Mb[/COLOR] Of [COLOR darkgoldenrod]%.1f Mb[/COLOR]' %(downloaded, file_size)
                    line2 = 'Speed: [COLOR darkgoldenrod]%.01f Mbps[/COLOR]' %mbps_speed
                    line2 += ' ETA: [COLOR darkgoldenrod]%02d:%02d[/COLOR]' %divmod(eta, 60)
                    dp.update(progress, line1, line2)
        dp.close()
    except:
        dp.close()




###########################
## Making the Directory####
###########################
def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE+ ' Addon Installer and Maintenence', overwrite=True, fanart=FANART, icon=ICON, themeit=None):
#def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url == None: u += "&url="+urllib.quote_plus(url)
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE+ ' Addon Installer and Maintenence', overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url == None: u += "&url="+urllib.quote_plus(url)
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]

        return param

params=get_params()
url=None
name=None
mode=None
try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass

wiz.log('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]' % (VERSION, mode if not mode == '' else None, name, url))

def setView(content, viewType):
    if wiz.getS('auto-view')=='true':
        views = wiz.getS(viewType)
        # skin estuary
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
        # skin confluence
        if views == '50' and KODIV >= 17 and SKIN == 'skin.confluence': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.confluence': views = '50'
        # skin mods
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary16': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary17': views = '50'
        
        wiz.ebi("Container.SetViewMode(%s)" %  views)
        
if   mode==None             : index()

elif mode=='wizardupdate'   : wiz.wizardUpdate()
elif mode=='builds'         : buildMenu()
elif mode=='viewbuild'      : viewBuild(name)
elif mode=='buildinfo'      : buildInfo(name)
elif mode=='buildpreview'   : buildVideo(name)
elif mode=='install'        : buildWizard(name, url)
elif mode=='theme'          : buildWizard(name, mode, url)
elif mode=='viewthirdparty' : viewThirdList(name)
elif mode=='installthird'   : thirdPartyInstall(name, url)
elif mode=='editthird'      : editThirdParty(name); wiz.refresh()

elif mode=='maint'          : maintMenu(name)
elif mode=='kodi17fix'      : wiz.kodi17Fix()
elif mode=='advancedsetting': advancedWindow(name)
elif mode=='autoadvanced'   : showAutoAdvanced(); wiz.refresh()
elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()
elif mode=='asciicheck'     : wiz.asciiCheck()
elif mode=='backupbuild'    : wiz.backUpOptions('build')
elif mode=='backupgui'      : wiz.backUpOptions('guifix')
elif mode=='backuptheme'    : wiz.backUpOptions('theme')
elif mode=='backupaddon'    : wiz.backUpOptions('addondata')
elif mode=='oldThumbs'      : wiz.oldThumbs()
elif mode=='clearbackup'    : wiz.cleanupBackup()
elif mode=='convertpath'    : wiz.convertSpecial(HOME)
elif mode=='currentsettings': viewAdvanced()
elif mode=='fullclean'      : totalClean(); wiz.refresh()
elif mode=='clearcache'     : clearCache(); wiz.refresh()
elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
elif mode=='checksources'   : wiz.checkSources(); wiz.refresh()
elif mode=='checkrepos'     : wiz.checkRepos(); wiz.refresh()
elif mode=='freshstart'     : freshStart()
elif mode=='forceupdate'    : wiz.forceUpdate()
elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
elif mode=='forceclose'     : wiz.killxbmc()
elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
elif mode=='hidepassword'   : wiz.hidePassword()
elif mode=='unhidepassword' : wiz.unhidePassword()
elif mode=='enableaddons'   : enableAddons()
elif mode=='toggleaddon'    : wiz.toggleAddon(name, url); wiz.refresh()
elif mode=='togglecache'    : toggleCache(name); wiz.refresh()
elif mode=='toggleadult'    : wiz.toggleAdult(); wiz.refresh()
elif mode=='changefeq'      : changeFeq(); wiz.refresh()
elif mode=='uploadlog'      : uploadLog.Main()
elif mode=='viewlog'        : LogViewer()
elif mode=='viewwizlog'     : LogViewer(WIZLOG)
elif mode=='viewerrorlog'   : errorChecking(all=True)
elif mode=='clearwizlog'    : f = open(WIZLOG, 'w'); f.close(); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Wizard Log Cleared![/COLOR]" % COLOR2)
elif mode=='purgedb'        : purgeDb()
elif mode=='fixaddonupdate' : fixUpdate()
elif mode=='removeaddons'   : removeAddonMenu()
elif mode=='removeaddon'    : removeAddon(name)
elif mode=='removeaddondata': removeAddonDataMenu()
elif mode=='removedata'     : removeAddonData(name)
elif mode=='resetaddon'     : total = wiz.cleanHouse(ADDONDATA, ignore=True); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Addon_Data reset[/COLOR]" % COLOR2)
elif mode=='systeminfo'     : systemInfo()
elif mode=='restorezip'     : restoreit('build')
elif mode=='restoregui'     : restoreit('gui')
elif mode=='restoreaddon'   : restoreit('addondata')
elif mode=='restoreextzip'  : restoreextit('build')
elif mode=='restoreextgui'  : restoreextit('gui')
elif mode=='restoreextaddon': restoreextit('addondata')
elif mode=='writeadvanced'  : writeAdvanced(name, url)

elif mode=='apk'            : apkMenu(name)
elif mode=='apkscrape'      : apkScraper(name)
elif mode=='apkinstall'     : apkInstaller(name, url)

elif mode=='youtube'        : youtubeMenu(name)
elif mode=='viewVideo'      : playVideo(url)

elif mode=='addons'         : addonMenu(name)
elif mode=='addoninstall'   : addonInstaller(name, url)

elif mode=='savedata'       : saveMenu()
elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()
elif mode=='managedata'     : manageSaveData(name)
elif mode=='whitelist'      : wiz.whiteList(name)

elif mode=='trakt'          : traktMenu()
elif mode=='savetrakt'      : traktit.traktIt('update',      name)
elif mode=='restoretrakt'   : traktit.traktIt('restore',     name)
elif mode=='addontrakt'     : traktit.traktIt('clearaddon',  name)
elif mode=='cleartrakt'     : traktit.clearSaved(name)
elif mode=='authtrakt'      : traktit.activateTrakt(name); wiz.refresh()
elif mode=='updatetrakt'    : traktit.autoUpdate('all')
elif mode=='importtrakt'    : traktit.importlist(name); wiz.refresh()

elif mode=='realdebrid'     : realMenu()
elif mode=='savedebrid'     : debridit.debridIt('update',      name)
elif mode=='restoredebrid'  : debridit.debridIt('restore',     name)
elif mode=='addondebrid'    : debridit.debridIt('clearaddon',  name)
elif mode=='cleardebrid'    : debridit.clearSaved(name)
elif mode=='authdebrid'     : debridit.activateDebrid(name); wiz.refresh()
elif mode=='updatedebrid'   : debridit.autoUpdate('all')
elif mode=='importdebrid'   : debridit.importlist(name); wiz.refresh()

elif mode=='login'          : loginMenu()
elif mode=='savelogin'      : loginit.loginIt('update',      name)
elif mode=='restorelogin'   : loginit.loginIt('restore',     name)
elif mode=='addonlogin'     : loginit.loginIt('clearaddon',  name)
elif mode=='clearlogin'     : loginit.clearSaved(name)
elif mode=='authlogin'      : loginit.activateLogin(name); wiz.refresh()
elif mode=='updatelogin'    : loginit.autoUpdate('all')
elif mode=='importlogin'    : loginit.importlist(name); wiz.refresh()

elif mode=='contact'        : notify.contact(CONTACT)
elif mode=='settings'       : wiz.openS(name); wiz.refresh()
elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()

elif mode=='developer'      : developer()
elif mode=='converttext'    : wiz.convertText()
elif mode=='testnotify'     : testnotify()
elif mode=='testupdate'     : testupdate()
elif mode=='testfirst'      : testfirst()
elif mode=='testfirstrun'   : testfirstRun()
elif mode=='testapk'        : notify.apkInstaller('SPMC')

######################
# menus
elif mode=='indexinstallthings'    : index_installthings()
elif mode=='indexzipinstaller'     : index_zipinstaller()
elif mode=='indexcleaning'         : index_cleaning()
elif mode=='indexbackup'           : index_backup()
elif mode=='indexlog'              : index_log()
elif mode=='indexinstallxml'       : index_installxml()
elif mode=='indexaddonfixes'       : index_addonfixes()
elif mode=='indexsourcesxml'       : index_sourcesxml()
elif mode=='indexrss'              : index_rss()
elif mode=='indexadvancedsettings' : index_advancedsettings()
elif mode=='indexplayercorefactory': index_playercorefactory()
# extras
elif mode=='emaillog'              : email_log()
elif mode=='Repolink'              : Repolink();sys.exit(0)
# apk
elif mode=='androidappmanager'     : xbmc.executebuiltin('StartAndroidActivity(,android.settings.APPLICATION_SETTINGS)')
elif mode=='androidkodisettings'   : xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS","","package:org.xbmc.kodi")')
elif mode=='androidprograms'       : xbmc.executebuiltin('ActivateWindow(Programs)')
elif mode=='androidsettings'       : xbmc.executebuiltin('ActivateWindow(10001,androidsetting://sources/settings/, return)')#Android Settings
elif mode=='androidapps'           : xbmc.executebuiltin('ActivateWindow(10001,androidapp://sources/apps/, return)')#Android Apps
elif mode=='androidprogramaddons'  : xbmc.executebuiltin('ActivateWindow(10001,addons://sources/executable/, return)')#Program Addons
# zip installs
elif mode=='InstallAll'            :  Install_All()
elif mode=='ReposInstall'          :  ReposInstall()
elif mode=='themeAddonsInstall'    :  themeAddonsInstall()
elif mode=='audioAddonsInstall'    :  audioAddonsInstall()
elif mode=='programAddonsInstall'  :  programAddonsInstall()
elif mode=='videoAddonsInstall'    :  videoAddonsInstall()
elif mode=='IPTVAddonsInstall'     :  IPTVAddonsInstall()
elif mode=='IPTVSubbedAddonsInstall': IPTVSubbedAddonsInstall()
elif mode=='AddonDataInstall'      :  AddonDataInstall()
elif mode=='EnableRTMP'            :  EnableRTMP()
# Github Browser
elif mode=='githubmain'            :  github_main()
elif mode=='github_update'         :  github_update()
elif mode=='github_instructions'   :  github_instructions()
elif mode=='github_install'        :  github_install(url)
elif mode=='github_search_username':  github_search('username')
elif mode=='github_search_repo'    :  github_search('repo')
elif mode=='github_search_addon_id':  github_search('addon_id')

#
xbmcplugin.endOfDirectory(int(sys.argv[1]))
