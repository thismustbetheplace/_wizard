# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, sys, time, uservar
import wizard as wiz
ADDONTITLE         = uservar.ADDONTITLE
COLORHEADER        = uservar.COLORHEADER
COLORHEADERTXT     = uservar.COLORHEADERTXT
COLORHEADERINFO    = uservar.COLORHEADERINFO


#urllib.URLopener.version = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
USER_AGENT       = uservar.USER_AGENT
urllib.URLopener.version = USER_AGENT

def download(url, dest, dp = None, unzip=False):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE ,"Downloading Content...",' ', ' ')
    dp.update(0)
    start_time=time.time()
    urllib.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, dp, start_time))

def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    try: 
        percent = min(numblocks * blocksize * 100 / filesize, 100) 
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
        kbps_speed = numblocks * blocksize / (time.time() - start_time) 
        if kbps_speed > 0 and not percent == 100: 
            eta = (filesize - numblocks * blocksize) / kbps_speed 
        else: 
            eta = 0
        kbps_speed = kbps_speed / 1024 
        type_speed = 'KB'
        if kbps_speed >= 1024:
            kbps_speed = kbps_speed / 1024 
            type_speed = 'MB'
        total = float(filesize) / (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B]   [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (COLORHEADERTXT, COLORHEADERINFO, currently_downloaded, COLORHEADERINFO, total) 
        e   = '[COLOR %s][B]Speed:[/B]  [COLOR %s]%.02f [/COLOR]%s/s ' % (COLORHEADERTXT, COLORHEADERINFO, kbps_speed, type_speed)
        e  += '[B]ETA:[/B] [COLOR '+COLORHEADERINFO+']%02d:%02d[/COLOR][/COLOR]' % divmod(eta, 60)
        dp.update(percent, '', mbs, e)
    except Exception, e:
        wiz.log("ERROR Downloading: %s" % str(e), xbmc.LOGERROR)
        return str(e)
    if dp.iscanceled(): 
        dp.close()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR red]Download Cancelled[/COLOR]")
        sys.exit()
        
        
# other DLer
def download_notify(url, destination, dp=None, headers=None, cookies=None, allow_redirects=True, verify=True, timeout=30, auth=None):
    from resources.lib import requests
    if os.path.exists(destination):
        yes = DIALOG.yesno('Already Exists', "Would you like to Redownload?")
        if not yes:
            return
    try: os.remove(destination)
    except: pass
    dp = xbmcgui.DialogProgressBG()
    dp.create('Downloading')
    try:
        with open(destination, 'wb') as f:
            start = time.time()
            r = requests.get(url, headers=headers, cookies=cookies,
                             allow_redirects=allow_redirects, verify=verify,
                             timeout=timeout, auth=auth, stream=True)
            content_length = int(r.headers.get('content-length'))
            if content_length is None:
                f.write(r.content)
            else:
                dl = 0
                for chunk in r.iter_content(chunk_size=content_length/100):
                    dl += len(chunk)
                    if chunk:
                        f.write(chunk)
                    progress = (dl * 100 / content_length)
                    byte_speed = dl / (time.time() - start)
                    kbps_speed = byte_speed / 1024
                    mbps_speed = kbps_speed / 1024
                    downloaded = float(dl) / (1024 * 1024)
                    file_size = float(content_length) / (1024 * 1024)
                    if byte_speed > 0:
                        eta = (content_length - dl) / byte_speed
                    else:
                        eta = 0
                    line1 = '[COLOR darkgoldenrod]%.1f Mb[/COLOR] Of [COLOR darkgoldenrod]%.1f Mb[/COLOR]' %(downloaded, file_size)
                    line2 = 'Speed: [COLOR darkgoldenrod]%.01f Mbps[/COLOR]' %mbps_speed
                    line2 += ' ETA: [COLOR darkgoldenrod]%02d:%02d[/COLOR]' %divmod(eta, 60)
                    dp.update(progress, line1, line2)
        dp.close()
    except:
        dp.close()
        
        