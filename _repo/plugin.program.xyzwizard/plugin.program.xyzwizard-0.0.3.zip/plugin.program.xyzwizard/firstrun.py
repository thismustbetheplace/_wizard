# -*- coding: utf-8 -*-
import os, xbmc, xbmcaddon, xbmcgui, xbmcvfs, shutil
try: from uservar import ADDON_ID
except ImportError: ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON              = xbmcaddon.Addon(ADDON_ID)
ADDON_DATA         = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDON_ID))
ADDONPATH          = xbmc.translatePath(os.path.join('special://home/addons', ADDON_ID))
from uservar import ADDONTITLE
from uservar import ART
from uservar import ICON
from uservar import EXTRAPATH
from uservar import DATAPATH
from uservar import DATAPATHUSERDATA

################################################################################
###### add custom settings to settings.xml
################################################################################
def firstrun(force=False):
    ADDON.setSetting('firstrun', 'false')
    WIZNAME = ADDONTITLE
    progress = xbmcgui.DialogProgressBG()
    progress.create(WIZNAME,'Parsing Fallbacks...')

    ############################################################################
    ############################################################################
    ###### Add custom settings to settings.xml below
    progress.update(0,WIZNAME,'Set Wizard Defaults') 
    ############################################################################
    setS('ADDONTITLE',     WIZNAME)
    setS('REPOID',        'repository._xyz')
    setS('repo.url',      'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_repo/')
    
    setS('REPOADDONXML',  'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_repo/repository._xyz/addon.xml')
    setS('REPOZIPURL',    'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_repo/repository._xyz/')

    
    ############################################################################
    # Main online txt
    progress.update(0,WIZNAME,'Online txts')
    ############################################################################
    setS('ADDONFILE',                                              'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/addons.txt')
    setS('APKFILE',                                                'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/apks.txt')         
    setS('NOTIFICATION',                                           'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/notify.txt')
    #setS('WIZARDFILE',                                             'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/zips.txt')  
    #setS('WIZARDFILE',                                             'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/zips.txt')  
    #setS('BUILDFILE',                                              'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/zips.txt')
    #setS('ADVANCEDFILE',                                          'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/advanced.txt')
    #setS('YOUTUBEFILE',                                            'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/youtube.txt')
    #setS('ROMPACKFILE1',                                           'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/rompacks.txt')
    #setS('KEYMAPSFILE',                                            'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/keymaps.txt')
    #setS('THEMEFILE',                                             'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/notify.txt')
    #
    setS('zips.url',                                               'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/')
    #setS('THEMENAME1',  'Estuary 18 Leia');      setS('THEMEURL1', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/18_theme.zip')
    #setS('THEMENAME2',  'Estuary 17 Krypton');   setS('THEMEURL2', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/17_theme.zip')
    #setS('THEMENAME3',  'Estuary 16 Jarvis');    setS('THEMEURL3', 'https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/_zips/16_theme.zip')
    #setS('ADDONNAME1',  'addons2.txt (Modules)');setS('ADDONFILE1','https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/addons2.txt')
    #setS('ADDONNAME2',  'addons_Top10.txt');     setS('ADDONFILE2','https://raw.githubusercontent.com/thismustbetheplace/_wizard/master/addons_Top10.txt')
    #setS('THEMEFILE1',                                            'http://aftermathwizard.net/repo/wizard/test1themes.txt')
    #setS('KEYMAPSFILE',                                           'http://indigo.tvaddons.co/keymaps/customkeys.txt')
    
    ############################################################################
    progress.update(0,WIZNAME,'TV EPG Settings')
    ############################################################################
    setS('xmltv.url',             "https://raw.githubusercontent.com/thismustbetheplace/_xmltv/master/xmltv.xml.gz")
    setS('xmltv2.url',            "https://raw.githubusercontent.com/thismustbetheplace/_xmltv/master/xmltv2.xml.gz")
    setS('addons.ini.file',       xbmc.translatePath(os.path.join('special://profile/','addon_data/','script.tvguide.fullscreen','addons2.ini')))
    setS('logos.folder',          xbmc.translatePath(os.path.join('special://profile/','addon_data/','script.tvguide.fullscreen','resources','logos','Default')))

    
    
    ############################################################################
    progress.update(0,WIZNAME,'Playercorefactory xml')
    ############################################################################
    ######  playerfactorycore links (android)
    setS('PLAYERCFNAME1',     'LocalCast');                                setS('PLAYERCFFILE1',   'de.stefanpledl.localcast')
    setS('PLAYERCFNAME2',     'SopCast');                                  setS('PLAYERCFFILE2',   'org.sopcast.android')
    setS('PLAYERCFNAME3',     'VLCPlayer');                                setS('PLAYERCFFILE3',   'com.vlcforandroid.vlcdirectprofree')
    setS('PLAYERCFNAME4',     'MXPlayerFree');                             setS('PLAYERCFFILE4',   'com.mxtech.videoplayer.ad')
    setS('PLAYERCFNAME5',     'MXPlayerPro');                              setS('PLAYERCFFILE5',   'com.mxtech.videoplayer.pro')
    setS('PLAYERCFNAME6',     'WondersharePlayer');                        setS('PLAYERCFFILE6',   'com.wondershare.player')
    setS('PLAYERCFNAME7',     'BSPlayerFree');                             setS('PLAYERCFFILE7',   'com.bsplayer.bspandroid.free')
    setS('PLAYERCFNAME8',     'Tiantian Player');                          setS('PLAYERCFFILE8',   'com.tiantian.android.player.app')

    ############################################################################
    progress.update(0, WIZNAME,'M3u')
    ############################################################################
    setS('M3UNAME1',     'CrachTvListPro');  setS('M3UENABLE1', 'true');   setS('M3UURL1',   'https://raw.githubusercontent.com/Crach1015/CrachTvListPro/master/LIstas/DEPORTES.M3U')
    #
    setS('M3UTNAME1',    'Radio');           setS('M3UTURL1',         xbmc.translatePath(os.path.join(DATAPATHUSERDATA, 'm3us', 'Radio.m3u'))) ;setS('M3UTENABLE1','true')

    ############################################################################
    progress.update(0, WIZNAME,'RSS urls')
    ############################################################################
    setS('RSS1',         'http://rarbg.to/rssdd.php?categories=14')
    setS('RSS2',         'http://rarbg.to/rssdd.php?categories=18')
    setS('RSS3',         'http://rss.cnn.com/rss/cnn_latest.rss')
    setS('RSS4',         'http://www.cbsnews.com/feeds/rss/main.rss')
    setS('RSS5',         'http://rss.cnn.com/rss/cnn_showbiz.rss')
    
    
    ############################################################################
    progress.update(0, WIZNAME,'3rd Build Paths')
    ############################################################################
    ######  build txt menus
    '''
    setS('THIRDNAME1',     'Supremebuilds');                               setS('THIRDURL1',   'https://wizard.supremebuilds.com/texts/builds.txt')
    setS('THIRDNAME2',     'Firestickplus');                               setS('THIRDURL2',   'http://firestickplusmancomlu.com/wizard/Advanced%20wizard/autobuilds.txt')
    setS('THIRDNAME3',     'Steventv Wizard');                             setS('THIRDURL3',   'http://www.steventvwizard.xyz/build/builds12.txt')
    setS('THIRDNAME4',     'MaverickTV');                                  setS('THIRDURL4',   'http://mavericktv.net/wiz/wizard.txt')
    setS('THIRDNAME5',     'Supremebuilds');                               setS('THIRDURL5',   'https://wizard.supremebuilds.com/texts/builds.txt')
    setS('THIRDNAME6',     'Brettusbuilds Community');                     setS('THIRDURL6',   'http://brettusbuilds.com/Brettus%20Builds/community.txt')
    setS('THIRDNAME7',     'Brettusbuilds Brett');                         setS('THIRDURL7',   'http://brettusbuilds.com/Brettus%20Builds/brett.txt')
    setS('THIRDNAME8',     'Brettusbuilds BrettusAdmin');                  setS('THIRDURL8',   'http://brettusbuilds.com/Brettus%20Builds/BrettusAdmin.txt')
    setS('THIRDNAME9',     'Zerotolerance');                               setS('THIRDURL9',   'http://builds.zerotolerance.gq/xmls/texts/builds.txt')
    setS('THIRDNAME10',    'Zerotolerance Emulators');                     setS('THIRDURL10',  'http://builds.zerotolerance.gq/xmls/texts/rompacks.txt')
    '''
    
    
    ############################################################################
    #### DONE #### set setting to not run again until settings.xml is set to default
    ############################################################################
    progress.close()
    
def setS(name, value):
    try: ADDON.setSetting(name, value)
    except: return False
