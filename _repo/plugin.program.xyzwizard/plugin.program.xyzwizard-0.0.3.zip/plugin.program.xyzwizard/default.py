# -*- coding: utf-8 -*-
#from __future__ import unicode_literals  # BAD
#from resources.libs.xbmcswift2 import Plugin
#from resources.libs.xbmcswift2 import actions
#plugin = Plugin()
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs
import glob
import shutil
import urllib2,urllib
import re
import zipfile
import uservar
import fnmatch
import platform
import time
import subprocess
import xml.etree.ElementTree as ET
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta
from urlparse import urljoin
from resources.libs import extract, downloader, notify, debridit, traktit, allucit, loginit, skinSwitch, uploadLog, yt, speedtest, wizard as wiz
ADDON_ID  = uservar.ADDON_ID
ADDON     = uservar.ADDON
if ADDON: # Main Settings START
    #xbmc.log(msg='##['+ADDON_ID+'] Start',level=xbmc.LOGNOTICE)
    ADDONTITLE       = uservar.ADDONTITLE
    DIALOG           = xbmcgui.Dialog()
    DP               = xbmcgui.DialogProgress()
    NAME             = uservar.NAME
    VERSION          = uservar.VERSION
    PROFILE          = uservar.PROFILE
    ADDONPATH        = uservar.ADDONPATH
    ADDONTEMPFOLDER  = uservar.ADDONTEMPFOLDER
    LOG              = uservar.LOG
    TEMPDIR          = uservar.TEMPDIR
    HOME             = uservar.HOME
    USERDATA         = uservar.USERDATA
    ADDONS           = uservar.ADDONS
    PLUGIN           = uservar.PLUGIN 
    PACKAGES         = uservar.PACKAGES
    ADDOND           = uservar.ADDOND
    ADDONDATA        = uservar.ADDONDATA
    ART              = uservar.ART
    ICON             = uservar.ICON
    FANART           = uservar.FANART
    ADVANCED         = uservar.ADVANCED
    SOURCES          = uservar.SOURCES
    PLAYERCORE       = uservar.PLAYERCORE
    RSSFEED          = uservar.RSSFEED
    FAVOURITES       = uservar.FAVOURITES
    PROFILES         = uservar.PROFILES
    GUISETTINGS      = uservar.GUISETTINGS
    THUMBS           = uservar.THUMBS
    DATABASE         = uservar.DATABASE
    WIZLOG           = uservar.WIZLOG
    SPEEDTESTFOLD    = uservar.SPEEDTESTFOLD
    ARCHIVE_CACHE    = uservar.ARCHIVE_CACHE
    SKIN             = xbmc.getSkinDir()
    BUILDNAME        = wiz.getS('buildname')
    DEFAULTSKIN      = wiz.getS('defaultskin')
    DEFAULTNAME      = wiz.getS('defaultskinname')
    DEFAULTIGNORE    = wiz.getS('defaultskinignore')
    BUILDVERSION     = wiz.getS('buildversion')
    BUILDTHEME       = wiz.getS('buildtheme')
    BUILDLATEST      = wiz.getS('latestversion')
    SHOW15           = wiz.getS('show15')
    SHOW16           = wiz.getS('show16')
    SHOW17           = wiz.getS('show17')
    SHOW18           = wiz.getS('show18')
    SHOWADULT        = wiz.getS('adult')
    SHOWMAINT        = wiz.getS('showmaint')
    AUTOCLEANUP      = wiz.getS('autoclean')
    AUTOCACHE        = wiz.getS('clearcache')
    AUTOPACKAGES     = wiz.getS('clearpackages')
    AUTOTHUMBS       = wiz.getS('clearthumbs')
    AUTOFEQ          = wiz.getS('autocleanfeq')
    AUTONEXTRUN      = wiz.getS('nextautocleanup')
    INCLUDEVIDEO     = wiz.getS('includevideo')
    INCLUDEALL       = wiz.getS('includeall')
    INCLUDEBOB       = wiz.getS('includebob')
    INCLUDESPECTO    = wiz.getS('includespecto')
    INCLUDEGENESIS   = wiz.getS('includegenesis')
    INCLUDEEXODUS    = wiz.getS('includeexodus')
    INCLUDEELY       = wiz.getS('includeely')
    INCLUDEONECHAN   = wiz.getS('includeonechan')
    INCLUDESALTS     = wiz.getS('includesalts')
    INCLUDESALTSHD   = wiz.getS('includesaltslite')
    SEPERATE         = wiz.getS('seperate')
    NOTIFY           = wiz.getS('notify')
    NOTEID           = wiz.getS('noteid')
    NOTEDISMISS      = wiz.getS('notedismiss')
    TRAKTSAVE        = wiz.getS('traktlastsave')
    REALSAVE         = wiz.getS('debridlastsave')
    ALLUCSAVE        = wiz.getS('alluclastsave')
    LOGINSAVE        = wiz.getS('loginlastsave')
    KEEPFAVS         = wiz.getS('keepfavourites')
    KEEPSOURCES      = wiz.getS('keepsources')
    KEEPPROFILES     = wiz.getS('keepprofiles')
    KEEPADVANCED     = wiz.getS('keepadvanced')
    KEEPREPOS        = wiz.getS('keeprepos')
    KEEPSUPER        = wiz.getS('keepsuper')
    KEEPWHITELIST    = wiz.getS('keepwhitelist')
    KEEPTRAKT        = wiz.getS('keeptrakt')
    KEEPREAL         = wiz.getS('keepdebrid')
    KEEPALLUC        = wiz.getS('keepalluc')
    KEEPLOGIN        = wiz.getS('keeplogin')
    DEVELOPER        = wiz.getS('developer')
    THIRDPARTY       = wiz.getS('enable3rd')
    THIRD1NAME       = wiz.getS('wizard1name')
    THIRD1URL        = wiz.getS('wizard1url')
    THIRD2NAME       = wiz.getS('wizard2name')
    THIRD2URL        = wiz.getS('wizard2url')
    THIRD3NAME       = wiz.getS('wizard3name')
    THIRD3URL        = wiz.getS('wizard3url')
    BACKUPROMS       = wiz.getS('rompath')
    AUTOFEQ          = int(float(AUTOFEQ)) if AUTOFEQ.isdigit() else 0
    TODAY            = date.today()
    TOMORROW         = TODAY + timedelta(days=1)
    THREEDAYS        = TODAY + timedelta(days=3)
    MCNAME           = wiz.mediaCenter()
    KODIV            = uservar.KODIV
    #KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    My_Builds        = uservar.My_Builds
    BACKUPLOCATION   = uservar.BACKUPLOCATION
    MYBUILDS         = uservar.MYBUILDS
    MYADDONS         = uservar.MYADDONS                                         # BACKUPDIR\addons
    MYAPKS           = uservar.MYAPKS                                           # BACKUPDIR\apks
    MYZIPS           = uservar.MYZIPS                                           # BACKUPDIR\zips
    SAVEDL           = uservar.SAVEDL  # saves to backups folder
    if not os.path.exists(MYADDONS): xbmcvfs.mkdirs(MYADDONS)
    if not os.path.exists(MYAPKS):   xbmcvfs.mkdirs(MYAPKS)
    if not os.path.exists(MYZIPS):   xbmcvfs.mkdirs(MYZIPS)
    EXCLUDES         = uservar.EXCLUDES
    CACHETEXT        = uservar.CACHETEXT
    CACHEAGE         = uservar.CACHEAGE if str(uservar.CACHEAGE).isdigit() else 30
    BUILDFILE        = uservar.BUILDFILE
    APKFILE          = uservar.APKFILE
    YOUTUBETITLE     = uservar.YOUTUBETITLE
    YOUTUBEFILE      = uservar.YOUTUBEFILE
    ADDONFILE        = uservar.ADDONFILE
    ADVANCEDFILE     = uservar.ADVANCEDFILE
    KEYBOARD_FILE    = uservar.KEYBOARD_FILE
    ######################
    UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
    NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
    NOTIFICATION     = uservar.NOTIFICATION
    ENABLE           = uservar.ENABLE
    HEADERMESSAGE    = uservar.HEADERMESSAGE
    HIDESPACERS      = uservar.HIDESPACERS
    AUTOUPDATE       = uservar.AUTOUPDATE
    WIZARDFILE       = uservar.WIZARDFILE
    HIDECONTACT      = uservar.HIDECONTACT
    CONTACT          = uservar.CONTACT
    CONTACTICON      = uservar.CONTACTICON  if not uservar.CONTACTICON   == 'http://' else ICON 
    CONTACTFANART    = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
    ICONBUILDS       = uservar.ICONBUILDS   if not uservar.ICONBUILDS  == 'http://' else ICON
    ICONMAINT        = uservar.ICONMAINT    if not uservar.ICONMAINT   == 'http://' else ICON
    ICONAPK          = uservar.ICONAPK      if not uservar.ICONAPK     == 'http://' else ICON
    ICONADDONS       = uservar.ICONADDONS   if not uservar.ICONADDONS  == 'http://' else ICON
    ICONYOUTUBE      = uservar.ICONYOUTUBE  if not uservar.ICONYOUTUBE == 'http://' else ICON
    ICONSAVE         = uservar.ICONSAVE     if not uservar.ICONSAVE    == 'http://' else ICON
    ICONTRAKT        = uservar.ICONTRAKT    if not uservar.ICONTRAKT   == 'http://' else ICON
    ICONREAL         = uservar.ICONREAL     if not uservar.ICONREAL    == 'http://' else ICON
    ICONLOGIN        = uservar.ICONLOGIN    if not uservar.ICONLOGIN   == 'http://' else ICON
    ICONCONTACT      = uservar.ICONCONTACT  if not uservar.ICONCONTACT == 'http://' else ICON
    ICONSETTINGS     = uservar.ICONSETTINGS if not uservar.ICONSETTINGS== 'http://' else ICON
    # custom
    ICONCLEAN        = uservar.ICONCLEAN    if not uservar.ICONCLEAN   == 'http://' else ICON
    ICONCLOSE        = uservar.ICONCLOSE    if not uservar.ICONCLOSE   == 'http://' else ICON
    ICONDELETE       = uservar.ICONDELETE   if not uservar.ICONDELETE  == 'http://' else ICON
    ICONBACKUP       = uservar.ICONBACKUP   if not uservar.ICONBACKUP  == 'http://' else ICON
    ICONLOG          = uservar.ICONLOG      if not uservar.ICONLOG     == 'http://' else ICON
    ICONXML          = uservar.ICONXML      if not uservar.ICONXML     == 'http://' else ICON
    ICONVIDEO        = uservar.ICONVIDEO    if not uservar.ICONVIDEO   == 'http://' else ICON
    ICONGITHUB       = uservar.ICONGITHUB   if not uservar.ICONGITHUB  == 'http://' else ICON
    ICONURL          = uservar.ICONURL      if not uservar.ICONURL     == 'http://' else ICON
    ICONINFO         = uservar.ICONINFO     if not uservar.ICONINFO    == 'http://' else ICON
    ICONOS           = uservar.ICONOS       if not uservar.ICONOS      == 'http://' else ICON
    ICONREPO         = uservar.ICONREPO     if not uservar.ICONREPO    == 'http://' else ICON
    # where settings files are stored  ########################################## 
    EXTRAPATH          = uservar.EXTRAPATH                                      # home\addons\ADDONPATH\resources\extras
    DATAPATH           = uservar.DATAPATH                                       # home\addons\ADDONPATH\resources\data
    DATAPATHUSERDATA   = uservar.DATAPATHUSERDATA                               # home\userdata\addon_data\ADDONPATH\resources\data
    linkortxt          = uservar.linkortxt
    #addonsXMLFolder    = uservar.addonsXMLFolder                               # addonsxml
    addonsTXTFolder    = uservar.addonsTXTFolder                                # addons
    #addons2TXTFolder   = uservar.addons2TXTFolder                              # addons2
    reposTXTFolder     = uservar.reposTXTFolder                                 # repos
    #depsTXTFolder      = uservar.depsTXTFolder                                 # deps
    pluginsTXTFolder   = uservar.pluginsTXTFolder                               # plugins
    apksTXTFolder      = uservar.apksTXTFolder                                  # apks
    buildsTXTFolder    = uservar.buildsTXTFolder                                # builds
    m3usTXTFolder      = uservar.m3usTXTFolder                                  # m3us
    playlistsTXTFolder = uservar.playlistsTXTFolder                             # playlists
    rompacksTXTFolder  = uservar.rompacksTXTFolder                              # rompacks
    sitesTXTFolder     = uservar.sitesTXTFolder                                 # sites
    themesTXTFolder    = uservar.themesTXTFolder                                # themes
    youtubeTXTFolder   = uservar.youtubeTXTFolder                               # youtube
    
    #addonfile = os.path.join(DATAPATHUSERDATA, 'addons'+linkortxt)
    #repofile  = os.path.join(DATAPATHUSERDATA, 'repos'+linkortxt)
    addonfile = xbmc.translatePath(os.path.join(DATAPATHUSERDATA, 'addons'+linkortxt))
    pluginfile = xbmc.translatePath(os.path.join(DATAPATHUSERDATA, 'plugins'+linkortxt))
    repofile   = xbmc.translatePath(os.path.join(DATAPATHUSERDATA, 'repos'+linkortxt))
    #linkortxt         = '.link'
    ## chrome
    stopPlayback       = 'no'
    kiosk              = 'no'
    # visible check online/offline
    ENABLEONLINE       = uservar.ENABLEONLINE
    ENABLEOFFLINE      = uservar.ENABLEOFFLINE
    ENABLEXML          = uservar.ENABLEXML
    ## Special unicode spacers
    SHADEFULL          = uservar.SHADEFULL
    SHADEDARK          = uservar.SHADEDARK
    SHADEMEDIUM        = uservar.SHADEMEDIUM
    SHADELIGHT         = uservar.SHADEFULL
    SPACERSHADE        = uservar.SPACERSHADE
    SPACERUP           = uservar.SPACERUP
    SPACERDOWN         = uservar.SPACERDOWN
    SPACERRIGHT        = uservar.SPACERRIGHT
    SPACERLEFT         = uservar.SPACERLEFT
    SPACERSQUARE       = uservar.SPACERSQUARE #---best
    SPACERSQUAREL      = uservar.SPACERSQUAREL
    SPACERCIRCLE       = uservar.SPACERCIRCLE #---best
    SPACERCIRCLEL      = uservar.SPACERCIRCLEL
    SPACERSTAR         = uservar.SPACERSTAR
    SPACERCICLELINE    = uservar.SPACERCICLELINE
    SPACERDASH         = uservar.SPACERDASH
    SPACERRIGHTWARD    = uservar.SPACERRIGHTWARD
    SPACERNO           = uservar.SPACERNO
    SPACERYES          = uservar.SPACERYES
    SPACERSEP          = uservar.SPACERSEP
    SPACERTRIANGLE     = uservar.SPACERTRIANGLE
    # default color flags
    COLORTXT           = uservar.COLORTXT          # white
    COLORSPACER        = uservar.COLORSPACER       # darkgrey
    COLORSIZES         = uservar.COLORSIZES        # lightgreen
    COLORWARNING       = uservar.COLORWARNING      # orange
    COLORONLINE        = uservar.COLORONLINE       # steelblue
    COLOROFFLINE       = uservar.COLOROFFLINE      # cadetblue
    COLORON            = uservar.COLORON           # limegreen
    COLOROFF           = uservar.COLOROFF          # red
    # menu item dir flags
    COLORMENU          = uservar.COLORMENU         # goldenrod
    COLORSUBMENU       = uservar.COLORSUBMENU      # darkgreen
    COLORSUBTITLE      = uservar.COLORSUBTITLE     # grey
    COLORDESC          = uservar.COLORDESC         # dodgerblue
    # popup headers
    COLORHEADER        = uservar.COLORHEADER       # gold
    COLORHEADERTXT     = uservar.COLORHEADERTXT    # white
    COLORHEADERINFO    = uservar.COLORHEADERINFO   # lightblue
    #
    LOGFILES           = wiz.LOGFILES
    TRAKTID            = traktit.TRAKTID
    DEBRIDID           = debridit.DEBRIDID
    LOGINID            = loginit.LOGINID
    ALLUCID            = allucit.ALLUCID
    MODURL             = uservar.MODURL
    MODURL2            = uservar.MODURL2
    INSTALLMETHODS     = ['Always Ask', 'Reload Profile', 'Force Close']
    DEFAULTPLUGINS     = uservar.DEFAULTPLUGINS
    # custom sys info below
    REPOID             = uservar.REPOID
    userAgent          = 'User-Agent'
    USER_AGENT         = uservar.USER_AGENT
    ### sys info for descriptions ###
    kodi_version       = uservar.kodi_version
    pythonver          = platform.python_version()
    osinfo             = platform.system()+' '+platform.release() 
    dns1               = xbmc.getInfoLabel('Network.DNS1Address')
    gateway            = xbmc.getInfoLabel('Network.GatewayAddress')
    IPAddress          = xbmc.getInfoLabel('Network.IPAddress')
    InternetState      = xbmc.getInfoLabel('System.InternetState')
    CpuUsage           = xbmc.getInfoLabel('System.CpuUsage')
    totalmem           = xbmc.getInfoLabel('System.Memory(total)')
    freemem            = xbmc.getInfoLabel('System.FreeMemory')
    ScreenWidth        = xbmc.getInfoLabel('System.ScreenWidth')
    ScreenHeight       = xbmc.getInfoLabel('System.ScreenHeight')
    screenres          = ScreenWidth+'x'+ScreenHeight
    SPACER             = uservar.SPACER
    descriptioninfo    = '[COLOR '+COLORDESC+']Ver:[/COLOR] [COLOR '+COLORTXT+']'+kodi_version+ '[/COLOR]\n[COLOR '+COLORDESC+']OS:[/COLOR] [COLOR '+COLORTXT+']'+osinfo+ '[/COLOR]\n[COLOR '+COLORDESC+']Cpu:[/COLOR] [COLOR '+COLORTXT+']'+CpuUsage+ '[/COLOR] [COLOR '+COLORDESC+']Mem:[/COLOR] [COLOR '+COLORTXT+']'+freemem+ ' \ '+totalmem+ '[/COLOR]\n[COLOR '+COLORDESC+']IP:[/COLOR] [COLOR '+COLORTXT+']'+IPAddress+ '[/COLOR]  '+screenres+'\n[COLOR '+COLORDESC+']py [B]'+pythonver+'[/B][/COLOR]  [COLOR '+COLORHEADER+']( 2.7.9+ TLS\https)[/COLOR]\n'
    ####################################
    ## themes
    ####################################
    # online flags
    ONLINEFLAG         = uservar.ONLINEFLAG
    OFFLINEFLAG        = uservar.OFFLINEFLAG
    OFFLINEXMLFLAG     = uservar.OFFLINEXMLFLAG
    # on off toggle
    SPACEROFF          = uservar.SPACEROFF
    SPACERON           = uservar.SPACERON
    off                = uservar.off
    on                 = uservar.on
    offitem            = uservar.offitem
    onitem             = uservar.onitem
    # special themes
    THEMESPACER        = uservar.THEMESPACER
    THEMEWARNING       = uservar.THEMEWARNING
    # primary menu
    THEMEMENU          = uservar.THEMEMENU
    THEMEMENUB         = uservar.THEMEMENUB
    THEMETOGGLE        = uservar.THEMETOGGLE
    THEMEMENUITEM      = uservar.THEMEMENUITEM
    # Primary file items
    THEMEDEFAULT       = uservar.THEMEDEFAULT
    THEMEDEFAULTI      = uservar.THEMEDEFAULTI
    THEMEDEFAULTB      = uservar.THEMEDEFAULTB
    # Sub menu items
    THEMESUBMENU        = uservar.THEMESUBMENU
    THEMESUBMENUB       = uservar.THEMESUBMENUB
    THEMESUBMENUITEM    = uservar.THEMESUBMENUITEM
    THEMESUBMENUITEMB   = uservar.THEMESUBMENUITEMB
    # build and skin headers
    THEMECURRENTSKIN   = uservar.THEMECURRENTSKIN
    THEMECURRENTBUILD  = uservar.THEMECURRENTBUILD
    try:    INSTALLMETHOD    = int(float(wiz.getS('installmethod')))
    except: INSTALLMETHOD    = 0
#           Main Settings END
def index(name=None, url=None):
    #addDir (display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
    #addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
    # this addon possible update
    if AUTOUPDATE == 'Yes':
        wizfile = wiz.textCache(WIZARDFILE)
        if not wizfile == False:
            ver = wiz.checkWizard('version')
            if ver > VERSION: addFile('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (ADDONTITLE, VERSION, ver), 'wizardupdate', themeit=THEMEDEFAULT)
            #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEMEDEFAULT)
        #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEMEDEFAULT)
    #else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEMEDEFAULT)
    # build version tag
    if len(BUILDNAME) > 0:
        version = wiz.checkBuild(BUILDNAME, 'version')
        build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
        if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
        addDir(build,'viewbuild', BUILDNAME, themeit=THEMECURRENTBUILD)
        themefile = wiz.themeCount(BUILDNAME)
        if not themefile == False:
            addFile('None' if BUILDTHEME == "" else BUILDTHEME, 'theme', BUILDNAME, themeit=THEMECURRENTSKIN)
    #else: addDir('None', 'builds', themeit=THEMECURRENTBUILD)
    #if have_internet() == False: addFile('INTERNET NOT CONNECTED',   '',  description='Connect to Internet',  icon=ICONSETTINGS, themeit=THEMEMENUB)
    # Cleaner sizes
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    sizecache  = wiz.getCacheSize()
    totalsize  = sizepack+sizethumb+sizecache
    addDir('CLEAN KODI FILES  [COLOR %s][I](Cache\Packages\Thumbs)[/I][/COLOR]  [COLOR %s]%s[/COLOR]' % (COLORDESC,COLORSIZES,wiz.convertSize(totalsize)), 'cleaningMenu', name, url, createMenu('autoclean', '', 'Clean All Kodi Files Now'), description='Clean common Kodi files like Cache\Packages\Thumbs that slow your system down over time.',  icon=ICONCLEAN, themeit=THEMEMENUB)
    addDir('ADDONS   [COLOR %s](Programs)[/COLOR]' % COLORDESC, 'addonMenuMain',  description='Install Kodi 3rd party addons, pre configured addon zips (builds) or Android apks.\nStart here if you have a fresh setup.', icon=ICONADDONS,themeit=THEMEMENUB)
    addDir('ANDROID  [COLOR %s](apk)[/COLOR]' % COLORDESC,  'apkMenuMain',  description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPK, themeit=THEMEMENUB)
    addDir('BUILDS      [COLOR %s](Zips)[/COLOR]' % COLORDESC,  'buildsMenu',  description='3rd Party pre fabricated builds or zips of preset Kodi configurations',  icon=ICONBUILDS, themeit=THEMEMENUB)
    addDir('TWEAKS     [COLOR %s](FIXES %s TOOLS %s MAINTENANCE)[/COLOR]' % (COLORDESC,SPACER,SPACER), 'maint', 'tweaks', description='Perform various Kodi and Addon tweaks',  icon=ICONMAINT, themeit=THEMEMENUB)
    addDir('BACKUP  [COLOR %s]%s[/COLOR]  RESTORE' % (COLORDESC,SPACER),  'backupMenu',   description='Backup or Restore a zip file backup of your Kodi system setup and addons', icon=ICONBACKUP,themeit=THEMEMENUB)
    addDir('XMLs      [COLOR %s](playerfactorycore.xml %s advancedsettings.xml)[/COLOR]' % (COLORDESC,SPACER), 'xmlMenu',   description='Install an XML file like advancedsettings or playercorefactory to increse Kodi performance or features.',  icon=ICONXML,themeit=THEMEMENUB)
    addDir('MEDIA    [COLOR %s](Youtube %s M3U %s VOD %s CHROME)[/COLOR]' % (COLORDESC, SPACER, SPACER, SPACER),  'mediaMenu',  description='Youtube tutorials for what the hell to do',  icon=ICONVIDEO, themeit=THEMEMENUB)
    addDir('LOG        [COLOR %s](Errors %s Help)[/COLOR]' % (COLORDESC, SPACER), 'logMenu',   description='View or upload your Kodi log file to diagnose errors',  icon=ICONLOG,themeit=THEMEMENUB)
    errors = int(errorChecking(count=True))
    errorsfound = '  [COLOR goldenrod]'+str(errors)+'[/COLOR]  Error(s) Found' if errors > 0 else 'None Found'
    if errors > 0: addFile('View Errors in Log:   %s' % (errorsfound), 'viewerrorlog', description='View all errors in the Kodi log',  icon=ICONMAINT, themeit=THEMEDEFAULT)
    if DEVELOPER == 'true': addDir('DEVELOPER', 'developer',  description='These are advanced Kodi settings intended for seasoned users', icon=ICON, themeit=THEMEMENUB)
    if HIDECONTACT == 'No': addFile('Help With Server and Donate via https://www.paypal.me/name',   'contact',  description='Cheers',  icon=ICONCONTACT, themeit=THEMEMENUB)
    #if wiz.workingURL('www.google.com') == False: addFile('[B][COLOR red]NO INTERNET CONNECTION[/COLOR][/B]', '',  description='Connect to internet',  icon=ICONCONTACT, themeit=THEMEMENUB)
    #addFile('DBremove',  'DBremove',  description='Instructions for how to use GitHub Browser',  icon=ICONINFO, themeit=THEMEDEFAULTB)
    #addDir('ADDONS',     'addons',     description='Install Kodi 3rd party addons, pre configured addon zips (builds) or Android apks.\nStart here if you have a fresh setup.', icon=ICONADDONS,themeit=THEMEMENUB)
    #addDir('ANDROID  [COLOR %s](apk)[/COLOR]' % COLORDESC,   'apk',      description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPK, themeit=THEMEMENUB)
    #if xbmc.getCondVisibility('system.platform.android'):   addDir ('ANDROID  [COLOR %s](apk)[/COLOR]'% COLORDESC,'apkMenuMain',description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPKS, themeit=THEMEMENUB)
    #addDir('BUILDS      [COLOR %s](Zips)[/COLOR]' % COLORDESC,    'builds',      description='3rd Party pre fabricated builds or zips of preset Kodi configurations',  icon=ICONBUILDS, themeit=THEMEMENUB)
    #addDir('CLEAN KODI FILES  [COLOR %s][I](Cache\Packages\Thumbs)[/I][/COLOR]  [COLOR %s]%s[/COLOR]' % (COLORDESC, COLORSIZES, wiz.convertSize(totalsize)), 'maint', 'clean', description='Clean common Kodi files like Cache\Packages\Thumbs that slow your system down over time.',  icon=ICONCLEAN, menu=menuautoclean, themeit=THEMEMENUB)
    #addDir('MAINTENANCE  and  FIXES',  'maint', 'misc', description='Various Kodi Maintenance Tools and Fixes', icon=ICONMAINT,themeit=THEMEMENUB)
    #addDir('BACKUP  [COLOR %s]%s[/COLOR]  RESTORE' % (COLORDESC,SPACER),'maint', 'backup',   icon=ICONMAINT, themeit=THEMEMENUB)
    #addDir('ADDON TOOLS','maint', 'addon',   icon=ICONMAINT, themeit=THEMEMENUB)
    #addDir('TWEAKS','maint', 'tweaks',   icon=ICONMAINT, themeit=THEMEMENUB)
    #addDir('GITHUB BROWSER',   'githubmain',       description='Search the common addon www host Github for addons.\nThanks to TVA.', icon=ICONGITHUB, themeit=THEMEMENUB)
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
    #addDir ('SAVE DATA', 'savedata', icon=ICONSAVE,     themeit=THEMEMENUB)
    #if not YOUTUBEFILE == 'http://' and not YOUTUBETITLE == '': addDir (YOUTUBETITLE ,'youtube', icon=ICONYOUTUBE, themeit=THEMEMENUB)
    #addFile('Upload Log File', 'uploadlog',       icon=ICONMAINT, themeit=THEMEMENUB)
    #addFile('View Errors in Log: %s' % (errorsfound), 'viewerrorlog', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #if errors > 0: addFile('View Last Error In Log', 'viewerrorlast', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('Force Update Text Files', 'forcetext', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
    #addFile('Settings', 'settings', icon=ICONSETTINGS, themeit=THEMEDEFAULT)
    #addDir('TV Guide Skins  [COLOR grey](IPTV)[/COLOR]',    'indextvguide',  description='Set skin modded settings for tv guide fullscreen', icon=ICONVIDEO, themeit=THEMEMENUB)
    #addFile('Repo [COLOR grey]'+REPOID+'[/COLOR]  (Main repo)', 'Repolink', REPOID, description='Browse the main '+REPOID+' Default Repo for Addons and Skins',  icon=ICONREPO,themeit=THEMEDEFAULT)
    #addFile('Settings     [COLOR grey]' +ADDONTITLE+'  ('+ADDON_ID+')[/COLOR]','settings', description='Open the main settings for '+ADDON_ID, icon=ICONSETTINGS, themeit=THEMEDEFAULT)
    #if not ADDONNEWID == '':  addFile('Run Clone    [COLOR %s]%s  (%s)[/COLOR]' % (COLORHEADERINFO,ADDONNEWNAME,ADDONNEWID), 'runaddon',  name=ADDONNEWID,  description='Open the settings for '+ADDON_ID, icon=ICONSETTINGS, themeit=THEMEDEFAULT)
    setView('files', 'viewType')

















# create addon text
def addaddon(name=None, plugin=None, url=None, repository=None, repositoryxml=None, repositoryurl=None, icon=ICONADDONS, fanart=FANART, adult=None, description=None): # create txt addon entry
    if url:
        filename = getFileName(name)
        content = 'name="'+name+'"\nplugin="'+plugin+'"\nurl="'+url+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+name+'"'
        fh = open(os.path.join(pluginsTXTFolder, filename+linkortxt), 'w')
        fh.write(content)
        fh.close()
        wiz.refresh()
    else:
        choice = DIALOG.select('Create Addon Style  (Section)', ['[COLOR yellow]Cancel[/COLOR]',
                                   'Addon or Repo (ID)',
                                   'Menu  (url to txt)',
                                   'Addon Pack  (url to zip)',
                                   'Skin Pack   (url to zip)',
                                   'Rom Pack    (url to zip)'])
        if choice == 0: sys.exit(0)
        if choice == 1:
            keyboard = xbmc.Keyboard('', 'Plugin Name (ID)')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():  plugin = keyboard.getText()
        if choice == 2: plugin = 'section'
        if choice == 3: plugin = 'pack'
        if choice == 4: plugin = 'skin'
        if choice == 5: plugin = 'rom'
        #
        keyboard = xbmc.Keyboard(plugin, 'Menu Name')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():  name = keyboard.getText()
        #
        
        
        keyboard = xbmc.Keyboard('none', 'Repository Name (ID)')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText(): repository = keyboard.getText()
        #
        if repository == 'none':
            repositoryurl = 'http://'
            repositoryxml = 'http://'
        else:
            keyboard = xbmc.Keyboard('', 'Repository url')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText(): repositoryurl = keyboard.getText()
            #
            keyboard = xbmc.Keyboard(repositoryurl+'addon.xml', 'Repository xml url')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText(): repositoryxml = keyboard.getText()
            
        
        
        keyboard = xbmc.Keyboard('', 'URL to file')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText(): url = keyboard.getText()
        #
        icon = url+'icon.png'
        description = name
        '''
        #
        keyboard = xbmc.Keyboard(url+'icon.png', 'URL to icon (Default)')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText(): icon = keyboard.getText()
        #
        keyboard = xbmc.Keyboard(name, 'Description?')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():  description = keyboard.getText()
        #
        '''
        
        #####################
        #
        if name == None:  name = 'Addons'
        if url == None:  url = 'http://'
        if plugin == None:  plugin = 'section'
        if repository == None:  repository = 'none'
        if repositoryxml == None:  repositoryxml = 'http://'
        if repositoryurl == None:  repositoryurl = 'http://'
        if icon == None:  icon   = 'http://'
        if fanart == None:  fanart = 'http://'
        if adult == None:  adult  = 'no'
        if description == None:  description = name
        #
        content = 'name="'+name+'"\nplugin="'+plugin+'"\nurl="'+url+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"'
        #fh = open(os.path.join(pluginsTXTFolder, getFileName(name)+linkortxt), 'w')
        if plugin == 'none': fh = open(os.path.join(pluginsTXTFolder, getFileName(name)+linkortxt), 'w')
        else:  fh = open(os.path.join(pluginsTXTFolder, plugin+linkortxt), 'w')
        fh.write(content)
        fh.close()
    wiz.refresh()









# install addons or repos from xml dirs
def exportaddons(name=None, symlinks=False, ignore=None):
    src = xbmc.translatePath(addonsTXTFolder)
    dst = xbmc.translatePath(ADDONS)
    do = ['Install ALL', 'Install Repos', 'Install Addons']
    selected = DIALOG.select("[COLOR %s]Export Plugins[/COLOR]" % COLORHEADER, do)
    if selected == 0: #all
        if os.path.exists(src):
            for item in os.listdir(src):
                s = os.path.join(src, item)
                d = os.path.join(dst, item)
                if os.path.isdir(s):
                    if not os.path.exists(d): 
                        shutil.copytree(s, d, symlinks, ignore)
                else:
                    shutil.copy2(s, d)
                set_enabled(item, data=None)
            #_notify('Parsing Repos', 'DONE!', ICON, duration=1000)
            #DIALOG.ok(ADDONTITLE, "[COLOR %s]Done exporting Repositories.[/COLOR]" % COLORHEADERTXT)
            #xbmc.executebuiltin('UpdateAddonRepos')
            #xbmc.executebuiltin('UpdateLocalAddons')
    elif selected == 1: # repos
        if os.path.exists(src):
            for item in os.listdir(src):
                s = os.path.join(src, item)
                d = os.path.join(dst, item)
                if os.path.isdir(s):
                    if not os.path.exists(d): 
                        shutil.copytree(s, d, symlinks, ignore)
                else:
                    shutil.copy2(s, d)
                set_enabled(item, data=None)
            #_notify('Parsing Repos', 'DONE!', ICON, duration=1000)
            #DIALOG.ok(ADDONTITLE, "[COLOR %s]Done exporting Repositories.[/COLOR]" % COLORHEADERTXT)
            #xbmc.executebuiltin('UpdateAddonRepos')
            #xbmc.executebuiltin('UpdateLocalAddons')
    elif selected == 2: # addons
        if os.path.exists(src):
            for item in os.listdir(src):
                s = os.path.join(src, item)
                d = os.path.join(dst, item)
                if os.path.isdir(s):
                    if not os.path.exists(d): 
                        shutil.copytree(s, d, symlinks, ignore)
                else:
                    shutil.copy2(s, d)
                set_enabled(item, data=None)
            #_notify('Parsing Repos', 'DONE!', ICON, duration=1000)
            #DIALOG.ok(ADDONTITLE, "[COLOR %s]Done exporting Repositories.[/COLOR]" % COLORHEADERTXT)
            #xbmc.executebuiltin('UpdateAddonRepos')
            #xbmc.executebuiltin('UpdateLocalAddons')
            
    else: return


# backup addons and repos to xml dirs
def importaddons(name=None, plugin=None, url=None, repository=None, repositoryxml=None, repositoryurl=None, icon=ICONADDONS, fanart=FANART, adult=None, description=None, DP=None):
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        elif foldername in DEFAULTPLUGINS: continue
        elif foldername in ADDONTEMPFOLDER: continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            #
            #TEMPADDON         = xbmcaddon.Addon().getAddonInfo('id')
            try: TEMPADDONID  = xbmcaddon.Addon(id=foldername)
            except TypeError: continue
            type    = TEMPADDONID.getAddonInfo('type')
            name    = TEMPADDONID.getAddonInfo('name')
            author  = TEMPADDONID.getAddonInfo('author')
            version = TEMPADDONID.getAddonInfo('version')
            plugin         = foldername
            url            = "http://"
            repository     = "none"
            repositoryxml  = "http://"
            repositoryurl  = "http://"
            icon           = "http://"
            fanart         = "http://"
            adult          = 'no'
            description    = TEMPADDONID.getAddonInfo('description')
            #
            # xml addonsXMLFolder
            newxmlfile = os.path.join(addonsTXTFolder, plugin, 'addon.xml')
            if not os.path.exists(os.path.join(addonsTXTFolder, plugin)):   xbmcvfs.mkdirs(os.path.join(addonsTXTFolder, plugin))
            s=open(xml).read()
            s=s.replace(version, '0.0.0')
            f=open(newxmlfile,'w')
            f.write(s)
            f.close()
            
            if type == 'xbmc.addon.repository':
                # txt
                newfile = os.path.join(reposTXTFolder, plugin+linkortxt)
                delete_file(newfile)
                #
                f = open(xml)
                a = f.read()
                f.close()
                repository = plugin
                repositoryxmltest = wiz.parseDOM(a, 'info')
                repositoryurltest = wiz.parseDOM(a, 'datadir')
                item = [];x='';y=''
                for item in range(0,5):
                    REPOWORKING = False
                    try: REPOWORKING = wiz.workingURL(repositoryxmltest[item])
                    except: False
                    if REPOWORKING == True and not 'noobsandnerds' in url:
                        ico = xbmc.translatePath(os.path.join(ADDONS, plugin, 'icon.png'))
                        if not os.path.exists(ico):  _notify('Import Repo', plugin, ICON, duration=1000)
                        else:  _notify('Import Repo', plugin, ico, duration=1000)
                        repositoryxml = repositoryxmltest[item]
                        repositoryurl2 = repositoryurltest[item]
                        if not repositoryurl2.endswith('/'): repositoryurl = repositoryurl2+'/'+plugin+'/'
                        else:  repositoryurl = repositoryurl2+plugin+'/'
                        url  = repositoryurl
                        icon = repositoryurl+'icon.png'
                        ICONWORKING = wiz.workingURL(icon)
                        if not ICONWORKING == True: icon = "http://"
                        #
                        if not item == 0:                  x = '  ('+str(item)+')'; y = '_'+str(item)
                        if   'helix' in repositoryurl:     x = '  (14 Helix)'; y = '_14'
                        elif 'isengard' in repositoryurl:  x = '  (15 Isengard)'; y = '_15'
                        elif 'jarvis' in repositoryurl:    x = '  (16 Jarvis)'; y = '_16'
                        elif 'krypton' in repositoryurl:   x = '  (17 Krypton)'; y = '_17'
                        elif 'leia' in repositoryurl:      x = '  (18 Leia)'; y = '_18'
                        elif 'modules' in repositoryurl:   x = '  (Modules)'; y = '_module'
                        #
                        newfile = os.path.join(reposTXTFolder, plugin+y+linkortxt)
                        fh = open(newfile, 'w')
                        fh.write('name="'+name+x+'"\n')
                        fh.write('plugin="'+plugin+'"\n')
                        fh.write('url="'+url+'"\n')
                        fh.write('repository="'+repository+'"\n')
                        fh.write('repositoryxml="'+repositoryxml+'"\n')
                        fh.write('repositoryurl="'+repositoryurl+'"\n')
                        fh.write('icon="'+icon+'"\n')
                        fh.write('fanart="'+fanart+'"\n')
                        fh.write('adult="'+adult+'"\n')
                        fh.write('description="Imported '+name+' '+version+' '+author+' '+description+'"\n\n')
                        fh.close()

    wiz.refresh()
    _notify('Parsing Repos DONE!', plugin, ICON, duration=3000)
    #xbmc.executebuiltin('UpdateAddonRepos')
    #xbmc.executebuiltin('UpdateLocalAddons')
    DIALOG.ok(ADDONTITLE, "[COLOR %s]Done importing Repositories.  Right click a Repo txt to import an addon.[/COLOR]" % COLORHEADERTXT)



'''
#wiz.ebi('RunPlugin(plugin://%s)' % plugin)
def installzip():
    wiz.ebi('RunAddon()')
def zipinstaller():
    wiz.ebi('PlayMedia(plugin://'+ADDON_ID+'/?mode=addoninstall&name=%s)' % plugin)
def Myaddons():
    wiz.ebi('ActivateWindow(10040,addons://user/,return)')
def Videoaddons():
    wiz.ebi('ActivateWindow(10040,addons://user/xbmc.addon.video,return)')
def Addonrepository():
    wiz.ebi('ActivateWindow(10040,addons://user/xbmc.addon.repository,return)')
def recently_updated():
    wiz.ebi('ActivateWindow(10040,addons://recently_updated/,return)')
def Installfromrepository():
    wiz.ebi('ActivateWindow(10040,addons://repos/,return)')
def reposearch():
    wiz.ebi('ActivateWindow(10040,addons://search/,return)')
def aaaAddonrepository():
    wiz.ebi('ActivateWindow(10040,addons://'+ADDON_ID+'/xbmc.addon.repository,return)')
def Programaddons():
    wiz.ebi('ActivateWindow(10040,addons://'+ADDON_ID+'/xbmc.addon.executable,return)')
def Lookandfeel():
    wiz.ebi('ActivateWindow(10040,addons://'+ADDON_ID+'/category.lookandfeel,return)')
'''
'''
def installOPENaddon(IDdoADDON):    
    pathTOaddon = os.path.join(xbmc.translatePath('special://home/addons'), IDdoADDON)
    if not os.path.exists(pathTOaddon)==True:
        xbmc.executebuiltin('InstallAddon(%s)' % (IDdoADDON))
        xbmc.executebuiltin('SendClick(11)'), time.sleep(2), xbmcgui.Dialog().ok("Add-on Install", "The addon was not present. Please wait for installation to finish.")
    else:  pass
    if os.path.exists(pathTOaddon)==True:  xbmc.executebuiltin('RunAddon(%s)' % (IDdoADDON))
    else:  xbmcgui.Dialog().ok("Add-on Error", "Could not install or open add-on. Please try again...")
'''


###########################
# Addons               ####
###########################
def addonMenuMain(name=None, url=None):
    # Append Built in files to plugins.txt
    txt   = os.path.join(pluginsTXTFolder, '*'+linkortxt)
    filenames = glob.glob(txt)
    with open(pluginfile, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    # Append Built in files to repos.txt
    txt2   = os.path.join(reposTXTFolder, '*'+linkortxt)
    filenames = glob.glob(txt2)
    with open(repofile, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    #
    #addDir('Install from zip file', 'installzip', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('zipinstaller', 'zipinstaller', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    ##addDir('My add-ons', 'Myaddons', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    ##addDir('Video add-ons', 'Videoaddons', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Add-on repository', 'Addonrepository', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Recently updated', 'recently_updated', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Install from repository', 'Installfromrepository', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Search repository', 'reposearch', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Add-on repository', 'Addonrepository', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Program add-ons', 'Programaddons', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    #addDir('Look and feel', 'Lookandfeel', '', description='Perform various Kodi and Addon tweaks',  icon=ICONADDONS, themeit=THEMEDEFAULT)
    addDir('ADDON TOOLS', 'addonMenuTools', '', description='Perform various Kodi and Addon tweaks',  icon=ICONMAINT, themeit=THEMEMENUB)
    # addon file
    if ENABLEONLINE  == 'true':
        if not ADDONFILE == 'http://':
            #menuaddonrefresh = createMenu('editaddon', 'addons', addonsTXTFolder)
            if not ADDONFILE   == 'http://': 
                name   = os.path.basename(ADDONFILE)
                name2  = os.path.basename(ADDONFILE)
                addDir('[B]%s[/B]   (MAIN ONLINE)' % name2, 'addons', '', '', createMenu('editaddon', 'addons', ADDONFILE), description='[COLOR %s]Main Menu url:[/COLOR]\n%s\n%s' % (COLORDESC, name, ADDONFILE), icon=ICONADDONS, fanart=FANART, themeit=THEMEMENU)
                if url == None:
                    TEMPADDONFILE = wiz.textCache(uservar.ADDONFILE)
                    if TEMPADDONFILE == False: ADDONWORKING  = wiz.workingURL(uservar.ADDONFILE)
                else:
                    TEMPADDONFILE = wiz.textCache(url)
                    if TEMPADDONFILE == False: ADDONWORKING  = wiz.workingURL(url)
                if not TEMPADDONFILE == False:
                    link = TEMPADDONFILE.replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                    match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                    if len(match) > 0:
                        x = 0
                        for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                            x += 1
                            if icon   == 'http://': icon = ICONADDONS
                            if fanart == 'http://': fanart = FANART
                            if not aurl == 'http://':
                                name2    =  os.path.basename(aurl)
                                '''
                                if plugin.lower() == 'section':
                                    x += 1
                                    addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', ADDONFILE), description='[COLOR %s]Menu url:[/COLOR]\n%s  %s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                                elif plugin.lower() == 'skin':
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    x += 1
                                    addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', ADDONFILE), description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                                elif plugin.lower() == 'pack':
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    x += 1
                                    addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', ADDONFILE), description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                                else:
                                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                    x += 1
                                    # check is installed
                                    SETCOL1='white'
                                    SETCOL2='grey'
                                    if os.path.exists(os.path.join(ADDONS, plugin)):
                                        try:
                                            if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                            elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                                        except: pass
                                    if os.path.exists(os.path.join(ADDONS, repository)):
                                        try:
                                            if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                            elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                                        except: pass
                                    if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                                    if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                    elif plugin.startswith('repo'): NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                    else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                    if ADDONENABLEONLINE2 == 'true':
                                        addFile(NAME, 'addoninstall', plugin, url, createMenu('editaddon', 'addons', ADDONFILE), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                                '''
                                if x < 1:
                                    addFile("No addons added to this menu yet!", '', themeit=THEMEDEFAULT)
                        #else: 
                        #    addFile('Text File not formated correctly!', '', themeit=THEMEDEFAULT)
                        #    wiz.log("[Addon Menu] ERROR: Invalid Format.")
                    else: 
                        wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
                        addFile('Url for txt file not valid', '', themeit=THEMEDEFAULT)
                        addFile('%s' % ADDONWORKING, '', themeit=THEMEDEFAULT)
                else: wiz.log("[Addon Menu] No Addon list added.")
    #
    if ENABLEOFFLINE == 'true':
        if os.path.exists(addonfile): addDir('[B]PLUGINS[/B]   (txt)',   'addonMenuoffline', name, pluginfile, createMenu('editaddon', 'plugins', pluginfile), description='[COLOR %s]Main Menu url:[/COLOR]\n%s\n%s' % (COLORDESC, name, ADDONFILE), icon=ICONADDONS, fanart=FANART, themeit=THEMEMENU)
        if os.path.exists(repofile):  addDir('[B]REPOS[/B]      (txt)', 'addonMenuoffline', name, repofile, createMenu('editaddon', 'repos', repofile), description='[COLOR %s]Main Menu url:[/COLOR]\n%s\n%s' % (COLORDESC, name, ADDONFILE), icon=ICONADDONS, fanart=FANART, themeit=THEMEMENU)
        # plugins
        files2 = []
        try: files2 = os.listdir(pluginsTXTFolder)
        except: pass
        for file in files2:
            file  = xbmc.translatePath(os.path.join(pluginsTXTFolder, file))
            link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    if icon   == 'http://': icon = ICONADDONS
                    if fanart == 'http://': fanart = FANART
                    name2    =  os.path.basename(aurl)
                    if plugin.lower()   == 'section':
                        x += 1
                        addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                    '''
                    elif plugin.lower() == 'skin':
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                    elif plugin.lower() == 'pack':
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'plugins', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                    else:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        # check is installed
                        SETCOL1='white'
                        SETCOL2='grey'
                        if os.path.exists(os.path.join(ADDONS, plugin)):
                            try:
                                if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                            except: pass
                        if os.path.exists(os.path.join(ADDONS, repository)):
                            try:
                                if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                            except: pass
                        if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                        if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                    '''
        # repos
        files3 = []
        try: files3 = os.listdir(reposTXTFolder)
        except: pass
        for file in files3:
            file  = xbmc.translatePath(os.path.join(reposTXTFolder, file))
            link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                    if icon   == 'http://': icon = ICONADDONS
                    if fanart == 'http://': fanart = FANART
                    name2    =  os.path.basename(aurl)
                    '''
                    if plugin.lower()   == 'section':
                        x += 1
                        addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                    elif plugin.lower() == 'skin':
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                    elif plugin.lower() == 'pack':
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                    else:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        x += 1
                        # check is installed
                        SETCOL1='white'
                        SETCOL2='grey'
                        if os.path.exists(os.path.join(ADDONS, plugin)):
                            try:
                                if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                            except: pass
                        if os.path.exists(os.path.join(ADDONS, repository)):
                            try:
                                if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                            except: pass
                        if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                        if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        #elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                        addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                    '''
        #menuaddonrefresh = createMenu('editaddon', 'addons', addonsTXTFolder)
        # online txt menu file urls
        for items in range(1,100):
            name = wiz.getS('ADDONNAMEONLINE%s' % items)
            url  = wiz.getS('ADDONFILEONLINE%s' % items)
            name2   = 'xml'
            if not url == 'http://':
                if wiz.workingURL(url) == True:
                    addDir('[B]%s[/B]' % name, 'addons',  name, url,  description='[COLOR %s]Kodi addon menu:[/COLOR]\n%s\n%s\n%s' % (COLORDESC, name,name2,url), icon=ICONADDONS, themeit=THEMEMENU)
                    # this is an unnessessary txt merge so you can post them all online
                    try:
                        content = 'name="'+name+'"\nplugin="section"\nurl="'+url+'"\nrepository="none"\nrepositoryxml="http://"\nrepositoryurl="http://"\nicon="'+ICONADDONS+'"\nfanart="'+FANART+'"\nadult="no"\ndescription="'+name+'"\n\n'
                        fh = open(pluginfile, 'a')
                        fh.write(content)
                        fh.close()
                    except: pass
        #
        # full xml plugin range
        for items in range(1,100):
            enable        = wiz.getS('ADDONENABLE%s' % items) # bool
            aname         = wiz.getS('ADDONNAME%s' % items)
            aurl          = wiz.getS('ADDONURL%s' % items)
            icon          = wiz.getS('ADDONICONURL%s' % items)
            section       = wiz.getS('ADDONSECTION%s' % items) # bool
            plugin        = wiz.getS('ADDONPLUGIN%s' % items)
            repository    = wiz.getS('ADDONREPO%s' % items)
            repositoryxml = wiz.getS('ADDONREPOXML%s' % items)
            repositoryurl = wiz.getS('ADDONREPOURL%s' % items)
            if icon   == 'http://': icon = ICONADDONS
            fanart=FANART
            adult='no'
            description=aname
            name2 = os.path.basename(aurl)
            if enable == 'true':
                '''
                if plugin.lower()   == 'section':
                    addDir("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', items, aname), description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                elif plugin.lower() == 'skin':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl,  createMenu('editaddon', items, aname), description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENUITEM)
                elif plugin.lower() == 'pack':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl,  createMenu('editaddon', items, aname), description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENUITEM)
                else:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    # check is installed
                    SETCOL1='white'
                    SETCOL2='grey'
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                        except: pass
                    if os.path.exists(os.path.join(ADDONS, repository)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                        except: pass
                    if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                    if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    elif plugin.startswith('repo'): NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    addFile(NAME, 'addoninstall', plugin, url, createMenu('editaddon', items, aname), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMEMENUITEM)
                '''
                # this is an unnessessary txt merge so you can post them all online
                try:
                    content = 'name="'+aname+'"\nplugin="'+plugin+'"\nurl="'+aurl+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"\n\n'
                    fh = open(pluginfile, 'a')
                    fh.write(content)
                    fh.close()
                except: pass
    # Append to addons.txt
    #delete_file(addonfile)
    filenames = [pluginfile, repofile]
    with open(addonfile, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    #
    # addons (plugins non packs and menus)
    ADDONENABLEOFFLINE  = 'true' if wiz.getS('ADDONENABLEOFFLINE')  == 'true' else 'false'
    addFile('%s   [B]%s[/B]  EDIT TXT ADDONS' % (ADDONENABLEOFFLINE.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINE', url, menu=createMenu('editaddon', 'addons', addonsTXTFolder), description='ADDON Offline txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
    if ADDONENABLEOFFLINE == 'true':
        #
        # add txt imports
        addFile('(EXPORT)  Repos and Addons (Install)', 'exportaddons', description='Export your backed up repos',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
        addFile('(IMPORT)  Backup Plugins and Repos to txt',    'importaddons', description='Import your installed repos to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
        addFile('(IMPORT)  Create Plugin txt file [COLOR %s]%s[/COLOR] Addon [COLOR %s]%s[/COLOR] Repo [COLOR %s]%s[/COLOR] Menu [COLOR %s]%s[/COLOR] Pack' % (COLORDESC,SPACER,COLORDESC,SPACER,COLORDESC,SPACER,COLORDESC,SPACER),          'addaddon', description='Add Addon to offline txt file',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
        #addFile('Import Addons to txt',   'importaddons', description='Import your installed Addons to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
        # 
        # addons (plugins non packs and menus)
        ADDONENABLEOFFLINEplugins  = 'true' if wiz.getS('ADDONENABLEOFFLINEplugins')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]  EDIT ADDONS' % (ADDONENABLEOFFLINEplugins.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINEplugins', url, menu=createMenu('editaddon', 'plugins', pluginsTXTFolder), description='ADDON Offline Plgins txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
        if ADDONENABLEOFFLINEplugins == 'true':
            #addFile('Import Addon to txt', 'importaddons', description='Import your installed Addons to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            #delete_file(addonfile)
            #delete_file(repofile)
            #addDir('[B]PLUGINS[/B]   (txt)', 'addonMenuoffline', name, addonfile, createMenu('editaddon', 'addons', addonfile), description='[COLOR %s]Main Menu url:[/COLOR]\n%s\n%s' % (COLORDESC, name, ADDONFILE), icon=ICONADDONS, fanart=FANART, themeit=THEMESUBMENU)
            #addDir('[B]REPOS[/B]     (txt)', 'addonMenuoffline', name, repofile, createMenu('editaddon', 'repos', repofile), description='[COLOR %s]Main Menu url:[/COLOR]\n%s\n%s' % (COLORDESC, name, ADDONFILE), icon=ICONADDONS, fanart=FANART, themeit=THEMESUBMENU)
            files2 = []
            try: files2 = os.listdir(pluginsTXTFolder)
            except: pass
            for file in files2:
                file  = xbmc.translatePath(os.path.join(pluginsTXTFolder, file))
                link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                if len(match) > 0:
                    x = 0
                    for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                        if icon   == 'http://': icon = ICONADDONS
                        if fanart == 'http://': fanart = FANART
                        name2    =  os.path.basename(aurl)
                        if plugin.lower()   == 'section':
                            x += 1
                            addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        elif plugin.lower() == 'skin':
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        elif plugin.lower() == 'pack':
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        #'''
                        else:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            # check is installed
                            SETCOL1='white'
                            SETCOL2='grey'
                            if os.path.exists(os.path.join(ADDONS, plugin)):
                                try:
                                    if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                    elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                                except: pass
                            if os.path.exists(os.path.join(ADDONS, repository)):
                                try:
                                    if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                    elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                                except: pass
                            if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                            if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                        #'''
                        # this is an unnessessary txt merge so you can post them all online
                        '''
                        try:
                            content = 'name="'+aname+'"\nplugin="'+plugin+'"\nurl="'+aurl+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"\n\n'
                            fh = open(addonfile, 'a')
                            fh.write(content)
                            fh.close()
                        except: pass
                        '''
        #
        # repos
        ADDONENABLEOFFLINErepos  = 'true' if wiz.getS('ADDONENABLEOFFLINErepos')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]  EDIT REPOS   ' % (ADDONENABLEOFFLINErepos.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINErepos', url, menu=createMenu('editaddon', 'repos', reposTXTFolder), description='ADDON Offline Repository txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
        if ADDONENABLEOFFLINErepos == 'true':
            # edit
            addFile('Export Repos to txt', 'exportaddons', description='Export your backed up repos',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            addFile('Import Repos to txt', 'importaddons', description='Import your installed repos to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            files3 = []
            try: files3 = os.listdir(reposTXTFolder)
            except: pass
            for file in files3:
                file  = xbmc.translatePath(os.path.join(reposTXTFolder, file))
                link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                if len(match) > 0:
                    x = 0
                    for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                        if icon   == 'http://': icon = ICONADDONS
                        if fanart == 'http://': fanart = FANART
                        name2    =  os.path.basename(aurl)
                        if plugin.lower()   == 'section':
                            x += 1
                            addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        elif plugin.lower() == 'skin':
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        elif plugin.lower() == 'pack':
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                        #'''
                        else:
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            x += 1
                            # check is installed
                            SETCOL1='white'
                            SETCOL2='grey'
                            if os.path.exists(os.path.join(ADDONS, plugin)):
                                try:
                                    if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                    elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                                except: pass
                            if os.path.exists(os.path.join(ADDONS, repository)):
                                try:
                                    if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                    elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                                except: pass
                            if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                            if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            #elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                            addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                        #'''
                        # this is an unnessessary txt merge so you can post them all online
                        '''
                        try:
                            content = 'name="'+aname+'"\nplugin="'+plugin+'"\nurl="'+aurl+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"\n\n'
                            fh = open(repofile, 'a')
                            fh.write(content)
                            fh.close()
                        except: pass
                        '''
        #
    addFile('Install Default XMLs', 'installxmls', description='Install Default XMLs', fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)


    setView('files', 'viewType')

def addonMenuoffline(name='', url=None):
    # untouched online
    if url == None:
        TEMPADDONFILE = wiz.textCache(uservar.ADDONFILE)
        if TEMPADDONFILE == False: ADDONWORKING  = wiz.workingURL(uservar.ADDONFILE)
    else:
        TEMPADDONFILE = url
        try: TEMPADDONFILE = wiz.textCache(url)
        except: pass
        if TEMPADDONFILE == True:
            link = TEMPADDONFILE.replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
        else:
            if os.path.exists(url):
                link = xbmcvfs.File(url,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                TEMPADDONFILE = url
    if not TEMPADDONFILE == False:
        match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
        if len(match) > 0:
            x = 0
            for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                name2 = os.path.basename(aurl)
                if icon   == 'http://': icon = ICONADDONS
                if fanart == 'http://': fanart = FANART
                if plugin.lower() == 'section':
                    x += 1
                    addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Menu url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                elif plugin.lower() == 'skin':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'skinpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Skin url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENUITEM)
                elif plugin.lower() == 'pack':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'addonpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Pack url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENUITEM)

                elif plugin.lower() == 'buildpack':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'addonbuildpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Pack url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENUITEM)

                else:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    # check is installed
                    SETCOL1='white'
                    SETCOL2='grey'
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                        except: pass
                    if os.path.exists(os.path.join(ADDONS, repository)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                        except: pass
                    if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                    if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    #elif plugin.startswith('repo'): NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    #NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    x += 1
                    addFile(NAME, 'addoninstall', plugin, url, createMenu('editaddon', 'addons', url), description='[COLOR blue]Addon url:[/COLOR]\n%s - %s\n%s\n%s' % (aname, name2, url, description), fanart=fanart, icon=icon, themeit=THEMEDEFAULT)
                if x < 1:
                    addFile("No addons added to this menu yet!", '', themeit=THEMEDEFAULT)
        else: 
            addFile('Text File not formated correctly!', '', themeit=THEMEDEFAULT)
            wiz.log("[Addon Menu] ERROR: Invalid Format.")
    else: 
        wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
        addFile('Url for txt file not valid', '', themeit=THEMEDEFAULT)
        addFile('%s' % ADDONWORKING, '', themeit=THEMEDEFAULT)
    setView('files', 'viewType')

def addonMenu(name=None, url=None):
    # untouched online
    if url == None:
        TEMPADDONFILE = wiz.textCache(uservar.ADDONFILE)
        if TEMPADDONFILE == False: ADDONWORKING  = wiz.workingURL(uservar.ADDONFILE)
    else:
        TEMPADDONFILE = wiz.textCache(url)
        if TEMPADDONFILE == False: ADDONWORKING  = wiz.workingURL(url)
    if TEMPADDONFILE == False:
        if os.path.exists(url):
            link = xbmcvfs.File(TEMPADDONFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
            TEMPADDONFILE = True
    else:
        link = TEMPADDONFILE.replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
    if not TEMPADDONFILE == False:
        match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
        if len(match) > 0:
            x = 0
            for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                name2 = os.path.basename(aurl)
                if icon   == 'http://': icon = ICONADDONS
                if fanart == 'http://': fanart = FANART
                if plugin.lower() == 'section':
                    x += 1
                    addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Menu url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                elif plugin.lower() == 'skin':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'skinpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Skin url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)
                elif plugin.lower() == 'pack':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'addonpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Pack url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)

                elif plugin.lower() == 'buildpack':
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    x += 1
                    addFile("[B]%s[/B]" % aname, 'addonbuildpack', aname, aurl, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Pack url:[/COLOR]\n%s  %s\n%s\n%s' % (aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMEMENU)

                else:
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    # check is installed
                    SETCOL1='white'
                    SETCOL2='grey'
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                        except: pass
                    if os.path.exists(os.path.join(ADDONS, repository)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                        except: pass
                    if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                    if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    #elif plugin.startswith('repo'): NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    #NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                    x += 1
                    addFile(NAME, 'addoninstall', plugin, url, createMenu('editaddon', 'addons', TEMPADDONFILE), description='[COLOR blue]Addon url:[/COLOR]\n%s - %s\n%s\n%s' % (aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMEDEFAULT)
                if x < 1:
                    addFile("No addons added to this menu yet!", '', themeit=THEMEDEFAULT)
        else: 
            addFile('Text File not formated correctly!', '', themeit=THEMEDEFAULT)
            wiz.log("[Addon Menu] ERROR: Invalid Format.")
    else: 
        wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
        addFile('Url for txt file not valid', '', themeit=THEMEDEFAULT)
        addFile('%s' % ADDONWORKING, '', themeit=THEMEDEFAULT)
    setView('files', 'viewType')
def addonMenuTools(name=None, url=None):
        addFile('Fresh Start?',   'freshstart',    description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings',    icon=ICONDELETE, themeit=THEMEWARNING)
        addDir('ADDON TWEAKS', 'maint', 'addon', description='Perform various Kodi and Addon tweaks',  icon=ICONMAINT, themeit=THEMEMENUB)
        addDir('GITHUB BROWSER',   'githubmain', description='Search the common addon www host Github for addons.\nThanks to TVA.', icon=ICONGITHUB, themeit=THEMEMENUB)
        addFile('Scan Sources.xml for broken links?', 'checksources',  description='Check sources.xml for broken links',    icon=ICONMAINT, themeit=THEMEDEFAULTB)
        addFile('Scan For Broken Repositories?',     'checkrepos',     description='Check for broken repos',  icon=ICONMAINT, themeit=THEMEDEFAULTB)
        addFile('Scan for Missing Dependencies',     'checkdeps',      description='Install Kodi addons dependencies that run in the background and are needed to work.',icon=ICONMAINT, themeit=THEMEDEFAULTB)
        addFile('Install Offline Addon zip', 'chooseofflineaddon',     description='Install addon direct from USB',icon=ICONADDONS, themeit=THEMEDEFAULTB)
        #addFile('Remove Addons',                         'removeaddons',     icon=ICONMAINT, themeit=THEMEDEFAULTB)
        #addDir ('Remove Addon Data',                     'removeaddondata',  icon=ICONMAINT, themeit=THEMEDEFAULTB)
        #addDir ('Enable/Disable Addons',                 'enableaddons',     icon=ICONMAINT, themeit=THEMEDEFAULTB)
        #addFile('Force Update Addons',                   'forceupdate',      icon=ICONMAINT, themeit=THEMEDEFAULTB)
        #
        # restore packs
        #addDir('[B]Restore[/B]',  'maint', 'backup', icon=ICONBACKUP,  themeit=THEMEMENUB)
        ENABLERESTORE =  wiz.getS('ENABLERESTORE')
        testENABLERESTORE  = 'true' if ENABLERESTORE == 'true' else 'false'
        addFile('%s    RESTORE' % testENABLERESTORE.replace('true',onitem).replace('false',offitem),'togglesetting', name='ENABLERESTORE', description='Turn on Restore',  fanart=FANART, icon=ICONBACKUP, themeit=THEMETOGGLE)
        if ENABLERESTORE == 'true':
            addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Build' % COLOROFFLINE,         'restorezip',      description='Restore Local Build zip',       icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
            addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local GuiFix' % COLOROFFLINE,        'restoregui',      description='Restore Local Gui Fix',         icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
            addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Addon_data' % COLOROFFLINE,    'restoreaddon',    description='Restore Local Addon_data',      icon=ICONBACKUP,  themeit=THEMESUBMENUITEM) 
        # addons (plugins non packs and menus)
        ADDONENABLEOFFLINE  = 'true' if wiz.getS('ADDONENABLEOFFLINE')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]  EDIT TXT ADDONS' % (ADDONENABLEOFFLINE.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINE', url, menu=createMenu('editaddon', 'addons', addonsTXTFolder), description='ADDON Offline txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
        if ADDONENABLEOFFLINE == 'true':
            # add txt imports
            addFile('(EXPORT)  Repos (Install)', 'exportaddons', description='Export your backed up repos',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            addFile('(IMPORT)  Plugins Backup and Repos to txt ',    'importaddons', description='Import your installed repos to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            addFile('(IMPORT)  Create txt [COLOR %s]%s[/COLOR] Addon [COLOR %s]%s[/COLOR] Repo [COLOR %s]%s[/COLOR] Menu [COLOR %s]%s[/COLOR] Pack' % (COLORDESC,SPACER,COLORDESC,SPACER,COLORDESC,SPACER,COLORDESC,SPACER),          'addaddon', description='Add Addon to offline txt file',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
            # 
            # addons (plugins non packs and menus)
            ADDONENABLEOFFLINEplugins  = 'true' if wiz.getS('ADDONENABLEOFFLINEplugins')  == 'true' else 'false'
            addFile('%s   [B]%s[/B]  EDIT ADDONS' % (ADDONENABLEOFFLINEplugins.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINEplugins', url, menu=createMenu('editaddon', 'plugins', pluginsTXTFolder), description='ADDON Offline Plgins txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
            if ADDONENABLEOFFLINEplugins == 'true':
                files2 = []
                try: files2 = os.listdir(pluginsTXTFolder)
                except: pass
                for file in files2:
                    file  = xbmc.translatePath(os.path.join(pluginsTXTFolder, file))
                    link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                    match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                    if len(match) > 0:
                        x = 0
                        for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                            if icon   == 'http://': icon = ICONADDONS
                            if fanart == 'http://': fanart = FANART
                            name2    =  os.path.basename(aurl)
                            if plugin.lower()   == 'section':
                                x += 1
                                addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            elif plugin.lower() == 'skin':
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            elif plugin.lower() == 'pack':
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            else:
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                # check is installed
                                SETCOL1='white'
                                SETCOL2='grey'
                                if os.path.exists(os.path.join(ADDONS, plugin)):
                                    try:
                                        if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                        elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                                    except: pass
                                if os.path.exists(os.path.join(ADDONS, repository)):
                                    try:
                                        if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                        elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                                    except: pass
                                if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                                if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
            #
            # repos
            ADDONENABLEOFFLINErepos  = 'true' if wiz.getS('ADDONENABLEOFFLINErepos')  == 'true' else 'false'
            addFile('%s   [B]%s[/B]  EDIT REPOS   ' % (ADDONENABLEOFFLINErepos.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'ADDONENABLEOFFLINErepos', url, menu=createMenu('editaddon', 'repos', reposTXTFolder), description='ADDON Offline Repository txt', fanart=FANART, icon=ICONADDONS, themeit=THEMETOGGLE)
            if ADDONENABLEOFFLINErepos == 'true':
                # edit
                addFile('Export Repos to txt', 'exportaddons', description='Export your backed up repos',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
                addFile('Import Repos to txt', 'importaddons', description='Import your installed repos to offline txt files',  icon=ICONSETTINGS, themeit=THEMEDEFAULT)
                files3 = []
                try: files3 = os.listdir(reposTXTFolder)
                except: pass
                for file in files3:
                    file  = xbmc.translatePath(os.path.join(reposTXTFolder, file))
                    link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
                    match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                    if len(match) > 0:
                        x = 0
                        for aname, plugin, aurl, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
                            if icon   == 'http://': icon = ICONADDONS
                            if fanart == 'http://': fanart = FANART
                            name2    =  os.path.basename(aurl)
                            if plugin.lower()   == 'section':
                                x += 1
                                addDir ("[B]%s[/B]" % aname, 'addons', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Menu url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            elif plugin.lower() == 'skin':
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                addFile("[COLOR %s]SKIN[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'skinpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Skin url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            elif plugin.lower() == 'pack':
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                addFile("[COLOR %s]PACK[/COLOR]  [B]%s[/B]" % (COLORDESC, aname), 'addonpack', aname, aurl, createMenu('editaddon', 'addons', file),  description='[COLOR %s]Pack url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), icon=icon, fanart=fanart, themeit=THEMESUBMENU)
                            #'''
                            else:
                                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                                x += 1
                                # check is installed
                                SETCOL1='white'
                                SETCOL2='grey'
                                if os.path.exists(os.path.join(ADDONS, plugin)):
                                    try:
                                        if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:  SETCOL1='lightgreen'
                                        elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):  SETCOL1='orange'
                                    except: pass
                                if os.path.exists(os.path.join(ADDONS, repository)):
                                    try:
                                        if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                                        elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                                    except: pass
                                if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                                if 'module' in plugin:  NAME='[COLOR %s]*DEP*[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                #elif plugin.startswith('repo'):  NAME='[COLOR %s]*REPO[/COLOR]  [COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (COLORSUBTITLE, SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                else:  NAME='[COLOR %s]%s[/COLOR]  [COLOR %s][%s][/COLOR]  [COLOR %s][%s][/COLOR]' % (SETCOL1, aname, COLORDESC, plugin, SETCOL2, repository)
                                addFile(NAME, 'addoninstall', plugin, file, createMenu('editaddon', 'addons', file), description='[COLOR %s]Addon url:[/COLOR]\n%s\n%s\n%s\n%s' % (COLORDESC, aname, name2, aurl, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEM)
                            #'''
           
        addFile('Repo [COLOR grey]'+REPOID+'[/COLOR]  (Main repo)', 'Repolink', REPOID, description='Browse the main '+REPOID+' Default Repo for Addons and Skins',  icon=ICONREPO,themeit=THEMEDEFAULTB)
        addFile('Clone This Addon and ID',                      'cloneaddon',      description='Create your own addon', icon=ICONBACKUP, themeit=THEMEWARNING)
        setView('files', 'viewType')
def addonInstaller(plugin, url, force=False):
    xbmc.log(msg='##['+ADDON_ID+'] Start  addonInstaller  %s' % url,level=xbmc.LOGNOTICE)
    icon = xbmc.translatePath(os.path.join(ADDONS, plugin, 'icon.png'))
    if not os.path.exists(icon):  _notify('Checking Addon...', plugin, ICON, duration=5000)
    else:  _notify('Checking Addon...', plugin, icon, duration=5000)
    DP.create(ADDONTITLE,'[COLOR %s][B]Check Addon:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, plugin), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    #
    if url == None: url = ADDONFILE
    if os.path.exists(url):
        link = xbmcvfs.File(url,'rb').read().replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
        ADDONWORKING = True
    else:
        ADDONWORKING = wiz.workingURL(url)
        if ADDONWORKING == True:
            link = wiz.textCache(url).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
    if ADDONWORKING == True:
        match = re.compile('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % plugin).findall(link)
        if len(match) > 0:
            for name, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:

                # if addon exists menu  test
                #if os.path.exists(os.path.join(ADDONS, plugin)) or os.path.exists(os.path.join(ADDONS, repository)) and force == False:
                if os.path.exists(os.path.join(ADDONS, plugin)):
                    DP.close()
                    # check is installed
                    SETCOL1='white'
                    SETCOL2='grey'
                    TODO = 'Install Addon'
                    #
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin) == 1:
                                SETCOL1='lightgreen'
                                TODO = 'Launch Addon'
                            elif os.path.exists(os.path.join(ADDONS, plugin, 'addon.xml')):
                                SETCOL1='orange'
                                TODO = 'Re-Install Addon'
                        except: pass
                    #
                    if os.path.exists(os.path.join(ADDONS, repository)):
                        try:
                            if xbmc.getCondVisibility('System.HasAddon(%s)' % repository) == 1:  SETCOL2='lightgreen'
                            elif os.path.exists(os.path.join(ADDONS, repository, 'addon.xml')):  SETCOL2='orange'
                        except: pass
                    if repository == 'repository.xbmc.org': SETCOL2='lightgreen'
                    #
                    xbmc.log(msg='##['+ADDON_ID+'] Step 0 - ADDON ALREADY EXISTS woot', level=xbmc.LOGNOTICE)
                    do = [TODO, 'Fix Dependancies', 'Remove Addon: [COLOR %s]%s[/COLOR]' % (SETCOL1,plugin), 'Browse Repo:  [COLOR %s]%s[/COLOR]' %  (SETCOL2,repository), 'Remove Repo:  [COLOR %s]%s[/COLOR]' %  (SETCOL2,repository), 'ReInstall Repo:  [COLOR %s]%s[/COLOR]' %  (SETCOL2,repository), 'Refresh Addons and Repos', 'Enable Addon']
                    selected = DIALOG.select("[COLOR %s]%s[/COLOR]" % (COLORHEADER,plugin), do)
                    # launch addon
                    if selected == 0:
                        if os.path.exists(os.path.join(ADDONS, plugin)):
                            wiz.ebi('RunAddon(%s)' % plugin)
                            xbmc.sleep(500)
                            return True
                        else: addonInstaller(plugin, url, force=True)
                    # fix deps
                    elif selected == 1:
                        installed(plugin)
                        installDep(plugin, DP)
                        xbmc.sleep(500)
                        return True
                    # remove addon
                    elif selected == 2:
                        wiz.cleanHouse(os.path.join(ADDONS, plugin))
                        #remove_dir(os.path.join(ADDOND, plugin))
                        wiz.removeFolder(os.path.join(ADDONS, plugin))
                        #wiz.addonUpdates('set')
                        #wiz.ebi('UpdateLocalAddons()')
                        #DBremove(plugin)
                        wiz.refresh()
                        if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to remove the addon_data for:" % COLORHEADER, "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLORHEADER, plugin), yeslabel="[B][COLOR green]Yes Remove[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
                            remove_dir(os.path.join(ADDOND, plugin))
                            _notify('Delete Done', plugin, ICON)
                            return True
                        else: return True
                    # Browse repo
                    elif selected == 3:
                        repo = os.path.join(ADDONS, repository)
                        if not os.path.exists(repo): return
                        xbmc.executebuiltin('ActivateWindow(10040,addons://'+repository+'/,return)')
                        xbmc.sleep(500)
                        return True
                    # Remove repo
                    elif selected == 4:
                        repo = os.path.join(ADDONS, repository)
                        remove_dir(repo)
                        #wiz.addonUpdates('set')
                        #DBremove(repository)
                        wiz.ebi('UpdateAddonRepos()')
                        #wiz.ebi('UpdateLocalAddons()')
                        wiz.refresh()
                        _notify('Delete Done', repository, ICON)
                        return True
                    # Reinstall repo
                    elif selected == 5:
                        repo = os.path.join(ADDONS, repository)
                        if not repository.lower() == 'none' and not os.path.exists(repo):
                            if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Repository %s not installed, install ? [COLOR %s]%s[/COLOR]" % (COLORHEADERTXT, repository, COLOR6, plugin), "Repo:   [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLORHEADER, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
                                ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
                                if len(ver) > 0:
                                    repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
                                    wiz.log(repozip)
                                    if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                    install = installAddon(repository, repozip)
                                    if install:
                                        wiz.ebi('UpdateAddonRepos()')
                                        wiz.refresh()
                                        return True
                                    else:
                                        repozip2 = "%s%s.zip" % (repositoryurl, repository)
                                        wiz.log(repozip2)
                                        if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                        install2 = installAddon(repository, repozip2)
                                        if install2:
                                            wiz.log("Done - Install from Kodi: %s" % install2)
                                            wiz.refresh()
                                            return True
                    # Refresh addon
                    elif selected == 6:
                        wiz.forceUpdate()
                        wiz.refresh()
                        return True
                    # enable addon
                    elif selected == 7:
                        set_enabled(plugin, data=None)
                        wiz.forceUpdate()
                        wiz.refresh()
                        return True
                    #
                    # Return from found addon menu
                    else: return False
                #
                # Start Install
                #
                DP.close()
                if repository == 'repository.xbmc.org':
                    try: repository = xbmcaddon.Addon(id=repository).getAddonInfo('path')
                    except: pass
                #
                # try repo
                wiz.log("Step 1 - Repository - Check for %s" % repository)
                repo = os.path.join(ADDONS, repository)
                if not repository.lower() == 'none' and not os.path.exists(repo):
                    if not repository.lower() == 'none' and not os.path.exists(repo):
                    #if DIALOG.yesno(ADDONTITLE, "Would you like to install the repository for: [COLOR %s]%s[/COLOR]" % (COLORHEADER, plugin), "[COLOR %s]Repo:[/COLOR]  [COLOR %s]%s[/COLOR]" % (COLORDESC, COLORHEADER, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
                        wiz.log("Repository not installed, installing it")
                        ver = ''
                        REPOTEST = wiz.workingURL(repositoryxml)
                        if REPOTEST == True: ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
                        if len(ver) > 0:
                            repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
                            wiz.log("Step 1 - Repository - install repozip with version - %s" % repozip)
                            if KODIV >= 17: wiz.addonDatabase(repository, 1)
                            installAddon(repository, repozip)
                            xbmc.executebuiltin("UpdateAddonRepos")
                            if os.path.exists(os.path.join(ADDONS, repository)):
                                wiz.log("Installing Addon from Kodi")
                                install = installFromKodi(plugin)
                                if install == True:
                                    wiz.refresh()
                                    return True
                            else:
                                repozip = '%s%s.zip' % (repositoryurl, repository)
                                wiz.log("Step 2 - Repository - install repozip without version - %s" % repozip)
                                if KODIV >= 17: wiz.addonDatabase(repository, 1)
                                installAddon(repository, repozip)
                                xbmc.executebuiltin("UpdateAddonRepos")
                                if os.path.exists(os.path.join(ADDONS, repository)):
                                    wiz.log("Installing Addon from Kodi")
                                    install = installFromKodi(plugin)
                                    if install == True:
                                        wiz.refresh()
                                        return True
                        else:
                            wiz.log("[Addon Installer] Repository not installed: Unable to grab url! (%s)" % repository)
                    else:
                        wiz.log("[Addon Installer] Repository for %s skipped: %s" % (plugin, repository))
                #
                # No repository, installing addon
                elif repository.lower() == 'none':
                    wiz.log("No repository, installing addon")
                    pluginid = plugin
                    zipurl = url
                    installAddon(plugin, url)
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        wiz.refresh()
                        return True
                # Repository installed, installing addon
                else:
                    wiz.log("Repository installed, installing addon")
                    install = installFromKodi(plugin, False)
                    if install == True:
                        wiz.refresh()
                        return True
                #
                # last resort
                if os.path.exists(os.path.join(ADDONS, plugin)): return True
                #
                install = installFromKodi(plugin)
                if install == True:
                    wiz.refresh()
                    return True
                #
                ver2 = ''
                REPOTEST = wiz.workingURL(repositoryxml)
                if REPOTEST == True: ver2 = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': plugin})
                if len(ver2) > 0:
                    url = "%s%s-%s.zip" % (url, plugin, ver2[0])
                    wiz.log(str(url))
                    if KODIV >= 17: wiz.addonDatabase(plugin, 1)
                    installAddon(plugin, url)
                    if os.path.exists(os.path.join(ADDONS, plugin)):
                        wiz.refresh()
                        return True
                    else:
                        url = "%s%s.zip" % (url, plugin)
                        wiz.log(str(url))
                        if KODIV >= 17: wiz.addonDatabase(plugin, 1)
                        installAddon(plugin, url)
                        if os.path.exists(os.path.join(ADDONS, plugin)):
                            wiz.refresh()
                            return True
                else: 
                    wiz.log("no match")
                    _notify('No Match... Abort', plugin, ICON, duration=1000)
        else:
            wiz.log("[Addon Installer] Invalid Format")
def installFromKodi(plugin, over=True):
    if over == True:
        xbmc.sleep(2000)
    #wiz.ebi('InstallAddon(%s)' % plugin)
    wiz.ebi('RunPlugin(plugin://%s)' % plugin)
    #if not wiz.whileWindow('yesnodialog'):
    #    return False
    #xbmc.sleep(500)
    if wiz.whileWindow('okdialog'):
        return False
    #wiz.whileWindow('progressdialog')
    icon = xbmc.translatePath(os.path.join(ADDONS, plugin, 'icon.png'))
    if not os.path.exists(icon):  _notify('Finished Installing', plugin, ICON, duration=1000)
    else:  _notify('Finished Installing', plugin, icon, duration=1000)
    if os.path.exists(os.path.join(ADDONS, plugin)): return True
    else: return False
def installAddon(name, url):
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Invalid Zip Url[/COLOR]" % COLORHEADER, '[COLOR %s]%s:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, name, COLORHEADERTXT, url)); return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    if not os.path.exists(url):
        urlsplits = url.split('/')
        lib=os.path.join(PACKAGES, urlsplits[-1])
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
    else:
        lib=os.path.join(url)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
    DP.update(0, title, '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
    set_enabled(name, data=None)
    DP.update(0, title, '[COLOR %s]Installing Dependencies[/COLOR]' % COLORHEADERTXT)
    installed(name)
    installlist = grabAddons(lib)
    wiz.log(str(installlist))
    if KODIV >= 17: wiz.addonDatabase(installlist, 1, True)
    installDep(name, DP)
    DP.close()
    setall_enable()
    wiz.refresh()
    #xbmc.executebuiltin("ActivateWindow(busydialog)")
    #UpdateAddonRepos()
    #UpdateLocalAddons()
    #wiz.ebi('UpdateAddonRepos()')
    #wiz.ebi('UpdateLocalAddons()')
    icon = xbmc.translatePath(os.path.join(ADDONS, name, 'icon.png'))
    if not os.path.exists(icon):  _notify('Addon Installed', name, ICON, duration=1000)
    else:  _notify('Addon Installed', name, icon, duration=1000)
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    #wiz.forceUpdate()
    #xbmc.executebuiltin("Dialog.Close(busydialog)")
    for item in installlist:
        if item.startswith('skin.') == True and not item == 'skin.shortcuts':
            if not BUILDNAME == '' and DEFAULTIGNORE == 'true': wiz.setS('defaultskinignore', 'true')
            wiz.swapSkins(item, 'Skin Installer')
    if os.path.exists(os.path.join(ADDONS, name)): return True
    else: return False
def installDep(name, DP=None):
    dep=os.path.join(ADDONS,name,'addon.xml')
    if os.path.exists(dep):
        source = open(dep,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        for depends in match:
            if not 'xbmc.python' in depends:
                if not DP == None:
                    DP.update(0, '', '[COLOR %s]%s[/COLOR]' % (COLORHEADER, depends))
                try:
                    add   = xbmcaddon.Addon(id=depends)
                    name2 = add.getAddonInfo('name')
                except:
                    wiz.createTemp(depends)
                    if KODIV >= 17: wiz.addonDatabase(depends, 1)
                #continue
                dependspath=os.path.join(ADDONS, depends)
                if not os.path.exists(dependspath):
                    match2  = wiz.parseDOM(link, 'import', ret='addon')#test
                    zipname = '%s-%s.zip' % (depends, match2[match.index(depends)])
                    depzip = urljoin("%s%s/" % (MODURL2, depends), zipname)
                    if not wiz.workingURL(depzip) == True:
                        depzip = urljoin(MODURL, '%s.zip' % depends)
                        if not wiz.workingURL(depzip) == True:
                            wiz.createTemp(depends)
                            if KODIV >= 17: wiz.addonDatabase(depends, 1)
                            continue
                    lib=os.path.join(PACKAGES, '%s.zip' % depends)
                    try: os.remove(lib)
                    except: pass
                    DP.update(0, '[COLOR %s][B]Downloading Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, depends),'', 'Please Wait')
                    downloader.download(depzip, lib, DP)
                    xbmc.sleep(100)
                    title = '[COLOR %s][B]Installing Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, depends)
                    DP.update(0, title,'', 'Please Wait')
                    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
                    if KODIV >= 17: wiz.addonDatabase(depends, 1)
                    installed(depends)
                    installDep(depends)
                    xbmc.sleep(100)
                    DP.close()
def checkdeps(check=False):
    if DIALOG.yesno(ADDONTITLE, "Would you also like to make sure all addons are enabled?", yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):  check=True
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    DP.create(ADDONTITLE,'[COLOR %s][B]Check Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, ADDONS), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        DP.update(0, '[COLOR %s][B]Check Dependencies:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, foldername), foldername, '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
        if check == True:
            installed(foldername)
        installDep(foldername, DP)
    DP.close()
def installed(addon):
    url = os.path.join(ADDONS,addon,'addon.xml')
    if os.path.exists(url):
        try:
            list  = open(url,mode='r'); g = list.read(); list.close()
            name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': addon})
            #icon = xbmc.translatePath(os.path.join(ADDONS, addon, 'icon.png'))
            #if not os.path.exists(icon):  _notify('Addon Enabled', addon, ICON, duration=1000)
            #else:  _notify('Addon Enabled', addon, icon, duration=1000)
            #icon  = os.path.join(ADDONS,addon,'icon.png')
            #wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLORHEADER, name[0]), '[COLOR %s]Addon Enabled[/COLOR]' % COLORHEADERTXT, '2000', icon)
        except: pass
def grabAddons(path):
    zfile = zipfile.ZipFile(path)
    addonlist = []
    for item in zfile.infolist():
        if str(item.filename).find('addon.xml') == -1: continue
        info = str(item.filename).split('/')
        if not info[-2] in addonlist:
            addonlist.append(info[-2])
    return addonlist
def packInstaller(name, url):
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Addon Pack Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]' % (COLORHEADER, name, COLORHEADERTXT)); return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    urlsplits = url.split('/')
    lib = xbmc.makeLegalFilename(os.path.join(PACKAGES, urlsplits[-1]))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
    DP.update(0, title,'', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
    installed = grabAddons(lib)
    if KODIV >= 17: wiz.addonDatabase(installed, 1, True)
    DP.close()
    setall_enable()
    wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s: Installed![/COLOR]' % (COLORHEADERTXT, name))
    #wiz.ebi('UpdateAddonRepos()')
    #wiz.ebi('UpdateLocalAddons()')
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    #wiz.forceUpdate()
    wiz.refresh()
    _notify('Pack Finished Installing', name, ICON, duration=1000)
def packbuildInstaller(name, url):
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Addon Pack Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]' % (COLORHEADER, name, COLORHEADERTXT)); return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    urlsplits = url.split('/')
    lib = xbmc.makeLegalFilename(os.path.join(PACKAGES, urlsplits[-1]))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
    DP.update(0, title,'', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    percent, errors, error = extract.all(lib,HOME,DP, title=title)
    installed = grabAddons(lib)
    if KODIV >= 17: wiz.addonDatabase(installed, 1, True)
    DP.close()
    setall_enable()
    wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s: Installed![/COLOR]' % (COLORHEADERTXT, name))
    #wiz.ebi('UpdateAddonRepos()')
    #wiz.ebi('UpdateLocalAddons()')
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    #wiz.forceUpdate()
    wiz.refresh()
    _notify('Pack Finished Installing', name, ICON, duration=1000)
def skinInstaller(name, url):
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]' % (COLORHEADER, name, COLORHEADERTXT)); return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    urlsplits = url.split('/')
    lib = xbmc.makeLegalFilename(os.path.join(PACKAGES, urlsplits[-1]))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
    DP.update(0, title,'', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    percent, errors, error = extract.all(lib,HOME,DP, title=title)
    installed = grabAddons(lib)
    if KODIV >= 17: wiz.addonDatabase(installed, 1, True)
    DP.close()
    setall_enable()
    wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLORHEADER, '[COLOR %s]%s: Installed![/COLOR]' % (COLORHEADERTXT, name))
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    #wiz.ebi('UpdateAddonRepos()')
    #wiz.ebi('UpdateLocalAddons()')
    #wiz.forceUpdate()
    for item in installed:
        if item.startswith('skin.') == True and not item == 'skin.shortcuts':
            if not BUILDNAME == '' and DEFAULTIGNORE == 'true': wiz.setS('defaultskinignore', 'true')
            wiz.swapSkins(item, 'Skin Installer')
    _notify('Skin Finished Installing', name, ICON, duration=1000)
    wiz.refresh()
def editaddon(title=None):  # edit txt addon entry
    filenameOld = title
    file = os.path.join(filenameOld)
    fh = open(file, 'r')
    for line in fh.readlines():
        entry = line[:line.find("=")]
        content = line[line.find("=")+1:]
        if entry   == "name": name = content.replace('"','').rstrip()
        elif entry == "plugin":  plugin = content.replace('"','').rstrip()
        elif entry == "url":  url = content.replace('"','').rstrip()
        elif entry == "repository": repository = content.replace('"','').rstrip()
        elif entry == "repositoryxml": repositoryxml = content.replace('"','').rstrip()
        elif entry == "repositoryurl": repositoryurl = content.replace('"','').rstrip()
        elif entry == "icon": icon = content.replace('"','').rstrip()
        elif entry == "fanart": fanart = content.replace('"','').rstrip()
        elif entry == "adult":  adult = content.replace('"','').rstrip()
        elif entry == "description":  description = content.replace('"','').rstrip()
    fh.close()
    oldTitle = name
    keyboard = xbmc.Keyboard(oldTitle, 'Name')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        name = keyboard.getText()
        #
        keyboard = xbmc.Keyboard(plugin, 'Plugin')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            plugin = keyboard.getText()
            #
            keyboard = xbmc.Keyboard(url, 'URL')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                url = keyboard.getText()
                #
                keyboard = xbmc.Keyboard(repository, 'Repository')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    repository = keyboard.getText()
                    #
                    keyboard = xbmc.Keyboard(repositoryxml, 'Repository xml')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        repositoryxml = keyboard.getText()
                        #
                        keyboard = xbmc.Keyboard(repositoryurl, 'Repository url')
                        keyboard.doModal()
                        if keyboard.isConfirmed() and keyboard.getText():
                            repositoryurl = keyboard.getText()
                            #
                            keyboard = xbmc.Keyboard(icon, 'Icon?')
                            keyboard.doModal()
                            if keyboard.isConfirmed() and keyboard.getText():
                                icon = keyboard.getText()
                                #
                                keyboard = xbmc.Keyboard(fanart, 'Fanart?')
                                keyboard.doModal()
                                if keyboard.isConfirmed() and keyboard.getText():
                                    fanart = keyboard.getText()
                                    #
                                    keyboard = xbmc.Keyboard(adult, 'Adult?')
                                    keyboard.doModal()
                                    if keyboard.isConfirmed() and keyboard.getText():
                                        adult = keyboard.getText()
                                        #
                                        keyboard = xbmc.Keyboard(description, 'Description?')
                                        keyboard.doModal()
                                        if keyboard.isConfirmed() and keyboard.getText():
                                            description = keyboard.getText()
                                            #
                                            #content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"'
                                            content = 'name="'+name+'"\nplugin="'+plugin+'"\nurl="'+url+'"\nrepository="'+repository+'"\nrepositoryxml="'+repositoryxml+'"\nrepositoryurl="'+repositoryurl+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+name+'"'
                                            #fh = open(os.path.join(addonsTXTFolder, getFileName(name)+linkortxt), 'w')
                                            if plugin == 'none': fh = open(os.path.join(addonsTXTFolder, getFileName(name)+linkortxt), 'w')
                                            else:  fh = open(os.path.join(addonsTXTFolder, plugin+linkortxt), 'w')
                                            fh.write(content)
                                            fh.close()
                                            #if name != oldTitle: os.remove(os.path.join(filenameOld))
                                            #if name != oldTitle: os.remove(os.path.join(filenameOld))
                                            wiz.refresh()
def xmleditaddon(number): # xml addon entry
    enable  = wiz.getS('ADDONENABLE%s' % number)
    name    = wiz.getS('ADDONNAME%s' % number)
    url     = wiz.getS('ADDONURL%s' % number)
    icon    = wiz.getS('ADDONICONURL%s' % number)
    section  = wiz.getS('ADDONSECTION%s' % number)
    plugin  = wiz.getS('ADDONPLUGIN%s' % number)
    repository  = wiz.getS('ADDONREPO%s' % number)
    repositoryxml  = wiz.getS('ADDONREPOXML%s' % number)
    repositoryurl  = wiz.getS('ADDONREPOURL%s' % number)
    fanart = FANART
    adult = 'no'
    description = name
    #
    enable2  = wiz.getKeyboard(enable, 'Enable the Entry?')
    name2    = wiz.getKeyboard(name, 'Enter the new Name')
    section2 = wiz.getKeyboard(section, 'txt menu url or direct link? (section yes\no)')
    url2     = wiz.getKeyboard(url, 'Enter the new URL')
    icon2    = wiz.getKeyboard(icon, 'Enter the new icon URL')
    plugin2    = wiz.getKeyboard(plugin, 'Enter the plugin name')
    repository2    = wiz.getKeyboard(repository, 'Enter the repo name')
    repositoryxml2    = wiz.getKeyboard(repositoryxml, 'Enter the repo xml URL')
    repositoryurl2    = wiz.getKeyboard(repositoryurl, 'Enter the repo URL')
    #
    wiz.setS('ADDONENABLE%s' % number, enable2)
    wiz.setS('ADDONNAME%s' % number, name2)
    wiz.setS('ADDONURL%s' % number, url2)
    wiz.setS('ADDONICONURL%s' % number, icon2)
    wiz.setS('ADDONSECTION%s' % number, section2)
    wiz.setS('ADDONPLUGIN%s' % number, plugin2)
    wiz.setS('ADDONREPO%s' % number, repository2)
    wiz.setS('ADDONREPOXML%s' % number, repositoryxml2)
    wiz.setS('ADDONREPOURL%s' % number, repositoryurl2)
    wiz.refresh()

def clone_addon():
    if DIALOG.yesno(ADDONTITLE, "Would you like to make your custom version of this addon?", yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
        check=True
    if check==True:
        name2 = wiz.getKeyboard(ADDONTITLE, 'Enter the Name of the Wizard')
        url2  = wiz.getKeyboard(ADDON_ID+'_', 'Enter the plugin ID of the Wizard')
        wiz.setS('ADDONNEWNAME', name2)
        wiz.setS('ADDONNEWID',   url2)
        shutil.copytree(PLUGIN, os.path.join(ADDONS, url2), symlinks=False, ignore=None)
        
        Clean_Name = os.path.join(ADDONS, url2, 'addon.xml')
        DUMMY      = xbmc.translatePath(os.path.join(DATAPATHUSERDATA, 'cloneaddon.txt'))
        if os.path.exists(DUMMY): os.remove(DUMMY)
        try:    os.rename(Clean_Name, DUMMY)
        except: pass
        #test
        s=open(DUMMY).read()
        s=s.replace(ADDON_ID, url2)
        s=s.replace('XYZ Wizard', name2)
        #s=s.replace('icon.gif','icon.png')
        f=open(Clean_Name,'w')
        f.write(s)
        f.close()
        if os.path.exists(DUMMY): os.remove(DUMMY)
        set_enabled(url2, data=None)
        wiz.forceUpdate()
        wiz.refresh()
        _notify('Done', url2, ICON, duration=1000)
        if DIALOG.yesno(ADDONTITLE, "Want to run your new addon?", yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
            check=True
        if check==True:
            wiz.ebi('RunAddon(%s)' % url2)
        else: return True

# wip
def DBremove(plugin):
    addons27path = xbmc.translatePath('special://database/Addons27.db')
    addons27 = database.connect(addons27path)
    getinfo = addons27.cursor().execute("SELECT id FROM repo WHERE addonID='%s'" % plugin)
    #addons27.commit()
    #addons27.close()
    print getinfo

###########################
# builds  third paty   ####
###########################
def buildsMenu(name=None, url=None):
    addDir('BUILDS      [COLOR %s](Zips)[/COLOR]' % COLORDESC,  'builds',  description='3rd Party pre fabricated builds or zips of preset Kodi configurations',  icon=ICONBUILDS, themeit=THEMEMENUB)
    #
    thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
    addFile('%s  Third Party Wizards?' % thirdparty.replace('true',onitem).replace('false',offitem) ,'togglesetting', 'enable3rd', url, description='Toggle Third party builds',  fanart=FANART, icon=ICONBUILDS, themeit=THEMETOGGLE)
    if thirdparty == 'true':
        first = THIRD1NAME if not THIRD1NAME == '' else 'Not Set'
        secon = THIRD2NAME if not THIRD2NAME == '' else 'Not Set'
        third = THIRD3NAME if not THIRD3NAME == '' else 'Not Set'
        addFile('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, first), 'editthird', '1', description='Toggle Third party build',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, secon), 'editthird', '2', description='Toggle Third party build',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, third), 'editthird', '3', description='Toggle Third party build',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
    #
    addFile('Fresh Start?',  'freshstart',    description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings',    icon=ICONDELETE, themeit=THEMEWARNING)
    setView('files', 'viewType')
def buildMenu():
    bf = wiz.textCache(BUILDFILE)
    if bf == False:
        WORKINGURL = wiz.workingURL(BUILDFILE)
        addFile('%s Version: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
        addDir ('Save Data Menu'       ,'savedata', icon=ICONSAVE,     themeit=THEMEMENUB)
        if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
        addFile('Url for txt file not valid', '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
        addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
        return
    #
    total, count15, count16, count17, count18, adultcount, hidden = wiz.buildCount()
    third = False; addin = []
    if THIRDPARTY == 'true':
        if not THIRD1NAME == '' and not THIRD1URL == '': third = True; addin.append('1')
        if not THIRD2NAME == '' and not THIRD2URL == '': third = True; addin.append('2')
        if not THIRD3NAME == '' and not THIRD3URL == '': third = True; addin.append('3')
    link  = bf.replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"').replace('adult=""', 'adult="no"')
    match = re.compile('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
    if total == 1 and third == False:
        for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
            if not DEVELOPER == 'true' and wiz.strTest(name): continue
            viewBuild(match[0][0])
            return
    addFile('%s Version: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
    addDir ('Save Data Menu'       ,'savedata', icon=ICONSAVE,     themeit=THEMEMENUB)
    #if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
    #
    if third == True:
        for item in addin:
            name = eval('THIRD%sNAME' % item)
            addDir("[B]%s[/B]" % name, 'viewthirdparty', item, icon=ICONBUILDS, themeit=THEMEMENUB)
    if len(match) >= 1:
        if SEPERATE == 'true':
            for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                if not DEVELOPER == 'true' and wiz.strTest(name): continue
                menu = createMenu('install', '', name)
                addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEMEMENUB)
        else:
            if count18 > 0:
                state = '+' if SHOW18 == 'false' else '-'
                addFile('[B]%s Leia Builds(%s)[/B]' % (state, count18), 'togglesetting',  'show17', themeit=THEMETOGGLE)
                if SHOW18 == 'true':
                    for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if not DEVELOPER == 'true' and wiz.strTest(name): continue
                        kodiv = int(float(kodi))
                        if kodiv == 18:
                            menu = createMenu('install', '', name)
                            addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEMEDEFAULT)
            if count17 > 0:
                state = '+' if SHOW17 == 'false' else '-'
                addFile('[B]%s Krypton Builds(%s)[/B]' % (state, count17), 'togglesetting',  'show17', themeit=THEMETOGGLE)
                if SHOW17 == 'true':
                    for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if not DEVELOPER == 'true' and wiz.strTest(name): continue
                        kodiv = int(float(kodi))
                        if kodiv == 17:
                            menu = createMenu('install', '', name)
                            addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEMEDEFAULT)
            if count16 > 0:
                state = '+' if SHOW16 == 'false' else '-'
                addFile('[B]%s Jarvis Builds(%s)[/B]' % (state, count16), 'togglesetting',  'show16', themeit=THEMETOGGLE)
                if SHOW16 == 'true':
                    for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if not DEVELOPER == 'true' and wiz.strTest(name): continue
                        kodiv = int(float(kodi))
                        if kodiv == 16:
                            menu = createMenu('install', '', name)
                            addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEMEDEFAULT)
            if count15 > 0:
                state = '+' if SHOW15 == 'false' else '-'
                addFile('[B]%s Isengard and Below Builds(%s)[/B]' % (state, count15), 'togglesetting',  'show15', themeit=THEMETOGGLE)
                if SHOW15 == 'true':
                    for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if not DEVELOPER == 'true' and wiz.strTest(name): continue
                        kodiv = int(float(kodi))
                        if kodiv <= 15:
                            menu = createMenu('install', '', name)
                            addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEMEDEFAULT)
    elif hidden > 0: 
        if adultcount > 0:
            addFile('There is currently only Adult builds', '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
            addFile('Enable Show Adults in Addon Settings > Misc', '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
        else:  addFile('Currently No Builds Offered from %s' % ADDONTITLE, '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
    else: addFile('Text file for builds not formated correctly.', '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
    setView('files', 'viewType')
def viewBuild(name):
    bf = wiz.textCache(BUILDFILE)
    if bf == False:
        WORKINGURL = wiz.workingURL(BUILDFILE)
        addFile('Url for txt file not valid', '', themeit=THEMESUBMENUITEMB)
        addFile('%s' % WORKINGURL, '', themeit=THEMESUBMENUITEMB)
        return
    if wiz.checkBuild(name, 'version') == False: 
        addFile('Error reading the txt file.', '', themeit=THEMESUBMENUITEMB)
        addFile('%s was not found in the builds list.' % name, '', themeit=THEMESUBMENUITEMB)
        return
    link = bf.replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"')
    match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?inor="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?nfo="(.+?)".+?escription="(.+?)"' % name).findall(link)
    for version, url, minor, gui, kodi, themefile, icon, fanart, preview, adult, info, description in match:
        icon        = icon
        fanart      = fanart
        build       = '%s (v%s)' % (name, version)
        if BUILDNAME == name and version > BUILDVERSION:
            build = '%s [COLOR red][CURRENT v%s][/COLOR]' % (build, BUILDVERSION)
        addFile(build, '', description=description, fanart=fanart, icon=icon, themeit=THEMECURRENTBUILD)
        if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
        addDir ('Save Data Menu',       'savedata', icon=ICONSAVE,     themeit=THEMESUBMENUITEMB)
        addFile('Build Information',    'buildinfo', name, description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        if not preview == "http://": addFile('View Video Preview', 'buildpreview', name, description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        temp1 = int(float(KODIV)); temp2 = int(float(kodi))
        if not temp1 == temp2: 
            if temp1 == 16 and temp2 <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            addFile('[I]Build designed for kodi version %s(installed: %s)[/I]' % (str(kodi), str(KODIV)), '', fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        addFile(wiz.sep('INSTALL'), '', fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        addFile('Fresh Install'   , 'install', name, 'fresh'  , description=description, fanart=fanart, icon=icon, themeit=THEMEMENUB)
        addFile('Standard Install', 'install', name, 'normal' , description=description, fanart=fanart, icon=icon, themeit=THEMEMENUB)
        if not gui == 'http://': addFile('Apply guiFix'    , 'install', name, 'gui'     , description=description, fanart=fanart, icon=icon, themeit=THEMEMENUB)
        if not themefile == 'http://':
            themecheck = wiz.textCache(themefile)
            if not themecheck == False:
                addFile(wiz.sep('THEMES'), '', fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
                link  = themecheck.replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                for themename, themeurl, themeicon, themefanart, themeadult, description in match:
                    if not SHOWADULT == 'true' and themeadult.lower() == 'yes': continue
                    themeicon   = themeicon   if themeicon   == 'http://' else icon
                    themefanart = themefanart if themefanart == 'http://' else fanart
                    addFile(themename if not themename == BUILDTHEME else "[B]%s (Installed)[/B]" % themename, 'theme', name, themename, description=description, fanart=themefanart, icon=themeicon, themeit=THEMESUBMENUITEMB)
    setView('files', 'viewType')
def viewThirdList(number):
    name = eval('THIRD%sNAME' % number)
    url  = eval('THIRD%sURL' % number)
    work = wiz.workingURL(url)
    if not work == True:
        addFile('Url for txt file not valid', '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
        addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEMESUBMENUITEMB)
    else:
        type, buildslist = wiz.thirdParty(url)
        addFile("[B]%s[/B]" % name, '', themeit=THEMESUBMENUITEMB)
        if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
        if type:
            for name, version, url, kodi, icon, fanart, adult, description in buildslist:
                if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                addFile("[%s] %s v%s" % (kodi, name, version), 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEMEDEFAULT)
        else:
            for name, url, icon, fanart, description in buildslist:
                addFile(name, 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEMEDEFAULT)
def editThirdParty(number):
    name  = eval('THIRD%sNAME' % number)
    url   = eval('THIRD%sURL' % number)
    name2 = wiz.getKeyboard(name, 'Enter the Name of the Wizard')
    url2  = wiz.getKeyboard(url, 'Enter the URL of the Wizard Text')
    wiz.setS('wizard%sname' % number, name2)
    wiz.setS('wizard%surl' % number, url2)
def buildWizard(name, type, theme=None, over=False):
    if over == False:
        testbuild = wiz.checkBuild(name, 'url')
        if testbuild == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Unabled to find build[/COLOR]" % COLORHEADERTXT)
            return
        testworking = wiz.workingURL(testbuild)
        if testworking == False:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Build Zip Error: %s[/COLOR]" % (COLORHEADERTXT, testworking))
            return
    if type == 'gui':
        if name == BUILDNAME:
            if over == True: yes = 1
            else: yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to apply the guifix for:' % COLORHEADERTXT, '[COLOR %s]%s[/COLOR]?[/COLOR]' % (COLORHEADER, name), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        else: 
            yes = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, "[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed." % (COLORHEADERTXT, COLORHEADER, name), "Would you like to apply the guiFix anyways?.[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Apply Fix[/COLOR][/B]')
        if yes:
            buildzip = wiz.checkBuild(name,'gui')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]' % COLORHEADERTXT); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading GuiFix:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
            DP.update(0, title,'', 'Please Wait')
            extract.all(lib,USERDATA,DP, title=title)
            DP.close()
            wiz.defaultSkin()
            wiz.lookandFeelData('save')
            if KODIV >= 17: 
                installed = grabAddons(lib)
                wiz.addonDatabase(installed, 1, True)
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Gui fix has been installed.  Would you like to Reload the profile or Force Close Kodi?[/COLOR]" % COLORHEADERTXT, yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix()
            else: DIALOG.ok(ADDONTITLE, "[COLOR %s]To save changes you now need to force close Kodi, Press OK to force close Kodi[/COLOR]" % COLORHEADERTXT); wiz.killxbmc('true')
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]GuiFix: Cancelled![/COLOR]' % COLORHEADERTXT)
    elif type == 'fresh':
        freshStart(name)
    elif type == 'normal':
        if url == 'normal':
            if KEEPTRAKT == 'true':
                traktit.autoUpdate('all')
                wiz.setS('traktlastsave', str(THREEDAYS))
            if KEEPREAL == 'true':
                debridit.autoUpdate('all')
                wiz.setS('debridlastsave', str(THREEDAYS))
            if KEEPALLUC == 'true':
                allucit.autoUpdate('all')
                wiz.setS('allucnlastsave', str(THREEDAYS))
            if KEEPLOGIN == 'true':
                loginit.autoUpdate('all')
                wiz.setS('loginlastsave', str(THREEDAYS))
        temp_kodiv = int(KODIV); buildv = int(float(wiz.checkBuild(name, 'kodi')))
        if not temp_kodiv == buildv: 
            if temp_kodiv == 16 and buildv <= 15: warning = False
            else: warning = True
        else: warning = False
        if warning == True:
            yes_pressed = DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, '[COLOR %s]There is a chance that the skin will not appear correctly' % COLORHEADERTXT, 'When installing a %s build on a Kodi %s install' % (wiz.checkBuild(name, 'kodi'), KODIV), 'Would you still like to install: [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLORHEADER, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        else:
            if not over == False: yes_pressed = 1
            else: yes_pressed = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to Download and Install:' % COLORHEADERTXT, '[COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLORHEADER, name, wiz.checkBuild(name,'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Yes, Install[/COLOR][/B]')
        if yes_pressed:
            wiz.clearS('build')
            buildzip = wiz.checkBuild(name, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Build Install: Invalid Zip Url![/COLOR]' % COLORHEADERTXT); return
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name, wiz.checkBuild(name,'version')),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(buildzip, lib, DP)
            xbmc.sleep(500)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name, wiz.checkBuild(name,'version'))
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            if int(float(percent)) > 0:
                wiz.fixmetas()
                wiz.lookandFeelData('save')
                wiz.defaultSkin()
                #wiz.addonUpdates('set')
                wiz.setS('buildname', name)
                wiz.setS('buildversion', wiz.checkBuild( name,'version'))
                wiz.setS('buildtheme', '')
                wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                wiz.setS('lastbuildcheck', str(NEXTCHECK))
                wiz.setS('installed', 'true')
                wiz.setS('extract', str(percent))
                wiz.setS('errors', str(errors))
                wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
                try: os.remove(lib)
                except: pass
                if int(float(errors)) > 0:
                    yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s v%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name, wiz.checkBuild(name,'version')), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLORHEADER, percent, '%', COLORHEADER, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]', yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
                    if yes:
                        if isinstance(errors, unicode):
                            error = error.encode('utf-8')
                        wiz.TextBox(ADDONTITLE, error)
                DP.close()
                themefile = wiz.themeCount(name)
                if not themefile == False:
                    buildWizard(name, 'theme')
                if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
                if INSTALLMETHOD == 1: todo = 1
                elif INSTALLMETHOD == 2: todo = 0
                else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
                if todo == 1: wiz.reloadFix()
                else: wiz.killxbmc(True)
            else:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox("%s: Error Installing Build" % ADDONTITLE, error)
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Build Install: Cancelled![/COLOR]' % COLORHEADERTXT)
    elif type == 'theme':
        if theme == None:
            themefile = wiz.checkBuild(name, 'theme')
            themelist = []
            if not themefile == 'http://' and wiz.workingURL(themefile) == True:
                themelist = wiz.themeCount(name, False)
                if len(themelist) > 0:
                    if DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes" % (COLORHEADERTXT, COLORHEADER, name, COLORHEADER, len(themelist)), "Would you like to install one now?[/COLOR]", yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]"):
                        wiz.log("Theme List: %s " % str(themelist))
                        ret = DIALOG.select(ADDONTITLE, themelist)
                        wiz.log("Theme install selected: %s" % ret)
                        if not ret == -1: theme = themelist[ret]; installtheme = True
                        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLORHEADERTXT); return
                    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLORHEADERTXT); return
            else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Theme Install: None Found![/COLOR]' % COLORHEADERTXT)
        else: installtheme = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to install the theme:' % COLORHEADERTXT, '[COLOR %s]%s[/COLOR]' % (COLORHEADER, theme), 'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLORHEADER, name, wiz.checkBuild(name,'version')), yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
        if installtheme:
            themezip = wiz.checkTheme(name, theme, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
            if not wiz.workingURL(themezip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]' % COLORHEADERTXT); return False
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, theme),'', 'Please Wait')
            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            try: os.remove(lib)
            except: pass
            downloader.download(themezip, lib, DP)
            xbmc.sleep(500)
            DP.update(0,"", "Installing %s " % name)
            test = False
            if url not in ["fresh", "normal"]:
                test = testTheme(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                test2 = testGui(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estuary'] else False
                if test == True:
                    wiz.lookandFeelData('save')
                    swap = wiz.skinToDefault('Theme Install')
                    if swap == False: return False
                    xbmc.sleep(500)
            title = '[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, theme)
            DP.update(0, title,'', 'Please Wait')
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            wiz.setS('buildtheme', theme)
            wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
            DP.close()
            if url not in ["fresh", "normal"]: 
                wiz.forceUpdate()
                if KODIV >= 17: 
                    installed = grabAddons(lib)
                    wiz.addonDatabase(installed, 1, True)
                if test2 == True:
                    wiz.lookandFeelData('save')
                    wiz.defaultSkin()
                    gotoskin = wiz.getS('defaultskin')
                    wiz.swapSkins(gotoskin, "Theme Installer")
                    wiz.lookandFeelData('restore')
                elif test == True:
                    switch = wiz.swapSkins(gotoskin, 'Theme Install')
                    if switch == False: return
                    wiz.lookandFeelData('restore')
                else:
                    wiz.ebi("ReloadSkin()")
                    xbmc.sleep(1000)
                    wiz.ebi("Container.Refresh") 
        else:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLORHEADERTXT)
def thirdPartyInstall(name, url):
    if not wiz.workingURL(url):
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Invalid URL for Build[/COLOR]' % COLORHEADERTXT); return
    type = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER), "[COLOR %s]%s[/COLOR]" % (COLORHEADER, name), yeslabel="[B][COLOR green]Fresh Install[/COLOR][/B]", nolabel="[B][COLOR red]Normal Install[/COLOR][/B]")
    if type == 1:
        freshStart('third', True)
    wiz.clearS('build')
    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name),'', 'Please Wait')
    lib=os.path.join(PACKAGES, '%s.zip' % zipname)
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    xbmc.sleep(500)
    title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
    DP.update(0, title,'', 'Please Wait')
    percent, errors, error = extract.all(lib,HOME,DP, title=title)
    if int(float(percent)) > 0:
        wiz.fixmetas()
        wiz.lookandFeelData('save')
        wiz.defaultSkin()
        #wiz.addonUpdates('set')
        wiz.setS('installed', 'true')
        wiz.setS('extract', str(percent))
        wiz.setS('errors', str(errors))
        wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
        try: os.remove(lib)
        except: pass
        if int(float(errors)) > 0:
            yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLORHEADER, percent, '%', COLORHEADER, errors), 'Would you like to view the errors?[/COLOR]', nolabel='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel='[B][COLOR green]View Errors[/COLOR][/B]')
            if yes:
                if isinstance(errors, unicode):
                    error = error.encode('utf-8')
                wiz.TextBox(ADDONTITLE, error)
    DP.close()
    if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
    if INSTALLMETHOD == 1: todo = 1
    elif INSTALLMETHOD == 2: todo = 0
    else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
    if todo == 1: wiz.reloadFix()
    else: wiz.killxbmc(True)
def XML_All():
    doWriterss()
    if not os.path.isfile(SOURCES):     doWritesources()
    if not os.path.isfile(PLAYERCORE):  doWriteplayerfactorycore()
    if not os.path.isfile(ADVANCED):    showAutoAdvanced()
'''
def PATH_ADDON(name=None, url=None, dest=None):
    ISOFFLINE = xbmc.translatePath(os.path.join(MYBUILDS, name))
    if os.path.exists(ISOFFLINE):
        xbmc.log(msg='##['+ADDON_ID+'] **Zip exists offline '+ISOFFLINE, level=xbmc.LOGNOTICE)
        if DIALOG.yesno('Offline Zip Found!', '[COLOR %s]Do you wish to restore from your Zip Folder?[/COLOR]\nFile:       [COLOR gold]%s[/COLOR]\nFolder:  [COLOR gold]%s[/COLOR]' % (COLORHEADERTXT,name,MYBUILDS)):
            xbmc.log(msg='##['+ADDON_ID+'] **Zip is offline**', level=xbmc.LOGNOTICE)
            DP=xbmcgui.DialogProgress()
            DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
            DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
            percent, errors, error = extract.all(ISOFFLINE, dest, DP, title=title)
            wiz.forceUpdate()
            wiz.refresh()
        else: # dl
            xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
            DP=xbmcgui.DialogProgress()
            DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
            lib=os.path.join(PACKAGES,name)
            try: os.remove(lib)
            except: pass
            if str(url).endswith('[error]'):
                print url; dialog=xbmcgui.Dialog()
                DIALOG.ok("Error!",url)
                return
            if '[error]' in url:
                print url; dialog=xbmcgui.Dialog()
                DIALOG.ok("Error!",url)
                return
            downloader.download(url, lib, DP)
            title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
            DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
            percent, errors, error = extract.all(lib, dest, DP, title=title)
            try: os.remove(lib)
            except: pass
            #wiz.refresh()
    else: # dl
        xbmc.log(msg='##['+ADDON_ID+'] **Zip is online**', level=xbmc.LOGNOTICE)
        DP=xbmcgui.DialogProgress()
        DP.create(name,'','Downloading and Configuring [COLOR gold]%s[/COLOR]' % name,'[COLOR dodgerblue][B]Please Wait[/B][/COLOR]')
        lib=os.path.join(PACKAGES,name)
        try: os.remove(lib)
        except: pass
        if str(url).endswith('[error]'):
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
        if '[error]' in url:
            print url; dialog=xbmcgui.Dialog()
            DIALOG.ok("Error!",url)
            return
        downloader.download(url, lib, DP)
        title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name)
        DP.update(0, title,'Extracting '+name, '[COLOR %s]Please Wait[/COLOR]' % COLOR6)
        percent, errors, error = extract.all(lib, dest, DP, title=title)
        try: os.remove(lib)
        except: pass
'''



###########################
# Apk                  ####
###########################
def apkMenuMain(name=None, url=None):
    apkfile = os.path.join(DATAPATHUSERDATA, 'apks'+linkortxt)
    delete_file(apkfile)
    #menuapk = createMenu('editapk', 'apks', apkfile)
    menuapkrefresh = createMenu('editapk', 'apks', apksTXTFolder)
    #
    addFile('Install Offline Apk', 'chooseofflineapk', description='Install apk direct from USB',icon=ICONAPK, themeit=THEMEDEFAULTB)
    addDir ('Official Kodi Apk\'s', 'apkscrape', 'kodi', description='Install the latests version of Kodi direct from Kodi os.',icon=ICONAPK, themeit=THEMEMENUB)
    #addDir ('Official SPMC Apk\'s', 'apkscrape', 'spmc', description='Install the latests version of SPMC os', icon=ICONAPK, themeit=THEMEMENUB)
    #if xbmc.getCondVisibility('system.platform.android'):   addDir ('ANDROID  [COLOR %s](apk)[/COLOR]'% COLORDESC,'apk',description='Install Android apk programs that are run outside of Kodi but are generally not found on the Google Playstore',icon=ICONAPKS, themeit=THEMEMENUB)
    # online txt
    if ENABLEONLINE  == 'true':
        APKENABLEONLINE  = 'true' if wiz.getS('APKENABLEONLINE')  == 'true' else 'false'
        if not APKFILE   == 'http://': addFile('%s   [B]%s[/B]' % (APKENABLEONLINE.replace('true',on).replace('false',off),ONLINEFLAG),'togglesetting', 'APKENABLEONLINE', url, menu=menuapkrefresh, description='APK Online  txt',  fanart=FANART, icon=ICONAPK, themeit=THEMETOGGLE)
        if APKENABLEONLINE == 'true':
            # from xml online settings - txt url menus
            '''
            for items in range(1,100):
                url1  = wiz.getS('APKFILEONLINE%s' % items)
                name = wiz.getS('APKNAMEONLINE%s' % items)
                if name == ' ':   name = os.path.basename(url1)
                name2 =          os.path.basename(url1)
                description = name2
                if not url  == 'http://':
                    if not name  == '':
                    #if wiz.workingURL(url) == True:
                        #addDir('%s   [B]%s[/B]' % (ONLINEFLAG, name), 'apktxt',  name=name, url=url,  description='[COLOR blue]Apk txt Menus:[/COLOR]\n%s\n%s\n%s' % (name, name2, url), icon=ICONAPKS, themeit=THEMESUBMENUITEMB)
                        addDir('[B]%s[/B]   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apk', name, url1, description='[COLOR blue]APK  txt Menus:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url1, description), fanart=FANART, icon=ICONADDONS, themeit=THEMESUBMENUB)
            '''
            # apk main online file
            if not APKFILE == 'http://':
                if url == None:
                    TEMPAPKFILE = wiz.textCache(uservar.APKFILE)
                    if TEMPAPKFILE == False: APKWORKING  = wiz.workingURL(uservar.APKFILE)
                else:
                    TEMPAPKFILE = wiz.textCache(url)
                    if TEMPAPKFILE == False: APKWORKING  = wiz.workingURL(url)
                if not TEMPAPKFILE == False:
                    if os.path.exists(TEMPAPKFILE):
                        link = xbmcvfs.File(TEMPAPKFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                    else:
                        link = TEMPAPKFILE.replace('\n','').replace('\r','').replace('\t','')
                    match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                    if len(match) > 0:
                        x = 0
                        for name, section, url, icon, fanart, adult, description in match:
                            if icon   == 'http://': icon = ICONAPK
                            if fanart == 'http://': fanart = FANART
                            name2    =  os.path.basename(url)
                            if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                            if section.lower() == 'yes':
                                x += 1
                                addDir('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apk', name, url, createMenu('editapk', 'apks', APKFILE), description='[COLOR blue]APK url:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUB)
                            elif section.lower() == 'yes':
                                x += 1
                                addFile('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'rominstall', name, url, createMenu('editapk', 'apks', APKFILE), description='[COLOR blue]Rompack url:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon,  themeit=THEMESUBMENUB)
                            else:
                                x += 1
                                addFile('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apkinstall', name, url, createMenu('editapk', 'apks', APKFILE), description='[COLOR blue]APK url:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
                            if x == 0:
                                addFile("No addons added to this menu yet!", '', themeit=THEMEDEFAULT)
                    else: wiz.log("[APK Menu] ERROR: Invalid Format.", xbmc.LOGERROR)
                else:
                    wiz.log("[APK Menu] ERROR: URL for apk list not working.", xbmc.LOGERROR)
                    addFile('Url for txt file not valid', '', themeit=THEMESUBMENUITEMB)
                    addFile('%s' % APKWORKING, '', themeit=THEMESUBMENUITEMB)
            else: wiz.log("[APK Menu] No APK list added.")
    #
    if ENABLEOFFLINE == 'true':
        APKENABLEOFFLINE  = 'true' if wiz.getS('APKENABLEOFFLINE')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]' % (APKENABLEOFFLINE.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'APKENABLEOFFLINE', url, menu=menuapkrefresh, description='APK Offline txt', fanart=FANART, icon=ICONAPK, themeit=THEMETOGGLE)
        if APKENABLEOFFLINE == 'true':
            files = os.listdir(apksTXTFolder)
            for file in files:
                file  = xbmc.translatePath(os.path.join(apksTXTFolder, file))
                link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
                if len(match) > 0:
                    x = 0
                    for name, section, url, icon, fanart, adult, description in match:
                        if icon   == 'http://': icon = ICONAPK
                        if fanart == 'http://': fanart = FANART
                        name2    =       os.path.basename(url)
                        #menuapktxt = createMenu('editapk', 'apks', file)
                        if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                        if section.lower() == 'yes':
                            x += 1
                            addDir('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apk', name, url, createMenu('editapk', 'apks', file),  description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUB)
                        elif section.lower() == 'yes':
                            x += 1
                            addFile('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'rominstall', name, url,  createMenu('editapk', 'apks', file), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon,  themeit=THEMESUBMENUB)
                        else:
                            x += 1
                            addFile('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apkinstall',  name, url,  createMenu('editapk', 'apks', file), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
                    try: # this is an unnessessary txt merge so you can post them all online
                        s=open(file).read()
                        f=open(apkfile,'a')
                        f.write(s)
                        f.close()
                        s.close()
                    except: pass
                else: 
                    if match == 0:
                        wiz.log("[apk Menu] ERROR: Offline apk list not working.")
                        #menuapkrefresh = createMenu('editapk', 'apks', apksTXTFolder)
                        addFile('No Offline apk txts found', 'refreshtxtmenu', name, 'apk', menu=menuapkrefresh, description='Refresh Offline txt directory', icon=ICONAPK, themeit=THEMESUBMENUITEMB)
            addFile('*[B] - Add apk Link or txt url[/B]', 'addapk',   description='Add APK url to Menu.  Saves in user_data settings.', icon=ICONAPK, themeit=THEMEDEFAULT)
    #
    if ENABLEXML == 'true':
        APKENABLE  = 'true' if wiz.getS('APKENABLE')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]' % (APKENABLE.replace('true',on).replace('false',off),OFFLINEXMLFLAG),'togglesetting', 'APKENABLE', url,  menu=menuapkrefresh, description='Turn on APK direct links',  fanart=FANART,  icon=ICONAPK, themeit=THEMETOGGLE)
        if APKENABLE == 'true':
            for items in range(1,100):
                enable   = wiz.getS('APKENABLE%s' % items)
                name     = wiz.getS('APKNAME%s' % items)
                section  = wiz.getS('APKSECTION%s' % items)
                url      = wiz.getS('APKURL%s' % items)
                icon     = wiz.getS('APKICONURL%s' % items)
                if icon   == 'http://': icon = ICONAPK
                fanart=FANART
                adult='no'
                description=name
                name2     =      os.path.basename(url)
                if enable == 'true':
                    if section == 'true': 
                        addDir('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apk',  name, url, createMenu('editapk', items, name), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), icon=ICONAPK, themeit=THEMESUBMENUB)
                    else:
                        addFile('%s   [COLOR %s](%s)[/COLOR]' % (name, COLORDESC, name2), 'apkinstall',  name, url, createMenu('editapk', items, name), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), icon=ICONAPK, themeit=THEMESUBMENUITEMB)
                    try: # this is an unnessessary txt merge so you can post them all online
                        content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"adult="'+adult+'"\ndescription="'+description+'"'
                        #fh = open(os.path.join(apksTXTFolder, getFileName(title)+linkortxt), 'a')
                        fh = open(apkfile, 'a')
                        fh.write(content)
                        fh.close()
                    except: pass
    #
    setView('files', 'viewType')
def apkMenu(name=None, url=None):
        if url == None:
            TEMPAPKFILE = wiz.textCache(uservar.APKFILE)
            if TEMPAPKFILE == False: APKWORKING  = wiz.workingURL(uservar.APKFILE)
        else:
            TEMPAPKFILE = wiz.textCache(url)
            if TEMPAPKFILE == False: APKWORKING  = wiz.workingURL(url)
        if not TEMPAPKFILE == False:
            if os.path.exists(TEMPAPKFILE):
                link = xbmcvfs.File(TEMPAPKFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
            else:
                link = TEMPAPKFILE.replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                x = 0
                for name, section, url, icon, fanart, adult, description in match:
                    if icon   == 'http://': icon = ICONAPK
                    if fanart == 'http://': fanart = FANART
                    name2    =     os.path.basename(url)
                    if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
                    if section.lower() == 'yes':
                        x += 1
                        addDir ("%s  [COLOR %s](%s)[/COLOR]" % (name, COLORDESC, name2), 'apk', name, url, createMenu('editapk', 'apks', TEMPAPKFILE), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMEMENUB)
                    elif section.lower() == 'yes':
                        x += 1
                        addFile("%s  [COLOR %s](%s)[/COLOR]" % (name, COLORDESC, name2), 'rominstall', name, url, createMenu('editapk', 'apks', TEMPAPKFILE), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon, themeit=THEMEMENUB)
                    else:
                        x += 1
                        addFile("%s  [COLOR %s](%s)[/COLOR]" % (name, COLORDESC, name2), 'apkinstall', name, url, createMenu('editapk', 'apks', TEMPAPKFILE), description='[COLOR blue]APK urls:[/COLOR]\n%s  %s\n%s\n%s' % (name, name2, url, description), fanart=fanart, icon=icon,  themeit=THEMEDEFAULT)
                    if x == 0:
                        addFile("No addons added to this menu yet!", '', themeit=THEMEDEFAULT)
            else: wiz.log("[APK Menu] ERROR: Invalid Format.", xbmc.LOGERROR)
        else:
            wiz.log("[APK Menu] ERROR: URL for apk list not working.", xbmc.LOGERROR)
            addFile('Url for txt file not valid', '', themeit=THEMESUBMENUITEMB)
            addFile('%s' % APKWORKING, '', themeit=THEMESUBMENUITEMB)
        setView('files', 'viewType')
def apkInstaller(apk=None, url=None):
    wiz.log(apk)
    wiz.log(url)
    #if wiz.platform() == 'android':
    if url:
        yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install:" % COLORHEADERTXT, "[COLOR %s]%s[/COLOR]" % (COLORHEADER, apk), yeslabel="[B][COLOR green]Download[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        if not yes: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]ERROR: Install Cancelled[/COLOR]' % COLORHEADERTXT); return
        display = apk
        if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
        #if not os.path.exists(SAVEDL): os.makedirs(SAVEDL)
        if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]' % COLORHEADERTXT); return
        DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, display),'', 'Please Wait')
        lib=os.path.join(PACKAGES, "%s.apk" % apk.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', ''))
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        xbmc.sleep(100)
        DP.close()
        notify.apkInstaller(apk)
        wiz.ebi('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]ERROR: None Android Device[/COLOR]' % COLORHEADERTXT)
def romInstaller(name, url):
    myroms = xbmc.translatePath(BACKUPROMS)
    if myroms == '':
        if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that you do not have an extract location setup for Rom Packs" % COLORHEADERTXT, "Would you like to set one?[/COLOR]", yeslabel="[COLOR green][B]Set Location[/B][/COLOR]", nolabel="[COLOR red][B]Cancel Download[/B][/COLOR]"):
            wiz.openS()
            myroms = wiz.getS('rompath')
            if myroms == '': return
    yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Are you sure you would like to download and extract [COLOR %s]%s[/COLOR] to:" % (COLORHEADERTXT, COLORHEADER, name), "[COLOR %s]%s[/COLOR]" % (COLORHEADER, myroms), yeslabel="[B][COLOR green]Download[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
    if not yes: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]ERROR: Install Cancelled[/COLOR]' % COLORHEADERTXT); return
    display = name
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]APK Installer: Invalid Rom Url![/COLOR]' % COLORHEADERTXT); return
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, display),'', 'Please Wait')
    lib=os.path.join(PACKAGES, "%s.zip" % name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', ''))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    xbmc.sleep(100)
    percent, errors, error = extract.all(lib,myroms,DP, title=display)
    try: os.remove(lib)
    except: pass
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Rom Pack Installed[/COLOR]' % COLORHEADERTXT)
    DP.close()
def apkScraper(name=None):
    if name == 'kodi':
        #kodiurl1 = 'http://mirrors.kodi.tv/releases/android/arm/'
        #kodiurl2 = 'http://mirrors.kodi.tv/releases/android/arm/old/'
        kodiurl1 = uservar.kodiurl1
        kodiurl2 = uservar.kodiurl2
        url1 = wiz.openURL(kodiurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        url2 = wiz.openURL(kodiurl2).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url1)
        match2 = re.compile('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url2)
        
        addFile("Official Kodi Apk\'s", themeit=THEMEMENUB)
        rc = False
        for url, name, size, date in match1:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1 and rc == True: continue
            try:
                tempname = name.split('-')
                if not url.find('_') == -1:
                    rc = True
                    name2, v2 = tempname[2].split('_')
                else: 
                    name2 = tempname[2]
                    v2 = ''
                title = "[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLORHEADER, tempname[0].title(), tempname[1], v2.upper(), name2, COLORHEADERTXT, size.replace(' ', ''), COLORHEADER, date)
                download = urljoin(kodiurl1, url)
                addFile(title, 'apkinstall', "%s v%s%s %s" % (tempname[0].title(), tempname[1], v2.upper(), name2), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
            
        for url, name, size, date in match2:
            if url in ['../', 'old/']: continue
            if not url.endswith('.apk'): continue
            if not url.find('_') == -1: continue
            try:
                tempname = name.split('-')
                title = "[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLORHEADER, tempname[0].title(), tempname[1], tempname[2], COLORHEADERTXT, size.replace(' ', ''), COLORHEADER, date)
                download = urljoin(kodiurl2, url)
                addFile(title, 'apkinstall', "%s v%s %s" % (tempname[0].title(), tempname[1], tempname[2]), download)
                x += 1
            except:
                wiz.log("Error on: %s" % name)
        if x == 0: addFile("Error Kodi Scraper Is Currently Down.")
    elif name == 'spmc':
        #spmcurl1 = 'https://github.com/koying/SPMC/releases'
        spmcurl1 = uservar.spmcurl1
        url1 = wiz.openURL(spmcurl1).replace('\n', '').replace('\r', '').replace('\t', '')
        x = 0
        match1 = re.compile('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall(url1)
        
        addFile("Official SPMC Apk\'s", themeit=THEMEMENUB)

        for name, urls in match1:
            tempurl = ''
            match2 = re.compile('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall(urls)
            for apkurl, apksize, apkname in match2:
                if apkname.find('armeabi') == -1: continue
                if apkname.find('launcher') > -1: continue
                tempurl = urljoin('https://github.com', apkurl)
                break
            if tempurl == '': continue
            try:
                name = "SPMC %s" % name
                title = "[COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLORHEADER, name, COLORHEADERTXT, apksize.replace(' ', ''))
                download = tempurl
                addFile(title, 'apkinstall', name, download)
                x += 1
            except Exception, e:
                wiz.log("Error on: %s / %s" % (name, str(e)))
        if x == 0: addFile("Error SPMC Scraper Is Currently Down.")
    setView('files', 'viewType')
def addapk(url=None):
    icon   = ICONAPK
    fanart = FANART
    adult  = 'no'
    if url:
        filename = getFileName(name)
        content = 'name="'+name+'"\nsection="yes"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+name+'"'
        fh = open(os.path.join(apksTXTFolder, filename+linkortxt), 'w')
        fh.write(content)
        fh.close()
        wiz.refresh()
    else:
        keyboard = xbmc.Keyboard('', 'Name')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            name = keyboard.getText()
            #
            keyboard = xbmc.Keyboard('no', 'Section?  (Yes or No)')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                section = keyboard.getText()
                #
                keyboard = xbmc.Keyboard('http://', 'URL')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    url = keyboard.getText()
                    #
                    keyboard = xbmc.Keyboard(name, 'Description?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        description = keyboard.getText()
                        #
                        content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"'
                        fh = open(os.path.join(apksTXTFolder, getFileName(name)+linkortxt), 'w')
                        fh.write(content)
                        fh.close()
                        wiz.refresh()
                        return
    wiz.refresh()
def editapk(title=None):
    filenameOld = title
    file = os.path.join(filenameOld)
    fh = open(file, 'r')
    for line in fh.readlines():
        entry = line[:line.find("=")]
        content = line[line.find("=")+1:]
        if entry == "name": name = content.replace('"','').rstrip()
        elif entry == "section": section = content.replace('"','').rstrip()
        elif entry == "url":  url = content.replace('"','').rstrip()
        elif entry == "icon": icon = content.replace('"','').rstrip()
        elif entry == "fanart": fanart = content.replace('"','').rstrip()
        elif entry == "adult":  adult = content.replace('"','').rstrip()
        elif entry == "description":  description = content.replace('"','').rstrip()
    fh.close()
    oldTitle = name
    keyboard = xbmc.Keyboard(oldTitle, 'Name')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        name = keyboard.getText()
        #
        keyboard = xbmc.Keyboard(section, 'Section?')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            section = keyboard.getText()
            #
            keyboard = xbmc.Keyboard(url, 'URL')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                url = keyboard.getText()
                #
                keyboard = xbmc.Keyboard(icon, 'Icon?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    icon = keyboard.getText()
                    #
                    keyboard = xbmc.Keyboard(fanart, 'Fanart?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        fanart = keyboard.getText()
                        #
                        keyboard = xbmc.Keyboard(adult, 'Adult?')
                        keyboard.doModal()
                        if keyboard.isConfirmed() and keyboard.getText():
                            adult = keyboard.getText()
                            #
                            keyboard = xbmc.Keyboard(description, 'Description?')
                            keyboard.doModal()
                            if keyboard.isConfirmed() and keyboard.getText():
                                description = keyboard.getText()
                                #
                                content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\nadult="'+adult+'"\ndescription="'+description+'"'
                                fh = open(os.path.join(apksTXTFolder, getFileName(name)+linkortxt), 'w')
                                fh.write(content)
                                fh.close()
                                if name != oldTitle: os.remove(os.path.join(filenameOld))
    wiz.refresh()
def xmleditapk(number):
    enable  = wiz.getS('APKENABLE%s' % number)
    name    = wiz.getS('APKNAME%s' % number)
    section = wiz.getS('APKSECTION%s' % number)
    url     = wiz.getS('APKURL%s' % number)
    icon    = wiz.getS('APKICONURL%s' % number)
    #
    enable2  = wiz.getKeyboard(enable, 'Enable the Entry?')
    name2    = wiz.getKeyboard(name, 'Enter the new Name')
    section2 = wiz.getKeyboard(section, 'txt menu url or direct link? (section yes\no)')
    url2     = wiz.getKeyboard(url, 'Enter the new URL')
    icon2    = wiz.getKeyboard(icon, 'Enter the new icon URL')
    #
    wiz.setS('APKENABLE%s' % number, enable2)
    wiz.setS('APKNAME%s' % number, name2)
    wiz.setS('APKSECTION%s' % number, section2)
    wiz.setS('APKURL%s' % number, url2)
    wiz.setS('APKICONURL%s' % number, icon2)
    wiz.refresh()

###########################
###### Media           ####
###########################
def mediaMenu():
    if not YOUTUBETITLE == '': addDir (YOUTUBETITLE ,'youtubeMenu', icon=ICONYOUTUBE, themeit=THEMEMENUB)
    addDir ('M3U',      'm3uMenu',   description='Play an m3u File', icon=ICONVIDEO, themeit=THEMEMENUB)
    #if xbmc.getCondVisibility('Library.HasContent(TVShows) | Library.HasContent(Movies) | Library.HasContent(Music)'): addFile('VOD  (Library)', 'vodguixml', description='Open VOD'  ,icon=ICONVIDEO, themeit=THEMEMENUB)
    #else :  addFile('VOD  [COLOR red](Library)[/COLOR]', 'vodguixml', description='Open VOD'  ,icon=ICONSETTINGS, themeit=THEMEMENUB)
    addDir('CHROME url LAUNCHER    [COLOR blue](Needs Chrome Installed)[COLOR]',  'chromeMenu',  description='Chrome url Launcher', icon=ICONURL,themeit=THEMEMENUB)
    if xbmc.getCondVisibility('system.platform.windows'): addDir ('WINDOWS' ,'windowsMenu',    description='Perform a Windows task',icon=ICONOS, themeit=THEMEMENUB)
    ADDON_ID_CORE  = 'script.tvguide.fullscreen'
    if xbmc.getCondVisibility('System.HasAddon('+ADDON_ID_CORE+')'):  addDir('TV GUIDE FULLSCREEN SETTINGS  [COLOR grey](IPTV add-on)[/COLOR]',    'tvguidesettings',  description='Set skin modded settings for tv guide fullscreen', icon=ICONVIDEO, themeit=THEMEMENUB)
    setView('files', 'viewType')
def m3uMenu(url=None):
    # Direct
    M3UENABLE  = 'true' if wiz.getS('M3UENABLE')  == 'true' else 'false'
    addFile('%s   [B]%s[/B]    URL Links' % (M3UENABLE.replace('true',on).replace('false',off),ONLINEFLAG),'togglesetting', name='M3UENABLE', description='M3U Online urls',  fanart=FANART, icon=ICONVIDEO, themeit=THEMETOGGLE)
    if M3UENABLE == 'true':
        for items in range(1,100):
            enable  =  wiz.getS('M3UENABLE%s' % items)
            url     = wiz.getS('M3UURL%s' % items)
            name    = wiz.getS('M3UNAME%s' % items)
            if name == ' ':   name = os.path.basename(url)
            name2    =  os.path.basename(url)
            if not url  == 'http://':
                if enable == 'true':
                    addDir('%s' % name, 'playm3u',  name=name, url=url,  description='[COLOR blue]M3U:[/COLOR]\n%s\n%s\n%s' % (name, name2, url),   icon=ICONVIDEO, themeit=THEMESUBMENUITEM)
    # Local
    M3UTENABLE  = 'true' if wiz.getS('M3UTENABLE')  == 'true' else 'false'
    addFile('%s   [B]%s[/B]    Local Files' % (M3UTENABLE.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', name='M3UTENABLE', description='M3U Local Files',  fanart=FANART,   icon=ICONVIDEO, themeit=THEMETOGGLE)
    if M3UTENABLE == 'true':
        for items in range(1,100):
            enable  =  wiz.getS('M3UTENABLE%s' % items)
            url     = wiz.getS('M3UTURL%s' % items)
            name    = wiz.getS('M3UTNAME%s' % items)
            if name == ' ':   name = os.path.basename(url)
            name2    =  os.path.basename(url)
            if not url  == 'http://':
                if enable == 'true':
                    if os.path.exists(url):
                        addDir('%s' % name, 'playm3u',  name, url,  description='[COLOR blue]M3U:[/COLOR]\n%s\n%s\n%s' % (name, name2, url),  icon=ICONVIDEO, themeit=THEMESUBMENUITEM)
    setView('files', 'viewType')
def playm3u(url=None):
    xbmc.executebuiltin('ActivateWindow(10025,'+url+',return)')
def tvguidesettings():
    ADDON_ID_CORE  = 'script.tvguide.fullscreen'
    if not xbmc.getCondVisibility('System.HasAddon('+ADDON_ID_CORE+')'): return
    ADDON_CORE     = xbmcaddon.Addon(id=ADDON_ID_CORE)
    dialog = xbmcgui.Dialog()
    # set skin dir name and title
    SKINS = [["Cake", "Cake"],
             ["-", "-"]]
    d = xbmcgui.Dialog()
    names = [s[0] for s in SKINS]
    skin = d.select("TV Guide Fullscreen - Set Default Skin", names)
    if skin > -1:
        if ADDON_CORE:
            # Main Needed to run
            ADDON_CORE.setSetting('skin.source', '2')
            ADDON_CORE.setSetting('skin.folder', 'special://home/addons/'+ADDON_ID+'/')
            ADDON_CORE.setSetting('skin.user', SKINS[skin][1])
            #
            # set epg path 30101
            ADDON_CORE.setSetting('xmltv.type', '1')
            ADDON_CORE.setSetting('xmltv.file', 'special://profile/addon_data/'+ADDON_ID+'/xmltv.xml')
            ADDON_CORE.setSetting('xmltv.url', ADDON.getSetting('xmltv.url'))
            ADDON_CORE.setSetting('gz', ADDON.getSetting('gz'))
            #ADDON_CORE.setSetting('md5', ADDON.getSetting('md5'))
            ADDON_CORE.setSetting('xmltv.interval', ADDON.getSetting('xmltv.interval'))
            
            # NEW Lab3 Secondary XMLTV File
            ADDON_CORE.setSetting('xmltv2.enabled', ADDON.getSetting('xmltv2.enabled'))
            ADDON_CORE.setSetting('xmltv2.type', ADDON.getSetting('xmltv2.type'))
            ADDON_CORE.setSetting('xmltv2.file', ADDON.getSetting('xmltv2.file'))
            ADDON_CORE.setSetting('xmltv2.url', ADDON.getSetting('xmltv2.url'))
            # NEW Lab3 third XMLTV File
            ADDON_CORE.setSetting('xmltv3.enabled', ADDON.getSetting('xmltv3.enabled'))
            ADDON_CORE.setSetting('xmltv3.type', ADDON.getSetting('xmltv3.type'))
            ADDON_CORE.setSetting('xmltv3.file', ADDON.getSetting('xmltv3.file'))
            ADDON_CORE.setSetting('xmltv3.url', ADDON.getSetting('xmltv3.url'))
            
            # optional
            ADDON_CORE.setSetting('addons.ini.enabled', ADDON.getSetting('addons.ini.enabled'))
            ADDON_CORE.setSetting('addons.ini.file', ADDON.getSetting('addons.ini.file'))
            
            # set logos
            ADDON_CORE.setSetting('logos.source', ADDON.getSetting('logos.source'))
            ADDON_CORE.setSetting('logos.folder', ADDON.getSetting('logos.folder'))
            # Playback
            ADDON_CORE.setSetting('m3u.read', ADDON.getSetting('m3u.read'))
            ADDON_CORE.setSetting('catchup.text', ADDON.getSetting('catchup.text'))
            ADDON_CORE.setSetting('channel.shortcut', ADDON.getSetting('channel.shortcut'))
            ADDON_CORE.setSetting('play.alt.choose', ADDON.getSetting('play.alt.choose'))
            ADDON_CORE.setSetting('play.alt.continue', ADDON.getSetting('play.alt.continue'))
            ADDON_CORE.setSetting('stop.on.exit', ADDON.getSetting('stop.on.exit'))
            ADDON_CORE.setSetting('exit.on.back', ADDON.getSetting('exit.on.back'))
            # set Appearance
            ADDON_CORE.setSetting('epg.video.pip', ADDON.getSetting('epg.video.pip'))
            ADDON_CORE.setSetting('program.image.scale', ADDON.getSetting('program.image.scale'))
            ADDON_CORE.setSetting('stream.addon.list', ADDON.getSetting('stream.addon.list'))
            ADDON_CORE.setSetting('up.cat.mode', ADDON.getSetting('up.cat.mode'))
            ADDON_CORE.setSetting('action.bar', ADDON.getSetting('action.bar'))
            ADDON_CORE.setSetting('down.action', ADDON.getSetting('down.action'))
            ADDON_CORE.setSetting('program.search.plot', ADDON.getSetting('program.search.plot'))
            ADDON_CORE.setSetting('channel.logo', ADDON.getSetting('channel.logo'))
            ADDON_CORE.setSetting('addon.logo', ADDON.getSetting('addon.logo'))
            ADDON_CORE.setSetting('channels.per.page', ADDON.getSetting('channels.per.page'))
            ADDON_CORE.setSetting('channel.filter.sort', ADDON.getSetting('channel.filter.sort'))
            ADDON_CORE.setSetting('menu.addon', ADDON.getSetting('menu.addon'))
            # Background
            ADDON_CORE.setSetting('program.background.enabled', ADDON.getSetting('program.background.enabled'))
            ADDON_CORE.setSetting('program.background.image.source', ADDON.getSetting('program.background.image.source'))
            ADDON_CORE.setSetting('program.background.color', ADDON.getSetting('program.background.color'))
            ADDON_CORE.setSetting('program.background.flat', ADDON.getSetting('program.background.flat'))
            ADDON_CORE.setSetting('timebar.color', ADDON.getSetting('timebar.color'))
            ADDON_CORE.setSetting('categories.background.color', ADDON.getSetting('categories.background.color'))
            # Lab1
            ADDON_CORE.setSetting('cat.order', ADDON.getSetting('cat.order'))
            # Lab2
            '''
            ADDON_CORE.setSetting('yo.countries', 'canada,uk,us')
            ADDON_CORE.setSetting('yo.canada.headend', '325363')
            ADDON_CORE.setSetting('yo.us.headend', '318990-320445')
            ADDON_CORE.setSetting('yo.uk.headend', '114')
            ADDON_CORE.setSetting('tvguide.co.uk.days', '7')
            ADDON_CORE.setSetting('tvguide.co.uk.systemid', 'Virgin XL')
            '''
            dialog.ok('Done', 'Using "' + SKINS[skin][1] + '"')
        if not ADDON_CORE: dialog.ok('Error', 'Cannot set "' + SKINS[skin][1] + '"')
        if dialog.yesno('Built-in?', 'Do you want to refresh addons.ini?', 'These are built-in common channels.'):refresh_ini()
def windowsMenu():
    xbmc.log(msg='##['+ADDON_ID+'] **Windows Things MENU**', level=xbmc.LOGNOTICE)
    addFile('Firefox',   'runexe', name=xbmc.translatePath(os.path.join('C:','Program Files','Mozilla Firefox','firefox.exe')), url='www.google.com',  description='Run Windows exe file',  icon=ICONOS, themeit=THEMEDEFAULT)
    addFile('Notepad',   'runexe', name='C:/Windows/System32/notepad.exe', url='txt.txt',  description='Run Windows exe file',  icon=ICONOS, themeit=THEMEDEFAULT)
    #visible = xbmc.getCondVisibility('[Control.IsVisible(41) + !Control.IsVisible(12)]')
    #if xbmc.getCondVisibility('System.HasAddon(id)'):
    setView('files',  'viewType')
def run_exe(name=None, url=None):
    from subprocess import call
    from subprocess import Popen
    #xbmc.log(msg='##['+ADDON_ID+'] Start 3rd Party exe', level=xbmc.LOGNOTICE)
    if os.path.exists(name):
        cmd = [name, url]
        #cmd = [ffmpeg, "-y", "-i", url, "-c:v", "copy", "-c:a", "copy", "-t", str(seconds), "-f", "mpegts", "-map", "0:v", "-map", "0:a", filename]
        #cmd = [ffmpeg, "-y", "-i", url, "-c:v", "copy", "-c:a", "copy", "-t", str(seconds), filename]
        #p = Popen(cmd,shell=True) # has NO cmd window info prompt
        p = Popen(cmd,shell=False) # has cmd window info prompt
        #try: xbmc.executebuiltin('PlayMedia(%s)' % filename)
        #except: pass
        xbmcgui.Dialog().notification(name, url, ICON, 2000, False)
def skin_settings_minimal():
    dialog = xbmcgui.Dialog()
    ADDON_ID_CORE  = 'script.tvguide.fullscreen'
    ADDON_CORE     = xbmcaddon.Addon(id=ADDON_ID_CORE)
    # set skin dir name and title
    SKINS = [["Cake", "Cake"],
             ["-", "-"]]
    names = [s[0] for s in SKINS]
    skin = dialog.select("TV Guide Fullscreen - Set Default Skin", names)
    if skin > -1:
        if ADDON_CORE:
            # Main Needed to run
            ADDON_CORE.setSetting('skin.source', '2')
            ADDON_CORE.setSetting('skin.folder', 'special://home/addons/'+ADDON_ID+'/')
            ADDON_CORE.setSetting('skin.user', SKINS[skin][1])
            dialog.ok('Done', 'Using "' + SKINS[skin][1] + '"')
        if not ADDON_CORE: dialog.ok('Error', 'Cannot set "' + SKINS[skin][1] + '"')
def skin_settings():
    dialog = xbmcgui.Dialog()
    ADDON_ID_CORE  = 'script.tvguide.fullscreen'
    ADDON_CORE     = xbmcaddon.Addon(id=ADDON_ID_CORE)
    # set skin dir name and title
    SKINS = [["Cake", "Cake"],
             ["-", "-"]]
    d = xbmcgui.Dialog()
    names = [s[0] for s in SKINS]
    skin = d.select("TV Guide Fullscreen - Set Default Skin", names)
    if skin > -1:
        if ADDON_CORE:
            # Main Needed to run
            ADDON_CORE.setSetting('skin.source', '2')
            ADDON_CORE.setSetting('skin.folder', 'special://home/addons/'+ADDON_ID+'/')
            ADDON_CORE.setSetting('skin.user', SKINS[skin][1])
            #
            # set epg path 30101
            ADDON_CORE.setSetting('xmltv.type', '1')
            ADDON_CORE.setSetting('xmltv.file', 'special://profile/addon_data/'+ADDON_ID+'/xmltv.xml')
            ADDON_CORE.setSetting('xmltv.url', ADDON.getSetting('xmltv.url'))
            ADDON_CORE.setSetting('gz', ADDON.getSetting('gz'))
            #ADDON_CORE.setSetting('md5', ADDON.getSetting('md5'))
            ADDON_CORE.setSetting('xmltv.interval', ADDON.getSetting('xmltv.interval'))
            
            # NEW Lab3 Secondary XMLTV File
            ADDON_CORE.setSetting('xmltv2.enabled', ADDON.getSetting('xmltv2.enabled'))
            ADDON_CORE.setSetting('xmltv2.type', ADDON.getSetting('xmltv2.type'))
            ADDON_CORE.setSetting('xmltv2.file', ADDON.getSetting('xmltv2.file'))
            ADDON_CORE.setSetting('xmltv2.url', ADDON.getSetting('xmltv2.url'))
            # NEW Lab3 third XMLTV File
            ADDON_CORE.setSetting('xmltv3.enabled', ADDON.getSetting('xmltv3.enabled'))
            ADDON_CORE.setSetting('xmltv3.type', ADDON.getSetting('xmltv3.type'))
            ADDON_CORE.setSetting('xmltv3.file', ADDON.getSetting('xmltv3.file'))
            ADDON_CORE.setSetting('xmltv3.url', ADDON.getSetting('xmltv3.url'))
            
            # optional
            ADDON_CORE.setSetting('addons.ini.enabled', ADDON.getSetting('addons.ini.enabled'))
            ADDON_CORE.setSetting('addons.ini.file', ADDON.getSetting('addons.ini.file'))
            
            # set logos
            ADDON_CORE.setSetting('logos.source', ADDON.getSetting('logos.source'))
            ADDON_CORE.setSetting('logos.folder', ADDON.getSetting('logos.folder'))
            # Playback
            ADDON_CORE.setSetting('m3u.read', ADDON.getSetting('m3u.read'))
            ADDON_CORE.setSetting('catchup.text', ADDON.getSetting('catchup.text'))
            ADDON_CORE.setSetting('channel.shortcut', ADDON.getSetting('channel.shortcut'))
            ADDON_CORE.setSetting('play.alt.choose', ADDON.getSetting('play.alt.choose'))
            ADDON_CORE.setSetting('play.alt.continue', ADDON.getSetting('play.alt.continue'))
            ADDON_CORE.setSetting('stop.on.exit', ADDON.getSetting('stop.on.exit'))
            ADDON_CORE.setSetting('exit.on.back', ADDON.getSetting('exit.on.back'))
            # set Appearance
            ADDON_CORE.setSetting('epg.video.pip', ADDON.getSetting('epg.video.pip'))
            ADDON_CORE.setSetting('program.image.scale', ADDON.getSetting('program.image.scale'))
            ADDON_CORE.setSetting('stream.addon.list', ADDON.getSetting('stream.addon.list'))
            ADDON_CORE.setSetting('up.cat.mode', ADDON.getSetting('up.cat.mode'))
            ADDON_CORE.setSetting('action.bar', ADDON.getSetting('action.bar'))
            ADDON_CORE.setSetting('down.action', ADDON.getSetting('down.action'))
            ADDON_CORE.setSetting('program.search.plot', ADDON.getSetting('program.search.plot'))
            ADDON_CORE.setSetting('channel.logo', ADDON.getSetting('channel.logo'))
            ADDON_CORE.setSetting('addon.logo', ADDON.getSetting('addon.logo'))
            ADDON_CORE.setSetting('channels.per.page', ADDON.getSetting('channels.per.page'))
            ADDON_CORE.setSetting('channel.filter.sort', ADDON.getSetting('channel.filter.sort'))
            ADDON_CORE.setSetting('menu.addon', ADDON.getSetting('menu.addon'))
            # Background
            ADDON_CORE.setSetting('program.background.enabled', ADDON.getSetting('program.background.enabled'))
            ADDON_CORE.setSetting('program.background.image.source', ADDON.getSetting('program.background.image.source'))
            ADDON_CORE.setSetting('program.background.color', ADDON.getSetting('program.background.color'))
            ADDON_CORE.setSetting('program.background.flat', ADDON.getSetting('program.background.flat'))
            ADDON_CORE.setSetting('timebar.color', ADDON.getSetting('timebar.color'))
            ADDON_CORE.setSetting('categories.background.color', ADDON.getSetting('categories.background.color'))
            # Lab1
            ADDON_CORE.setSetting('cat.order', ADDON.getSetting('cat.order'))
            # Lab2
            '''
            ADDON_CORE.setSetting('yo.countries', 'canada,uk,us')
            ADDON_CORE.setSetting('yo.canada.headend', '325363')
            ADDON_CORE.setSetting('yo.us.headend', '318990-320445')
            ADDON_CORE.setSetting('yo.uk.headend', '114')
            ADDON_CORE.setSetting('tvguide.co.uk.days', '7')
            ADDON_CORE.setSetting('tvguide.co.uk.systemid', 'Virgin XL')
            '''
            dialog.ok('Done', 'Using "' + SKINS[skin][1] + '"')
        if not ADDON_CORE: dialog.ok('Error', 'Cannot set "' + SKINS[skin][1] + '"')

###########################
###### youtube Menu Items # add txt
###########################
def youtubeMenu(name=None, url=None):
    youtubefile = os.path.join(DATAPATHUSERDATA, 'youtube'+linkortxt)
    delete_file(youtubefile)
    #
    if ENABLEONLINE  == 'true':
        YOUTUBEENABLEONLINE  = 'true' if wiz.getS('YOUTUBEENABLEONLINE')  == 'true' else 'false'
        if not YOUTUBEFILE   == 'http://': addFile('%s   [B]%s[/B]' % (YOUTUBEENABLEONLINE.replace('true',on).replace('false',off),ONLINEFLAG),'togglesetting', 'YOUTUBEENABLEONLINE', url,  description='Youtube Online  txt',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEMETOGGLE)
        if YOUTUBEENABLEONLINE == 'true':
            if not YOUTUBEFILE == 'http://':
                if url == None:
                    TEMPYOUTUBEFILE = wiz.textCache(uservar.YOUTUBEFILE)
                    if TEMPYOUTUBEFILE == False: YOUTUBEWORKING  = wiz.workingURL(uservar.YOUTUBEFILE)
                else:
                    TEMPYOUTUBEFILE = wiz.textCache(url)
                    if TEMPYOUTUBEFILE == False: YOUTUBEWORKING  = wiz.workingURL(url)
                if not TEMPYOUTUBEFILE == False:
                    if os.path.exists(TEMPYOUTUBEFILE):
                        link = xbmcvfs.File(TEMPYOUTUBEFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                    else:
                        link = TEMPYOUTUBEFILE.replace('\n','').replace('\r','').replace('\t','')
                    match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
                    if len(match) > 0:
                        for name, section, url, icon, fanart, description in match:
                            if icon in ['http://', 'https://', ' ']: icon=ICONYOUTUBE
                            if fanart in ['http://', 'https://', ' ']: fanart=FANART
                            if section.lower() == "yes":
                                addDir("[B]%s[/B]" % name, 'youtube', name, url,  createMenu('edityoutube', 'youtube', YOUTUBEFILE), description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUB)
                            else:
                                addFile(name, 'viewVideo', name, url, createMenu('edityoutube', 'youtube', TEMPYOUTUBEFILE), description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
                    else: wiz.log("[YouTube Menu] ERROR: Invalid Format.")
                else:  addFile('Url for txt file not valid : %s' % YOUTUBEWORKING, '', themeit=THEMESUBMENUITEMB)
            else: addFile('No Online Youtube txts found : %s' % YOUTUBEWORKING, '', themeit=THEMESUBMENUITEMB)
    #
    if ENABLEOFFLINE == 'true':
        YOUTUBEENABLEOFFLINE  = 'true' if wiz.getS('YOUTUBEENABLEOFFLINE')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]' % (YOUTUBEENABLEOFFLINE.replace('true',on).replace('false',off),OFFLINEFLAG),'togglesetting', 'YOUTUBEENABLEOFFLINE', url, description='Youtube Offline txt',  fanart=FANART, icon=ICONYOUTUBE, themeit=THEMETOGGLE)
        if YOUTUBEENABLEOFFLINE == 'true':
            files = os.listdir(youtubeTXTFolder)
            for file in files:
                file  = xbmc.translatePath(os.path.join(youtubeTXTFolder, file))
                link  = xbmcvfs.File(file,'rb').read().replace('\n','').replace('\r','').replace('\t','')
                match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
                if len(match) > 0:
                    for name, section, url, icon, fanart, description in match:
                        if icon in ['http://', 'https://', ' ']: icon=ICONYOUTUBE
                        if fanart in ['http://', 'https://', ' ']: fanart=FANART
                        if section.lower() == "yes":
                            addDir('[B]%s[/B]' % name, 'youtube', name, url, createMenu('edityoutube', 'youtube', file), description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUB)
                        else:
                            addFile(name, 'viewVideo', name, url, createMenu('edityoutube', 'youtube', file), description=description, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
                    try: # this is an unnessessary txt merge so you can post them all online
                        s=open(file).read()
                        f=open(youtubefile,'a')
                        f.write(s)
                        f.close()
                        s.close()
                    except: pass
                else: 
                    if match == 0:
                        wiz.log("[YouTube Menu] ERROR: Offline YouTube list not working.")
                        addFile('No Offline Youtube txts found', 'refreshtxtmenu', name, 'youtube', createMenu('edityoutube', 'youtube', youtubeTXTFolder), description='Refresh Offline txt directory', icon=ICONYOUTUBE, themeit=THEMESUBMENUITEMB)
            addFile('*[B] - Add Youtube Link or txt url[/B]', 'addyoutube',  'Add Youtube url',  url,  description='Add Youtube url to Menu.  Saves in user_data settings.', icon=ICONYOUTUBE, themeit=THEMEDEFAULT)
    #
    if ENABLEXML == 'true':
        YOUTUBEENABLE  = 'true' if wiz.getS('YOUTUBEENABLE')  == 'true' else 'false'
        addFile('%s   [B]%s[/B]' % (YOUTUBEENABLE.replace('true',on).replace('false',off),OFFLINEXMLFLAG),'togglesetting', 'YOUTUBEENABLE', url, description='Turn on Youtube direct links',  fanart=FANART,  icon=ICONYOUTUBE, themeit=THEMETOGGLE)
        if YOUTUBEENABLE == 'true':
            for items in range(1,100):
                enable   = wiz.getS('YOUTUBEENABLE%s' % items)
                name     = wiz.getS('YOUTUBENAME%s' % items)
                section  = wiz.getS('YOUTUBESECTION%s' % items)
                url      = wiz.getS('YOUTUBEURL%s' % items)
                icon=ICONYOUTUBE
                fanart=FANART
                description=name
                if name == ' ':   name = os.path.basename(url)
                name2    =       os.path.basename(url)
                if enable == 'true':
                    if section == 'true': addDir(name, 'youtube',  name, url, createMenu('edityoutube', items, name), description='[COLOR blue]Youtube Online txt Menus:[/COLOR]\n%s\n%s\n%s' % (name, name2, url), icon=ICONYOUTUBE,  themeit=THEMESUBMENUB)
                    else: addFile(name, 'viewVideo', name, url, createMenu('edityoutube', items, name), description='[COLOR blue]Youtube urls:[/COLOR]\n%s\n%s\n%s' % (name, name2, url), icon=ICONYOUTUBE, themeit=THEMESUBMENUITEMB)
                    try: # this is an unnessessary txt merge so you can post them all online
                        content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\ndescription="'+description+'"'
                        #fh = open(os.path.join(youtubeTXTFolder, getFileName(title)+linkortxt), 'a')
                        fh = open(youtubefile, 'a')
                        fh.write(content)
                        fh.close()
                    except: pass
    #
    setView('files', 'viewType')
def youtube(name=None, url=None):
    if not YOUTUBEFILE == 'http://':
        if url == None:
            TEMPYOUTUBEFILE = wiz.textCache(uservar.YOUTUBEFILE)
            if TEMPYOUTUBEFILE == False: YOUTUBEWORKING  = wiz.workingURL(uservar.YOUTUBEFILE)
        else:
            TEMPYOUTUBEFILE = wiz.textCache(url)
            if TEMPYOUTUBEFILE == False: YOUTUBEWORKING  = wiz.workingURL(url)
        if not TEMPYOUTUBEFILE == False:
            if os.path.exists(TEMPYOUTUBEFILE):
                link = xbmcvfs.File(TEMPYOUTUBEFILE,'rb').read().replace('\n','').replace('\r','').replace('\t','')
            else:
                link = TEMPYOUTUBEFILE.replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                for name, section, url, icon, fanart, description in match:
                    if icon in ['http://', 'https://', ' ']: icon=ICONYOUTUBE
                    if fanart in ['http://', 'https://', ' ']: fanart=FANART
                    if section.lower() == "yes": addDir ("[B]%s[/B]" % name, 'youtube', name, url, description=description, fanart=fanart, icon=icon, themeit=THEMEMENUB)
                    else: addFile(name, 'viewVideo', name, url, description=description, fanart=fanart, icon=icon, themeit=THEMEDEFAULTB)
            else: wiz.log("[YouTube Menu] ERROR: Invalid Format.")
        else: 
            wiz.log("[YouTube Menu] ERROR: URL for YouTube list not working.")
            addFile('Url for txt file not valid', '', themeit=THEME3)
            addFile('%s' % YOUTUBEWORKING, '', themeit=THEME3)
    else: wiz.log("[YouTube Menu] No YouTube list added.")
    setView('files', 'viewType')
def addyoutube(site="", title=""):
    icon = ICONYOUTUBE
    fanart = FANART
    if site:
        filename = getFileName(title)
        content = 'name="'+title+'"\nsection="yes"\nurl="'+site+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\ndescription="'+title+'"'
        fh = open(os.path.join(youtubeTXTFolder, filename+linkortxt), 'w')
        fh.write(content)
        fh.close()
        wiz.refresh()
    else:
        keyboard = xbmc.Keyboard('', 'Name')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            title = keyboard.getText()
            #
            keyboard = xbmc.Keyboard('no', 'Section?  (Yes or No)')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                section = keyboard.getText()
                #
                keyboard = xbmc.Keyboard('http://', 'URL')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    url = keyboard.getText()
                    #
                    keyboard = xbmc.Keyboard(title, 'Description?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        description = keyboard.getText()
                        #
                        content = 'name="'+title+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\ndescription="'+description+'"'
                        fh = open(os.path.join(youtubeTXTFolder, getFileName(title)+linkortxt), 'w')
                        fh.write(content)
                        fh.close()
                        wiz.refresh()
                        return
    wiz.refresh()
    return
def edityoutube(title=None):
    filenameOld = title
    file = os.path.join(filenameOld)
    fh = open(file, 'r')
    for line in fh.readlines():
        entry = line[:line.find("=")]
        content = line[line.find("=")+1:]
        if entry == "name": name = content.replace('"','').rstrip()
        elif entry == "section": section = content.replace('"','').rstrip()
        elif entry == "url":  url = content.replace('"','').rstrip()
        elif entry == "icon": icon = content.replace('"','').rstrip()
        elif entry == "fanart": fanart = content.replace('"','').rstrip()
        elif entry == "description":  description = content.replace('"','').rstrip()
    fh.close()
    oldTitle = name
    keyboard = xbmc.Keyboard(oldTitle, 'Name')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        name = keyboard.getText()
        #
        keyboard = xbmc.Keyboard(section, 'Section?')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            section = keyboard.getText()
            #
            keyboard = xbmc.Keyboard(url, 'URL')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                url = keyboard.getText()
                #
                keyboard = xbmc.Keyboard(icon, 'Icon?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    icon = keyboard.getText()
                    #
                    keyboard = xbmc.Keyboard(fanart, 'Fanart?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        fanart = keyboard.getText()
                        #
                        keyboard = xbmc.Keyboard(description, 'Description?')
                        keyboard.doModal()
                        if keyboard.isConfirmed() and keyboard.getText():
                            description = keyboard.getText()
                            #
                            content = 'name="'+name+'"\nsection="'+section+'"\nurl="'+url+'"\nicon="'+icon+'"\nfanart="'+fanart+'"\ndescription="'+description+'"'
                            fh = open(os.path.join(youtubeTXTFolder, getFileName(name)+linkortxt), 'w')
                            fh.write(content)
                            fh.close()
                            if name != oldTitle: os.remove(os.path.join(filenameOld))
    wiz.refresh()
def xmledityoutube(number):
    enable  = wiz.getS('YOUTUBEENABLE%s' % number)
    name    = wiz.getS('YOUTUBENAME%s' % number)
    section = wiz.getS('YOUTUBESECTION%s' % number)
    url     = wiz.getS('YOUTUBEURL%s' % number)
    enable2  = wiz.getKeyboard(enable, 'Enable the Entry?')
    name2    = wiz.getKeyboard(name, 'Enter the new Name')
    section2 = wiz.getKeyboard(section, 'txt menu url or direct link? (section yes\no)')
    url2     = wiz.getKeyboard(url, 'Enter the new URL')
    wiz.setS('YOUTUBEENABLE%s' % number, enable2)
    wiz.setS('YOUTUBENAME%s' % number, name2)
    wiz.setS('YOUTUBESECTION%s' % number, section2)
    wiz.setS('YOUTUBEURL%s' % number, url2)
    wiz.refresh()

###########################
###### chrome Menu Items ##
###########################
def chromeMenu(name=None, url=None):
    kiosk  = 'true' if wiz.getS('CHROMEKIOSK')  == 'true' else 'false'
    addFile('(%s)   Kiosk Mode?' % kiosk.replace('true',on).replace('false',off), 'togglesetting', 'CHROMEKIOSK', url, description='Turn on Kiosk Mode',  fanart=FANART, icon=ICONURL, themeit=THEMETOGGLE)
    files = os.listdir(sitesTXTFolder)
    for file in files:
        if file.endswith(linkortxt):
            fh = open(os.path.join(sitesTXTFolder, file), 'r')
            for line in fh.readlines():
                entry = line[:line.find("=")]
                content = line[line.find("=")+1:]
                if entry   == "title":
                    title = content.strip()
                elif entry == "url":
                    url = content.strip()
                elif entry == "thumb":
                    thumb = content.strip()
                elif entry == "kiosk":
                    kiosk = content.strip()
                elif entry == "stopPlayback":
                    stopPlayback = content.strip()
                    addChromeSiteFile(title, title, url, 'showSite', thumb, stopPlayback, kiosk, description=title, themeit=THEMEDEFAULT)
            fh.close()
    # add another entry above and in settings.xml
    addFile('*[B]- Add Website url txt[/B]', 'addSite',  'Add Website',  url,  description='Add Website to Menu.  Saves in user_data settings.', icon=ICONURL, themeit=THEMEDEFAULT)
    addFile('[ VIMEO Couchmode ]',   'showSite', 'Vimeo',    "http://www.vimeo.com/couchmode",     description='Vimeo',       icon=ICONURL,  themeit=THEMEDEFAULT)
    addFile('[ YOUTUBE Leanback ]',  'showSite', 'Youtube',  "http://www.youtube.com/leanback",    description='Youtube',     icon=ICONYOUTUBE, themeit=THEMEDEFAULT)
    for items in range(1,10):
        url     = wiz.getS('CHROMEURL%s' % items)
        name    = url
        if name == ' ':   name = os.path.basename(url)
        name2    =  os.path.basename(url)
        if not url  == 'http://':
            addDir('[B]%s[/B]' % name, 'showSite',  name, url,  description='[COLOR blue]URL:[/COLOR]\n%s\n%s\n%s' % (name, name2, url), icon=ICONURL, themeit=THEMEDEFAULT)
    setView('files', 'viewType')
def addSite(site="", title=""):
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    if site:
        filename = getFileName(title)
        content = "title="+title+"\nurl="+site+"\nthumb=DefaultFolder.png\nstopPlayback=no\nkiosk="+kiosk
        fh = open(os.path.join(sitesTXTFolder, filename+linkortxt), 'w')
        fh.write(content)
        fh.close()
        wiz.refresh()
    else:
        keyboard = xbmc.Keyboard('', 'Title')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            title = keyboard.getText()
            keyboard = xbmc.Keyboard('http://', 'URL')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                url = keyboard.getText()
                keyboard = xbmc.Keyboard('no', 'Stop XBMC playback?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
                    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
                    stopPlayback = keyboard.getText()
                    keyboard = xbmc.Keyboard(kiosk, 'Use kiosk mode?')
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        kiosk = keyboard.getText()
                        content = "title="+title+"\nurl="+url+"\nthumb=DefaultFolder.png\nstopPlayback="+stopPlayback+"\nkiosk="+kiosk
                        fh = open(os.path.join(sitesTXTFolder, getFileName(title)+linkortxt), 'w')
                        fh.write(content)
                        fh.close()
                        wiz.refresh()
                        return
    return
def getFileName(title=None):
    return (''.join(c for c in unicode(title, 'utf-8') if c not in '/\\:?"*|<>')).strip()
def getFullPath(path=None, url=None, useKiosk=None, userAgent=None):
    profileFolder    = os.path.join(sitesTXTFolder, 'profile')
    if not os.path.isdir(profileFolder):  os.mkdir(profileFolder)
    profile = ""
    useOwnProfile    = ADDON.getSetting("useOwnProfile") == "true"
    if useOwnProfile:
        profile = '--user-data-dir="'+profileFolder+'" '
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    if useKiosk=="yes":
        kiosk = '--kiosk '
    else: kiosk = ' '
    if userAgent:
        userAgent = '--user-agent="'+userAgent+'" '
    return '"'+path+'" '+profile+userAgent+'--start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run '+kiosk+'"'+url+'"'
def showSite(url=None, stopPlayback=None, kiosk=None, userAgent=None):
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    useCustomPath    = ADDON.getSetting("useCustomPath") == "true"
    customPath       = xbmc.translatePath(ADDON.getSetting("customPath"))
    if stopPlayback == "yes":
        xbmc.Player().stop()
    if xbmc.getCondVisibility('system.platform.windows'):
        path = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
        path64 = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        elif os.path.exists(path64):
            fullUrl = getFullPath(path64, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=False)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    elif xbmc.getCondVisibility('system.platform.osx'):
        path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    elif xbmc.getCondVisibility('system.platform.linux'):
        path = "/usr/bin/google-chrome"
        if useCustomPath and os.path.exists(customPath):
            fullUrl = getFullPath(customPath, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        elif os.path.exists(path):
            fullUrl = getFullPath(path, url, kiosk, userAgent)
            subprocess.Popen(fullUrl, shell=True)
        else:
            xbmc.executebuiltin('XBMC.Notification(Info:,Chrome not found!,5000)')
            ADDON.openSettings()
    else : return
def removeSite(title=None):
    os.remove(os.path.join(sitesTXTFolder, getFileName(title)+linkortxt))
    wiz.refresh()
def editSite(title=None):
    filenameOld = getFileName(title)
    file = os.path.join(sitesTXTFolder, filenameOld+linkortxt)
    fh = open(file, 'r')
    title = ""
    url = ""
    #kiosk = "yes"
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    thumb = "DefaultFolder.png"
    stopPlayback = "no"
    for line in fh.readlines():
        entry = line[:line.find("=")]
        content = line[line.find("=")+1:]
        if entry == "title":
            title = content.strip()
        elif entry == "url":
            url = content.strip()
        elif entry == "kiosk":
            kiosk = content.strip()
        elif entry == "thumb":
            thumb = content.strip()
        elif entry == "stopPlayback":
            stopPlayback = content.strip()
    fh.close()
    oldTitle = title
    keyboard = xbmc.Keyboard(title, 'Title')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        title = keyboard.getText()
        keyboard = xbmc.Keyboard(url, 'URL')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = keyboard.getText()
            keyboard = xbmc.Keyboard(stopPlayback, 'Stop XBMC playback?')
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                stopPlayback = keyboard.getText()
                keyboard = xbmc.Keyboard(kiosk, 'Use kiosk mode?')
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    kiosk = keyboard.getText()
                    content = "title="+title+"\nurl="+url+"\nthumb="+thumb+"\nstopPlayback="+stopPlayback+"\nkiosk="+kiosk
                    fh = open(os.path.join(sitesTXTFolder, getFileName(title)+linkortxt), 'w')
                    fh.write(content)
                    fh.close()
                    if title != oldTitle:
                        os.remove(os.path.join(sitesTXTFolder, filenameOld+linkortxt))
    wiz.refresh()
def parameters_string_to_dict(parameters=None): # chrome
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

###########################
## plugin.git.browser     #
#  Thanks to TVA          #
###########################
def github_main():
    #github_instructions()
    addDir('[COLOR blue]SEARCH:[/COLOR]   GitHub Username', 'github_search_username',    description='Search Github (the common www source of many addons) for a specific Kodi developers User name',  icon=ICONGITHUB, themeit=THEMEMENUB)
    addDir('[COLOR blue]SEARCH:[/COLOR]   GitHub Repository Title','github_search_repo', description='Search Github (the common www source of many addons) for a specific Kodi developers Repo name', icon=ICONGITHUB, themeit=THEMEMENUB)
    addDir('[COLOR blue]SEARCH:[/COLOR]   GitHub by Addon ID','github_search_addon_id',     description='Search Github (the common www source of many addons) for a specific Kodi Addon', icon=ICONGITHUB, themeit=THEMEMENUB)
    addFile('GitHub Update Addons','github_update',                  description='GitHub Update Addons ',  icon=ICONSETTINGS, themeit=THEMEDEFAULTB)
    addFile('GitHub instructions','github_instructions',             description='Instructions for how to use GitHub Browser',  icon=ICONINFO, themeit=THEMEDEFAULTB)
    setView('files', 'viewType')
def _get_keyboard(default="", heading="", hidden=False):                       
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return unicode(keyboard.getText(), "utf-8")
    return default
def SEARCHADDON(url=None):                                                      
    vq = _get_keyboard(heading="Search add-ons")
    if (not vq):
        return False, 0
    title = urllib.quote_plus(vq)
    Get_search_results(title)
def Get_search_results(title=None):
    link = api.search_addons(title)
    my_list = sorted(link, key=lambda k: k['name'].upper())
    for e in link:
        name = e['name']
        repourl = e['repodlpath']
        path = e['addon_zip_path']
        description = e['description']
        icon = path.rsplit('/', 1)[0] + '/icon.png'
        fanart = path.rsplit('/', 1)[0] + '/fanart.jpg'
        if e['extension_point'] != 'xbmc.addon.repository':
            try:
                #addDir(name, path, 'addoninstall', fanart, icon, description, 'addon', repourl, '', '', CMi, contextreplace=False)
                addDir(name, path, 'addoninstall', fanart, icon, description, 'addon', repourl, '', '', CMi, contextreplace=False)
            except: pass
    setView('files', 'viewType')
def github_search(url):
    from resources.libs.github_installer import kodi as _kodi
    q = _get_keyboard("", "Search GitHub")
    if not q: return
    import json
    from resources.libs.github_installer import github_api
    if url == 'username':
        rtype = 'api'
        response = github_api.find_zips(q)
        if response is None: return
        for r in github_api.sort_results(response['items']):
            if not r['path'].endswith(".zip"): continue
            url = github_api.content_url % (r['repository']['full_name'], r['path'])
            _kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'repo':
        rtype = 'api'
        results = github_api.search(q, 'title')
        if results is None: return
        for i in results['items']:
            user = i['owner']['login']
            response = github_api.find_zips(user)
            if response is None: continue
            for r in github_api.sort_results(response['items']):
                if not r['path'].endswith(".zip"): continue
                url = github_api.content_url % (r['repository']['full_name'], r['path'])
                _kodi.addItem(r['name'], json.dumps({"url": url, "user": q, "file": r['name'], "full_name": "%s/%s" % (q, r['repository']['name'])}), 'github_install', '', description="")
        #viewsetter.set_view("list")
        return
    elif url == 'addon_id':
        rtype = 'web'
        results = github_api.web_search(q)
    else:
        rtype = 'api'
        results = github_api.search(q)
    if results is None: return
    for r in results['items']:
        if rtype == 'api':
            _kodi.addDir(r['name'], json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
        else:
            _kodi.addItem("%s/%s" % (r['owner']['login'], r['name']), json.dumps({"user":  r['owner']['login'], "repo": r['name'], "rtype": rtype}), 'github_results', '', description="")
    setView('files', 'viewType')
def github_results(url):
    import json
    from resources.libs import github_installer
    from resources.libs.github_installer import kodi as _kodi
    from resources.libs.github_installer import github_api
    args = json.loads(url)
    #viewsetter.set_view("list")
    if args['rtype'] == 'web':
        from resources.libs.github_installer import kodi as _kodi
        full_name = "%s/%s" % (args['user'], args['repo'])
        c = _kodi.dialog_confirm("Confirm Install", full_name, yes="Install", no="Cancel")
        if not c: return
        url = "https://github.com/%s/%s/archive/master.zip" % (args['user'], args['repo'])
        Ins = github_installer.GitHub_Installer(args['repo'], url, full_name, _kodi.vfs.join("special://home", "addons"), True)
        return
    results = github_api.find_zips(args['user'], args['repo'])
    if results is None: return
    for r in results['items']:
        if r['repository']['name'] != args['repo']: continue
        url = github_api.content_url % (r['repository']['full_name'], r['path'])
        _kodi.addItem(r['name'], json.dumps({'file': r['name'], "url": url, "full_name": r['repository']['full_name']}), 'github_install', '', description="")
    setView('files', 'viewType')
def github_install(url):
    import re
    import json
    from resources.libs import github_installer
    from resources.libs.github_installer import kodi as _kodi
    from resources.libs.github_installer import github_api
    args = json.loads(url)
    if 'file' in args:
        #viewsetter.set_view("list")
        c = _kodi.dialog_confirm("Confirm Install", args['file'])
        if not c: return
        addon_id = re.sub("-[\d\.]+zip$", "", args['file'])
        github_installer.GitHub_Installer(addon_id, args['url'], args['full_name'], _kodi.vfs.join("special://home", "addons"))
        if not DIALOG.yesno(ADDONTITLE, 'Click Continue to install more addons or','Restart button to finalize addon installation', "Brought To You By %s " % ADDONTITLE, nolabel='Restart', yeslabel='Continue'):
            xbmc.executebuiltin('ShutDown')
        #viewsetter.set_view("list")
    else: pass
def github_instructions():
    from resources.libs.github_installer import kodi as _kodi
    try:
        KODI_LANGUAGE = xbmc.getLanguage()
    except:
        KODI_LANGUAGE = 'English'
    #path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    path = _kodi.vfs.join(_kodi.get_path(), 'resources/language/%s/github_help.txt', KODI_LANGUAGE)
    if not _kodi.vfs.exists(path):
        path = _kodi.vfs.join(_kodi.get_path(), 'resources/libs/github_installer/github_help.txt')
    text = _kodi.vfs.read_file(path)
    _kodi.dialog_textbox('GitHub Browser Instructions', text)
def github_update():
    from resources.lib import github_installer
    from resources.libs.github_installer import kodi as _kodi
    c = _kodi.dialog_confirm("Confirm Update", "Search for updates?")
    if c : github_installer.update_addons()

###########################
###### Backup Restore  ####
###########################
def backupMenu(name=None, url=None):
    try:
        mybuilds = xbmc.translatePath(MYBUILDS)
        if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
    except:pass
    #if view == "backup" or SHOWMAINT == 'true':
    #addFile('Back Up Zip Location:   [COLOR %s]%s[/COLOR]' % (COLORDESC, MYBUILDS),'settings', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEMEDEFAULT)
    #addFile('Back Up Zip Location:   [COLOR %s]%s[/COLOR]' % (COLORDESC, MYBUILDS),'settings', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEMEDEFAULT)
    #addFile('Back Up Zip Location:   [COLOR %s]%s[/COLOR]' % (COLORDESC, MYBUILDS),'choosebackupfolder', 'Maintenance',  description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEMEDEFAULT)
    #addDir('SAVE DABRID AND TRAKT DATA',  'savedata',        icon=ICONTRAKT,    themeit=THEMEMENUB)
    addFile('Back Up Zip Location:   [COLOR %s]%s[/COLOR]' % (COLORDESC, MYBUILDS),'choosebackupfolder', url=MYBUILDS, description='Directory to save or restore zip backups from', icon=ICONBACKUP, themeit=THEMEDEFAULT)
    addDir('SAVE REAL DABRID AND TRAKT DATA',     'savedata',    description='Save credentials for Trakt or Real Debrid incase of a fresh start',    icon=ICONTRAKT,    themeit=THEMEMENUB)
    #addDir('Create Backup Zip of your Addons and Settings',    'indexbackuponly', description='Select wich files to backup of your Addons and Settings and create your own custom build or backup zip'  ,icon=ICONSETTINGS, themeit=THEMEMENUB)
    #
    ENABLEBACKUPS =  wiz.getS('ENABLEBACKUPS')
    testENABLEBACKUPS  = 'true' if ENABLEBACKUPS == 'true' else 'false'
    addFile('%s    BACKUPS' % testENABLEBACKUPS.replace('true',onitem).replace('false',offitem),'togglesetting', name='ENABLEBACKUPS', description='Turn on Backups',  fanart=FANART, icon=ICONBACKUP, themeit=THEMETOGGLE)
    if ENABLEBACKUPS == 'true':
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Build' % COLORONLINE,               'backupbuild',  description='Back Up Builds',      icon=ICONBACKUP,   themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] GuiFix' % COLORONLINE,              'backupgui',    description='Back Up Gui Fix',     icon=ICONBACKUP,   themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Theme' % COLORONLINE,               'backuptheme',  description='Back Up Theme',       icon=ICONBACKUP,   themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Addon_data' % COLORONLINE,          'backupaddon',  description='Back Up Addon_data',  icon=ICONBACKUP,   themeit=THEMESUBMENUITEM)
    #
    #addDir('[B]Restore[/B]',                                                          'maint', 'backup', icon=ICONBACKUP,  themeit=THEMEMENUB)
    ENABLERESTORE =  wiz.getS('ENABLERESTORE')
    testENABLERESTORE  = 'true' if ENABLERESTORE == 'true' else 'false'
    addFile('%s    RESTORE' % testENABLERESTORE.replace('true',onitem).replace('false',offitem),'togglesetting', name='ENABLERESTORE', description='Turn on Restore',  fanart=FANART, icon=ICONBACKUP, themeit=THEMETOGGLE)
    if ENABLERESTORE == 'true':
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Build' % COLOROFFLINE,         'restorezip',      description='Restore Local Build zip',       icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local GuiFix' % COLOROFFLINE,        'restoregui',      description='Restore Local Gui Fix',         icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Addon_data' % COLOROFFLINE,    'restoreaddon',    description='Restore Local Addon_data',      icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External Build' % COLOROFFLINE,      'restoreextzip',   description='Restore External Build',        icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External GuiFix' % COLOROFFLINE,     'restoreextgui',   description='Restore External Gui Fix',      icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External Addon_data' % COLOROFFLINE, 'restoreextaddon', description='Restore External Addon_data',   icon=ICONBACKUP,  themeit=THEMESUBMENUITEM)
    #addFile('Settings Whitelist (What to backup or erase)',                            'firstrunsettingsgui', description='Select wich files to backup or wipe when the time comes.'  ,icon=ICONSETTINGS, themeit=THEMEDEFAULT)
    addFile('Clean Back Up Folder  [COLOR yellow](Delete all Zips)[/COLOR]',    'clearbackup',     description='Erase all the zips in the save folder.', icon=ICONDELETE,  themeit=THEMEWARNING)
    setView('files', 'viewType')
def saveMenu():
    trakt      = 'true' if KEEPTRAKT     == 'true' else 'false'
    alluc      = 'true' if KEEPALLUC     == 'true' else 'false'
    real       = 'true' if KEEPREAL      == 'true' else 'false'
    login      = 'true' if KEEPLOGIN     == 'true' else 'false'
    sources    = 'true' if KEEPSOURCES   == 'true' else 'false'
    advanced   = 'true' if KEEPADVANCED  == 'true' else 'false'
    profiles   = 'true' if KEEPPROFILES  == 'true' else 'false'
    favourites = 'true' if KEEPFAVS      == 'true' else 'false'
    repos      = 'true' if KEEPREPOS     == 'true' else 'false'
    super      = 'true' if KEEPSUPER     == 'true' else 'false'
    whitelist  = 'true' if KEEPWHITELIST == 'true' else 'false'
    # 
    addDir ('Keep LOGIN Info (Default)',     'login',                 description='Keep LOGIN Info (Default)',   icon=ICONLOGIN, themeit=THEMEMENUB)
    addDir ('Keep TRAKT Data',               'trakt',                 description='Keep TRAKT Data',    icon=ICONTRAKT, themeit=THEMEMENUB)
    addDir ('Keep REAL DABRID',              'realdebrid',            description='Keep REAL DABRID',   icon=ICONREAL,  themeit=THEMEMENUB)
    addDir ('Keep ALLUC Login',              'alluc',                 description='Keep ALLUC Login',   icon=ICONLOGIN, themeit=THEMEMENUB)
    addFile('Import Save  Data',             'managedata', 'import',  description='Import Save  Data',  icon=ICONSAVE,  themeit=THEMEDEFAULTB)
    addFile('Export Saved Data',             'managedata', 'export',  description='Export Saved Data',  icon=ICONSAVE,  themeit=THEMEDEFAULTB)
    #
    addFile('%s  Save Trakt?' % trakt.replace('true',on).replace('false',off)                       ,'togglesetting', 'keeptrakt',       description='Save Trakt',   icon=ICONTRAKT, themeit=THEMETOGGLE)
    addFile('%s  Save Real Debrid?' % real.replace('true',on).replace('false',off)                  ,'togglesetting', 'keepdebrid',      description='Save Real Debrid',   icon=ICONREAL,  themeit=THEMETOGGLE)
    addFile('%s  Save Alluc Login?' % alluc.replace('true',on).replace('false',off)                 ,'togglesetting', 'keepalluc',       description='Save Alluc Login',   icon=ICONREAL,  themeit=THEMETOGGLE)
    addFile('%s  Save Login Info?' % login.replace('true',on).replace('false',off)                  ,'togglesetting', 'keeplogin',       description='Save Login Info',   icon=ICONLOGIN, themeit=THEMETOGGLE)
    addFile('%s  Keep Sources.xml?' % sources.replace('true',on).replace('false',off)               ,'togglesetting', 'keepsources',     description='Keep Sources.xml',  icon=ICONSAVE,  themeit=THEMETOGGLE)
    addFile('%s  Keep Profiles.xml?' % profiles.replace('true',on).replace('false',off)             ,'togglesetting', 'keepprofiles',    description='Keep Profiles.xml',  icon=ICONSAVE,  themeit=THEMETOGGLE)
    addFile('%s  Keep Advancedsettings.xml?' % advanced.replace('true',on).replace('false',off)     ,'togglesetting', 'keepadvanced',    description='Keep Advancedsettings.xml',  icon=ICONSAVE,  themeit=THEMETOGGLE)
    addFile('%s  Keep Favourites.xml?' % favourites.replace('true',on).replace('false',off)         ,'togglesetting', 'keepfavourites',  description='Keep Favourites.xml',  icon=ICONSAVE,  themeit=THEMETOGGLE)
    addFile('%s  Keep Super Favourites?' % super.replace('true',on).replace('false',off)            ,'togglesetting', 'keepsuper',       description='Keep Super Favourites',   icon=ICONSAVE,  themeit=THEMETOGGLE)
    addFile('%s  Keep Installed Repo?' % repos.replace('true',on).replace('false',off)              ,'togglesetting', 'keeprepos',       description='Keep Installed Repo',  icon=ICONSAVE,  themeit=THEMETOGGLE)
    # whitelist
    addFile('%s  Keep My WhiteList?' % whitelist.replace('true',onitem).replace('false',offitem)    ,'togglesetting', 'keepwhitelist',   icon=ICONSAVE,  themeit=THEMETOGGLE)
    if whitelist == 'true':
        addFile('Edit My Whitelist',        'whitelist', 'edit',    description='Edit My Whitelist',      icon=ICONSAVE,  themeit=THEMEDEFAULT)
        addFile('View My Whitelist',        'whitelist', 'view',    description='View My Whitelist',      icon=ICONSAVE,  themeit=THEMEDEFAULT)
        addFile('Clear My Whitelist',       'whitelist', 'clear',   description='Clear My Whitelist',     icon=ICONSAVE,  themeit=THEMEDEFAULT)
        addFile('Import My Whitelist',      'whitelist', 'import',   description='Import My Whitelist',   icon=ICONSAVE,  themeit=THEMEDEFAULT)
        addFile('Export My Whitelist',      'whitelist', 'export',   description='Export My Whitelist',   icon=ICONSAVE,  themeit=THEMEDEFAULT)
    # add blacklist
    setView('files', 'viewType')
def loginMenu():
    login = '[COLOR green]ON[/COLOR]' if KEEPLOGIN == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(LOGINSAVE) if not LOGINSAVE == '' else 'Login data hasnt been saved yet.'
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
    #addFile('[I]Several of these addons are PAID services.[/I]', '', icon=ICONLOGIN, themeit=THEMESUBMENUITEMB)
    addFile('Save Login Data: %s' % login,  'togglesetting', 'keeplogin', icon=ICONLOGIN, themeit=THEMETOGGLE)
    if KEEPLOGIN == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONLOGIN, themeit=THEMEDEFAULTB)
    addFile('Save All Login Data',          'savelogin',    'all', icon=ICONLOGIN,  themeit=THEMEDEFAULTB)
    addFile('Recover All Saved Login Data', 'restorelogin', 'all', icon=ICONLOGIN,  themeit=THEMEDEFAULTB)
    addFile('Import Login Data',            'importlogin',  'all', icon=ICONLOGIN,  themeit=THEMEDEFAULTB)
    addFile('Clear All Saved Login Data',   'clearlogin',   'all', icon=ICONLOGIN,  themeit=THEMEDEFAULTB)
    addFile('Clear All Addon Data',         'addonlogin',   'all', icon=ICONLOGIN,  themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONLOGIN, themeit=THEMESPACER)
    for login in loginit.ORDER:
        name   = LOGINID[login]['name']
        path   = LOGINID[login]['path']
        saved  = LOGINID[login]['saved']
        file   = LOGINID[login]['file']
        user   = wiz.getS(saved)
        auser  = loginit.loginUser(login)
        icon   = LOGINID[login]['icon']   if os.path.exists(path) else ICONLOGIN
        fanart = LOGINID[login]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Login', login)
        menu.append((THEMESUBMENUITEMB % '%s Settings' % name,  'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)' %   (ADDON_ID, login)))
        addFile('[+]-> %s' % name,  '', icon=icon, fanart=fanart, themeit=THEMEDEFAULT)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '',  menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin', login, menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authlogin', login, menu=menu, fanart=fanart, icon=icon,  themeit=THEMESUBMENUITEMB)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin', login, menu=createMenu('save', 'Login', login), fanart=fanart, icon=icon,  themeit=THEMESUBMENUITEMB)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin', login, menu=createMenu('save', 'Login', login), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', menu=createMenu('save', 'Login', login), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
    setView('files', 'viewType')
def traktMenu():
    trakt = '[COLOR green]ON[/COLOR]' if KEEPTRAKT == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(TRAKTSAVE) if not TRAKTSAVE == '' else 'Trakt hasnt been saved yet.'
    addFile('Save Trakt Data: %s' % trakt, 'togglesetting', 'keeptrakt', icon=ICONTRAKT, themeit=THEMEDEFAULTB)
    if KEEPTRAKT == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONTRAKT, themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONTRAKT, themeit=THEMESPACER)
    addFile('Save All Trakt Data',          'savetrakt',    'all', icon=ICONTRAKT,  themeit=THEMEDEFAULTB)
    addFile('Recover All Saved Trakt Data', 'restoretrakt', 'all', icon=ICONTRAKT,  themeit=THEMEDEFAULTB)
    addFile('Import Trakt Data',            'importtrakt',  'all', icon=ICONTRAKT,  themeit=THEMEDEFAULTB)
    addFile('Clear All Saved Trakt Data',   'cleartrakt',   'all', icon=ICONTRAKT,  themeit=THEMEDEFAULTB)
    addFile('Clear All Addon Data',         'addontrakt',   'all', icon=ICONTRAKT,  themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESPACER)
    for trakt in traktit.ORDER:
        name   = TRAKTID[trakt]['name']
        path   = TRAKTID[trakt]['path']
        saved  = TRAKTID[trakt]['saved']
        file   = TRAKTID[trakt]['file']
        user   = wiz.getS(saved)
        auser  = traktit.traktUser(trakt)
        icon   = TRAKTID[trakt]['icon']   if os.path.exists(path) else ICONTRAKT
        fanart = TRAKTID[trakt]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Trakt', trakt)
        menu.append((THEMEDEFAULT % '%s Settings' % name,  'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)' %   (ADDON_ID, trakt)))
        addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEMESUBMENUITEMB)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu, fanart=fanart, icon=icon,  themeit=THEMESUBMENUITEMB)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt', trakt, menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authtrakt', trakt, menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt', trakt,  menu=createMenu('save', 'Trakt', trakt),  fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt', trakt,  menu=createMenu('save', 'Trakt', trakt), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', menu=createMenu('save', 'Trakt', trakt), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
    addFile('[I]Register FREE Account at http://trakt.tv[/I]', '', icon=ICONTRAKT, themeit=THEMEDEFAULTI)
    setView('files', 'viewType')
def realMenu():
    real = '[COLOR green]ON[/COLOR]' if KEEPREAL == 'true' else '[COLOR red]OFF[/COLOR]'
    last = str(REALSAVE) if not REALSAVE == '' else 'Real Debrid hasnt been saved yet.'
    addFile('Save Real Debrid Data: %s' % real, 'togglesetting', 'keepdebrid', icon=ICONREAL, themeit=THEMEDEFAULTB)
    if KEEPREAL == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONREAL, themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONREAL, themeit=THEMESPACER)
    addFile('Save All Real Debrid Data',          'savedebrid',    'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Recover All Saved Real Debrid Data', 'restoredebrid', 'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Import Real Debrid Data',            'importdebrid',  'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Clear All Saved Real Debrid Data',   'cleardebrid',   'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Clear All Addon Data',               'addondebrid',   'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESPACER)
    for debrid in debridit.ORDER:
        name   = DEBRIDID[debrid]['name']
        path   = DEBRIDID[debrid]['path']
        saved  = DEBRIDID[debrid]['saved']
        file   = DEBRIDID[debrid]['file']
        user   = wiz.getS(saved)
        auser  = debridit.debridUser(debrid)
        icon   = DEBRIDID[debrid]['icon']   if os.path.exists(path) else ICONREAL
        fanart = DEBRIDID[debrid]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'Debrid', debrid)
        menu.append((THEMEDEFAULT % '%s Settings' % name,    'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)' %   (ADDON_ID, debrid)))
        addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEMESUBMENUITEMB)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '',  menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid', debrid, menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authdebrid', debrid, menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid', debrid, menu=createMenu('save', 'Debrid', debrid), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid', debrid, menu=createMenu('save', 'Debrid', debrid), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', menu=createMenu('save', 'Debrid', debrid), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
    addFile('[I]http://real-debrid.com is a PAID service.[/I]', '', icon=ICONREAL, themeit=THEMEDEFAULTI)
    setView('files', 'viewType')
def allucMenu():
    alluc = '[COLOR green]ON[/COLOR]' if KEEPALLUC == 'true' else '[COLOR red]OFF[/COLOR]'
    last  = str(ALLUCSAVE) if not ALLUCSAVE == '' else 'Alluc Login hasnt been saved yet.'
    addFile('Save Alluc Login Data: %s' % alluc, 'togglesetting', 'keepalluc', icon=ICONLOGIN, themeit=THEMEDEFAULTB)
    if KEEPALLUC == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONLOGIN, themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONLOGIN, themeit=THEMESPACER)
    addFile('Save All Alluc Login Data',          'savealluc',    'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Recover All Saved Alluc Login Data', 'restorealluc', 'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Import Alluc Login Data',            'importalluc',  'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Clear All Saved Alluc Login Data',   'clearalluc',   'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    addFile('Clear All Addon Data',               'addonalluc',   'all', icon=ICONREAL,  themeit=THEMEDEFAULTB)
    if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESPACER)
    for alluc in allucit.ORDER:
        name   = ALLUCID[alluc]['name']
        path   = ALLUCID[alluc]['path']
        saved  = ALLUCID[alluc]['saved']
        file   = ALLUCID[alluc]['file']
        user   = wiz.getS(saved)
        auser  = allucit.allucUser(alluc)
        icon   = ALLUCID[alluc]['icon']   if os.path.exists(path) else ICONLOGIN
        fanart = ALLUCID[alluc]['fanart'] if os.path.exists(path) else FANART
        menu = createMenu('saveaddon', 'ALLUC', alluc)
        menu.append((THEMEDEFAULT % '%s Settings' % name,  'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=alluc)' %   (ADDON_ID, alluc)))
        addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEMESUBMENUITEMB)
        if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', menu=menu, fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authalluc', alluc, menu=menu, fanart=fanart, icon=icon,  themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authalluc', alluc, menu=menu, fanart=fanart, icon=icon,  themeit=THEMESUBMENUITEMB)
        if user == "":
            if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importalluc', alluc, menu=createMenu('save', 'Alluc', alluc), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
            else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savealluc', alluc, menu=createMenu('save', 'Alluc', alluc), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
        else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', menu=createMenu('save', 'Alluc', alluc), fanart=fanart, icon=icon, themeit=THEMESUBMENUITEMB)
    addFile('[I]http://accounts.alluc.com/ is a Free service.[/I]', '', icon=ICONLOGIN, themeit=THEMEDEFAULTI)
    setView('files', 'viewType')

###########################
###### Offline installs  ##
###########################
def choosebackupfolder(url=None):
    """ shows a browse dialog and returns a value
        - 0 : ShowAndGetDirectory
        - 1 : ShowAndGetFile
        - 2 : ShowAndGetImage
        - 3 : ShowAndGetWriteableDirectory
    """
    fileroot = MYBUILDS+'/'
    browse_dialog = xbmcgui.Dialog()
    url = browse_dialog.browse(type=0, heading='Select Backup Directory Root', shares='files', mask='/', useThumbs=False, treatAsFolder=True, defaultt=fileroot, enableMultiple=False)
    #if not os.path.exists(url): return
    url2 = url+My_Builds+'/'
    wiz.setS('path', url2)
    wiz.refresh()
def chooseofflineapk(apk=None):
    fileroot = MYAPKS+'/'
    browse_dialog = xbmcgui.Dialog()
    apk = browse_dialog.browse(type=1, heading='Select apk File', shares='files', mask='.apk', useThumbs=False, treatAsFolder=False, defaultt=fileroot, enableMultiple=False)
    if not os.path.exists(apk): return
    #xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+apk+'")')
    notify.apkInstaller(apk)
def chooseofflineaddon(url=None):
    fileroot = MYADDONS+'/'
    browse_dialog = xbmcgui.Dialog()
    url = browse_dialog.browse(type=1, heading='Select zip File', shares='files', mask='.zip', useThumbs=False, treatAsFolder=False, defaultt=fileroot, enableMultiple=False)
    if not os.path.exists(url): return
    if os.path.exists(url):
        name  =  os.path.basename(url)
        installAddon(name, url)
def importtxt(url):  # save txt
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR]\n[COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, url), '', '[COLOR %s]Please Wait[/COLOR]' % COLORHEADERTXT)
    urlsplits = url.split('/')
    lib = xbmc.makeLegalFilename(os.path.join(PACKAGES, urlsplits[-1]))
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    if os.path.isfile(lib):
        fileroot = DATAPATHUSERDATA+'/'
        browse_dialog = xbmcgui.Dialog()
        savetoplace = browse_dialog.browse(type=0, heading='Select Save Location', shares='files', mask='/', useThumbs=False, treatAsFolder=True, defaultt=fileroot, enableMultiple=False)
        #keyboard = xbmc.Keyboard(urlsplits[-1], 'txt  Name')
        keyboard = xbmc.Keyboard('', 'txt  Name')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            name = keyboard.getText()
            saveto = xbmc.translatePath(os.path.join(savetoplace, name+'.txt'))
            xbmcvfs.copy(lib, saveto)
    wiz.refresh()

###########################
###### log             ####
###########################
def logMenu():
    errors = int(errorChecking(count=True))
    errorsfound = '  [COLOR goldenrod]'+str(errors)+'[/COLOR]  Error(s) Found' if errors > 0 else 'None Found'
    wizlogsize = '  [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else "  [COLOR %s]%s[/COLOR]" % (COLORSIZES, wiz.convertSize(os.path.getsize(WIZLOG)))
    addFile('View Log File',                          'viewlog',    description='View Log File',     icon=ICONLOG, themeit=THEMEDEFAULTB)
    addFile('View Errors in Log:   %s' % (errorsfound), 'viewerrorlog',  description='View Errors in Log',   icon=ICONLOG, themeit=THEMEDEFAULT)
    if errors > 0: addFile('View Last Error In Log',  'viewerrorlast', description='View Last Error In Log', icon=ICONLOG, themeit=THEMEDEFAULT)
    addFile('View Wizard Log File',                   'viewwizlog',    description='View Wizard Log File',   icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Clear Wizard Log File   [COLOR %s]%s[/COLOR]' % (COLORSIZES, wizlogsize),   'clearwizlog',  description='Clear Wizard Log File',    icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Upload Kodi.log to random Pastebin',     'uploadlog',  description='Upload Kodi.log to random Pastebin',      icon=ICONLOG, themeit=THEMEDEFAULT)
    #
    addFile('Email Log to yourself',                  'emaillog',        description='Email Log to yourself',  icon=ICONLOG, themeit=THEMEDEFAULT)
    addFile('Force Update Text Files', 'forcetext',  description='Force Update Text Files',  icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Toggle Debug',                           'debug',           description='Toggle debug mode',  icon=ICONSETTINGS, themeit=THEMETOGGLE)
    addFile('Help',  'helpMenu',  '',   description='Help file from settings',  icon=ICONINFO,themeit=THEMEMENUB)
    setView('files', 'viewType')
def Show_Dialog(line1,line2,line3):
    dialog = xbmcgui.Dialog()
    dialog.ok('Kodi Log Emailer', line1,line2,line3)
def send_email(LOG):
    xbmc.log(msg='##['+ADDON_ID+'] Email '+LOG, level=xbmc.LOGNOTICE)
    THESMTP ,THEPORT = Servers()
    fromaddr=wiz.getS('email')
    toaddr=fromaddr
    if toaddr =='[COLOR red]Cancel[/COLOR]':
        Show_Dialog('No Email Sent','','Email Cancelled')
    else:
        import datetime
        TODAY=datetime.datetime.today().strftime('[%d-%m-%Y %H:%M]')
        from email.MIMEMultipart import MIMEMultipart
        from email.MIMEText import MIMEText
        fromaddr = '"Hi Message From Yourself" <%s>'% (fromaddr)
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = toaddr
        msg['Subject'] = "Your Kodi Log "+str(TODAY)
        THEHTML = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'extras', 'theemail.html'))
        body = open(THEHTML).read()
        content = MIMEText(body, 'html')
        msg.attach(content)
        try:filename = LOG.rsplit('\\', 1)[1]
        except:filename = LOG.rsplit('/', 1)[1]
        f = file(LOG)
        attachment = MIMEText(f.read())
        attachment.add_header('Content-Disposition', 'attachment', filename=filename.replace('log','txt'))
        msg.attach(attachment)
        import smtplib
        server = smtplib.SMTP(str(THESMTP), int(THEPORT))
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(wiz.getS('email').encode('UTF-8'),wiz.getS('emailpassword').encode('UTF-8'))
        text = msg.as_string()
        server.sendmail(fromaddr, toaddr, text)
        Show_Dialog('Email Sent To','[COLOR green]'+toaddr+'[/COLOR]','Also Check Junk Folder')
def Servers():
    SERVER = wiz.getS('server')
    APPENDED=[]
    server_list   =[('Gmail','smtp.gmail.com','587'),
                    ('Outlook/Hotmail','smtp-mail.outlook.com','587'),
                    ('Office365','smtp.office365.com','587'),
                    ('Yahoo Mail','smtp.mail.yahoo.com','465'),
                    ('Yahoo Mail Plus','smtp.mail.yahoo.co.uk','465'),
                    ('AOL','smtp.att.yahoo.com','465'),
                    ('Verizon','smtp.zoho.com','465'),
                    ('Mail','smtp.mail.com','587'),
                    ('GMX','smtp.gmx.com','465')]
    for server , smtp ,port in server_list:
        if SERVER ==server:
            APPENDED.append([smtp ,port])
    return  APPENDED[0][0],APPENDED[0][1]
def email_log():
    # check email setting
    emailSERVER = wiz.getS('email')
    if not emailSERVER :
        DIALOG.ok('Enter Email and Password in settings', 'Invalid email for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDON_ID).openSettings()
        sys.exit(0)
    emailpass = wiz.getS('emailpassword')
    if not emailpass :
        DIALOG.ok('Enter password in settings', 'Invalid email PASSWORD for your log. Please enter one in settings under Extra paths')
        xbmcaddon.Addon(id=ADDON_ID).openSettings()
        sys.exit(0)
    #
    nameSelect=[]
    logSelect=[]
    import glob
    folder = xbmc.translatePath('special://logpath')
    xbmc.log(msg=folder, level=xbmc.LOGNOTICE)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
    LOG = logSelect[xbmcgui.Dialog().select('Please Select Log', nameSelect)]
    send_email(LOG)
def Grab_xml(advanced=False, playercore=False, sources=False, rssfeeds=False):  # xml in log viewer
    if advanced == True:
        if not os.path.exists(ADVANCED): return False
        else:
            if file == True:
                return ADVANCED
            else:
                filename    = open(ADVANCED, 'r')
                logtext     = filename.read()
                filename.close()
                return logtext
                
    if playercore == True:
        if not os.path.exists(PLAYERCORE): return False
        else:
            if file == True:
                return PLAYERCORE
            else:
                filename    = open(PLAYERCORE, 'r')
                logtext     = filename.read()
                filename.close()
                return logtext
                
    if sources == True:
        if not os.path.exists(SOURCES): return False
        else:
            if file == True:
                return SOURCES
            else:
                filename    = open(SOURCES, 'r')
                logtext     = filename.read()
                filename.close()
                return logtext
                
    if rssfeeds == True:
        if not os.path.exists(RSSFEED): return False
        else:
            if file == True:
                return RSSFEED
            else:
                filename    = open(RSSFEED, 'r')
                logtext     = filename.read()
                filename.close()
                return logtext
                
    finalfile   = 0
    #logfilepath = os.listdir(LOG)
    logsfound   = []
    if len(logsfound) > 0:
        logsfound.sort(key=lambda f: os.path.getmtime(f))
        if file == True: return logsfound[-1]
        else:
            filename    = open(logsfound[-1], 'r')
            logtext     = filename.read()
            filename.close()
            return logtext
    else: 
        return False
def LogViewer(default=None):
    class LogViewer(xbmcgui.WindowXMLDialog):
        def __init__(self,*args,**kwargs):
            self.default = kwargs['default']
        def onInit(self):
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.upload     = 201
            self.kodi       = 202
            self.kodiold    = 203
            self.wizard     = 204
            self.okbutton   = 205
            #
            self.advanced   = 206
            self.playercore = 207
            self.sources    = 208
            self.rssfeeds   = 209
            f = open(self.default, 'r')
            self.logmsg = f.read()
            f.close()
            self.titlemsg = "%s: %s" % (ADDONTITLE, self.default.replace(LOG, '').replace(ADDONDATA, ''))
            self.showdialog()
        def showdialog(self):
            self.getControl(self.title).setLabel(self.titlemsg)
            self.getControl(self.msg).setText(wiz.highlightText(self.logmsg))
            self.setFocusId(self.scrollbar)
        def onClick(self, controlId):
            if   controlId == self.okbutton: self.close()
            elif controlId == self.upload: self.close(); uploadLog.Main()
            elif controlId == self.kodi:
                newmsg = wiz.Grab_Log(False)
                filename = wiz.Grab_Log(True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.kodiold:  
                newmsg = wiz.Grab_Log(False, True)
                filename = wiz.Grab_Log(True, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.wizard:
                newmsg = wiz.Grab_Log(False, False, True)
                filename = wiz.Grab_Log(True, False, True)
                if newmsg == False:
                    self.titlemsg = "%s: View Log Error" % ADDONTITLE
                    self.getControl(self.msg).setText("Log File Does Not Exists!")
                else:
                    self.titlemsg = "[COLOR orange]%s: wizard.log[/COLOR]  (This addons Log)\n\n   %s" % (ADDONTITLE, filename.replace(ADDONDATA, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(wiz.highlightText(newmsg))
                    self.setFocusId(self.scrollbar)
            elif controlId == self.advanced:
                newmsg = Grab_xml(True, False, False, False)
                filename = Grab_xml(True, False, False, False)
                if os.path.exists(ADVANCED):
                    #self.titlemsg = "%s: %s" % (ADDONTITLE,  filename.replace(ADVANCED, ''))
                    self.titlemsg = "[COLOR orange]%s: advanced.xml[/COLOR]  (extra gui tweaks to override guisettings.xml)\n\n   %s" % (ADDONTITLE,  filename.replace(ADVANCED, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View advancedsettings Error" % ADDONTITLE
                    self.getControl(self.msg).setText("advancedsettings File Does Not Exists!")
            elif controlId == self.playercore:
                newmsg = Grab_xml(False, True, False, False)
                filename = Grab_xml(False, True, False, False)
                if os.path.exists(PLAYERCORE):
                    self.titlemsg = "[COLOR orange]%s: advanced.xml[/COLOR]  (3rd Party Players)\n\n   %s" % (ADDONTITLE,  filename.replace(PLAYERCORE, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View playerfactorycore.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("playerfactorycore.xml File Does Not Exists!")
            elif controlId == self.sources:
                newmsg = Grab_xml(False, False, True, False)
                filename = Grab_xml(False, False, True, False)
                if os.path.exists(SOURCES):
                    self.titlemsg = "[COLOR orange]%s: sources.xml[/COLOR]  (Media and repo paths)\n\n   %s" % (ADDONTITLE,  filename.replace(SOURCES, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View sources.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("sources.xml File Does Not Exists!")
            elif controlId == self.rssfeeds:
                newmsg = Grab_xml(False, False, False, True)
                filename = Grab_xml(False, False, False, True)
                if os.path.exists(RSSFEED):
                    self.titlemsg = "[COLOR orange]%s: RssFeeds.xml[/COLOR]  (Kodi Rss Feeds)\n\n   %s" % (ADDONTITLE,  filename.replace(RSSFEED, ''))
                    self.getControl(self.title).setLabel(self.titlemsg)
                    self.getControl(self.msg).setText(self.titlemsg)
                    self.setFocusId(self.scrollbar)
                else:
                    self.titlemsg = "%s: View rssfeeds.xml Error" % ADDONTITLE
                    self.getControl(self.msg).setText("rssfeeds.xml File Does Not Exists!")
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    if default == None: default = wiz.Grab_Log(True)
    lv = LogViewer( "LogViewer.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', default=default)
    lv.doModal()
    del lv

###########################
###### xml             ####
###########################
def xmlMenu():
    #if not ADVANCEDFILE == 'http://': addDir('%s    Advancedsettings.xml' % ONLINEFLAG,  'advancedsetting',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEMEMENUB)
    if not ADVANCEDFILE == 'http://' and not ADVANCEDFILE == '': addDir ('ADVANCEDSETTINGS.XML  Online txt',   'advancedsetting',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML, themeit=THEMEMENUB)
    if     os.path.isfile(ADVANCED):  addFile('[COLOR red][DELETE][/COLOR]     Advancedsettings.xml   [COLOR green][ENABLED][/COLOR]',  'delautoadvanced',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if not os.path.isfile(ADVANCED):  addFile('[COLOR green][INSTALL][/COLOR]    Advancedsettings.xml',                                 'autoadvanced',  description='Use a gui to create a custom advancedsettings.xml that allows you to tweak expert settings that generally improve streaming performance.',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if os.path.isfile(PLAYERCORE):    addFile('[COLOR red][DELETE][/COLOR]     playercorefactory.xml   [COLOR green][ENABLED][/COLOR]', 'delplayercorefactory', description='Install a playercorefactory.xml file to allow playing media from a 3rd party player like chromecast', icon=ICONXML,   themeit=THEMEDEFAULT)
    if not os.path.isfile(PLAYERCORE):addFile('[COLOR green][INSTALL][/COLOR]    playercorefactory.xml',                                'doWriteplayerfactorycore', description='Install a playercorefactory.xml file to allow playing media from a 3rd party player like chromecast', icon=ICONXML,   themeit=THEMEDEFAULT)
    if os.path.isfile(SOURCES):       addFile('[COLOR red][DELETE][/COLOR]     sources.xml   [COLOR green][ENABLED][/COLOR]',           'delsources', description='Install a sources.xml file to add repo sources',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if not os.path.isfile(SOURCES):   addFile('[COLOR green][INSTALL][/COLOR]    sources.xml',                                          'doWritesources', description='Install a sources.xml file to add repo sources',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if os.path.isfile(RSSFEED):       addFile('[COLOR red][DELETE][/COLOR]     RssFeeds.xml   [COLOR green][ENABLED][/COLOR]',          'delRssFeeds',     description='Install a better RSS feed xml to be more informed',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if not os.path.isfile(RSSFEED):   addFile('[COLOR green][INSTALL][/COLOR]    RssFeeds.xml',                                         'doWriterss',      description='Install a better RSS feed xml to be more informed',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if os.path.isfile(KEYBOARD_FILE):       addFile('[COLOR red][DELETE][/COLOR]     Keymap.xml   [COLOR green][ENABLED][/COLOR]',          'uninstall_keymap',    description='Install a better Keymap.xml to add extra key functions',  icon=ICONXML,   themeit=THEMEDEFAULT)
    if not os.path.isfile(KEYBOARD_FILE):   addFile('[COLOR green][INSTALL][/COLOR]    Keymap.xml',                                         'install_keymap',      description='Install a better Keymap.xml to add extra key functions',  icon=ICONXML,   themeit=THEMEDEFAULT)
    addFile('View one of the above', 'viewlog',        description='View the contents of the Logfile or xmls',  icon=ICONLOG, themeit=THEMEDEFAULT)
    setView('files', 'viewType')
def doWriterss():
    # RssFeeds.xml urls
    RSS1 = wiz.getS('RSS1')
    RSS2 = wiz.getS('RSS2')
    RSS3 = wiz.getS('RSS3')
    RSS4 = wiz.getS('RSS4')
    RSS5 = wiz.getS('RSS5')
    RSS6 = wiz.getS('RSS6')
    RSS7 = wiz.getS('RSS7')
    RSS8 = wiz.getS('RSS8')
    with open(RSSFEED, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<!--RSS feeds. To have multiple feeds, just add a feed to the set. You can also have multiple sets -->\n')
        f.write('<!--To use different sets in your skin, each must be called from skin with a unique id -->\n')
        f.write('<rssfeeds>\n')
        f.write('    <set id="1">\n')
        if not RSS1 == 'http://': f.write('        <feed updateinterval="30">'+RSS1+'</feed>\n')
        if not RSS2 == 'http://': f.write('        <feed updateinterval="30">'+RSS2+'</feed>\n')
        if not RSS3 == 'http://': f.write('        <feed updateinterval="30">'+RSS3+'</feed>\n')
        if not RSS4 == 'http://': f.write('        <feed updateinterval="30">'+RSS4+'</feed>\n')
        if not RSS5 == 'http://': f.write('        <feed updateinterval="30">'+RSS5+'</feed>\n')
        if not RSS6 == 'http://': f.write('        <feed updateinterval="30">'+RSS6+'</feed>\n')
        if not RSS7 == 'http://': f.write('        <feed updateinterval="30">'+RSS7+'</feed>\n')
        if not RSS8 == 'http://': f.write('        <feed updateinterval="30">'+RSS8+'</feed>\n')
        f.write('        <feed updateinterval="30">http://feeds.kodi.tv/xbmc</feed>\n')
        f.write('    </set>\n')
        f.write('</rssfeeds>\n')
    f.close()
def doWritesources():
    if os.path.isfile(SOURCES):
        choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]sources.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLORHEADERTXT, COLORHEADER), yeslabel="[B][COLOR green]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
        if not choice == 0:
            xbmcvfs.copy(SOURCES, SOURCES+'.last')
            delete_file(SOURCES)
    customsources = False
    iscustomsources = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to use custom media paths?[/COLOR]" % COLORHEADERTXT, '(Probably No)', yeslabel="[B][COLOR green]Yes[/COLOR][/B]", nolabel="[B][COLOR red]No[/COLOR][/B]")
    if iscustomsources == True: customsources = True
            
    with open(SOURCES, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<sources>\n')
        f.write('    <programs>\n')
        f.write('        <default pathversion="1"></default>\n')
        if xbmc.getCondVisibility('system.platform.android'):
            f.write('        <source>\n')
            f.write('            <name>!/storage/emulated/0/</name>\n')
            f.write('            <path pathversion="1">/storage/emulated/0/</path>\n')
            f.write('            <allowsharing>true</allowsharing>\n')
            f.write('        </source>\n')
        if xbmc.getCondVisibility('system.platform.windows'):
            f.write('        <source>\n')
            f.write('            <name>zC:\</name>\n')
            f.write('            <path pathversion="1">C:\</path>\n')
            f.write('            <allowsharing>true</allowsharing>\n')
            f.write('        </source>\n')
        f.write('    </programs>\n')
        f.write('    \n')
        f.write('    <pictures>\n')
        f.write('        <default pathversion="1"></default>\n')
        '''
        f.write('        <source>\n')
        f.write('            <name>Time Of Day</name>\n')
        f.write('            <path pathversion="1">rss://pla1.net/time.rss/</path>\n')
        #f.write('            <thumbnail pathversion="1">DefaultNetwork.png</thumbnail>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        '''
        f.write('    </pictures>\n')
        f.write('    \n')
        f.write('    <video>\n')
        f.write('        <default pathversion="1"></default>\n')
        #f.write('    \n')
        f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_video.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>PnP Media Servers (Auto-Discover)</name>\n')
        f.write('            <path pathversion="1">upnp://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        '''
        f.write('        <source>\n')
        f.write('            <name>PVR</name>\n')
        f.write('            <path pathversion="1">pvr://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        '''
        f.write('    </video>\n')
        f.write('    \n')
        f.write('    <music>\n')
        f.write('        <default pathversion="1"></default>\n')
        #f.write('    \n')
        f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_music.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>PnP Media Servers (Auto-Discover)</name>\n')
        f.write('            <path pathversion="1">upnp://</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </music>\n')
        f.write('    \n')
        f.write('    <files>\n')
        f.write('        <default pathversion="1"></default>\n')
        f.write('    \n')
        #f.close()
    if customsources == True: AppendText(xbmc.translatePath(os.path.join(EXTRAPATH, 'sources', 'sources_files.txt')), SOURCES)
    with open(SOURCES, 'a') as f:
        f.write('        <source>\n')
        f.write('            <name>!Home</name>\n')
        f.write('            <path pathversion="1">special://home/</path>\n')
        f.write('            <allowsharing>true</allowsharing>\n')
        f.write('        </source>\n')
        f.write('    </files>\n')
        f.write('</sources>\n')
        f.write('\n')
    f.close()
def doWriteplayerfactorycore():
    xbmc.log(msg='##['+ADDON_ID+'] dynamic playercorefactory.xml', level=xbmc.LOGNOTICE)
    if os.path.isfile(PLAYERCORE):
        choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]playerfactorycore.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLORHEADERTXT, COLORHEADER), yeslabel="[B][COLOR green]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
        if choice == 0: return
        if os.path.isfile(PLAYERCORE):
            xbmcvfs.copy(PLAYERCORE, PLAYERCORE+'.last')
            delete_file(PLAYERCORE)
    with open(PLAYERCORE, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<!-- http://kodi.wiki/view/HOW-TO:Use_external_players_on_Android  -->\n')
        f.write('<!-- http://kodi.wiki/view/External_players  -->\n')
        f.write('<playercorefactory>\n')
        f.write('    <players>\n')
        ##################
        if xbmc.getCondVisibility('system.platform.android'):
            PLAYERCFFILE1     = wiz.getS('PLAYERCFFILE1')
            PLAYERCFNAME1     = wiz.getS('PLAYERCFNAME1')
            f.write('         <player name="'+PLAYERCFNAME1+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE1+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE2     = wiz.getS('PLAYERCFFILE2')
            PLAYERCFNAME2     = wiz.getS('PLAYERCFNAME2')
            f.write('         <player name="'+PLAYERCFNAME2+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+playercorefactory2+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE3     = wiz.getS('PLAYERCFFILE3')
            PLAYERCFNAME3     = wiz.getS('PLAYERCFNAME3')
            f.write('         <player name="'+PLAYERCFNAME3+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE3+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE4     = wiz.getS('PLAYERCFFILE4')
            PLAYERCFNAME4     = wiz.getS('PLAYERCFNAME4')
            f.write('         <player name="'+PLAYERCFNAME4+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE4+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE5     = wiz.getS('PLAYERCFFILE5')
            PLAYERCFNAME5     = wiz.getS('PLAYERCFNAME5')
            f.write('         <player name="'+PLAYERCFNAME5+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE5+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE6     = wiz.getS('PLAYERCFFILE6')
            PLAYERCFNAME6     = wiz.getS('PLAYERCFNAME6')
            f.write('         <player name="'+PLAYERCFNAME6+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE6+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE7     = wiz.getS('PLAYERCFFILE7')
            PLAYERCFNAME7     = wiz.getS('PLAYERCFNAME7')
            f.write('         <player name="'+PLAYERCFNAME7+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE7+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
            PLAYERCFFILE8     = wiz.getS('PLAYERCFFILE8')
            PLAYERCFNAME8     = wiz.getS('PLAYERCFNAME8')
            f.write('         <player name="'+PLAYERCFNAME8+'" type="ExternalPlayer" audio="false" video="true">\n')
            f.write('            <filename>'+PLAYERCFFILE8+'</filename>\n')
            f.write('            <hidexbmc>true</hidexbmc>\n')
            f.write('            <playcountminimumtime>120</playcountminimumtime>\n')
            f.write('         </player>\n')
        ##################
        if xbmc.getCondVisibility('system.platform.windows'): 
            # vlc x64 
            if os.path.isfile(xbmc.translatePath('C:/Program Files/VideoLAN/VLC/vlc.exe')):
                f.write('         <player name="VLC" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\VideoLAN\VLC\vlc.exe</filename>\n')
                f.write('            <args>--play-and-exit --video-on-top --fullscreen "{1}"</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # vlc x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files (x86)/VideoLAN/VLC/vlc.exe')):
                f.write('         <player name="VLC" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files (x86)\VideoLAN\VLC\vlc.exe</filename>\n')
                f.write('            <args>--play-and-exit --video-on-top --fullscreen "{1}"</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC x64
            if os.path.isfile(xbmc.translatePath('C:/Program Files/MPC-HC64/mpc-hc64.exe')):
                f.write('         <player name="Media Player Classic x64" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\MPC-HC64\mpc-hc64.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files/MPC-HC/mpc-hc.exe')):
                f.write('         <player name="Media Player Classic" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\MPC-HC\mpc-hc.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC-KLite x64
            if os.path.isfile(xbmc.translatePath('C:/Program Files (x86)/K-Lite Codec Pack/MPC-HC64/mpc-hc64.exe')):
                f.write('         <player name="MPC-KLite x64" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64\mpc-hc64.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # MPC-KLite x86
            if os.path.isfile(xbmc.translatePath('C:/Program Files/K-Lite Codec Pack/MPC-HC/mpc-hc.exe')): 
                f.write('         <player name="MPC-KLite" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\Program Files\K-Lite Codec Pack\MPC-HC\mpc-hc.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>true</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('         </player>\n')
            # ffmpeg
            #'''
            if os.path.isfile(xbmc.translatePath('C:/utils/ffmpeg.exe')): 
                f.write('         <player name="Record ffmpeg" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\\utils\\ffmpeg.exe</filename> \n')
                f.write('            <args>-i "{1}" -y -c copy -t 4:00:00 c:\pvr_ffmpeg.ts</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>true</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('            <playonestackitem>true</playonestackitem>\n')
                f.write('         </player>\n')
                f.write('         <player name="Play with ffmpeg" type="ExternalPlayer" audio="false" video="true">\n')
                f.write('            <filename>C:\\utils\\ffmpeg.exe</filename>\n')
                f.write('            <args>"{1}" /fullscreen /close</args>\n')
                f.write('            <hidexbmc>false</hidexbmc>\n')
                f.write('            <hideconsole>false</hideconsole>\n')
                f.write('            <hidecursor>false</hidecursor>\n')
                f.write('            <warpcursor>none</warpcursor>\n')
                f.write('            <playonestackitem>true</playonestackitem>\n')
                f.write('         </player>\n')
            #'''
        #
        f.write('    </players>\n')
        f.write('    \n')
        '''
        f.write('    <rules action="overwrite">\n')
        f.write('<!--<rule protocols="nfs|smb" player="dvdplayer"></rule>-->\n')
        f.write('<!-- change the default player below -->\n')
        f.write('<!-- uncomment to make play the default player-->\n')
        f.write('<!--<rule video="true" player="play"></rule>-->\n')
        f.write('<!-- uncomment to make record the default player-->\n')
        f.write('<!-- <rule video="true" player="record"></rule>-->\n')
        f.write('<!--uncomment to make external player the default player -->\n')
        f.write('<!--<rule video="true" player="external player"></rule>-->\n')
        f.write('<!--uncomment to make stream the default player-->\n')
        f.write('<!--<rule video="true" player="stream"></rule>-->\n')
        f.write('    </rules>\n')
        '''
        f.write('</playercorefactory>\n')
        f.write('\n')
    f.close()
def delete_file_prompt(filename=None):
    if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like delete the current [COLOR %s]%s[/COLOR] file?" % (COLORMENU, COLORTXT, filename), yeslabel="[B][COLOR green]Yes Delete[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
        tries = 10
        while os.path.exists(filename) and tries > 0:
            try:
                os.remove(filename)
                break
            except:
                tries -= 1
        _notify('Done','Done Deleting  '+filename,ICON)
def install_keymap(name=None, url=None):
    fileroot = EXTRAPATH +'/keymaps/'
    browse_dialog = xbmcgui.Dialog()
    url = browse_dialog.browse(type=1, heading='Select zip File', shares='files', mask='.zip', useThumbs=False, treatAsFolder=False, defaultt=fileroot, enableMultiple=False)
    if not os.path.exists(url): return
    if os.path.isfile(KEYBOARD_FILE):
        try:
            os.remove(KEYBOARD_FILE)
        except:
            pass
    # Check is the packages folder exists, if not create it.
    dp = xbmcgui.DialogProgress()
    dp.create("Keymap Installer", "", "", "[B]Keymap: [/B]")
    dp.update(0, "", "Installing Please wait..", "")
    try:
        extract.all(url,HOME,dp, title="Installing Please wait..")
    except IOError, (errno, strerror):
        kodi.message("Failed to open required files", "Error code is:", strerror)
        return False
    xbmc.executebuiltin("Container.Refresh")
def uninstall_keymap():
    try: os.remove(KEYBOARD_FILE)
    except: pass
    wiz.refresh()

###########################
# advancedsettings xml ####
###########################
def advancedWindow(url=None):
    if not ADVANCEDFILE == 'http://':
        if url == None:
            TEMPADVANCEDFILE = wiz.textCache(uservar.ADVANCEDFILE)
            if TEMPADVANCEDFILE == False: ADVANCEDWORKING  = wiz.workingURL(uservar.ADVANCEDFILE)
        else:
            TEMPADVANCEDFILE = wiz.textCache(url)
            if TEMPADVANCEDFILE == False: ADVANCEDWORKING  = wiz.workingURL(url)
        addFile('Quick Configure AdvancedSettings.xml', 'autoadvanced', icon=ICONMAINT, themeit=THEMEMENUB)
        if os.path.exists(ADVANCED): 
            addFile('View Current AdvancedSettings.xml',   'currentsettings', icon=ICONMAINT, themeit=THEMEDEFAULT)
            addFile('Remove Current AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEMEDEFAULT)
        if not TEMPADVANCEDFILE == False:
            if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
            link = TEMPADVANCEDFILE.replace('\n','').replace('\r','').replace('\t','')
            match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
            if len(match) > 0:
                for name, section, url, icon, fanart, description in match:
                    if section.lower() == "yes":
                        addDir ('%s' % name, 'advancedsetting', url, description=description, icon=icon, fanart=fanart, themeit=THEMEMENUB)
                    else:
                        addFile(name, 'writeadvanced', name, url, description=description, icon=icon, fanart=fanart, themeit=THEMEDEFAULT)
            else: wiz.log("[Advanced Settings] ERROR: Invalid Format.")
        else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING)
    else: wiz.log("[Advanced Settings] not Enabled")
def writeAdvanced(name, url):
    ADVANCEDWORKING = wiz.workingURL(url)
    if ADVANCEDWORKING == True:
        if os.path.exists(ADVANCED): choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, name), yeslabel="[B][COLOR green]Overwrite[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
        else: choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, name), yeslabel="[B][COLOR green]Install[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")

        if choice == 1:
            file = wiz.openURL(url)
            f = open(ADVANCED, 'w'); 
            f.write(file)
            f.close()
            DIALOG.ok(ADDONTITLE, '[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]' % COLORHEADERTXT)
            wiz.killxbmc(True)
        else: wiz.log("[Advanced Settings] install canceled"); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLORHEADER, ADDONTITLE), "[COLOR %s]Write Cancelled![/COLOR]" % COLORHEADERTXT); return
    else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLORHEADER, ADDONTITLE), "[COLOR %s]URL Not Working[/COLOR]" % COLORHEADERTXT)
def viewAdvanced():
    f = open(ADVANCED)
    a = f.read().replace('\t', '    ')
    wiz.TextBox(ADDONTITLE, a)
    f.close()
def removeAdvanced():
    if os.path.exists(ADVANCED):
        wiz.removeFile(ADVANCED)
    else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")
def showAutoAdvanced():
    notify.autoConfig()

###########################
# Maintenance          ####
###########################
def maintMenu(view=None):# all subdirs
    #on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
    autoclean   = 'true' if AUTOCLEANUP    == 'true' else 'false'
    cache       = 'true' if AUTOCACHE      == 'true' else 'false'
    packages    = 'true' if AUTOPACKAGES   == 'true' else 'false'
    thumbs      = 'true' if AUTOTHUMBS     == 'true' else 'false'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    includevid  = 'true' if INCLUDEVIDEO   == 'true' else 'false'
    includeall  = 'true' if INCLUDEALL     == 'true' else 'false'
    # log error totals
    errors = int(errorChecking(count=True))
    errorsfound = str(errors) + ' Error(s) Found' if errors > 0 else 'None Found'
    wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
    # clean video cache
    if includeall == 'true':
        includebob = 'true'
        includeely = 'true'
        includespe = 'true'
        includegen = 'true'
        includeexo = 'true'
        includeone = 'true'
        includesal = 'true'
        includeshd = 'true'
    else:
        includebob = 'true' if INCLUDEBOB     == 'true' else 'false'
        includeely = 'true' if INCLUDEELY     == 'true' else 'false'
        includespe = 'true' if INCLUDESPECTO  == 'true' else 'false'
        includegen = 'true' if INCLUDEGENESIS == 'true' else 'false'
        includeexo = 'true' if INCLUDEEXODUS  == 'true' else 'false'
        includeone = 'true' if INCLUDEONECHAN == 'true' else 'false'
        includesal = 'true' if INCLUDESALTS   == 'true' else 'false'
        includeshd = 'true' if INCLUDESALTSHD == 'true' else 'false'
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    archive    = wiz.getSize(ARCHIVE_CACHE)
    sizecache  = (wiz.getCacheSize())-archive
    totalsize  = sizepack+sizethumb+sizecache
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']

    addFile('%s  SHOW ALL Maintenance' % maint.replace('true',onitem).replace('false',offitem) ,'togglesetting', 'showmaint',  description='Toggle all sections below',   icon=ICONMAINT, themeit=THEMETOGGLE)
    #
    addDir ('SYSTEM TWEAKS / FIXES',   'maint', 'tweaks',  description='SYSTEM TWEAKS',  icon=ICONMAINT, themeit=THEMEMENUB)
    if view == "tweaks" or SHOWMAINT == 'true': 
        if not ADVANCEDFILE == 'http://' and not ADVANCEDFILE == '':
            addDir ('ADVANCED SETTINGS',       'advancedsetting',  icon=ICONXML, themeit=THEMESUBMENUB)
        else: 
            if os.path.exists(ADVANCED):
                addFile('View Current AdvancedSettings.xml',   'currentsettings', icon=ICONXML, themeit=THEMESUBMENUITEMB)
                addFile('Remove Current AdvancedSettings.xml', 'removeadvanced',  icon=ICONDELETE, themeit=THEMESUBMENUITEMB)
            addFile('Quick Configure AdvancedSettings.xml',     'autoadvanced',    description='Create advancedsettings.xnl via a gui', icon=ICONXML, themeit=THEMESUBMENUITEMB)
        addFile('Scan Sources for broken links?',               'checksources',    description='Check sources.xml for broken links',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Scan For Broken Repositories?',                'checkrepos',      description='Check repos for broken links',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Scan for Missing Dependencies',                'checkdeps',       description='Install Kodi addons dependencies that run in the background and are needed to work.',icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Fix Addons Not Updating?',                     'fixaddonupdate',  description='Fix Addons Not Updating',  icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Remove Non-Ascii filenames?',                  'asciicheck',      description='Remove Non-Ascii filenames',  icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Convert Paths to special?',                    'convertpath',     description='Convert Paths to special',  icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clone This Addon and ID',                      'cloneaddon',      description='Create your own addon', icon=ICONBACKUP, themeit=THEMEWARNING)
    #
    addDir ('KODI MAINTENANCE',        'maint', 'misc',  description='KODI MAINTENANCE',   icon=ICONMAINT, themeit=THEMEMENUB)
    if view == "misc" or SHOWMAINT == 'true': 
        addFile('Kodi 17 Fix',                            'kodi17fix',       icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Enable Unknown Sources',                 'unknownsources',  icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Reload Skin',                            'forceskin',       icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Reload Profile',                         'forceprofile',    icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Force Close Kodi',                       'forceclose',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Upload Log File',                        'uploadlog',       icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('View Errors in Log: %s' % (errorsfound), 'viewerrorlog',    icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        if errors > 0: addFile('View Last Error In Log',  'viewerrorlast',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('View Log File',                          'viewlog',         icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('View Wizard Log File',                   'viewwizlog',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Wizard Log File%s' % wizlogsize,   'clearwizlog',     icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addDir ('SPEED TEST',                             'speedtest',       icon=ICONMAINT, themeit=THEMESUBMENUB)
    #
    addDir ('ADDON TOOLS',             'maint', 'addon',  description='ADDON TOOLS',   icon=ICONMAINT, themeit=THEMEMENUB)
    if view == "addon" or SHOWMAINT == 'true': 
        if KODIV >= 17: addFile('Enable All Addons  (Fix disabled plugins)',   'kodi17fix',  description='When you install addons from a zip file or build it doesnt install the normal way - it just extracts it.  In Kodi 17 addons must be Enabled to work to cover their ass for 3rd party addons and unknown sources.  This will scann the addons and enable them.',  icon=ICONSETTINGS, themeit=THEMESUBMENUITEMB)
        if KODIV >= 17: addFile('Enable RTMP for Streaming', 'EnableRTMP', description='Starting in Kodi 17 you must enable these 2 somewhat secret addons built into Kodi in order to stream properly.  This enables them.',  icon=ICONSETTINGS, themeit=THEMESUBMENUITEMB)
        addFile('Remove Addons',                         'removeaddons',     icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addDir ('Remove Addon Data',                     'removeaddondata',  icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addDir ('Enable/Disable Addons',                 'enableaddons',     icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Enable/Disable Adult Addons',           'toggleadult',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Force Update Addons',                   'forceupdate',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Hide Passwords On Keyboard Entry',      'hidepassword',     icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Unhide Passwords On Keyboard Entry',    'unhidepassword',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
    #
    addDir ('SYSTEM INFORMATION',        'systeminfo',     description='SYSTEM INFORMATION',   icon=ICONMAINT, themeit=THEMEMENUB)
    addDir ('CLEANING TOOLS',          'maint', 'clean',  description='CLEANING TOOLS',  icon=ICONMAINT, themeit=THEMEMENUB)
    if view == "clean" or SHOWMAINT == 'true': 
        addFile('Total Clean Up: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize),    'fullclean',       icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Cache: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizecache),       'clearcache',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Packages: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizepack),     'clearpackages',   icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Thumbnails: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizethumb),  'clearthumb',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        if os.path.exists(ARCHIVE_CACHE): addFile('Clear Archive_Cache: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(archive), 'cleararchive',    icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Old Thumbnails?',           'oldThumbs',       icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Clear Crash Logs?',               'clearcrash',      icon=ICONLOG, themeit=THEMESUBMENUITEMB)
        addFile('Purge Databases?',                'purgedb',         icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        #addFile('Fresh Start?',                    'freshstart',      icon=ICONDELETE, themeit=THEMEWARNING)
        # autoclean
        #addFile('Auto Clean', '', fanart=FANART, icon=ICONMAINT, themeit=THEMEMENUB)
        addFile('%s  Auto Clean Up On Startup?' % autoclean.replace('true',onitem).replace('false',offitem),  'togglesetting', 'autoclean',   icon=ICONMAINT, themeit=THEMETOGGLE)
        if autoclean == 'true':
            addFile('%s  Clear Cache on Startup?' % cache.replace('true',on).replace('false',off),        'togglesetting', 'clearcache',    icon=ICONMAINT, themeit=THEMEDEFAULT)
            addFile('%s  Clear Packages on Startup?' % packages.replace('true',on).replace('false',off),  'togglesetting', 'clearpackages', icon=ICONMAINT, themeit=THEMEDEFAULT)
            addFile('%s  Clear Old Thumbs on Startup?' % thumbs.replace('true',on).replace('false',off),  'togglesetting', 'clearthumbs',   icon=ICONMAINT, themeit=THEMEDEFAULT)
            addFile('[B][COLOR green]%s[/COLOR][/B]  Auto Clean Fequency' % feq[AUTOFEQ],                 'changefeq',                      icon=ICONMAINT, themeit=THEMEDEFAULT)
    #

    #
    #addDir ('BACKUP / RESTORE',        'maint', 'backup', icon=ICONMAINT, themeit=THEMEMENUB)
    if view == "backup" or SHOWMAINT == 'true':
        addDir('BACKUP  [COLOR %s]%s[/COLOR]  RESTORE' % (COLORDESC,SPACER),  'backupMenu',    description='Backup or Restore a zip file backup of your Kodi system setup and addons', icon=ICONBACKUP,themeit=THEMEMENUB)
        '''
        addFile('BACKUP LOCATION: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, MYBUILDS),          'settings', 'Maintenance', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        #addFile('Extract a ZipFile',                                                  'extractazip',     icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Build' % COLORONLINE,               'backupbuild',     icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] GuiFix' % COLORONLINE,              'backupgui',       icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Theme' % COLORONLINE,               'backuptheme',     icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Addon Pack' % COLORONLINE,          'backupaddonpack', icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Back Up:[/B][/COLOR] Addon_data' % COLORONLINE,          'backupaddon',     icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Build' % COLOROFFLINE,         'restorezip',      icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local GuiFix' % COLOROFFLINE,        'restoregui',      icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] Local Addon_data' % COLOROFFLINE,    'restoreaddon',    icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External Build' % COLOROFFLINE,      'restoreextzip',   icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External GuiFix' % COLOROFFLINE,     'restoreextgui',   icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('[COLOR %s][B]Restore:[/B][/COLOR] External Addon_data' % COLOROFFLINE, 'restoreextaddon', icon=ICONMAINT,   themeit=THEMESUBMENUITEMB)
        addFile('Clean Back Up Folder?  (Deletes all zips)',        'clearbackup',     icon=ICONMAINT,   themeit=THEMEWARNING)
        '''
    #
    ############################################################################
    #
    #addFile('Clear Video Cache', '', fanart=FANART, icon=ICONMAINT, themeit=THEMEMENUB)
    addFile('%s  INCLUDE Video Cache in Clear Cache?' % includevid.replace('true',onitem).replace('false',offitem), 'togglecache', 'includevideo',   description='INCLUDE Video Cache in Clear Cache',  icon=ICONMAINT, themeit=THEMETOGGLE)
    if includevid == 'true':
        addFile('%s  Include All Video Addons?' % includeall.replace('true',on).replace('false',off),  'togglecache', 'includeall', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Bob?' % includebob.replace('true',on).replace('false',off),               'togglecache', 'includebob', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Elysium?' % includeely.replace('true',on).replace('false',off),           'togglecache', 'includeely', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Specto?' % includespe.replace('true',on).replace('false',off),            'togglecache', 'includespecto', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Exodus?' % includeexo.replace('true',on).replace('false',off),            'togglecache', 'includeexodus', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Salts?' % includesal.replace('true',on).replace('false',off),             'togglecache', 'includesalts', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Salts HD Lite?' % includeshd.replace('true',on).replace('false',off),     'togglecache', 'includesaltslite', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include One Channel?' % includeone.replace('true',on).replace('false',off),       'togglecache', 'includeonechan', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Genesis?' % includegen.replace('true',on).replace('false',off),           'togglecache', 'includegenesis', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('Enable All Video Addons?',  'togglecache', 'true', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('Disable All Video Addons?', 'togglecache', 'false', icon=ICONMAINT, themeit=THEMETOGGLE)
    #
    '''
    thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
    addFile('%s  Third Party Wizards?' % thirdparty.replace('true',onitem).replace('false',offitem) ,'togglesetting', 'enable3rd', fanart=FANART, icon=ICONBUILDS, themeit=THEMETOGGLE)
    if thirdparty == 'true':
        first = THIRD1NAME if not THIRD1NAME == '' else 'Not Set'
        secon = THIRD2NAME if not THIRD2NAME == '' else 'Not Set'
        third = THIRD3NAME if not THIRD3NAME == '' else 'Not Set'
        addFile('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, first), 'editthird', '1', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, secon), 'editthird', '2', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
        addFile('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, third), 'editthird', '3', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
    #
    '''
    addFile('Fresh Start?',              'freshstart',     description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings',    icon=ICONDELETE, themeit=THEMEWARNING)
    setView('files', 'viewType')
def cleaningMenu():
    autoclean   = 'true' if AUTOCLEANUP    == 'true' else 'false'
    cache       = 'true' if AUTOCACHE      == 'true' else 'false'
    packages    = 'true' if AUTOPACKAGES   == 'true' else 'false'
    thumbs      = 'true' if AUTOTHUMBS     == 'true' else 'false'
    maint       = 'true' if SHOWMAINT      == 'true' else 'false'
    includevid  = 'true' if INCLUDEVIDEO   == 'true' else 'false'
    includeall  = 'true' if INCLUDEALL     == 'true' else 'false'
    # clean video cache
    if includeall == 'true':
        includebob = 'true'
        includeely = 'true'
        includespe = 'true'
        includegen = 'true'
        includeexo = 'true'
        includeone = 'true'
        includesal = 'true'
        includeshd = 'true'
    else:
        includebob = 'true' if INCLUDEBOB     == 'true' else 'false'
        includeely = 'true' if INCLUDEELY     == 'true' else 'false'
        includespe = 'true' if INCLUDESPECTO  == 'true' else 'false'
        includegen = 'true' if INCLUDEGENESIS == 'true' else 'false'
        includeexo = 'true' if INCLUDEEXODUS  == 'true' else 'false'
        includeone = 'true' if INCLUDEONECHAN == 'true' else 'false'
        includesal = 'true' if INCLUDESALTS   == 'true' else 'false'
        includeshd = 'true' if INCLUDESALTSHD == 'true' else 'false'
    sizepack   = wiz.getSize(PACKAGES)
    sizethumb  = wiz.getSize(THUMBS)
    archive    = wiz.getSize(ARCHIVE_CACHE)
    sizecache  = (wiz.getCacheSize())-archive
    totalsize  = sizepack+sizethumb+sizecache
    feq        = ['Always', 'Daily', '3 Days', 'Weekly']
    addFile('[COLOR %s]Run Total Clean Up Now[/COLOR]    [COLOR %s](Cache\Packages\Thumbs)[/COLOR]  [COLOR %s]%s[/COLOR]' % (COLORHEADERINFO, COLORDESC, COLORSIZES, wiz.convertSize(totalsize)),    'fullclean',   description='Clean NOW the Kodi files like Cache\Packages\Thumbs that slow your system down over time.',    icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('%s  Auto Clean Up On Startup?' % autoclean.replace('true',onitem).replace('false',offitem),  'togglesetting', 'autoclean',   description='Toggle if you want the Kodi temp files like thumbnails and cache cleaned occasionally.',  icon=ICONMAINT, themeit=THEMETOGGLE)
    if autoclean == 'true':
        addFile('%s  Clear Cache on Startup?' % cache.replace('true',on).replace('false',off),        'togglesetting', 'clearcache',   description='Clean the Kodi cache of temporary files created by addons to run.  After awhile the files pile up and slow down performance.  Cleaning them refreshes the files too often fixing small errors',    icon=ICONMAINT, themeit=THEMEDEFAULT)
        addFile('%s  Clear Packages on Startup?' % packages.replace('true',on).replace('false',off),  'togglesetting', 'clearpackages', description='Clean the addon zip files left over from an addon install.  By default they arent deleted so you can downgrade an addon, but they eventually take up alot of space.',   icon=ICONMAINT, themeit=THEMEDEFAULT)
        addFile('%s  Clear Old Thumbs on Startup?' % thumbs.replace('true',on).replace('false',off),  'togglesetting', 'clearthumbs',   description='Clean the thumbnail pictures that accumulate over time when loading movie information tags.',   icon=ICONMAINT, themeit=THEMEDEFAULT)
        addFile('[B][COLOR %s]%s[/COLOR][/B]  Auto Clean Fequency' % (COLORSIZES, feq[AUTOFEQ]),   'changefeq',    description='How often to run the auto clean on startup', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #
    addFile('Clear Cache:          [COLOR %s][B]%s[/B][/COLOR]' % (COLORSIZES, wiz.convertSize(sizecache)),       'clearcache',    description='Clear Cache on Startup',   icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Clear Packages:       [COLOR %s][B]%s[/B][/COLOR]' % (COLORSIZES, wiz.convertSize(sizepack)),     'clearpackages',   description='Clear Packages on Startup',  icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Clear Thumbnails:     [COLOR %s][B]%s[/B][/COLOR]' % (COLORSIZES, wiz.convertSize(sizethumb)),  'clearthumb',   description='Clear Thumbs on Startup',    icon=ICONMAINT, themeit=THEMEDEFAULT)
    if os.path.exists(ARCHIVE_CACHE): addFile('Clear Archive_Cache:  [COLOR %s][B]%s[/B][/COLOR]' % (COLORSIZES, wiz.convertSize(archive)), 'cleararchive',   description='Clear the archive cache on Startup',  icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Clear Old Thumbnails?',           'oldThumbs',     description='Clear Old Thumbs on Startup',     icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('Clear Crash Logs?',               'clearcrash',     description='Clear Old Crash Logs on Startup',    icon=ICONLOG, themeit=THEMEDEFAULT)
    addFile('Purge Databases?',                'purgedb',       description='Purge Databases on Startup',     icon=ICONMAINT, themeit=THEMEDEFAULT)
    #
    #addFile('Clear Video Cache', '', fanart=FANART, icon=ICONMAINT, themeit=THEMEMENUB)
    addFile('%s  INCLUDE Video Cache in Clear Cache?' % includevid.replace('true',onitem).replace('false',offitem), 'togglecache', 'includevideo',  description='INCLUDE Video Cache in Clear Cache on Startup',  icon=ICONMAINT, themeit=THEMETOGGLE)
    if includevid == 'true':
        addFile('Disable All Video Addons?', 'togglecache', 'false', description='Disable All Video Addons cach cleaning on Startup',   icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('Enable All Video Addons?',  'togglecache', 'true', description='Enable All Video Addons cach cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include All Video Addons?' % includeall.replace('true',on).replace('false',off),  'togglecache', 'includeall', icon=ICONMAINT, description='Clean ALL caches on Startup', themeit=THEMETOGGLE)
        addFile('%s  Include Bob?' % includebob.replace('true',on).replace('false',off),               'togglecache', 'includebob', icon=ICONMAINT,description='BOB cache cleaning on Startup',  themeit=THEMETOGGLE)
        addFile('%s  Include Elysium?' % includeely.replace('true',on).replace('false',off),           'togglecache', 'includeely', description='Elysium cache cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Specto?' % includespe.replace('true',on).replace('false',off),            'togglecache', 'includespecto',description='Specto cache cleaning on Startup',  icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Exodus?' % includeexo.replace('true',on).replace('false',off),            'togglecache', 'includeexodus', description='Exodus cache cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Salts?' % includesal.replace('true',on).replace('false',off),             'togglecache', 'includesalts',description='SALTS cache cleaning on Startup',  icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Salts HD Lite?' % includeshd.replace('true',on).replace('false',off),     'togglecache', 'includesaltslite', description='SALTS lite cache cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include One Channel?' % includeone.replace('true',on).replace('false',off),       'togglecache', 'includeonechan', description='1Chan cache cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
        addFile('%s  Include Genesis?' % includegen.replace('true',on).replace('false',off),           'togglecache', 'includegenesis', description='Genesis cache cleaning on Startup', icon=ICONMAINT, themeit=THEMETOGGLE)
    #
    addFile('Fresh Start?',    'freshstart',     description='ERASE ALL ADDONS AND SETTINGS returning your Kodi to default settings',    icon=ICONDELETE, themeit=THEMEWARNING)
    setView('files', 'viewType')

###########################
###DELETE CACHE############
####THANKS GUYS @ NaN #####
def clearCache():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache?[/COLOR]' % COLORHEADERTXT, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Clear Cache[/COLOR][/B]'):
        wiz.clearCache()
def clearArchive():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear the \'Archive_Cache\' folder?[/COLOR]' % COLORHEADERTXT, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Yes Clear[/COLOR][/B]'):
        wiz.clearArchive()
def totalClean():
    if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLORHEADERTXT, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
        wiz.clearCache()
        wiz.clearPackages('total')
        clearThumb('total')
def clearThumb(type=None):
    latest = wiz.latestDB('Textures')
    if not type == None: choice = 1
    else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLORHEADERTXT, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
    if choice == 1:
        try: wiz.removeFile(os.join(DATABASE, latest))
        except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
        wiz.removeFolder(THUMBS)
        #if not type == 'total': wiz.killxbmc()
    else: wiz.log('Clear thumbnames cancelled')
    wiz.redoThumbs()
def purgeDb():
    DB = []; display = []
    for dirpath, dirnames, files in os.walk(HOME):
        for f in fnmatch.filter(files, '*.db'):
            if f != 'Thumbs.db':
                found = os.path.join(dirpath, f)
                DB.append(found)
                dir = found.replace('\\', '/').split('/')
                display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
    if KODIV >= 16: 
        choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLORHEADERTXT, display)
        if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLORHEADER, "[COLOR %s]Cancelled[/COLOR]" % COLORHEADERTXT)
        elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLORHEADER, "[COLOR %s]Cancelled[/COLOR]" % COLORHEADERTXT)
        else: 
            for purge in choice: wiz.purgeDb(DB[purge])
    else:
        choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLORHEADERTXT, display)
        if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLORHEADER, "[COLOR %s]Cancelled[/COLOR]" % COLORHEADERTXT)
        else: wiz.purgeDb(DB[purge])

###########################
### DEVELOPER MENU  #######
###########################
def developer():
    addFile('Convert Text Files to 0.1.7',         'converttext',           themeit=THEMEMENUB)
    addFile('Create QR Code',                      'createqr',              themeit=THEMEMENUB)
    addFile('Test Notifications',                  'testnotify',            themeit=THEMEMENUB)
    addFile('Test Update',                         'testupdate',            themeit=THEMEMENUB)
    addFile('Test First Run',                      'testfirst',             themeit=THEMEMENUB)
    addFile('Test First Run Settings',             'testfirstrun',          themeit=THEMEMENUB)
    setView('files', 'viewType')
def testTheme(path):
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        wiz.log(str(item.filename))
        if '/settings.xml' in item.filename:
            return True
    return False
def testGui(path):
    zfile = zipfile.ZipFile(path)
    for item in zfile.infolist():
        if '/guisettings.xml' in item.filename:
            return True
    return False
def testnotify():
    url = wiz.workingURL(NOTIFICATION)
    if url == True:
        try:
            id, msg = wiz.splitNotify(NOTIFICATION)
            if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Notification: Not Formated Correctly[/COLOR]" % COLORHEADERTXT); return
            notify.notification(msg, True)
        except Exception, e:
            wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Invalid URL for Notification[/COLOR]" % COLORHEADERTXT)
def testupdate():
    if BUILDNAME == "":
        notify.updateWindow()
    else:
        notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))
def testfirst():
    notify.firstRun()
def testfirstRun():
    notify.firstRunSettings()

###########################
# Sysyinfo             ####
###########################
def systemInfo():
    infoLabel = ['System.FriendlyName', 
                 'System.BuildVersion', 
                 'System.CpuUsage',
                 'System.ScreenMode',
                 'Network.IPAddress',
                 'Network.MacAddress',
                 'System.Uptime',
                 'System.TotalUptime',
                 'System.FreeSpace',
                 'System.UsedSpace',
                 'System.TotalSpace',
                 'System.Memory(free)',
                 'System.Memory(used)',
                 'System.Memory(total)']
    data      = []; x = 0
    for info in infoLabel:
        temp = wiz.getInfo(info)
        y = 0
        while temp == "Busy" and y < 10:
            temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(200)
        data.append(temp)
        x += 1
    storage_free  = data[8] if 'Una' in data[8] else wiz.convertSize(int(float(data[8][:-8]))*1024*1024)
    storage_used  = data[9] if 'Una' in data[9] else wiz.convertSize(int(float(data[9][:-8]))*1024*1024)
    storage_total = data[10] if 'Una' in data[10] else wiz.convertSize(int(float(data[10][:-8]))*1024*1024)
    ram_free      = wiz.convertSize(int(float(data[11][:-2]))*1024*1024)
    ram_used      = wiz.convertSize(int(float(data[12][:-2]))*1024*1024)
    ram_total     = wiz.convertSize(int(float(data[13][:-2]))*1024*1024)
    picture = []; music = []; video = []; programs = []; repos = []; scripts = []; skins = []
    
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            prov   = re.compile("<provides>(.+?)</provides>").findall(a)
            if len(prov) == 0:
                if foldername.startswith('skin'): skins.append(foldername)
                if foldername.startswith('repo'): repos.append(foldername)
                else: scripts.append(foldername)
            elif not (prov[0]).find('executable') == -1: programs.append(foldername)
            elif not (prov[0]).find('video') == -1: video.append(foldername)
            elif not (prov[0]).find('audio') == -1: music.append(foldername)
            elif not (prov[0]).find('image') == -1: picture.append(foldername)
    # getip
    '''
    m = '0.0.0.0'
    try:
        f = urllib.urlopen("http://www.canyouseeme.org/")
        html_doc = f.read()
        f.close()
        m = re.search('IP"\svalue="([^"]*)', html_doc)
    except: pass
    '''
    #addFile('[B]Media Center Info:[/B]', '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]' %        (COLORHEADER, COLORHEADERTXT, data[0]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]' %     (COLORHEADER, COLORHEADERTXT, data[1]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]' %    (COLORHEADER, COLORHEADERTXT, wiz.platform().title()), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLORHEADER, COLORHEADERTXT, data[2]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[B]Ram Usage:[/B]', '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Memory:[/COLOR] [COLOR %s]%s[/COLOR]   Free:%s\%s' % (COLORHEADER, COLORHEADERTXT, ram_total, ram_used, ram_free), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[B]Local Storage:[/B]', '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Storage:[/COLOR] [COLOR %s]%s[/COLOR]  Free: %s\%s' % (COLORHEADER, COLORHEADERTXT, storage_total, storage_free,storage_used), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR grey]py [B]%s[/B]  ( 2.7.9+ TLS\https)[/COLOR]' % pythonver, '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, data[3]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[B]Uptime:[/B]', '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, data[6]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, data[7]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    
    #addFile('[B]Network:[/B]', '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]IP:[/COLOR] [COLOR %s]%s[/COLOR]     (%s)' % (COLORHEADER, COLORHEADERTXT, data[4], m.group(1)), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLORHEADER, COLORHEADERTXT, exter_ip), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, provider), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    #addFile('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, location), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'% (COLORHEADER, COLORHEADERTXT, data[5]), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    
    totalcount = len(picture) + len(music) + len(video) + len(programs) + len(scripts) + len(skins) + len(repos) 
    addFile('[B]Addons([COLOR %s]%s[/COLOR]):[/B]' % (COLORHEADER, totalcount), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLORHEADER, COLORHEADERTXT, str(len(video))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, str(len(programs))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLORHEADER, COLORHEADERTXT, str(len(music))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLORHEADER, COLORHEADERTXT, str(len(picture))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]' %   (COLORHEADER, COLORHEADERTXT, str(len(repos))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]' %          (COLORHEADER, COLORHEADERTXT, str(len(skins))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
    addFile('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'% (COLORHEADER, COLORHEADERTXT, str(len(scripts))), '', icon=ICONMAINT, themeit=THEMEDEFAULT)
def getIP():
    site  = 'http://whatismyipaddress.com/'
    if not wiz.workingURL(site): return 'Unknown', 'Unknown', 'Unknown'
    page  = wiz.openURL(site).replace('\n','').replace('\r','')
    if not 'Access Denied' in page:
        ipmatch   = re.compile('whatismyipaddress.com/ip/(.+?)"').findall(page)
        ipfinal   = ipmatch[0] if (len(ipmatch) > 0) else 'Unknown'
        details   = re.compile('"font-size:14px;">(.+?)</td>').findall(page)
        provider  = details[0] if (len(details) > 0) else 'Unknown'
        location  = details[1]+', '+details[2]+', '+details[3] if (len(details) > 2) else 'Unknown'
        return ipfinal, provider, location
    else: return 'Unknown', 'Unknown', 'Unknown'

###########################
# Speedtest            ####
###########################
def speedTest():
    addFile('Run Speed Test',             'runspeedtest',      icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
    if os.path.exists(SPEEDTESTFOLD):
        speedimg = glob.glob(os.path.join(SPEEDTESTFOLD, '*.png'))
        speedimg.sort(key=lambda f: os.path.getmtime(f), reverse=True)
        if len(speedimg) > 0:
            addFile('Clear Results',          'clearspeedtest',    icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
            addFile(wiz.sep('Previous Runs'), '', icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
            for item in speedimg:
                created = datetime.fromtimestamp(os.path.getmtime(item)).strftime('%m/%d/%Y %H:%M:%S')
                img = item.replace(os.path.join(SPEEDTESTFOLD, ''), '')
                addFile('[B]%s[/B]: [I]Ran %s[/I]' % (img, created), 'viewspeedtest', img, icon=ICONMAINT, themeit=THEMESUBMENUITEMB)
def clearSpeedTest():
    speedimg = glob.glob(os.path.join(SPEEDTESTFOLD, '*.png'))
    for file in speedimg:
        wiz.removeFile(file)
def viewSpeedTest(img=None):
    img = os.path.join(SPEEDTESTFOLD, img)
    notify.speedTest(img)
def runSpeedTest():
    try:
        found = speedtest.speedtest()
        if not os.path.exists(SPEEDTESTFOLD): os.makedirs(SPEEDTESTFOLD)
        urlsplits = found[0].split('/')
        dest = os.path.join(SPEEDTESTFOLD, urlsplits[-1])
        urllib.urlretrieve(found[0], dest)
        viewSpeedTest(urlsplits[-1])
    except:
        wiz.log("[Speed Test] Error Running Speed Test")
        pass

###########################
###### Misc Functions #####
###########################
def fixUpdate():
    if KODIV < 17: 
        dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
        try:
            os.remove(dbfile)
        except Exception, e:
            wiz.log("Unable to remove %s, Purging DB" % dbfile)
            wiz.purgeDb(dbfile)
    else:
        if os.path.exists(os.path.join(USERDATA, 'autoexec.py')):
            temp = os.path.join(USERDATA, 'autoexec_temp.py')
            if os.path.exists(temp): xbmcvfs.delete(temp)
            xbmcvfs.rename(os.path.join(USERDATA, 'autoexec.py'), temp)
        xbmcvfs.copy(os.path.join(PLUGIN, 'resources', 'libs', 'autoexec.py'), os.path.join(USERDATA, 'autoexec.py'))
        dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
        try:
            os.remove(dbfile)
        except Exception, e:
            wiz.log("Unable to remove %s, Purging DB" % dbfile)
            wiz.purgeDb(dbfile)
        wiz.killxbmc(True)
def removeAddonMenu():
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    addonnames = []; addonids = []
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        elif foldername in DEFAULTPLUGINS: continue
        elif foldername == 'packages': continue
        xml = os.path.join(folder, 'addon.xml')
        if os.path.exists(xml):
            f      = open(xml)
            a      = f.read()
            match  = wiz.parseDOM(a, 'addon', ret='id')
            addid  = foldername if len(match) == 0 else match[0]
            try: 
                add = xbmcaddon.Addon(id=addid)
                addonnames.append(add.getAddonInfo('name'))
                addonids.append(addid)
            except:
                pass
    if len(addonnames) == 0:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]No Addons To Remove[/COLOR]" % COLORHEADERTXT)
        return
    if KODIV > 16:
        selected = DIALOG.multiselect("%s: Select the addons you wish to remove." % ADDONTITLE, addonnames)
    else:
        selected = []; choice = 0
        tempaddonnames = ["-- Click here to Continue --"] + addonnames
        while not choice == -1:
            choice = DIALOG.select("%s: Select the addons you wish to remove." % ADDONTITLE, tempaddonnames)
            if choice == -1: break
            elif choice == 0: break
            else: 
                choice2 = (choice-1)
                if choice2 in selected:
                    selected.remove(choice2)
                    tempaddonnames[choice] = addonnames[choice2]
                else:
                    selected.append(choice2)
                    tempaddonnames[choice] = "[B][COLOR %s]%s[/COLOR][/B]" % (COLORHEADER, addonnames[choice2])
    if selected == None: return
    if len(selected) > 0:
        wiz.addonUpdates('set')
        for addon in selected:
            removeAddon(addonids[addon], addonnames[addon], True)
        xbmc.sleep(500)
        if INSTALLMETHOD == 1: todo = 1
        elif INSTALLMETHOD == 2: todo = 0
        else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
        if todo == 1: wiz.reloadFix('remove addon')
        else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
def removeAddonDataMenu():
    if os.path.exists(ADDOND):
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data', 'removedata', 'all', themeit=THEMEDEFAULT)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons', 'removedata', 'uninstalled', themeit=THEMEDEFAULT)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data', 'removedata', 'empty', themeit=THEMEDEFAULT)
        addFile('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data' % ADDONTITLE, 'resetaddon', themeit=THEMEDEFAULT)
        if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEMESUBMENUITEMB)
        fold = glob.glob(os.path.join(ADDOND, '*/'))
        for folder in sorted(fold, key = lambda x: x):
            foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
            icon = os.path.join(folder.replace(ADDOND, ADDONS), 'icon.png')
            fanart = os.path.join(folder.replace(ADDOND, ADDONS), 'fanart.png')
            folderdisplay = foldername
            replace = {'audio.':'[COLOR orange][AUDIO] [/COLOR]', 'metadata.':'[COLOR cyan][METADATA] [/COLOR]', 'module.':'[COLOR orange][MODULE] [/COLOR]', 'plugin.':'[COLOR blue][PLUGIN] [/COLOR]', 'program.':'[COLOR orange][PROGRAM] [/COLOR]', 'repository.':'[COLOR gold][REPO] [/COLOR]', 'script.':'[COLOR green][SCRIPT] [/COLOR]', 'service.':'[COLOR green][SERVICE] [/COLOR]', 'skin.':'[COLOR dodgerblue][SKIN] [/COLOR]', 'video.':'[COLOR orange][VIDEO] [/COLOR]', 'weather.':'[COLOR yellow][WEATHER] [/COLOR]'}
            for rep in replace:
                folderdisplay = folderdisplay.replace(rep, replace[rep])
            if foldername in EXCLUDES: folderdisplay = '[COLOR green][B][PROTECTED][/B][/COLOR] %s' % folderdisplay
            else: folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] %s' % folderdisplay
            addFile(' %s' % folderdisplay, 'removedata', foldername, icon=icon, fanart=fanart, themeit=THEMEDEFAULT)
    else:
        addFile('No Addon data folder found.', '', themeit=THEMESUBMENUITEMB)
    setView('files', 'viewType')
def enableAddons():
    addFile("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]", '', icon=ICONMAINT)
    fold = glob.glob(os.path.join(ADDONS, '*/'))
    x = 0
    for folder in sorted(fold, key = lambda x: x):
        foldername = os.path.split(folder[:-1])[1]
        if foldername in EXCLUDES: continue
        if foldername in DEFAULTPLUGINS: continue
        addonxml = os.path.join(folder, 'addon.xml')
        if os.path.exists(addonxml):
            x += 1
            fold   = folder.replace(ADDONS, '')[1:-1]
            f      = open(addonxml)
            a      = f.read().replace('\n','').replace('\r','').replace('\t','')
            match  = wiz.parseDOM(a, 'addon', ret='id')
            match2 = wiz.parseDOM(a, 'addon', ret='name')
            try:
                pluginid = match[0]
                name = match2[0]
            except:
                continue
            try:
                add    = xbmcaddon.Addon(id=pluginid)
                state  = "[COLOR green][Enabled][/COLOR]"
                goto   = "false"
            except:
                state  = "[COLOR red][Disabled][/COLOR]"
                goto   = "true"
                pass
            icon   = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ICON
            fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else FANART
            addFile("%s %s" % (state, name), 'toggleaddon', fold, goto, icon=icon, fanart=fanart)
            f.close()
    if x == 0:
        addFile("No Addons Found to Enable or Disable.", '', icon=ICONMAINT)
    setView('files', 'viewType')
def changeFeq():
    feq        = ['Every Startup', 'Every Day', 'Every Three Days', 'Every Weekly']
    change     = DIALOG.select("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]" % COLORHEADERTXT, feq)
    if not change == -1: 
        wiz.setS('autocleanfeq', str(change))
        wiz.LogNotify('[COLOR %s]Auto Clean Up[/COLOR]' % COLORHEADER, '[COLOR %s]Fequency Now %s[/COLOR]' % (COLORHEADERTXT, feq[change]))
def removeAddon(addon, name, over=False):
    if not over == False:
        yes = 1
    else: 
        yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Are you sure you want to delete the addon:'% COLORHEADERTXT, 'Name: [COLOR %s]%s[/COLOR]' % (COLORHEADER, name), 'ID: [COLOR %s]%s[/COLOR][/COLOR]' % (COLORHEADER, addon), yeslabel='[B][COLOR green]Remove Addon[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
    if yes == 1:
        folder = os.path.join(ADDONS, addon)
        wiz.log("Removing Addon %s" % addon)
        wiz.cleanHouse(folder)
        xbmc.sleep(200)
        try: shutil.rmtree(folder)
        except Exception ,e: wiz.log("Error removing %s" % addon, xbmc.LOGNOTICE)
        removeAddonData(addon, name, over)
    if over == False:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]%s Removed[/COLOR]" % (COLORHEADERTXT, name))
def removeAddonData(addon, name=None, over=False):
    if addon == 'all':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % (COLORHEADERTXT, COLORHEADER), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            wiz.cleanHouse(ADDOND)
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLORHEADER, '[COLOR %s]Cancelled![/COLOR]' % COLORHEADERTXT)
    elif addon == 'uninstalled':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (COLORHEADERTXT, COLORHEADER), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = 0
            for folder in glob.glob(os.path.join(ADDOND, '*')):
                foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
                if foldername in EXCLUDES: pass
                elif os.path.exists(os.path.join(ADDONS, foldername)): pass
                else: wiz.cleanHouse(folder); total += 1; wiz.log(folder); shutil.rmtree(folder)
            wiz.LogNotify('[COLOR %s]Clean up Uninstalled[/COLOR]' % COLORHEADER, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLORHEADERTXT, total))
        else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLORHEADER, '[COLOR %s]Cancelled![/COLOR]' % COLORHEADERTXT)
    elif addon == 'empty':
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % (COLORHEADERTXT, COLORHEADER), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
            total = wiz.emptyfolder(ADDOND)
            wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLORHEADER, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLORHEADERTXT, total))
        else: wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLORHEADER, '[COLOR %s]Cancelled![/COLOR]' % COLORHEADERTXT)
    else:
        addon_data = os.path.join(USERDATA, 'addon_data', addon)
        if addon in EXCLUDES:
            wiz.LogNotify("[COLOR %s]Protected Plugin[/COLOR]" % COLORHEADER, "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % COLORHEADERTXT)
        elif os.path.exists(addon_data):  
            if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % COLORHEADERTXT, '[COLOR %s]%s[/COLOR]' % (COLORHEADER, addon), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
                wiz.cleanHouse(addon_data)
                try:
                    shutil.rmtree(addon_data)
                except:
                    wiz.log("Error deleting: %s" % addon_data)
            else: 
                wiz.log('Addon data for %s was not removed' % addon)
    wiz.refresh()
def restoreit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Local Restore Cancelled[/COLOR]" % COLORHEADERTXT); return
    if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
        wiz.skinToDefault('Restore Backup')
    wiz.restoreLocal(type)
def restoreextit(type):
    if type == 'build':
        x = freshStart('restore')
        if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]External Restore Cancelled[/COLOR]" % COLORHEADERTXT); return
    wiz.restoreExternal(type)
def buildInfo(name):
    if wiz.workingURL(BUILDFILE) == True:
        if wiz.checkBuild(name, 'url'):
            name, version, url, minor, gui, kodi, theme, icon, fanart, preview, adult, info, description = wiz.checkBuild(name, 'all')
            adult = 'Yes' if adult.lower() == 'yes' else 'No'
            extend = False
            if not info == "http://":
                try:
                    tname, extracted, zipsize, skin, created, programs, video, music, picture, repos, scripts = wiz.checkInfo(info)
                    extend = True
                except:
                    extend = False
            if extend == True:
                msg  = "[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, name)
                msg += "[COLOR %s]Build Version:[/COLOR] v[COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, version)
                msg += "[COLOR %s]Latest Update:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, created)
                if not theme == "http://":
                    themecount = wiz.themeCount(name, False)
                    msg += "[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, ', '.join(themecount))
                msg += "[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, kodi)
                msg += "[COLOR %s]Extracted Size:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, wiz.convertSize(int(float(extracted))))
                msg += "[COLOR %s]Zip Size:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, wiz.convertSize(int(float(zipsize))))
                msg += "[COLOR %s]Skin Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, skin)
                msg += "[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, adult)
                msg += "[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, description)
                msg += "[COLOR %s]Programs:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, programs)
                msg += "[COLOR %s]Video:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, video)
                msg += "[COLOR %s]Music:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, music)
                msg += "[COLOR %s]Pictures:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, picture)
                msg += "[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]" % (COLORHEADERTXT, COLORHEADER, repos)
                msg += "[COLOR %s]Scripts:[/COLOR] [COLOR %s]%s[/COLOR]" % (COLORHEADERTXT, COLORHEADER, scripts)
            else:
                msg  = "[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, name)
                msg += "[COLOR %s]Build Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, version)
                if not theme == "http://":
                    themecount = wiz.themeCount(name, False)
                    msg += "[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, ', '.join(themecount))
                msg += "[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, kodi)
                msg += "[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, adult)
                msg += "[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLORHEADERTXT, COLORHEADER, description)
            
            wiz.TextBox(ADDONTITLE, msg)
        else: wiz.log("Invalid Build Name!")
    else: wiz.log("Build text file not working: %s" % WORKINGURL)
def buildVideo(name):
    if wiz.workingURL(BUILDFILE) == True:
        videofile = wiz.checkBuild(name, 'preview')
        if videofile and not videofile == 'http://': playVideo(videofile)
        else: wiz.log("[%s]Unable to find url for video preview" % name)
    else: wiz.log("Build text file not working: %s" % WORKINGURL)
def dependsList(plugin):
    addonxml = os.path.join(ADDONS, plugin, 'addon.xml')
    if os.path.exists(addonxml):
        source = open(addonxml,mode='r'); link = source.read(); source.close(); 
        match  = wiz.parseDOM(link, 'import', ret='addon')
        items  = []
        for depends in match:
            if not 'xbmc.python' in depends:
                items.append(depends)
        return items
    return []
def manageSaveData(do):
    if do == 'import':
        TEMP = os.path.join(ADDONDATA, 'temp')
        if not os.path.exists(TEMP): os.makedirs(TEMP)
        source = DIALOG.browse(1, '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % COLORHEADERTXT, 'files', '.zip', False, False, HOME)
        if not source.endswith('.zip'):
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Import Data Error![/COLOR]" % (COLORHEADERTXT))
            return
        source   = xbmc.translatePath(source)
        tempfile = xbmc.translatePath(os.path.join(MYBUILDS, 'SaveData.zip'))
        if not tempfile == source:
            goto = xbmcvfs.copy(source, tempfile)
        if extract.all(xbmc.translatePath(tempfile), TEMP) == False:
            wiz.log("Error trying to extract the zip file!")
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Import Data Error![/COLOR]" % (COLORHEADERTXT))
            return
        trakt  = os.path.join(TEMP, 'trakt')
        login  = os.path.join(TEMP, 'login')
        debrid = os.path.join(TEMP, 'debrid')
        alluc  = os.path.join(TEMP, 'alluc')
        super  = os.path.join(TEMP, 'plugin.program.super.favourites')
        xmls   = os.path.join(TEMP, 'xmls')
        x = 0
        overwrite = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you rather we overwrite all Save Data files or ask you for each file being imported?[/COLOR]" % (COLORHEADERTXT), yeslabel="[B][COLOR green]Overwrite All[/COLOR][/B]", nolabel="[B][COLOR red]No Ask[/COLOR][/B]")
        if os.path.exists(trakt):
            x += 1
            files = os.listdir(trakt)
            if not os.path.exists(traktit.TRAKTFOLD): os.makedirs(traktit.TRAKTFOLD)
            for item in files:
                old  = os.path.join(traktit.TRAKTFOLD, item)
                temp = os.path.join(trakt, item)
                if os.path.exists(old):
                    if overwrite == 1: os.remove(old)
                    else:
                        if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLORHEADERTXT, COLORHEADER, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                        else: os.remove(old) 
                shutil.copy(temp, old)
            traktit.importlist('all')
            traktit.traktIt('restore', 'all')
        if os.path.exists(login):
            x += 1
            files = os.listdir(login)
            if not os.path.exists(loginit.LOGINFOLD): os.makedirs(loginit.LOGINFOLD)
            for item in files:
                old  = os.path.join(loginit.LOGINFOLD, item)
                temp = os.path.join(login, item)
                if os.path.exists(old):
                    if overwrite == 1: os.remove(old)
                    else:
                        if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLORHEADERTXT, COLORHEADER, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                        else: os.remove(old)
                shutil.copy(temp, old)
            loginit.importlist('all')
            loginit.loginIt('restore', 'all')
        if os.path.exists(debrid):
            x += 1
            files = os.listdir(debrid)
            if not os.path.exists(debridit.REALFOLD): os.makedirs(debridit.REALFOLD)
            for item in files:
                old  = os.path.join(debridit.REALFOLD, item)
                temp = os.path.join(debrid, item)
                if os.path.exists(old):
                    if overwrite == 1: os.remove(old)
                    else:
                        if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLORHEADERTXT, COLORHEADER, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                        else: os.remove(old)
                shutil.copy(temp, old)
            debridit.importlist('all')
            debridit.debridIt('restore', 'all')
        if os.path.exists(alluc):
            x += 1
            files = os.listdir(alluc)
            if not os.path.exists(allucit.ALLUCFOLD): os.makedirs(allucit.ALLUCFOLD)
            for item in files:
                old  = os.path.join(allucit.ALLUCFOLD, item)
                temp = os.path.join(alluc, item)
                if os.path.exists(old):
                    if overwrite == 1: os.remove(old)
                    else:
                        if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLORHEADERTXT, COLORHEADER, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                        else: os.remove(old)
                shutil.copy(temp, old)
            allucit.importlist('all')
            allucit.allucIt('restore', 'all')
        if os.path.exists(xmls):
            x += 1
            files = ['advancedsettings.xml', 'sources.xml', 'favourites.xml', 'profiles.xml']
            for item in files:
                old = os.path.join(USERDATA, item)
                new = os.path.join(xmls, item)
                if not os.path.exists(new): continue
                if os.path.exists(old):
                    if not overwrite == 1:
                        if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLORHEADERTXT, COLORHEADER, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
                os.remove(old)
                shutil.copy(new, old)
        if os.path.exists(super):
            x += 1
            old = os.path.join(ADDOND, 'plugin.program.super.favourites')
            if os.path.exists(old):
                cont = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]Super Favourites[/COLOR] addon_data folder with the new one?" % (COLORHEADERTXT, COLORHEADER), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]")
            else: cont = 1
            if cont == 1:
                wiz.cleanHouse(old)
                wiz.removeFolder(old)
                xbmcvfs.copy(super, old)
        wiz.cleanHouse(TEMP)
        wiz.removeFolder(TEMP)
        if not tempfile == source:
            xbmcvfs.delete(tempfile)
        if x == 0: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Save Data Import Failed[/COLOR]" % COLORHEADERTXT)
        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Save Data Import Complete[/COLOR]" % COLORHEADERTXT)
    elif do == 'export':
        mybuilds = xbmc.translatePath(MYBUILDS)
        dir   = [traktit.TRAKTFOLD, debridit.REALFOLD, loginit.LOGINFOLD, allucit.ALLUCFOLD]
        xmls  = ['advancedsettings.xml', 'sources.xml', 'favourites.xml', 'profiles.xml']
        keepx = [KEEPADVANCED, KEEPSOURCES, KEEPFAVS, KEEPPROFILES]
        traktit.traktIt('update', 'all')
        loginit.loginIt('update', 'all')
        debridit.debridIt('update', 'all')
        allucit.allucIt('update', 'all')
        source = DIALOG.browse(3, '[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]' % COLORHEADERTXT, 'files', '', False, True, HOME)
        source = xbmc.translatePath(source)
        tempzip = os.path.join(mybuilds, 'SaveData.zip')
        superfold = os.path.join(ADDOND, 'plugin.program.super.favourites')
        zipf = zipfile.ZipFile(tempzip, mode='w')
        for fold in dir:
            if os.path.exists(fold):
                files = os.listdir(fold)
                for file in files:
                    fn = os.path.join(fold, file)
                    zipf.write(fn, fn[len(ADDONDATA):], zipfile.ZIP_DEFLATED)
        if KEEPSUPER == 'true' and os.path.exists(superfold):
            for base, dirs, files in os.walk(superfold):
                for file in files:
                    fn = os.path.join(base, file)
                    zipf.write(fn, fn[len(ADDOND):], zipfile.ZIP_DEFLATED)
        for item in xmls:
            if keepx[xmls.index(item)] == 'true' and os.path.exists(os.path.join(USERDATA, item)):
                zipf.write(os.path.join(USERDATA, item), os.path.join('xmls', item), zipfile.ZIP_DEFLATED)
        zipf.close()
        if source == mybuilds:
            DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLORHEADERTXT), "[COLOR %s]%s[/COLOR]" % (COLORHEADER, tempzip))
        else:
            try:
                xbmcvfs.copy(tempzip, os.path.join(source, 'SaveData.zip'))
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLORHEADERTXT), "[COLOR %s]%s[/COLOR]" % (COLORHEADER, os.path.join(source, 'SaveData.zip')))
            except:
                DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLORHEADERTXT), "[COLOR %s]%s[/COLOR]" % (COLORHEADER, tempzip))
def freshStart(install=None, over=False):
    if KEEPTRAKT == 'true':
        traktit.autoUpdate('all')
        wiz.setS('traktlastsave', str(THREEDAYS))
    if KEEPREAL == 'true':
        debridit.autoUpdate('all')
        wiz.setS('debridlastsave', str(THREEDAYS))
    if KEEPLOGIN == 'true':
        loginit.autoUpdate('all')
        wiz.setS('loginlastsave', str(THREEDAYS))
    if over == True: yes_pressed = 1
    elif install == 'restore': yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLORHEADERTXT, "Kodi configuration to default settings", "Before installing the local backup?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    elif install: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLORHEADERTXT, "Kodi configuration to default settings", "Before installing [COLOR %s]%s[/COLOR]?" % (COLORHEADER, install), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    else: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLORHEADERTXT, "Kodi configuration to default settings?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
    if yes_pressed:
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            swap = wiz.skinToDefault('Fresh Install')
            if swap == False: return False
            xbmc.sleep(1000)
        if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Failed![/COLOR]' % COLORHEADERTXT)
            return
        wiz.addonUpdates('set')
        xbmcPath=os.path.abspath(HOME)
        DP.create(ADDONTITLE,"[COLOR %s]Calculating files and folders" % COLORHEADERTXT,'', 'Please Wait![/COLOR]')
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
        DP.update(0, "[COLOR %s]Gathering Excludes list." % COLORHEADERTXT)
        #EXCLUDES.append('My_Builds')
        EXCLUDES.append(My_Builds)
        EXCLUDES.append('archive_cache')
        if KEEPREPOS == 'true':
            repos = glob.glob(os.path.join(ADDONS, 'repo*/'))
            for item in repos:
                repofolder = os.path.split(item[:-1])[1]
                if not repofolder == EXCLUDES:
                    EXCLUDES.append(repofolder)
        if KEEPSUPER == 'true':
            EXCLUDES.append('plugin.program.super.favourites')
        if KEEPWHITELIST == 'true':
            pvr = ''
            whitelist = wiz.whiteList('read')
            if len(whitelist) > 0:
                for item in whitelist:
                    try: name, id, fold = item
                    except: pass
                    if fold.startswith('pvr'): pvr = id 
                    depends = dependsList(fold)
                    for plug in depends:
                        if not plug in EXCLUDES:
                            EXCLUDES.append(plug)
                        depends2 = dependsList(plug)
                        for plug2 in depends2:
                            if not plug2 in EXCLUDES:
                                EXCLUDES.append(plug2)
                    if not fold in EXCLUDES:
                        EXCLUDES.append(fold)
                if not pvr == '': wiz.setS('pvrclient', fold)
        if wiz.getS('pvrclient') == '':
            for item in EXCLUDES:
                if item.startswith('pvr'):
                    wiz.setS('pvrclient', item)
        DP.update(0, "[COLOR %s]Clearing out files and folders:" % COLORHEADERTXT)
        latestAddonDB = wiz.latestDB('Addons')
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                del_file += 1
                fold = root.replace('/','\\').split('\\')
                x = len(fold)-1
                if name == 'sources.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep Sources: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'favourites.xml' and fold[-1] == 'userdata' and KEEPFAVS == 'true': wiz.log("Keep Favourites: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'profiles.xml' and fold[-1] == 'userdata' and KEEPPROFILES == 'true': wiz.log("Keep Profiles: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'advancedsettings.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep Advanced Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name == 'playercorefactory.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep playercorefactory Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                elif name in LOGFILES: wiz.log("Keep Log File: %s" % name, xbmc.LOGNOTICE)
                elif name.endswith('.db'):
                    try:
                        if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), xbmc.LOGNOTICE)
                        else: os.remove(os.path.join(root,name))
                    except Exception, e: 
                        if not name.startswith('Textures13'):
                            wiz.log('Failed to delete, Purging DB', xbmc.LOGNOTICE)
                            wiz.log("-> %s" % (str(e)), xbmc.LOGNOTICE)
                            wiz.purgeDb(os.path.join(root,name))
                else:
                    DP.update(int(wiz.percentage(del_file, total_files)), '', '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % (COLORHEADERTXT, COLORHEADER, name), '')
                    try: os.remove(os.path.join(root,name))
                    except Exception, e: 
                        wiz.log("Error removing %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                        wiz.log("-> / %s" % (str(e)), xbmc.LOGNOTICE)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLORHEADERTXT)
                return False
        for root, dirs, files in os.walk(xbmcPath,topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in dirs:
                DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLORHEADER, name), '')
                if name not in ["Database","userdata","temp","addons","addon_data"]:
                    shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
            if DP.iscanceled(): 
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLORHEADERTXT)
                return False
        DP.close()
        wiz.clearS('build')
        set_enabled(REPOID, data=None)
        set_enabled(ADDON_ID, data=None)
        if over == True:
            return True
        elif install == 'restore': 
            return True
        elif install: 
            buildWizard(install, 'normal', over=True)
        else:
            if INSTALLMETHOD == 1: todo = 1
            elif INSTALLMETHOD == 2: todo = 0
            else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
            if todo == 1: wiz.reloadFix('fresh')
            else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
    else: 
        if not install == 'restore':
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), '[COLOR %s]Fresh Install: Cancelled![/COLOR]' % COLORHEADERTXT)
            wiz.refresh()
def EnableRTMP():
    set_enabled("inputstream.adaptive")
    time.sleep(0.5)
    set_enabled("inputstream.rtmp")
    time.sleep(0.5)
def toggleCache(state):
    cachelist = ['includevideo', 'includeall', 'includebob', 'includeely', 'includespecto', 'includegenesis', 'includeexodus', 'includeonechan', 'includesalts', 'includesaltslite']
    titlelist = ['Include Video Addons', 'Include All Addons', 'Include Bob', 'Include Elysium', 'Include Specto', 'Include Genesis', 'Include Exodus', 'Include One Channel', 'Include Salts', 'Include Salts Lite HD']
    if state in ['true', 'false']:
        for item in cachelist:
            wiz.setS(item, state)
    else:
        if not state in ['includevideo', 'includeall'] and wiz.getS('includeall') == 'true':
            try:
                item = titlelist[cachelist.index(state)]
                DIALOG.ok(ADDONTITLE, "[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]" % (COLORHEADERTXT, COLORHEADER, COLORHEADER, item))
            except:
                wiz.LogNotify("[COLOR %s]Toggle Cache[/COLOR]" % COLORHEADER, "[COLOR %s]Invalid id: %s[/COLOR]" % (COLORHEADERTXT, state))
        else:
            new = 'true' if wiz.getS(state) == 'false' else 'false'
            wiz.setS(state, new)
def playVideo(url):
    if 'watch?v=' in url:
        a, b = url.split('?')
        find = b.split('&')
        for item in find:
            if item.startswith('v='):
                url = item[2:]
                break
            else: continue
    elif 'embed' in url or 'youtu.be' in url:
        a = url.split('/')
        if len(a[-1]) > 5:
            url = a[-1]
        elif len(a[-2]) > 5:
            url = a[-2]
    wiz.log("YouTube URL: %s" % url)
    if wiz.getCond('System.HasAddon(plugin.video.youtube)') == 1:
        url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
        xbmc.Player().play(url)
    xbmc.sleep(2000)
    if xbmc.Player().isPlayingVideo() == 0:
        yt.PlayVideo(url)
def viewLogFile():
    mainlog = wiz.Grab_Log(True)
    oldlog  = wiz.Grab_Log(True, True)
    which = 0; logtype = mainlog
    if not oldlog == False and not mainlog == False:
        which = DIALOG.select(ADDONTITLE, ["View %s" % mainlog.replace(LOG, ""), "View %s" % oldlog.replace(LOG, "")])
        if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLORHEADER, '[COLOR %s]View Log Cancelled![/COLOR]' % COLORHEADERTXT); return
    elif mainlog == False and oldlog == False:
        wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLORHEADER, '[COLOR %s]No Log File Found![/COLOR]' % COLORHEADERTXT)
        return
    elif not mainlog == False: which = 0
    elif not oldlog == False: which = 1
    
    logtype = mainlog if which == 0 else oldlog
    msg     = wiz.Grab_Log(False) if which == 0 else wiz.Grab_Log(False, True)
    
    wiz.TextBox("%s - %s" % (ADDONTITLE, logtype), msg)
def errorList(file):
    errors = []
    a=open(file).read()
    b=a.replace('\n','[CR]').replace('\r','')
    match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(b)
    for item in match:
        errors.append(item)
    return errors
def errorChecking(log=None, count=None, last=None):
    errors = []; error1 = []; error2 = [];
    if log == None:
        curr = wiz.Grab_Log(True, False)
        old = wiz.Grab_Log(True, True)
        if old == False and curr == False:
            if count == None: 
                wiz.LogNotify('[COLOR %s]View Error Log[/COLOR]' % COLORHEADER, '[COLOR %s]No Log File Found![/COLOR]' % COLORHEADERTXT)
                return
            else:
                return 0
        if not curr == False: 
            error1 = errorList(curr)
        if not old == False: 
            error2 = errorList(old)
        if len(error2) > 0: 
            for item in error2: errors = [item] + errors
        if len(error1) > 0: 
            for item in error1: errors = [item] + errors
    else:
        error1 = errorList(log)
        if len(error1) > 0:
            for item in error1: errors = [item] + errors
    if not count == None:
        return len(errors)
    elif len(errors) > 0:
        if last == None:
            i = 0; string = ''
            for item in errors:
                i += 1
                string += "[B][COLOR red]ERROR NUMBER %s:[/B][/COLOR]%s\n" % (str(i), item.replace(HOME, '/').replace('                                        ', ''))
        else:
            string = "[B][COLOR red]Last Error in Log:[/B][/COLOR]%s\n" % (errors[0].replace(HOME, '/').replace('                                        ', ''))
        wiz.TextBox("%s: Errors in Log" % ADDONTITLE, string)
    else:
        wiz.LogNotify('[COLOR %s]View Error Log[/COLOR]' % COLORHEADER, '[COLOR %s]No Errors Found![/COLOR]' % COLORHEADERTXT)
ACTION_PREVIOUS_MENU            =  10    ## ESC action
ACTION_NAV_BACK                 =  92    ## Backspace action
ACTION_MOVE_LEFT                =   1    ## Left arrow key
ACTION_MOVE_RIGHT               =   2    ## Right arrow key
ACTION_MOVE_UP                  =   3    ## Up arrow key
ACTION_MOVE_DOWN                =   4    ## Down arrow key
ACTION_MOUSE_WHEEL_UP           = 104    ## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN         = 105    ## Mouse wheel down
ACTION_MOVE_MOUSE               = 107    ## Down arrow key
ACTION_SELECT_ITEM              =   7    ## Number Pad Enter
ACTION_BACKSPACE                = 110    ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108
# new below
def _notify(header,msg,icon=None, duration=500, sound=False):
    #xbmc.executebuiltin('XBMC.Notification(%s,%s, %s, %s, %s, %s)' % (header, msg, duration, icon,time=duration, sound=False))
    xbmcgui.Dialog().notification(header, msg, icon=icon, time=duration, sound=False)
def EnableDebug():
    xbmc.executebuiltin('ToggleDebug')
    xbmc.executebuiltin('Skin.ToggleDebug')
def Repolink(REPO_ID=None):
    #xbmc.executebuiltin('ActivateWindow(10040,addons://'+ADDON_ID+'/,return)')
    xbmc.executebuiltin('ActivateWindow(10040,addons://'+REPO_ID+'/,return)')
def helpMenu(url=None):
    """ shows a browse dialog and returns a value
        - 0 : ShowAndGetDirectory
        - 1 : ShowAndGetFile
        - 2 : ShowAndGetImage
        - 3 : ShowAndGetWriteableDirectory
    """
    if url == None:
        HELPFILE = EXTRAPATH+'/help/'
        browse_dialog = xbmcgui.Dialog()
        url = browse_dialog.browse(type=1, heading='Select File', shares='files', mask='.txt', useThumbs=False, treatAsFolder=False, defaultt=HELPFILE, enableMultiple=False)
        if not os.path.exists(url): return
    if os.path.exists(url):
        name2 =  os.path.basename(url)
        f = xbmcvfs.File(url,'rb')
        data = f.read()
        dialog = xbmcgui.Dialog()
        dialog.textviewer(name2, data)
def set_enabled(newaddon=None, data=None):                                      # enable installed single addon (Addons27.db)
    from sqlite3 import dbapi2 as db_lib
    db_path = os.path.join(DATABASE, 'Addons27.db')
    conn = db_lib.connect(db_path)
    conn.text_factory = str
    if KODIV >= 17:
        if os.path.exists(os.path.join(ADDONS, newaddon, 'icon.png')):  _notify('Enable', 'Enabling '+newaddon, os.path.join(ADDONS, newaddon, 'icon.png'))
        else:  _notify('Enable','Enabling '+newaddon, ICON)
        setit = 1
        if data is None: data = ''
        sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
        conn.execute(sql, (newaddon, setit,))
        conn.commit()
    else:  pass
def setall_enable():                                                            # enable all installed addons (Addons27.db)
    from sqlite3 import dbapi2 as db_lib
    db_path = os.path.join(DATABASE, 'Addons27.db')
    conn = db_lib.connect(db_path)
    conn.text_factory = str
    #if kodi.get_kversion() > 16.5:
    if KODIV >= 17:
        _notify('Enable','Enabling All Addons',ICON)
        contents = os.listdir(ADDONS)
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in contents))
        conn.commit()
    else: pass
def delete_file(filename=None):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1
def remove_dir(path=None):
    dirList, flsList = xbmcvfs.listdir(path)
    for fl in flsList:
        xbmcvfs.delete(os.path.join(path, fl))
    for dr in dirList:
        xbmcvfs.delete(xbmc.translatePath(os.path.join(path, '%s')) % dr)
    xbmcvfs.rmdir(path)
def removetxtmenu(name=None):  # txt edit
    source = xbmc.translatePath(os.path.join(name))
    #xbmc.log(msg='##['+ADDON_ID+'] source %s' % source,level=xbmc.LOGNOTICE)
    todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you want to delete the txt file?  This is irreversible[/COLOR]\n%s" % (COLORTXT,source), yeslabel="[B][COLOR lightgreen]YES[/COLOR][/B]", nolabel="[B][COLOR red]NO[/COLOR][/B]")
    if todo == 1:
        if os.path.exists(source):
            os.remove(name)
    wiz.refresh()
def refreshtxtmenu(name=None, symlinks=False, ignore=None):  # txt edit
    src = xbmc.translatePath(os.path.join(DATAPATH, name))
    dst = xbmc.translatePath(os.path.join(DATAPATHUSERDATA, name))
    todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you want to refresh the txt dir with built in files?  This is irreversible andd may overwrite your custom file[/COLOR] (from - to)\n%s\n%s" % (COLORTXT,src, dst), yeslabel="[B][COLOR lightgreen]YES[/COLOR][/B]", nolabel="[B][COLOR red]NO[/COLOR][/B]")
    if todo == 1:
        if os.path.exists(src):
            for item in os.listdir(src):
                s = os.path.join(src, item)
                d = os.path.join(dst, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, symlinks, ignore)
                else:
                    shutil.copy2(s, d)
    wiz.refresh()
def AppendText(SourceFile=None, DestFile=None):
    #xbmc.log(msg='##['+ADDON_ID+'] Append text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'a')
            f.write(s)
            f.close()
            s.close()
        except: pass
def WriteText(SourceFile=None, DestFile=None):
    #xbmc.log(msg='##['+ADDON_ID+'] Write text', level=xbmc.LOGNOTICE)
    if os.path.exists(SourceFile):
        try:
            s=open(SourceFile).read()
            f=open(DestFile,'w')
            f.write(s)
            f.close()
            s.close()
        except: pass
def have_internet(url="www.google.com"):
    import httplib
    conn = httplib.HTTPConnection(url, timeout=5)
    try:
        conn.request("HEAD", "/")
        conn.close()
        return True
    except:
        conn.close()
def Refresh():
    return xbmc.executebuiltin("Container.Refresh")
def UpdateAddonRepos():
    return xbmc.executebuiltin("UpdateAddonRepos")
def UpdateLocalAddons():
    return xbmc.executebuiltin("UpdateLocalAddons")
def InstallAddonDirect(plugin):
    return xbmc.executebuiltin("RunPlugin(plugin://%s)" % plugin)
    #return xbmc.executebuiltin("InstallAddon(%s)" % plugin)
def GetAddonInfo():
    info = {}
    for key in ("author", "changelog", "description", "disclaimer", "fanart", "icon", "id", "name", "profile", "stars", "summary", "type", "version"):
        info[key] = ADDON.getAddonInfo(key)
    info['path'] = ADDON_PATH
    return info
'''
def Notify(header, message, image=ICON):
    return notify(getLocalizedLabel(message), header, 3000, image)
def Keyboard(default="", heading="", hidden=False):
    keyboard = xbmc.Keyboard(default, getLocalizedLabel(heading), hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
def Dialog(title, message):
    dialog = xbmcgui.Dialog()
    return dialog.ok(getLocalizedLabel(title), getLocalizedLabel(message))
def Dialog_Confirm(title, message):
    dialog = xbmcgui.Dialog()
    return dialog.yesno(getLocalizedLabel(title), getLocalizedLabel(message))
def Dialog_Select(title, items):
    dialog = xbmcgui.Dialog()
    return dialog.select(getLocalizedLabel(title), items)
def Dialog_Select_Large(title, subject, items):
    title_encoded = "%s %s" % (getLocalizedLabel(title), toUtf8(subject))
    # For Kodi <= 16
    if PLATFORM['kodi'] <= 16:
        window = DialogSelect("DialogSelectLargeLegacy.xml",
                              ADDON_PATH,
                              "Default",
                              title=title_encoded,
                              items=items)
    # For Kodi >= 17
    else:
        window = DialogSelect("DialogSelectLarge.xml",
                              ADDON_PATH,
                              "Default",
                              title=title_encoded,
                              items=items)
    window.doModal()
    retval = window.retval
    del window
    return retval
'''

###########################
## Making the Directory ###
###########################
# context menu
def createMenu(type, add, name):
    menu_items=[]
    name2 = urllib.quote_plus(name)
    name3 = os.path.basename(name2)
    menu_items.append((THEMEDEFAULTI %  '[COLOR %s]%s[/COLOR]   Settings' % (COLORDESC,ADDONTITLE), 'RunPlugin(plugin://%s/?mode=settings)'     % ADDON_ID))
    if   type == 'default':
        #menu_items.append((THEMEDEFAULTB % 'Wizard Refresh Screen',   'RunPlugin(plugin://%s/?mode=refresh)'     % ADDON_ID))
        #menu_items.append((THEMEDEFAULTB % 'View Wizard Log',         'RunPlugin(plugin://%s/?mode=viewwizlog)'  % ADDON_ID))
        menu_items.append((THEMETOGGLE % 'ONLINE   txt',      'RunPlugin(plugin://%s/?mode=togglesetting&name=ENABLEONLINE)'  % ADDON_ID))
        menu_items.append((THEMETOGGLE % 'OFFLINE  txt',      'RunPlugin(plugin://%s/?mode=togglesetting&name=ENABLEOFFLINE)'  % ADDON_ID))
        menu_items.append((THEMETOGGLE % 'XML         txt',   'RunPlugin(plugin://%s/?mode=togglesetting&name=ENABLEXML)'  % ADDON_ID))
        menu_items.append((THEMETOGGLE % 'Debug  (Log)',      'RunPlugin(plugin://%s/?mode=debug)'        % ADDON_ID))
    #
    elif type == 'saveaddon':
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEMEDEFAULT % name.title(),             ' '))
        menu_items.append((THEMESUBMENUITEMB % 'Save %s Data' % add3,            'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Restore %s Data' % add3,         'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Clear %s Data' % add3,           'RunPlugin(plugin://%s/?mode=clear%s&name=%s)' %   (ADDON_ID, add2, name2)))
    #  
    elif type == 'save':
        add2  = urllib.quote_plus(add.lower().replace(' ', ''))
        add3  = add.replace('Debrid', 'Real Debrid')
        name2 = urllib.quote_plus(name.lower().replace(' ', ''))
        name = name.replace('url', 'URL Resolver')
        menu_items.append((THEMEDEFAULT % name.title(),             ' '))
        menu_items.append((THEMESUBMENUITEMB % 'Register %s' % add3,             'RunPlugin(plugin://%s/?mode=auth%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Save %s Data' % add3,            'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Restore %s Data' % add3,         'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Import %s Data' % add3,          'RunPlugin(plugin://%s/?mode=import%s&name=%s)' %  (ADDON_ID, add2, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Clear Addon %s Data' % add3,     'RunPlugin(plugin://%s/?mode=addon%s&name=%s)' %   (ADDON_ID, add2, name2)))
    #
    elif type == 'install':
        menu_items.append((THEMEDEFAULT % name,                                'RunAddon(%s, ?mode=viewbuild&name=%s)'  % (ADDON_ID, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Fresh Install',                 'RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'  % (ADDON_ID, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Normal Install',                'RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)' % (ADDON_ID, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Apply guiFix',                  'RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'    % (ADDON_ID, name2)))
        menu_items.append((THEMESUBMENUITEMB % 'Build Information',             'RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'  % (ADDON_ID, name2)))
    #
    elif type == 'edityoutube':
        menu_items.append((THEMEDEFAULT % 'Create a txt plugin entry',          'RunPlugin(plugin://%s/?mode=addyoutube&url=%s)'  % (ADDON_ID, name2)))
        if add == 'youtube':  menu_items.append((THEMEDEFAULT % 'Refresh   "%s" Dir' % add,                   'RunPlugin(plugin://%s/?mode=refreshtxtmenu&url=%s)'  % (ADDON_ID, add)))
        if not add == 'youtube':   menu_items.append((THEMEDEFAULTB % 'Edit  xml',   'RunPlugin(plugin://%s/?mode=xmledityoutube&url=%s)'  % (ADDON_ID, add)))
        if os.path.isfile(name):       menu_items.append((THEMEDEFAULTB % 'Edit  txt',   'RunPlugin(plugin://%s/?mode=edityoutube&url=%s)'     % (ADDON_ID, name2)))
        if not os.path.isfile(name):  menu_items.append((THEMEDEFAULTB % 'Import  txt  %s' % name,   'RunPlugin(plugin://%s/?mode=importtxt&url=%s)'  % (ADDON_ID, name2)))
    #
    elif type == 'editapk':
        menu_items.append((THEMEDEFAULT % 'Create a txt plugin entry',          'RunPlugin(plugin://%s/?mode=addapk&url=%s)'  % (ADDON_ID, name2)))
        if add == 'apks':  menu_items.append((THEMEDEFAULT % 'Refresh   "%s" Dir' % add, 'RunPlugin(plugin://%s/?mode=refreshtxtmenu&url=%s)'  % (ADDON_ID, add)))
        if not add == 'apks':  menu_items.append((THEMEDEFAULTB % 'Edit  xml',   'RunPlugin(plugin://%s/?mode=xmleditapk&url=%s)'      % (ADDON_ID, add)))
        if os.path.isfile(name):      menu_items.append((THEMEDEFAULTB % 'Edit  txt',   'RunPlugin(plugin://%s/?mode=editapk&url=%s)'         % (ADDON_ID, name2)))
        if not os.path.isfile(name):  menu_items.append((THEMEDEFAULTB % 'Import  txt  %s' % name,   'RunPlugin(plugin://%s/?mode=importtxt&url=%s)'  % (ADDON_ID, name2)))
    #
    elif type == 'editbuilds':
        menu_items.append((THEMEDEFAULT % 'Create a txt plugin entry',          'RunPlugin(plugin://%s/?mode=addbuild&url=%s)'  % (ADDON_ID, name2)))
        if add == 'builds':  menu_items.append((THEMEDEFAULT % 'Refresh   "%s" Dir' % add,   'RunPlugin(plugin://%s/?mode=refreshtxtmenu&url=%s)'  % (ADDON_ID, add)))
        if not add == 'builds':  menu_items.append((THEMEDEFAULT % 'Edit  xml',       'RunPlugin(plugin://%s/?mode=xmleditbuilds&url=%s)'   % (ADDON_ID, add)))
        if os.path.isfile(name):      menu_items.append((THEMEDEFAULT % 'Edit  txt',       'RunPlugin(plugin://%s/?mode=editbuilds&url=%s)'      % (ADDON_ID, name2)))
        if not os.path.isfile(name):  menu_items.append((THEMEDEFAULTB % 'Import  txt  %s' % name,   'RunPlugin(plugin://%s/?mode=importtxt&url=%s)'  % (ADDON_ID, name2)))
    #
    elif type == 'editaddon':
        # 
        menu_items.append((THEMEDEFAULT % 'type %s add %s name %s name2 %s name3 %s' % (type, add, name,name2,name3),   'RunPlugin(plugin://%s/?mode=addaddon&url=%s)'  % (ADDON_ID, name2)))
        
        menu_items.append((THEMEDEFAULT % 'Create a txt plugin entry',   'RunPlugin(plugin://%s/?mode=addaddon&url=%s)'  % (ADDON_ID, name2)))
        ####
        if add == 'addons':
            menu_items.append((THEMEDEFAULT % 'Refresh   "%s" Dir' % add,   'RunPlugin(plugin://%s/?mode=refreshtxtmenu&url=%s)'  % (ADDON_ID, add)))
        #
        else:
            menu_items.append((THEMEDEFAULTB % 'Edit  xml',    'RunPlugin(plugin://%s/?mode=xmleditaddon&url=%s)'    % (ADDON_ID, add)))
        #
        if os.path.isfile(name):
            menu_items.append((THEMEDEFAULTB % 'Edit  %s'% name3,    'RunPlugin(plugin://%s/?mode=editaddon&url=%s)'       % (ADDON_ID, name2)))
        #
        if not os.path.isfile(name):
            menu_items.append((THEMEDEFAULTB % 'Import  txt  %s' % add,   'RunPlugin(plugin://%s/?mode=importtxt&url=%s)'  % (ADDON_ID, name2)))
        #####
    #
    # global
    if xbmc.getCondVisibility('system.platform.windows'):
        if os.path.isfile(name):  menu_items.append((THEMEDEFAULTB % 'Notepad  -  Edit txt',   'RunPlugin(plugin://%s/?mode=notepad&url=%s)'  % (ADDON_ID, name2)))
    if os.path.isfile(name):  menu_items.append((THEMEDEFAULTB %  'View    txt',        'RunPlugin(plugin://%s/?mode=helpMenu&url=%s)'       % (ADDON_ID, name2)))
    if os.path.isfile(name):  menu_items.append((THEMEDEFAULTB %  'Delete  txt',        'RunPlugin(plugin://%s/?mode=removetxtmenu&url=%s)'  % (ADDON_ID, name2)))
    menu_items.append((THEMEDEFAULTB % 'View    Log',                                   'RunPlugin(plugin://%s/?mode=viewlog)'      % ADDON_ID))
    menu_items.append((THEMEDEFAULTB % 'Refresh Addons',                                'RunPlugin(plugin://%s/?mode=forceupdate)'  % ADDON_ID))
    menu_items.append((THEMEWARNING %  '[COLOR %s]Fresh  Start[/COLOR]' % COLORTXT,     'RunPlugin(plugin://%s/?mode=freshstart)'   % ADDON_ID))
    menu_items.append((THEMEWARNING %  '[COLOR %s]Force  Close[/COLOR]' % COLORTXT,     'RunPlugin(plugin://%s/?mode=forceclose)'   % ADDON_ID))
    if xbmc.getCondVisibility('system.platform.android'):  menu_items.append((THEMEDEFAULTB % 'Android App Manager',  'RunPlugin(plugin://%s/?mode=androidappmanager&url=%s)'   % (ADDON_ID, name)))
    if xbmc.getCondVisibility('system.platform.android'):  menu_items.append((THEMEDEFAULTB % 'Android Kodi Settings',  'RunPlugin(plugin://%s/?mode=androidkodisettings&url=%s)' % (ADDON_ID, name)))
    if xbmc.getCondVisibility('system.platform.android'):  menu_items.append((THEMEDEFAULTB % 'Android Apps',  'RunPlugin(plugin://%s/?mode=androidapps&url=%s)'         % (ADDON_ID, name)))
    return menu_items
def addChromeSiteFile(display, name=None, url=None, mode=None, icon=None, stopPlayback=None, kiosk=None, description=None, themeit=THEMEDEFAULT): # chrome
    CHROMEKIOSK  = wiz.getS('CHROMEKIOSK')
    kiosk  = 'yes' if CHROMEKIOSK  == 'true' else 'no'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&stopPlayback="+urllib.quote_plus(stopPlayback)+"&kiosk="+urllib.quote_plus(kiosk)+"&description="+urllib.quote_plus(description)+"&themeit="+urllib.quote_plus(themeit)
    ok = True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo(type="Video", infoLabels={"Title": display, "Plot": descriptioninfo+description})
    liz.addContextMenuItems([('Edit Website Settings', 'RunPlugin(plugin://'+ADDON_ID+'/?mode=editSite&url='+urllib.quote_plus(name)+')',), ('Remove Website', 'RunPlugin(plugin://'+ADDON_ID+'/?mode=removeSite&url='+urllib.quote_plus(name)+')',)])
    #if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok
def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=THEMEDEFAULT):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url == None: u += "&url="+urllib.quote_plus(url)
    if menu     == None: menu = createMenu('default', '', '')
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": descriptioninfo+description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=THEMEDEFAULT):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
    if not name == None: u += "&name="+urllib.quote_plus(name)
    if not url  == None: u += "&url="+urllib.quote_plus(url)
    if menu     == None: menu = createMenu('default', '', '')
    ok=True
    if themeit: display = themeit % display
    liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": descriptioninfo+description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
        return param
#if not len(sys.argv) > 1: notify.vodguixml('vod.xml') ############# Run Vod if no params
params=get_params()
url=None
name=None
mode=None
try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass
wiz.log('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]' % (VERSION, mode if not mode == '' else None, name, url))
def setView(content, viewType):
    if wiz.getS('auto-view')=='true':
        views = wiz.getS(viewType)
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary':  views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
        wiz.ebi("Container.SetViewMode(%s)" %  views)
        '''
        # skin estuary
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
        '''
        '''
        # skin confluence
        if views == '55' and KODIV >= 17 and SKIN == 'skin.confluence': views = '50'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.confluence': views = '50'
        # skin mods
        if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary.16': views = '55'
        if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary.17': views = '55'
        if views == '50' and KODIV == 18 and SKIN == 'skin.estuary.18': views = '55'
        #estuary autoviews
        #<views>50,51,52,53,54,55,500,501,502</views>
        <include>View_50_List</include>
        <include>View_51_Poster</include>
        <include>View_52_IconWall</include>
        <include>View_53_Shift</include>
        <include>View_54_InfoWall</include>
        <include>View_55_WideList</include>
        <include>View_500_Wall</include>
        <include>View_501_Banner</include>
        <include>View_502_FanArt</include>
        '''
#if __name__ == '__main__':
#    plugin.run()
#if wiz.workingURL('www.google.com') == False: _notify('Checking Addon...', plugin, ICON, duration=1000)
if   mode==None             : index()
# builds
elif mode=='wizardupdate'   : wiz.wizardUpdate()
elif mode=='builds'         : buildMenu()
elif mode=='viewbuild'      : viewBuild(name)
elif mode=='buildinfo'      : buildInfo(name)
elif mode=='buildpreview'   : buildVideo(name)
elif mode=='install'        : buildWizard(name, url)
elif mode=='theme'          : buildWizard(name, mode, url)
elif mode=='viewthirdparty' : viewThirdList(name)
elif mode=='installthird'   : thirdPartyInstall(name, url)
elif mode=='editthird'      : editThirdParty(name); wiz.refresh()
# maintenence and cleaning
elif mode=='maint'          : maintMenu(name)
elif mode=='kodi17fix'      : wiz.kodi17Fix()
elif mode=='unknownsources' : skinSwitch.swapUS()
elif mode=='advancedsetting': advancedWindow(name)
elif mode=='autoadvanced'   : showAutoAdvanced(); wiz.refresh()
elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()
elif mode=='asciicheck'     : wiz.asciiCheck()
elif mode=='extractazip'    : wiz.extractAZip()
elif mode=='backupbuild'    : wiz.backUpOptions('build')
elif mode=='backupgui'      : wiz.backUpOptions('guifix')
elif mode=='backuptheme'    : wiz.backUpOptions('theme')
elif mode=='backupaddonpack': wiz.backUpOptions('addon pack')
elif mode=='backupaddon'    : wiz.backUpOptions('addondata')
elif mode=='oldThumbs'      : wiz.oldThumbs()
elif mode=='clearbackup'    : wiz.cleanupBackup()
elif mode=='convertpath'    : wiz.convertSpecial(HOME)
elif mode=='currentsettings': viewAdvanced()
elif mode=='fullclean'      : totalClean(); wiz.refresh()
elif mode=='clearcache'     : clearCache(); wiz.refresh()
elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
elif mode=='cleararchive'   : clearArchive(); wiz.refresh()
elif mode=='checksources'   : wiz.checkSources(); wiz.refresh()
elif mode=='checkrepos'     : wiz.checkRepos(); wiz.refresh()
elif mode=='freshstart'     : freshStart()
elif mode=='forceupdate'    : wiz.forceUpdate()
elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
elif mode=='forceclose'     : wiz.killxbmc()
elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
elif mode=='hidepassword'   : wiz.hidePassword()
elif mode=='unhidepassword' : wiz.unhidePassword()
elif mode=='enableaddons'   : enableAddons()
elif mode=='toggleaddon'    : wiz.toggleAddon(name, url); wiz.refresh()
elif mode=='togglecache'    : toggleCache(name); wiz.refresh()
elif mode=='toggleadult'    : wiz.toggleAdult(); wiz.refresh()
elif mode=='changefeq'      : changeFeq(); wiz.refresh()
elif mode=='uploadlog'      : uploadLog.Main()
elif mode=='viewlog'        : LogViewer()
elif mode=='viewwizlog'     : LogViewer(WIZLOG)
elif mode=='viewerrorlog'   : errorChecking()
elif mode=='viewerrorlast'  : errorChecking(last=True)
elif mode=='clearwizlog'    : f = open(WIZLOG, 'w'); f.close(); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Wizard Log Cleared![/COLOR]" % COLORHEADERTXT); wiz.refresh()
elif mode=='purgedb'        : purgeDb()
elif mode=='fixaddonupdate' : fixUpdate()
elif mode=='removeaddons'   : removeAddonMenu()
elif mode=='removeaddon'    : removeAddon(name)
elif mode=='removeaddondata': removeAddonDataMenu()
elif mode=='removedata'     : removeAddonData(name)
elif mode=='resetaddon'     : total = wiz.cleanHouse(ADDONDATA, ignore=True); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLORHEADER, ADDONTITLE), "[COLOR %s]Addon_Data reset[/COLOR]" % COLORHEADERTXT); wiz.refresh()
elif mode=='systeminfo'     : systemInfo()
elif mode=='restorezip'     : restoreit('build')
elif mode=='restoregui'     : restoreit('gui')
elif mode=='restoreaddon'   : restoreit('addondata')
elif mode=='restoreextzip'  : restoreextit('build')
elif mode=='restoreextgui'  : restoreextit('gui')
elif mode=='restoreextaddon': restoreextit('addondata')
elif mode=='writeadvanced'  : writeAdvanced(name, url)
elif mode=='speedtest'      : speedTest()
elif mode=='runspeedtest'   : runSpeedTest(); wiz.refresh()
elif mode=='clearspeedtest' : clearSpeedTest(); wiz.refresh()
elif mode=='viewspeedtest'  : viewSpeedTest(name); wiz.refresh()
# apk
elif mode=='apk'            : apkMenu(name, url)
elif mode=='apkscrape'      : apkScraper(name)
elif mode=='apkinstall'     : apkInstaller(name, url)
elif mode=='rominstall'     : romInstaller(name, url)
# youtube
elif mode=='youtube'        : youtube(name, url)
elif mode=='viewVideo'      : playVideo(url)
# addons
elif mode=='addons'         : addonMenu(name, url)
elif mode=='addonpack'      : packInstaller(name, url)
elif mode=='skinpack'       : skinInstaller(name, url)
elif mode=='addoninstall'   : addonInstaller(name, url)
elif mode=='addonbuildpack' : packbuildInstaller(name, url)

#elif mode=='addoninstall'   : addonInstaller(plugin, url)
# save data
elif mode=='savedata'       : saveMenu()
elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()
elif mode=='managedata'     : manageSaveData(name)
elif mode=='whitelist'      : wiz.whiteList(name)
# trakt dabrid credentials
elif mode=='trakt'          : traktMenu()
elif mode=='savetrakt'      : traktit.traktIt('update',      name)
elif mode=='restoretrakt'   : traktit.traktIt('restore',     name)
elif mode=='addontrakt'     : traktit.traktIt('clearaddon',  name)
elif mode=='cleartrakt'     : traktit.clearSaved(name)
elif mode=='authtrakt'      : traktit.activateTrakt(name); wiz.refresh()
elif mode=='updatetrakt'    : traktit.autoUpdate('all')
elif mode=='importtrakt'    : traktit.importlist(name); wiz.refresh()
# real dabrid credentials
elif mode=='realdebrid'     : realMenu()
elif mode=='savedebrid'     : debridit.debridIt('update',      name)
elif mode=='restoredebrid'  : debridit.debridIt('restore',     name)
elif mode=='addondebrid'    : debridit.debridIt('clearaddon',  name)
elif mode=='cleardebrid'    : debridit.clearSaved(name)
elif mode=='authdebrid'     : debridit.activateDebrid(name); wiz.refresh()
elif mode=='updatedebrid'   : debridit.autoUpdate('all')
elif mode=='importdebrid'   : debridit.importlist(name); wiz.refresh()
# alluc credentials
elif mode=='alluc'          : allucMenu()
elif mode=='savealluc'      : allucit.allucIt('update',      name)
elif mode=='restorealluc'   : allucit.allucIt('restore',     name)
elif mode=='addonalluc'     : allucit.allucIt('clearaddon',  name)
elif mode=='clearalluc'     : allucit.clearSaved(name)
elif mode=='authalluc'      : allucit.activateAlluc(name); wiz.refresh()
elif mode=='updatealluc'    : allucit.autoUpdate('all')
elif mode=='importalluc'    : allucit.importlist(name); wiz.refresh()
# login credentials
elif mode=='login'          : loginMenu()
elif mode=='savelogin'      : loginit.loginIt('update',      name)
elif mode=='restorelogin'   : loginit.loginIt('restore',     name)
elif mode=='addonlogin'     : loginit.loginIt('clearaddon',  name)
elif mode=='clearlogin'     : loginit.clearSaved(name)
elif mode=='authlogin'      : loginit.activateLogin(name); wiz.refresh()
elif mode=='updatelogin'    : loginit.autoUpdate('all')
elif mode=='importlogin'    : loginit.importlist(name); wiz.refresh()
# group contact info
elif mode=='contact'        : notify.contact(CONTACT)
elif mode=='settings'       : wiz.openS(name); wiz.refresh()
elif mode=='forcetext'      : wiz.forceText()
elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()
# developer test and advanced settings
elif mode=='developer'      : developer()
elif mode=='converttext'    : wiz.convertText()
elif mode=='createqr'       : wiz.createQR()
elif mode=='testnotify'     : testnotify()
elif mode=='testupdate'     : testupdate()
elif mode=='testfirst'      : testfirst()
elif mode=='testfirstrun'   : testfirstRun()
################################################################################
###################### new
################################################################################
# Menus
elif mode=='cleaningMenu'          : cleaningMenu()
elif mode=='buildsMenu'            : buildsMenu()
elif mode=='backupMenu'            : backupMenu()
elif mode=='helpMenu'              : helpMenu(url)
elif mode=='xmlMenu'               : xmlMenu()
######################
#  xml files
elif mode=='logMenu'               : logMenu()
elif mode=='delautoadvanced'       : delete_file_prompt(ADVANCED);wiz.refresh()
elif mode=='delplayercorefactory'  : delete_file_prompt(PLAYERCORE);wiz.refresh()
elif mode=='delsources'            : delete_file_prompt(SOURCES);wiz.refresh()
elif mode=='delRssFeeds'           : delete_file_prompt(RSSFEED);wiz.refresh()
elif mode=='doWriterss'            : doWriterss();wiz.refresh(); _notify('Done','Done Writing RSS.xml',ICON)
elif mode=='doWritesources'        : doWritesources();wiz.refresh(); _notify('Done','Done Writing sources.xml',ICON)
elif mode=='doWriteplayerfactorycore': doWriteplayerfactorycore();wiz.refresh(); _notify('Done','Done Writing playerfactorycore.xml',ICON)
######################
# Github Browser
elif mode=='githubmain'            : github_main()
elif mode=='github_update'         : github_update()
elif mode=='github_instructions'   : github_instructions()
elif mode=='github_install'        : github_install(url)
elif mode=='github_search_username': github_search('username')
elif mode=='github_search_repo'    : github_search('repo')
elif mode=='github_search_addon_id': github_search('addon_id')
######################
# edit txt menu global
elif mode=='removetxtmenu'         : removetxtmenu(url)
elif mode=='refreshtxtmenu'        : refreshtxtmenu(url)
elif mode=='importtxt'             : importtxt(url)
######################
# media
elif mode=='mediaMenu'             : mediaMenu()
elif mode=='m3uMenu'               : m3uMenu()
elif mode=='playm3u'               : playm3u(url)
elif mode=='tvguidesettings'       : tvguidesettings()
#elif mode=='vodguixml'            : notify.vodguixml('vod.xml')
elif mode=='skin_settings_minimal' : skin_settings_minimal()
elif mode=='skin_settings'         : skin_settings()
######################
# chrome
elif mode=='chromeMenu'            : chromeMenu()
elif mode=='addSite'               : addSite()
elif mode=='showSite'              : showSite(url, 'no', 'no', userAgent) # showSite(url, stopPlayback, kiosk, userAgent)
elif mode=='removeSite'            : removeSite(url)
elif mode=='editSite'              : editSite(url)
######################
# youtube
elif mode=='youtubeMenu'           : youtubeMenu(name)
elif mode=='viewVideo'             : playVideo(url)
elif mode=='addyoutube'            : addyoutube(url)
elif mode=='edityoutube'           : edityoutube(url)
elif mode=='xmledityoutube'        : xmledityoutube(url)
######################
# apk Menu
elif mode=='androidappmanager'     : xbmc.executebuiltin('StartAndroidActivity(,android.settings.APPLICATION_SETTINGS)')
elif mode=='androidkodisettings'   : xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS","","package:org.xbmc.kodi")')
elif mode=='androidapps'           : xbmc.executebuiltin('ActivateWindow(10001,androidapp://sources/apps/, return)')#Android Apps
#elif mode=='androidprograms'      : xbmc.executebuiltin('ActivateWindow(Programs)')
#elif mode=='androidsettings'      : xbmc.executebuiltin('ActivateWindow(10001,androidsetting://sources/settings/, return)')#Android Settings
#elif mode=='androidprogramaddons' : xbmc.executebuiltin('ActivateWindow(10001,addons://sources/executable/, return)')#Program Addons
elif mode=='apkMenuMain'           : apkMenuMain()
elif mode=='addapk'                : addapk(url)
elif mode=='editapk'               : editapk(url)
elif mode=='xmleditapk'            : xmleditapk(url)
elif mode=='chooseofflineapk'      : chooseofflineapk(url)
######################
# addons Menu
elif mode=='addonMenuMain'         : addonMenuMain()
elif mode=='addonMenuTools'        : addonMenuTools()
elif mode=='addonMenuoffline'      : addonMenuoffline(name, url)

elif mode=='addaddon'              : addaddon(url)
elif mode=='editaddon'             : editaddon(url)
elif mode=='xmleditaddon'          : xmleditaddon(url)
elif mode=='chooseofflineaddon'    : chooseofflineaddon(url)
elif mode=='checkdeps'             : checkdeps()
######################
# windows
elif mode=='windowsMenu'           : windowsMenu()
elif mode=='runexe'                : run_exe(name, url)
elif mode=='notepad'               : run_exe('C:/Windows/System32/notepad.exe', url)
######################
# Extra Functions
elif mode=='EnableRTMP'            : EnableRTMP()
elif mode=='emaillog'              : email_log()
elif mode=='debug'                 : EnableDebug()
elif mode=='Repolink'              : Repolink(REPOID);sys.exit(0)
elif mode=='cloneaddon'            : clone_addon()
elif mode=='choosebackupfolder'    : choosebackupfolder(url);wiz.refresh()
######################
# keymap
elif mode=='install_keymap'        : install_keymap()
elif mode=='uninstall_keymap'      : uninstall_keymap()
elif mode=='installxmls'           : XML_All()
# wip
######################
elif mode=='DBremove'              : DBremove()                                 # wip
elif mode=='importaddons'           : importaddons()
#elif mode=='importaddons'          : importaddons()
elif mode=='exportaddons'           : exportaddons()
# builds
#elif mode=='addbuild'              : addbuild(url)  # wip
#elif mode=='editbuild'             : editbuild(url)  # wip
#elif mode=='xmleditbuild'          : xmleditbuild(url)  # wip
######################



'''
elif mode=='installzip'             : installzip()#RunAddon()#Install from zip file  RunAddon()
elif mode=='zipinstaller'          : zipinstaller()#Indigo Wizard              PlayMedia(plugin://plugin.program.xyzwizard/?mode=addoninstall&name=plugin.program.indigo)
elif mode=='Myaddons'              : Myaddons()#My add-ons                     ActivateWindow(10040,addons://user/,return)
elif mode=='Videoaddons'           : Videoaddons()#Video add-ons               ActivateWindow(10040,addons://user/xbmc.addon.video,return)
elif mode=='Addonrepository'       : Addonrepository()#Add-on repository       ActivateWindow(10040,addons://user/xbmc.addon.repository,return)
elif mode=='recently_updated'      : recently_updated()#Recently updated       ActivateWindow(10040,addons://recently_updated/,return)
elif mode=='Installfromrepository' : Installfromrepository()#Install from      ActivateWindow(10040,addons://repos/,return)
elif mode=='reposearch'            : reposearch()#Search                       ActivateWindow(10040,addons://search/,return)
#elif mode=='Addonrepository'       : Addonrepository()#Add-on repository       ActivateWindow(10040,addons://repository._xyz/xbmc.addon.repository,return)
elif mode=='Programaddons'         : Programaddons()#Program add-ons           ActivateWindow(10040,addons://repository._xyz/xbmc.addon.executable,return)
elif mode=='Lookandfeel'           : Lookandfeel()#Look and feel               ActivateWindow(10040,addons://repository._xyz/category.lookandfeel,return)
'''







xbmcplugin.endOfDirectory(int(sys.argv[1]))
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################
