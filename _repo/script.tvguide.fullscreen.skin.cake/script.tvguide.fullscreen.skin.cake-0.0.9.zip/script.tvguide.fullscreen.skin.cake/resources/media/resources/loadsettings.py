# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
'''
import sys
import os
import xbmcvfs
import shutil
import re
import glob
import string
import json
'''
ADDONID   = 'script.tvguide.fullscreen.skin.cake'
#ADDON     = xbmcaddon.Addon(id=ADDONID)
# reopen
#xbmc.executebuiltin('Dialog.Close(all,true)')
#xbmc.executebuiltin('ActivateWindow(home)')
#xbmc.sleep(500)
#addonPath = xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID))
#xbmc.executebuiltin('RunScript('+ addonPath + '/addon.py)')
xbmcaddon.Addon(id=ADDONID).openSettings()

