# -*- coding: utf-8 -*-
import sys
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
import os
import shutil
import re
import glob
ADDONID        = 'script.tvguide.fullscreen.skin.cake'
ADDON          = xbmcaddon.Addon(id=ADDONID)
addonPath      = xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID))
basePath       = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDONID))
#addonPath      = os.path.join('special://home', 'addons', ADDONID)
#basePath       = os.path.join('special://profile', 'addon_data', ADDONID)
#
ADDONID_TVGFS        = 'script.tvguide.fullscreen'
if not os.path.exists(xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID_TVGFS))): xbmc.executebuiltin('RunPlugin(plugin://%s)' % ADDONID_TVGFS)
if not os.path.exists(xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID_TVGFS))): ADDON_TVGFS = xbmcaddon.Addon(id=ADDONID)
if os.path.exists(xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID_TVGFS))): ADDON_TVGFS  = xbmcaddon.Addon(id=ADDONID_TVGFS)
addonPath_tvgfs      = xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID_TVGFS))
basePath_tvgfs       = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDONID_TVGFS))
#addonPath_tvgfs      = os.path.join('special://home', 'addons', ADDONID_TVGFS)
#basePath_tvgfs       = os.path.join('special://profile', 'addon_data', ADDONID_TVGFS)
#
# set skin user vars
skin                 = ADDON.getSetting('skin.user')   if not ADDON.getSetting('skin.user') == ''   else 'Cake'
skinfolder           = ADDON.getSetting('skin.folder') if not ADDON.getSetting('skin.folder') == '' else addonPath
skinPath             = xbmc.translatePath(os.path.join(skinfolder,'resources','skins',skin))# for skin toggle mods
#skinPath             = os.path.join(skinfolder,'resources','skins',skin)# for skin toggle mods
fadepath             = xbmc.translatePath(os.path.join(skinPath,'media','fade/'))
fadewhitepath        = xbmc.translatePath(os.path.join(skinPath,'media','fadewhite/'))



def set_skin_vars():
    # these are the main addons and paths
    #_set_vars('rez',rez)# not used yet and 180i should be avoided imo until the logo alignment works
    _set_vars('main_addon',ADDONID_TVGFS)# ie  tvgfs
    _set_vars('skin_addon',ADDONID)# this addon
    _set_vars('skin',skin)# this skin
    _set_vars('skin_folder',skinfolder)# this skin path
    #_set_vars('skin_path',xbmc.translatePath(os.path.join(skinfolder, 'resources', 'skins', skin)))# this skin
    _set_vars('skin_path',skinfolder+ '/resources/skins/'+ skin)# this skin
    _set_vars('run_script','special://home/addons/'+ADDONID+'/installer.py')# to run this py for future scripts
    #
    # color diffuse
    _set_vars('color_popup_background',remove_formatting(ADDON.getSetting('var.color_popup_background'))) if not remove_formatting(ADDON.getSetting('var.color_popup_background')) == '' else 'steelblue'
    _set_vars('color_bar',remove_formatting(ADDON.getSetting('var.color_bar'))) if not remove_formatting(ADDON.getSetting('var.color_bar')) == '' else 'lightgreen'
    _set_vars('color_description_bar',remove_formatting(ADDON.getSetting('var.color_description_bar'))) if not remove_formatting(ADDON.getSetting('var.color_description_bar')) == '' else 'green'
    _set_vars('color_description_info',remove_formatting(ADDON.getSetting('var.color_description_info'))) if not remove_formatting(ADDON.getSetting('var.color_description_info')) == '' else 'skyblue'
    _set_vars('color_channelbg',remove_formatting(ADDON.getSetting('var.color_channelbg'))) if not remove_formatting(ADDON.getSetting('var.color_channelbg')) == '' else 'black'
    _set_vars('color_epgbg',remove_formatting(ADDON.getSetting('var.color_epgbg'))) if not remove_formatting(ADDON.getSetting('var.color_epgbg')) == '' else 'dimgrey'
    _set_vars('color_focus',remove_formatting(ADDON.getSetting('var.color_focus'))) if not remove_formatting(ADDON.getSetting('var.color_focus')) == '' else 'darkgreen'
    _set_vars('color_focus_current',remove_formatting(ADDON.getSetting('var.color_focus_current'))) if not remove_formatting(ADDON.getSetting('var.color_focus_current')) == '' else 'forrestgreen'
    _set_vars('color_scrollbarbg',remove_formatting(ADDON.getSetting('var.color_scrollbarbg'))) if not remove_formatting(ADDON.getSetting('var.color_scrollbarbg')) == '' else 'dimgrey'
    _set_vars('color_scrollbarnf',remove_formatting(ADDON.getSetting('var.color_scrollbarnf'))) if not remove_formatting(ADDON.getSetting('var.color_scrollbarnf')) == '' else 'black'
    _set_vars('color_progress',remove_formatting(ADDON.getSetting('var.color_progress'))) if not remove_formatting(ADDON.getSetting('var.color_progress')) == '' else 'darkcyan'
    #
    # images
    _set_vars('image_fade','fade/'+ADDON.getSetting('var.image_fade')) if not ADDON.getSetting('var.image_fade') == '' else 'fade/50.png'
    _set_vars('image_fadebg','fade/'+ADDON.getSetting('var.image_fadebg')) if not ADDON.getSetting('var.image_fadebg') == '' else 'fade/50.png'
    _set_vars('image_fadewhite','fadewhite/'+ADDON.getSetting('var.image_fadewhite')) if not ADDON.getSetting('var.image_fadewhite') == '' else 'fadewhite/50.png'
    _set_vars('image_fadewhitebg','fadewhite/'+ADDON.getSetting('var.image_fadewhitebg')) if not ADDON.getSetting('var.image_fadewhitebg') == '' else 'fadewhite/50.png'
    _set_vars('image_helpmarker',ADDON.getSetting('var.image_helpmarker')) if not ADDON.getSetting('var.image_helpmarker') == '' else 'backgrounds/help_marker.png'
    #
    #
    ## Skin Specific ##
    _set_vars('osd_align',  ADDON.getSetting('skin.osd_align')) if not ADDON.getSetting('skin.osd_align') == '' else 'top'
    _set_vars('theme_epg',  ADDON.getSetting('skin.theme_epg')) if not ADDON.getSetting('skin.theme_epg') == '' else 'Default'
    _set_vars('image_flags',ADDON.getSetting('skin.image_flags')) if not ADDON.getSetting('skin.image_flags') == '' else '_grey'
    _set_vars('eyecandy',remove_formatting(ADDON.getSetting('var.eyecandy'))) if not remove_formatting(ADDON.getSetting('var.eyecandy')) == '' else 'false'
    _set_vars('yoda',remove_formatting(ADDON.getSetting('var.yoda'))) if not remove_formatting(ADDON.getSetting('var.yoda')) == '' else 'false'
    _set_vars('xps_playlists',xbmc.translatePath(os.path.join(skinPath,'playlists')))
    #_set_vars('xps_playlists',skinPath+'/playlists')
    #_set_vars('xps_playlists',ADDON.getSetting('skin.xps_playlists')) if not ADDON.getSetting('skin.xps_playlists') == '' else 'special://profile/addon_data/'+ADDONID+'/resources/playlists/'
    #_set_vars('xps_playlists',ADDON.getSetting('skin.xps_playlists')) if not ADDON.getSetting('skin.xps_playlists') == '' else skinPath+'/playlists/'
    #
    # VOD #
    #
    # vod1 root widget
    if not ADDON.getSetting('vodrootvisible') == 'false':  _set_vars('vodrootvisible', 'true'); _set_vars('vodrootwidget', ADDON.getSetting('vodrootwidget'));  _set_vars('vodroottitle', ADDON.getSetting('vodroottitle')); _set_vars('vodrootpath', ADDON.getSetting('vodrootpath')); _set_vars('vodrootthumb', ADDON.getSetting('vodrootthumb'))
    # vod2 root widget
    if not ADDON.getSetting('vod2rootvisible') == 'false':  _set_vars('vod2rootvisible', 'true'); _set_vars('vod2rootwidget', ADDON.getSetting('vod2rootwidget'));  _set_vars('vod2roottitle', ADDON.getSetting('vod2roottitle')); _set_vars('vod2rootpath', ADDON.getSetting('vod2rootpath')); _set_vars('vod2rootthumb', ADDON.getSetting('vod2rootthumb'))
    # vod1 widgets
    _set_vars('vodenable', ADDON.getSetting('vodenable'))
    #if not ADDON.getSetting('vodenable') == 'false':  _set_vars('vodenable', 'true')
    #_set_vars('vodenable','true') if not ADDON.getSetting('vodenable') == 'false' else 'false'
    if not ADDON.getSetting('vodvisible1') == 'false':  _set_vars('vodvisible1', ADDON.getSetting('vodvisible1')); _set_vars('vodwidget1', ADDON.getSetting('vodwidget1'));  _set_vars('vodtitle1', ADDON.getSetting('vodtitle1')); _set_vars('vodpath1', ADDON.getSetting('vodpath1')); _set_vars('vodthumb1', ADDON.getSetting('vodthumb1'))
    if not ADDON.getSetting('vodvisible2') == 'false':  _set_vars('vodvisible2', ADDON.getSetting('vodvisible2')); _set_vars('vodwidget2', ADDON.getSetting('vodwidget2')); _set_vars('vodtitle2', ADDON.getSetting('vodtitle2')); _set_vars('vodpath2', ADDON.getSetting('vodpath2')); _set_vars('vodthumb2', ADDON.getSetting('vodthumb2'))
    if not ADDON.getSetting('vodvisible3') == 'false':  _set_vars('vodvisible3', ADDON.getSetting('vodvisible3')); _set_vars('vodwidget3', ADDON.getSetting('vodwidget3'));  _set_vars('vodtitle3', ADDON.getSetting('vodtitle3')); _set_vars('vodpath3', ADDON.getSetting('vodpath3')); _set_vars('vodthumb3', ADDON.getSetting('vodthumb3'))
    if not ADDON.getSetting('vodvisible4') == 'false':  _set_vars('vodvisible4', ADDON.getSetting('vodvisible4')); _set_vars('vodwidget4', ADDON.getSetting('vodwidget4'));  _set_vars('vodtitle4', ADDON.getSetting('vodtitle4')); _set_vars('vodpath4', ADDON.getSetting('vodpath4')); _set_vars('vodthumb4', ADDON.getSetting('vodthumb4'))
    if not ADDON.getSetting('vodvisible5') == 'false':  _set_vars('vodvisible5', ADDON.getSetting('vodvisible5')); _set_vars('vodwidget5', ADDON.getSetting('vodwidget5'));  _set_vars('vodtitle5', ADDON.getSetting('vodtitle5')); _set_vars('vodpath5', ADDON.getSetting('vodpath5')); _set_vars('vodthumb5', ADDON.getSetting('vodthumb5'))
    if not ADDON.getSetting('vodvisible6') == 'false':  _set_vars('vodvisible6', ADDON.getSetting('vodvisible6')); _set_vars('vodwidget6', ADDON.getSetting('vodwidget6'));  _set_vars('vodtitle6', ADDON.getSetting('vodtitle6')); _set_vars('vodpath6', ADDON.getSetting('vodpath6')); _set_vars('vodthumb6', ADDON.getSetting('vodthumb6'))
    if not ADDON.getSetting('vodvisible7') == 'false':  _set_vars('vodvisible7', ADDON.getSetting('vodvisible7')); _set_vars('vodwidget7', ADDON.getSetting('vodwidget7'));  _set_vars('vodtitle7', ADDON.getSetting('vodtitle7')); _set_vars('vodpath7', ADDON.getSetting('vodpath7')); _set_vars('vodthumb7', ADDON.getSetting('vodthumb7'))
    if not ADDON.getSetting('vodvisible8') == 'false':  _set_vars('vodvisible8', ADDON.getSetting('vodvisible8')); _set_vars('vodwidget8', ADDON.getSetting('vodwidget8'));  _set_vars('vodtitle8', ADDON.getSetting('vodtitle8')); _set_vars('vodpath8', ADDON.getSetting('vodpath8')); _set_vars('vodthumb8', ADDON.getSetting('vodthumb8'))
    if not ADDON.getSetting('vodvisible9') == 'false':  _set_vars('vodvisible9', ADDON.getSetting('vodvisible9')); _set_vars('vodwidget9', ADDON.getSetting('vodwidget9')); _set_vars('vodtitle9', ADDON.getSetting('vodtitle9')); _set_vars('vodpath9', ADDON.getSetting('vodpath9')); _set_vars('vodthumb9', ADDON.getSetting('vodthumb9'))
    if not ADDON.getSetting('vodvisible10') == 'false':  _set_vars('vodvisible10', ADDON.getSetting('vodvisible10')); _set_vars('vodwidget10', ADDON.getSetting('vodwidget10')); _set_vars('vodtitle10',ADDON.getSetting('vodtitle10'));_set_vars('vodpath10',ADDON.getSetting('vodpath10'));_set_vars('vodthumb10',ADDON.getSetting('vodthumb10'))
    if not ADDON.getSetting('vodvisible11') == 'false':  _set_vars('vodvisible11', ADDON.getSetting('vodvisible11')); _set_vars('vodwidget11', ADDON.getSetting('vodwidget11')); _set_vars('vodtitle11',ADDON.getSetting('vodtitle11'));_set_vars('vodpath11',ADDON.getSetting('vodpath11'));_set_vars('vodthumb11',ADDON.getSetting('vodthumb11'))
    if not ADDON.getSetting('vodvisible12') == 'false':  _set_vars('vodvisible12', ADDON.getSetting('vodvisible12')); _set_vars('vodwidget12', ADDON.getSetting('vodwidget12')); _set_vars('vodtitle12',ADDON.getSetting('vodtitle12'));_set_vars('vodpath12',ADDON.getSetting('vodpath12'));_set_vars('vodthumb12',ADDON.getSetting('vodthumb12'))
    # vod2 widgets
    _set_vars('vod2enable',ADDON.getSetting('vod2enable'))
    #_set_vars('vod2enable','true') if not ADDON.getSetting('vod2enable') == 'false' else 'false'
    #if not ADDON.getSetting('vod2enable') == 'false':  _set_vars('vod2enable', 'true')
    if not ADDON.getSetting('vod2visible1') == 'false':  _set_vars('vod2visible1', ADDON.getSetting('vod2visible1')); _set_vars('vod2widget1', ADDON.getSetting('vod2widget1'));  _set_vars('vod2title1', ADDON.getSetting('vod2title1')); _set_vars('vod2path1', ADDON.getSetting('vod2path1')); _set_vars('vod2thumb1', ADDON.getSetting('vod2thumb1'))
    if not ADDON.getSetting('vod2visible2') == 'false':  _set_vars('vod2visible2', ADDON.getSetting('vod2visible2')); _set_vars('vod2widget2', ADDON.getSetting('vod2widget2'));  _set_vars('vod2title2', ADDON.getSetting('vod2title2')); _set_vars('vod2path2', ADDON.getSetting('vod2path2')); _set_vars('vod2thumb2', ADDON.getSetting('vod2thumb2'))
    if not ADDON.getSetting('vod2visible3') == 'false':  _set_vars('vod2visible3', ADDON.getSetting('vod2visible3')); _set_vars('vod2widget3', ADDON.getSetting('vod2widget3'));  _set_vars('vod2title3', ADDON.getSetting('vod2title3')); _set_vars('vod2path3', ADDON.getSetting('vod2path3')); _set_vars('vod2thumb3', ADDON.getSetting('vod2thumb3'))
    if not ADDON.getSetting('vod2visible4') == 'false':  _set_vars('vod2visible4', ADDON.getSetting('vod2visible4')); _set_vars('vod2widget4', ADDON.getSetting('vod2widget4'));  _set_vars('vod2title4', ADDON.getSetting('vod2title4')); _set_vars('vod2path4', ADDON.getSetting('vod2path4')); _set_vars('vod2thumb4', ADDON.getSetting('vod2thumb4'))
    if not ADDON.getSetting('vod2visible5') == 'false':  _set_vars('vod2visible5', ADDON.getSetting('vod2visible5')); _set_vars('vod2widget5', ADDON.getSetting('vod2widget5'));  _set_vars('vod2title5', ADDON.getSetting('vod2title5')); _set_vars('vod2path5', ADDON.getSetting('vod2path5')); _set_vars('vod2thumb5', ADDON.getSetting('vod2thumb5'))
    if not ADDON.getSetting('vod2visible6') == 'false':  _set_vars('vod2visible6', ADDON.getSetting('vod2visible6')); _set_vars('vod2widget6', ADDON.getSetting('vod2widget6'));  _set_vars('vod2title6', ADDON.getSetting('vod2title6')); _set_vars('vod2path6', ADDON.getSetting('vod2path6')); _set_vars('vod2thumb6', ADDON.getSetting('vod2thumb6'))
    if not ADDON.getSetting('vod2visible7') == 'false':  _set_vars('vod2visible7', ADDON.getSetting('vod2visible7')); _set_vars('vod2widget7', ADDON.getSetting('vod2widget7'));  _set_vars('vod2title7', ADDON.getSetting('vod2title7')); _set_vars('vod2path7', ADDON.getSetting('vod2path7')); _set_vars('vod2thumb7', ADDON.getSetting('vod2thumb7'))
    if not ADDON.getSetting('vod2visible8') == 'false':  _set_vars('vod2visible8', ADDON.getSetting('vod2visible8')); _set_vars('vod2widget8', ADDON.getSetting('vod2widget8'));  _set_vars('vod2title8', ADDON.getSetting('vod2title8')); _set_vars('vod2path8', ADDON.getSetting('vod2path8')); _set_vars('vod2thumb8', ADDON.getSetting('vod2thumb8'))
    if not ADDON.getSetting('vod2visible9') == 'false':  _set_vars('vod2visible9', ADDON.getSetting('vod2visible9')); _set_vars('vod2widget9', ADDON.getSetting('vod2widget9'));   _set_vars('vod2title9', ADDON.getSetting('vod2title9')); _set_vars('vod2path9', ADDON.getSetting('vod2path9')); _set_vars('vod2thumb9', ADDON.getSetting('vod2thumb9'))
    if not ADDON.getSetting('vod2visible10') == 'false':  _set_vars('vod2visible10', ADDON.getSetting('vod2visible10')); _set_vars('vod2widget10', ADDON.getSetting('vod2widget10'));  _set_vars('vod2title10',ADDON.getSetting('vod2title10'));_set_vars('vod2path10',ADDON.getSetting('vod2path10'));_set_vars('vod2thumb10',ADDON.getSetting('vod2thumb10'))
    if not ADDON.getSetting('vod2visible11') == 'false':  _set_vars('vod2visible11', ADDON.getSetting('vod2visible11')); _set_vars('vod2widget11', ADDON.getSetting('vod2widget11'));  _set_vars('vod2title11',ADDON.getSetting('vod2title11'));_set_vars('vod2path11',ADDON.getSetting('vod2path11'));_set_vars('vod2thumb11',ADDON.getSetting('vod2thumb11'))
    if not ADDON.getSetting('vod2visible12') == 'false':  _set_vars('vod2visible12', ADDON.getSetting('vod2visible12')); _set_vars('vod2widget12', ADDON.getSetting('vod2widget12'));  _set_vars('vod2title12',ADDON.getSetting('vod2title12'));_set_vars('vod2path12',ADDON.getSetting('vod2path12'));_set_vars('vod2thumb12',ADDON.getSetting('vod2thumb12'))
    #
    # this is for the flip toggle and is based on a condition statement using slide animations
    #_set_vars('referencenumber','240.6')# 240.6 or 30.6
    _set_vars('referencenumber',ADDON.getSetting('skin.referencenumber')) if not ADDON.getSetting('skin.referencenumber') == '' else '240.6'
    if xbmc.getCondVisibility('String.IsEqual(Window(home).Property(referencenumber),)'): _set_vars('referencenumber','240.6')# 5001 bullshit
    if not xbmc.getCondVisibility('String.IsEqual(Window(home).Property(referencenumber),240.6)'): _set_vars('flip_vertical','true');ADDON.setSetting('skin.flip_vertical','true')# toggle
    else:  _set_vars('flip_vertical','false');ADDON.setSetting('skin.flip_vertical','false')# toggle
    if ADDON.getSetting('skin.flip_horizontal') == 'true': _set_vars('flip_horizontal','true')# toggle
    else: _set_vars('flip_horizontal','false')# toggle
    # end #

def _set_vars(thevar,varset): xbmc.executebuiltin('SetProperty('+thevar+','+varset+',home)')# home sets the kodi default custom stuff window id you can maybe change it
def remove_formatting(label):
    label = re.sub(r"\[/?[BI]\]",'',label)
    label = re.sub(r"\[/?COLOR.*?\]",'',label)
    return label
################################################################################
##### Run
################################################################################
if __name__ == '__main__':
    set_skin_vars()
    