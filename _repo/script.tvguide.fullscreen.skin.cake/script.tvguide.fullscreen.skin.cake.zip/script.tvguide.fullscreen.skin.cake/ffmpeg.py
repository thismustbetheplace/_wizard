# -*- coding: utf-8 -*-
import sys
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
import os
import shutil
import re
import glob
import urllib
from datetime import datetime
nowtime = datetime.now().strftime('%Y-%m-%d %H.%M.%S')

ADDONID        = 'script.tvguide.fullscreen.skin.cake'
ADDON          = xbmcaddon.Addon(id=ADDONID)
addonPath      = xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID))
basePath       = xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDONID))

#title = xbmc.getInfoLabel('Player.Title')
Filenameandpath = xbmc.getInfoLabel('Player.Filenameandpath')
actualtitle = xbmcgui.Window(10000).getProperty('tvgfs_currentprogram')
for rep in [r"\[/?[BI]\]", r"\[/?COLOR.*?\]",]: # removes bold and colour
    actualtitle = re.sub(rep, '', actualtitle) 

dest = ADDON.getSetting('autoplaywiths.folder') if not ADDON.getSetting('autoplaywiths.folder') == '' else xbmc.translatePath("special://temp/")
#file = '_'+nowtime+'_'+actualtitle+title+'.mkv'
file = actualtitle+' '+nowtime+'.mkv'
file = file.replace('*','')

url = re.sub(r'.*url=h', 'h', Filenameandpath)
url = re.sub(r'&mode=.*', '', url)
url = urllib.unquote(url).decode('utf8') 

duration = '24:00:00'
dialog = xbmcgui.Dialog()
setduration = dialog.select('[COLOR grey]Set Recording Duration  ●[/COLOR] ' +actualtitle, ['Record Indefinitely',
'30  minutes',
'60  minutes',
'90  minutes',
'120 minutes',
'3 hours',
'4 hours'])
if setduration == 0:  duration = '24:00:00'
#if setduration == 0:  duration = '00:00:30'
if setduration == 1:  duration = '00:30:00'
if setduration == 2:  duration = '01:00:00'
if setduration == 3:  duration = '01:30:00'
if setduration == 4:  duration = '02:00:00'
if setduration == 5:  duration = '03:00:00'
if setduration == 6:  duration = '04:00:00'

from subprocess import call
from subprocess import Popen

#name = xbmc.translatePath(os.path.join('special://home', 'addons', ADDONID, 'ffmpeg_skin.cmd'))
name = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages', 'ffmpeg_skin.cmd'))
with open(name, 'w+') as f:
    f.write('@echo on\n')
    f.write('set dest='+dest+'\n')
    f.write('set file='+file+'\n')
    f.write('set chan='+url+'\n')
    f.write('set duration='+duration+'\n')
    f.write('if not exist %dest% md %dest%\n')
    f.write('rem "C:\\windows\\system32\\ffmpeg.exe" -y -v 1 -i "'+url+'" -vcodec copy -acodec copy -f mpegts -t '+duration+' "'+dest+file+'"\n')
    f.write('"C:\\windows\\system32\\ffmpeg.exe" -y -v 1 -i "%chan%" -vcodec copy -acodec copy -f mpegts -t %duration% "%dest%%file%"\n')
    f.write('exit')

namerun = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages', 'run_ffmpeg_skin.cmd'))
with open(namerun, 'w+') as f:
    f.write('@echo off\n')
    f.write('start /min '+name+'\n')
    f.write('exit\n')

cmd = [namerun, url]
#cmd = [name, url]
#p = Popen(cmd,shell=True) # has NO cmd window info prompt
p = Popen(cmd,shell=False) # has cmd window info prompt
#xbmc.executebuiltin('RunScript('+xbmc.translatePath(os.path.join(basePath,'ffmpeg.py'))+')')
xbmc.executebuiltin('SetProperty(recording,true,home)')
