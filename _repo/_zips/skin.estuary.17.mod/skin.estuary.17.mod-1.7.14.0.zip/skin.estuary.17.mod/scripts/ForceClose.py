import xbmc,xbmcgui,os
mode = 'killkodi'
###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED
###############################################################
def killkodi():
    myplatform = platform()
    print 'Platform: ' + str(myplatform)
    if myplatform == 'windows': # Windows
        try: os._exit(1)
        except: pass    
        try:
            os.system('@ECHO off')
            os.system('tskill quasar.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im quasar.exe /f')
        except: pass        
        try:
            os.system('@ECHO off')
            os.system('tskill pulsar.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im pulsar.exe /f')
        except: pass        
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass        
        try:
            os.system('@ECHO off')
            os.system('tskill SMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im SMC.exe /f')
        except: pass       
        try:
            os.system('@ECHO off')
            os.system('tskill TVMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im TVMC.exe /f')
        except: pass        
        try:
            os.system('@ECHO off')
            os.system('tskill FreeTelly.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im FreeTelly.exe /f')
        except: pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]', 'If you\'re seeing this message it means the force close', 'was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.','Use task manager and NOT ALT F4')
    
    elif myplatform == 'android': # Android  
        try: os._exit(1)
        except: pass    
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass     
        try: os.system('adb shell am force-stop com.semperpax.spmc16')
        except: pass
        try: os.system('adb shell am force-stop com.spmc16')
        except: pass            
        try: os.system('adb shell am force-stop com.semperpax.spmc')
        except: pass
        try: os.system('adb shell am force-stop com.spmc')
        except: pass    
        try: os.system('adb shell am force-stop uk.droidbox.dbmc')
        except: pass
        try: os.system('adb shell am force-stop uk.dbmc')
        except: pass   
        try: os.system('adb shell am force-stop com.perfectzoneproductions.jesusboxmedia')
        except: pass
        try: os.system('adb shell am force-stop com.jesusboxmedia')
        except: pass 
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]', 'Your system has been detected as Android, you ', '[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.','Pulling the power cable is the simplest method to force close.')

    elif myplatform == 'osx': # OSX
        try: os._exit(1)
        except: pass    
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]', 'If you\'re seeing this message it means the force close', 'was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.','')
    elif myplatform == 'linux': #Linux
        try: os._exit(1)
        except: pass    
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]', 'If you\'re seeing this message it means the force close', 'was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.','')
    else: #ATV
        try: os._exit(1)
        except: pass    
        try: os.system('killall AppleTV')
        except: pass
        print 'try raspbmc force close' #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]', 'If you\'re seeing this message it means the force close', 'was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.','Your platform could not be detected so just pull the power cable.')      
#

##########################
###DETERMINE PLATFORM#####
##########################    
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
#
if mode == 'killkodi': killkodi()