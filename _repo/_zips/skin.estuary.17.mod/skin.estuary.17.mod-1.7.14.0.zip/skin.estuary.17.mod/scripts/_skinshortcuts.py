import xbmc,xbmcgui,os
mode = 1
###############################################################
###copy skin shortcut defaults
###############################################################
def copy_shortcuts():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'






if mode == 1: copy_shortcuts()
