# -*- coding: utf-8 -*-

# Copyright (C) 2005  Michael Urman
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of version 2 of the GNU General Public License as
# published by the Free Software Foundation.


"""Mutagen aims to be an all purpose multimedia tagging library.

::

    import mutagen_culrc.[format]
    metadata = mutagen_culrc.[format].Open(filename)

`metadata` acts like a dictionary of tags in the file. Tags are generally a
list of string-like values, but may have additional methods available
depending on tag or format. They may also be entirely different objects
for certain keys, again depending on format.
"""

from mutagen_culrc._util import MutagenError
from mutagen_culrc._file import FileType, StreamInfo, File
from mutagen_culrc._tags import Metadata, PaddingInfo

version = (1, 31)
"""Version tuple."""

version_string = ".".join(map(str, version))
"""Version string."""

MutagenError

FileType

StreamInfo

File

Metadata

PaddingInfo
